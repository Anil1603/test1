# Impact Analysis: BFOFS-10788 — Enable bFS Australia for the BU - DB

**Date:** 2026-09-14
**Story:** BFOFS-10788 (Story, Minor - Low priority)
**Analyst:** Planner Agent

---

## 1. User Story Context

**Story:** BFOFS-10788 — Enable bFS Australia for the BU - DB (Digital Buildings)
**Status:** Ready for UAT
**Fix Version:** R10.0 — AU Go-live explicitly pushed from an earlier target to October, per David Guerra Martin (2026-07-08), even though UAT validation had already passed.

This story enables **Australia (AU)** as a supported country for the **DB (Digital Buildings)** Business Unit across the bFS (Field Service) data model. Enablement is validated by confirming that 8 objects correctly resolve their **Country of Back Office** and **BO System** fields when Country = Australia and Business Unit = DB.

Per Deepika S R's UAT verification (2026-03-27, reconfirmed 2026-04-16 with an attached verification document), the confirmed target values for all 8 objects are:
- Country of Back Office = **AU**
- BO System = **BBO_AP**

Only one object (Impacted IP) was noted as partially present ("AU present") in the *original* story description before the full cross-object verification was completed — indicating this enablement was rolled out object-by-object and IIP was the first to support AU.

---

## 2. Related Features

### Directly Related Objects (all 8 in scope)
1. WO — Work Order
2. WOG — Work Order Group
3. PO — Parts Order
4. SCContract — Service Contract
5. IIP — Impacted IP
6. Plant
7. Digital Entitlement
8. ISR Org

### Adjacent Country/BU Enablement Pattern
This story follows a common bFS pattern of enabling a new Country for an existing Business Unit — the same validation shape (Country × BU → Country of Back Office × BO System) likely recurs for other country/BU enablement stories in this program (e.g., prior AU enablements for other BUs, or other countries for DB). No other such stories were found directly referenced elsewhere in this workspace's `user-stories/` folder at analysis time, suggesting this is either the first formally tracked instance or others are tracked outside this workspace snapshot.

---

## 3. Affected Components

### Salesforce Metadata (inferred; not confirmed against schema)
| Component | Type | Impact |
|-----------|------|--------|
| Country field (assumed `Country__c`) | Field, present on all 8 objects | Input/trigger for the back office resolution logic |
| Business Unit / SBU field (assumed `SBU__c` or `BusinessUnit__c`) | Field, present on all 8 objects | Input/trigger for the back office resolution logic |
| Country of Back Office field (assumed `CountryOfBackOffice__c`) | Field, present on all 8 objects | Derived output — must equal AU for AU+DB combination |
| BO System field (assumed `BOSystem__c`) | Field, present on all 8 objects | Derived output — must equal BBO_AP for AU+DB combination |
| Back-office mapping configuration (Custom Metadata Type / Custom Setting / lookup table, exact mechanism unconfirmed) | Configuration | Central store of Country × BU → Country of Back Office × BO System mappings; this is what was updated to add the AU+DB row |

### Test Automation
- This is a **data/configuration validation** story rather than a UI transaction flow — automated tests should focus on record creation (or existing record inspection) per object type and field-level assertions, not multi-step business processes
- No dedicated Page Objects likely exist yet for object-level field inspection across 8 different object types; Explorer/Generator should assess whether a shared "object field validator" pattern is more efficient than 8 separate Page Objects

---

## 4. Existing Test Patterns

- **No linked test cases** exist for this story ("Test Coverage: No linked test cases")
- No comparable "Country/BU enablement" test automation pattern was found elsewhere in this workspace's `test-cases/` folder at analysis time — this is new test coverage
- Given the story is fundamentally the same validation repeated across 8 objects, the underlying automation is a strong candidate for a **data-driven single test** (looping over the 8 objects) rather than 8 fully independent specs — flagged as a recommendation for the Generator Agent

---

## 5. Dependencies & Integration Points

### Hard Dependencies
| Dependency | Notes |
|------------|-------|
| Confirmed field API names for Country, Business Unit/SBU, Country of Back Office, and BO System on all 8 objects | All assumed in this plan; must be confirmed during Explorer/DOM analysis — likely to vary per object (e.g., standard `WorkOrder` vs. custom objects) |
| Back-office mapping configuration mechanism | Whether AU+DB mapping is stored via Custom Metadata, Custom Setting, or a formula/Apex resolution affects whether tests can seed data via API vs. must exercise UI record creation |
| R10.0 fix version / Go-live timing | AU Go-live is pushed to October; automated regression coverage should be validated against the fix version before broader production rollout dependent on this change |

### Downstream / Integration Points
- BBO_AP (Back Office system) integration — this story confirms the **mapping** resolves correctly in Salesforce; it does not (per the story text) validate the downstream BBO_AP integration payload itself, which would be a separate integration test concern outside this story's scope

---

## 6. Recommendations

- **Prioritize TC-001 (Work Order) and TC-009 (regression guardrail) first**: WO is the most central object in the bFS data model and the regression guardrail protects against unintended mapping leakage across other Country/BU combinations
- **Confirm field API names per object individually**: unlike prior stories in this program, this story spans 8 different objects (mix of standard and likely custom), so field name assumptions should be validated per-object rather than as a single shared assumption
- **Consider a data-driven test design** for TC-001 through TC-008 in the Generator phase, given they share an identical assertion pattern varying only by object type
- **Clarify the back-office mapping configuration mechanism** with the dev team before Explorer/Generator phases — this determines whether tests can seed test data via API (faster, less flaky) or must create records through the UI (required if mapping logic triggers only on UI-driven save with dependent picklists, etc.)

## RAG Sources
- No RAG server context was available at plan generation time; this analysis is based on the user story content, comment history (Suresh Varma Mudunuru, Sanjali Gupta, Deepika S R, David Guerra Martin), and the attached UAT verification document referenced in [BFOFS-10788_Enable_bFS_Australia_for_the_BU_-_DB.md](../user-stories/BFOFS-10788_Enable_bFS_Australia_for_the_BU_-_DB.md).
