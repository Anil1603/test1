# Impact Analysis: BFOFS-12406 — Process Automation: Add new WO subtypes

**Date:** 2026-09-14
**Story:** BFOFS-12406
**Analyst:** Planner Agent

---

## 1. User Story Context

**Story:** BFOFS-12406 — Process Automation: Add new WO subtypes
**Status:** Ready for UAT
**Priority:** Major - High

### Business Need
As a Planner, new Work Order subtypes are needed to properly classify jobs so FSRs can easily understand the type of work required. This originated from a J2R Germany Process Automation request and evolved through multiple release cycles (R5.0 → R6.0 → R7.0+) due to extensive cross-system dependencies (Oracle, Onsite, multiple SAP instances, OnePI mapping).

### Acceptance Criteria (as amended through UAT)
1. ~~Inactivate "Standby"~~ and create "On Site Assistance" under "Managed Service/Operations" — **amended**: keep "Standby" active in addition to "On Site Assistance", per Mike McGowan's UAT feedback (2026-07-03) since Oracle-originated WOs still map to "Standby"
   1.1 Existing WOs with subtype "Standby" must remain completable
2. Add new subtype "Meeting" to Type "Consulting" (existing Type "Meeting" must remain unaffected)
3. Add existing subtype "Report Delivery" as a valid dependency under Type "Consulting"
4. Add new subtype "Parts Management" under Type "Managed Service/Operations"
5. Propagate new subtypes to PM Plan Template, PM Plan, SLA Detail, Service Time
6. Allow new subtypes on the Service Board

### Multi-System Complexity
This is one of the more cross-system-dependent stories reviewed: it required coordinated configuration changes in ECC (SAP `YYWOTYPE`/`YYWOSUBTYPE` tables), Oracle (Category Set / DFF), OnePI (value mapping across all ERPs), and Onsite — with the bFS change repeatedly deployed to UAT and then reverted before PROD across R5.0 and R6.0 until all dependent systems were aligned for R7.0+.

---

## 2. Related Features

### Directly Related Story
- **BFOFS-12823** — "Service board: Add new WO subtypes" (**Pushed to Production**) — implements AC6 (Service Board support) as a separate, already-delivered story. TC-010 in this plan verifies end-to-end consistency rather than re-testing BFOFS-12823's own scope.

### Related Cross-System Story
- **ORCLFS-943** — "New WO subtypes" (Oracle-side, UAT Passed) — Oracle configuration counterpart to this story; not testable within the bFS Salesforce UI but relevant for understanding the "WO creation from BFS to ORACLE for new subtypes" test performed by the story owner (2026-06-12)

### Comparable Data-Model Pattern
- **BFOFS-12231** — Mean Time To Service (MTTS) calculation — references "WO Type + WO SubType + DeviceType" as a lookup key into `Service_Time__c`, confirming Service Time is a real, already-instrumented consumer of the Type/Subtype combination (relevant to AC5.4/TC-008)

---

## 3. Affected Components

### Salesforce Metadata
| Component | Type | Impact |
|-----------|------|--------|
| Work Order Type/Subtype picklist fields | Picklist + Field Dependency on `SVMXC__Service_Order__c` (Work Order) | Add "On Site Assistance", "Parts Management" under "Managed Service/Operations"; add "Meeting", "Report Delivery" dependency under "Consulting"; retain "Standby" (do not inactivate) |
| PM Plan Template | Object with Type/Subtype fields | Field dependency must mirror the Work Order mapping |
| PM Plan | Object with Type/Subtype fields | Same as above; was the subject of a defect (Standby visibility) found and fixed during UAT (2026-07-02/03) |
| SLA Detail | Object with Type/Subtype fields | Same mapping required |
| Service Time | Object with Type/Subtype fields | Same mapping required; also consumed by MTTS lookup logic (BFOFS-12231) |
| Service Board | LWC/component | Covered by BFOFS-12823 (separate story) |

### External / Cross-System (informational, not directly testable in this workspace)
| System | Impact |
|--------|--------|
| SAP ECC (multiple instances: UK, AM/USA, AP/Australia, EU/France, Iberia, Italy) | `YYWOTYPE`/`YYWOSUBTYPE` configuration tables updated |
| Oracle | Category Set / DFF values added (ORCLFS-943) |
| OnePI | Global value-mapping table updated for all ERP entities (REQ3672327) |
| Onsite | Separate story tracked (ONSE-25218), impacts activity type derived from WO Type/Subtype |

---

## 4. Existing Test Patterns

- No linked test cases exist for this story ("No linked test cases" per story metadata)
- The story's own comment history contains extensive **manual** UAT evidence (WO numbers, Type/Subtype pairs tested per SAP instance: QRO, QRH, QRA, UQA, QBS) — useful as real-world reference data for `Test_Data.json` scenarios, though these are ERP-integration tests outside the scope of bFS UI automation
- BFOFS-12231's Service Time lookup logic (Category + WO Type + WO SubType + DeviceType) confirms a reusable pattern for validating Type/Subtype propagation into downstream calculation logic

---

## 5. Dependencies & Integration Points

### Hard Dependencies (blocking automation)
| Dependency | Notes |
|------------|-------|
| Confirmed final Type/Subtype dependency configuration in the target test org | Story has a long history of deploy-to-UAT-then-revert cycles across R5.0/R6.0; must confirm current UAT org (UAT25/UAT26) actually has the final R7.0+ configuration active, including "Standby" retained, before executing TC-002/TC-009 |
| PM Plan/PM Plan Template Subtype dependency fix (2026-07-02/03) verified as deployed | Required for TC-007/TC-009 to pass |

### Downstream / Cross-Story
- **BFOFS-12823** (Service Board) — must be deployed together with/before this story's Work Order changes for TC-010 to be meaningful
- **Oracle/SAP/OnePI configuration** — out of scope for bFS UI automation but a source of flakiness if ERP-side mapping is not aligned in the shared UAT environment (e.g., risk of WOs created from Oracle still resolving to "Standby" unexpectedly, per Mike McGowan's comment)

---

## 6. Recommendations

- **Confirm current deployment state before automating**: Given the repeated deploy/revert history (R5.0 → reverted, R6.0 → reverted, targeting R7.0+), verify with the story owner (Ivan Gutierrez) that the UAT org used for automation currently has the final, intended configuration (Standby retained + 3 new subtypes) before running TC-001/TC-002/TC-009
- **Regression priority**: TC-009 (PM Plan/Template subtype dependency) should be prioritized given the concrete defect history in this exact area
- **Scope boundary for TC-010**: Treat Service Board verification as a light consistency check only; deep Service Board test coverage belongs to BFOFS-12823's own test suite
- **Field API names unconfirmed**: Type/Subtype field API names on Work Order, PM Plan Template, PM Plan, SLA Detail, and Service Time are inferred from story context; Explorer Agent should confirm exact API names and picklist dependency configuration during DOM analysis

## RAG Sources
- No RAG server context was available at plan generation time; this analysis is based on the user story content and comment history in [BFOFS-12406_Process_Automation_Add_new_WO_subtypes.md](../user-stories/BFOFS-12406_Process_Automation_Add_new_WO_subtypes.md), plus workspace grep searches for related WO Subtype/Service Board/MTTS patterns across `user-stories/`.
