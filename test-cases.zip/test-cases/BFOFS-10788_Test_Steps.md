# Test Steps: BFOFS-10788 — Enable bFS Australia for the BU - DB

**Story:** BFOFS-10788
**Base URL:** https://se--uat25.sandbox.lightning.force.com *(inferred — confirm before execution)*
**Date Generated:** 2026-09-14

---

## TC-001: Work Order (WO) — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Work Order records
- Australia and DB (Digital Buildings) Business Unit are configured as selectable values

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Work Order with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-002: Work Order Group (WOG) — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Work Order Group records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Work Order Group with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-003: Parts Order (PO) — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Parts Order records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Parts Order with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-004: Service Contract (SCContract) — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Service Contract records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Service Contract with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-005: Impacted IP (IIP) — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Impacted IP records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open an Impacted IP record with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-006: Plant — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Plant records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Plant record with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-007: Digital Entitlement — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view Digital Entitlement records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Digital Entitlement record with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-008: ISR Org — AU + DB Back Office Mapping

**Preconditions:**
- User has permissions to create/view ISR Org records

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open an ISR Org record with Country set to Australia and Business Unit set to DB
3. Save the record (if newly created)
4. Open the Country of Back Office field on the record
5. Open the BO System field on the record

**Expected Result:** Country of Back Office = AU; BO System = BBO_AP

---

## TC-009: Non-AU or Non-DB Combination Remains Unaffected (Regression Guardrail)

**Preconditions:**
- A previously-enabled Country/Business Unit combination is known and available for comparison

1. Navigate to https://se--uat25.sandbox.lightning.force.com
2. Create or open a Work Order with Country set to Australia and Business Unit set to a non-DB value
3. Open the Country of Back Office and BO System fields and record their values
4. Create or open a second Work Order with Country set to a non-Australia country and Business Unit set to DB
5. Open the Country of Back Office and BO System fields on the second record and record their values
6. Compare both results against the previously-known/expected mapping for that Country/Business Unit combination

**Expected Result:** Neither record incorrectly resolves to Country of Back Office = AU / BO System = BBO_AP unless that was already the valid mapping; no regression in existing mappings
