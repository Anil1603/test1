# Test Cases: BFOFS-10788 — Enable bFS Australia for the BU - DB

**Story:** BFOFS-10788
**Title:** Enable bFS Australia for the BU - DB (Digital Buildings)
**Status:** Ready for UAT
**Priority:** Minor - Low
**Fix Version:** R10.0 (AU Go-live pushed to October per David Guerra Martin, 2026-07-08)
**Base URL:** https://se--uat25.sandbox.lightning.force.com *(inferred bFS UAT sandbox convention — confirm before execution)*

## Summary

This story enables Australia (AU) as a valid Country/Country-of-Back-Office combination for the **DB (Digital Buildings)** Business Unit across 8 bFS objects. Per Deepika S R's confirmation (2026-03-27, reconfirmed 2026-04-16 in UAT), each object must resolve to:
- **Country of back office = AU**
- **BO system = BBO_AP**

when the record's Country is Australia and the Business Unit is DB. The 8 affected objects are:
1. WO — Work Order
2. WOG — Work Order Group
3. PO — Parts Order
4. SCContract — Service Contract
5. IIP — Impacted IP
6. Plant
7. Digital Entitlement
8. ISR Org — Intragroup/Intergroup Service Request Organization

This is primarily a **data/configuration validation** story (mapping rules), not a transactional UI workflow — test cases focus on creating/inspecting a record of each object type with Country=AU and BU=DB, and asserting the derived Country of Back Office and BO System values.

---

### TC-001: Work Order (WO) — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning (valid AU+DB partition)
- **Description:** Verify a Work Order created/associated with Country=Australia and Business Unit=DB correctly resolves Country of Back Office and BO System.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Work Order with Country = Australia and SBU/Business Unit = DB (Digital Buildings)
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP
- **Notes:** Field API names assumed; confirm during Explorer phase.

---

### TC-002: Work Order Group (WOG) — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify a Work Order Group with Country=Australia and Business Unit=DB correctly resolves the back office mapping.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Work Order Group with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP
- **Notes:** WOG may be derived from its parent WO; confirm relationship during Explorer.

---

### TC-003: Parts Order (PO) — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify a Parts Order with Country=Australia and Business Unit=DB correctly resolves the back office mapping.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Parts Order with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP

---

### TC-004: Service Contract (SCContract) — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify a Service Contract with Country=Australia and Business Unit=DB correctly resolves the back office mapping.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Service Contract with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP

---

### TC-005: Impacted IP (IIP) — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify an Impacted IP record with Country=Australia and Business Unit=DB correctly resolves the back office mapping (this was the object originally already showing "AU present" prior to full enablement, per the original story description).
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open an Impacted IP record with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP

---

### TC-006: Plant — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify a Plant record with Country=Australia and Business Unit=DB correctly resolves the back office mapping.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Plant record with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP

---

### TC-007: Digital Entitlement — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify a Digital Entitlement record with Country=Australia and Business Unit=DB correctly resolves the back office mapping.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Digital Entitlement record with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP

---

### TC-008: ISR Org — AU + DB Resolves to Correct Back Office Mapping — EP

- **Priority:** Medium
- **Type:** Positive
- **Technique:** Equivalence Partitioning
- **Description:** Verify an ISR Org (Intragroup/Intergroup Service Request Organization) record with Country=Australia and Business Unit=DB correctly resolves the back office mapping.
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open an ISR Org record with Country = Australia and SBU = DB
  3. Save/refresh the record
  4. Inspect the Country of Back Office and BO System fields
- **Assertions:**
  - Country of Back Office = AU
  - BO System = BBO_AP

---

### TC-009: Non-AU or Non-DB Combination Remains Unaffected — Decision Table / Error Guessing (Regression Guardrail)

- **Priority:** Medium
- **Type:** Negative
- **Technique:** Decision Table (Country × Business Unit combinations), Error Guessing
- **Description:** Verify that the new AU+DB back office mapping does not leak into other Country/Business Unit combinations — e.g., AU + a non-DB business unit, or DB + a non-AU country — on at least one representative object (Work Order).
- **Flow Steps:**
  1. Navigate to https://se--uat25.sandbox.lightning.force.com
  2. Create or open a Work Order with Country = Australia and SBU = a non-DB Business Unit (e.g., an existing already-enabled BU)
  3. Inspect the Country of Back Office and BO System fields
  4. Create or open a second Work Order with Country = a non-Australia country and SBU = DB
  5. Inspect the Country of Back Office and BO System fields for the second record
- **Assertions:**
  - Neither combination unexpectedly resolves to the AU+DB mapping (Country of Back Office = AU, BO System = BBO_AP) unless that combination was already valid prior to this change
  - Existing back office mappings for other Country/BU combinations remain unchanged (no regression)
- **Notes:** Use a previously-enabled Country/BU combination as the regression baseline; exact "already enabled" combination to be confirmed during Explorer/DOM analysis or via a config export.

---

## Traceability

| Test Case | Object Covered |
|-----------|-----------------|
| TC-001 | WO — Work Order |
| TC-002 | WOG — Work Order Group |
| TC-003 | PO — Parts Order |
| TC-004 | SCContract — Service Contract |
| TC-005 | IIP — Impacted IP |
| TC-006 | Plant |
| TC-007 | Digital Entitlement |
| TC-008 | ISR Org |
| TC-009 | Regression guardrail (all objects, represented via WO) |

**Source Story:** [BFOFS-10788_Enable_bFS_Australia_for_the_BU_-_DB.md](../user-stories/BFOFS-10788_Enable_bFS_Australia_for_the_BU_-_DB.md)
**Related Fix Version Note:** AU Go-live pushed to R10.0 (October), per David Guerra Martin (2026-07-08).
