# User Story Review: BFOFS-11394 – Automatically send the Account Maintenance Plan report to one or multiple predefined contacts

**Reviewed:** 2026-03-19  
**Reviewer:** User Story Review Agent  
**Story File:** `user-stories/BFOFS-11394_Automatically_send_the_Account_Maintenance_Plan_report_to_one_or_multiple_predef.md`  
**Status:** In Progress | **Priority:** Major - High | **Labels:** FS, Contract  
**Assignee:** Neha Singh | **Reporter:** Ivan Gutierrez  

---

## Quick Health Check

| Check | Status | Notes |
|---|---|---|
| Story Title | ✅ Pass | Clearly states the goal and the actor (contract manager) |
| User Story Format | ✅ Pass | Implicit "As a contract manager … I want … So that …" is present in narrative |
| Description | ⚠️ Partial | Detailed narrative and ACs present; mockup is an image attachment (not text-described), so its content is unavailable for review and cannot be validated |
| Acceptance Criteria | ⚠️ Partial | 5 high-level ACs with sub-items; happy path is covered; no negative-path ACs, no error message text, no SLA/performance requirements |
| Definition of Ready | ❌ Fail | Metadata object API name unknown; Lightning mail template format not defined; Activity recording type not specified; story is too large for a single sprint |
| Comments / Context | ⚠️ Partial | Single comment (Ivan Gutierrez, 2026-01-21) requests effort estimate; no formal responses or clarifications on record |

> **⚠️ Key Risk — Inaccessible Mockup:** The story references `!screenshot-1.png|thumbnail!` which is a Confluence/Jira inline attachment. The actual UI layout, field arrangement, and button labels are not described in text, making the story partially un-reviewable and testers unable to validate UI without accessing the attachment separately.

---

## INVEST Evaluation

| Principle | Score (0–2) | Notes |
|---|---|---|
| **I**ndependent | 1 | The "Account Maintenance Plan" trigger path can be built independently. However, the "Service Certificate with Site Visit Displayed" combined-report path depends on BFOFS-11380. Concurrent development risk exists. |
| **N**egotiable | 1 | Core value (send report by email to selected contacts) is well-defined. Implementation details are heavily pre-specified (checkbox UI, 4-tier fallback chain, specific contact types), leaving limited room to negotiate the approach. |
| **V**aluable | 2 | Clear persona (contract manager) and well-articulated business value: eliminates manual "generate, export, email" cycle. High priority aligns with value. |
| **E**stimable | 1 | Enough detail to begin estimation, but several technical dimensions are undefined: Custom Metadata Type API name, email merge field catalog, Activity recording object/type, and whether integration with an existing email service or a net-new component is expected. |
| **S**mall | 0 | The story is too large for a single sprint. It spans: (1) a new metadata model, (2) UI changes to the report generation page, (3) contact selection logic, (4) a 4-level template-resolution algorithm, (5) email construction and delivery, and (6) Activity feed recording. This is 3–4 separate deliverables. |
| **T**estable | 1 | Happy-path behavior is described. Negative paths, error message text, field-level context (page name, object type), and expected Activity entry format are absent. The mockup is inaccessible. |
| **Total** | **6/10** | ❌ Does not meet minimum threshold of 8/10 |

---

## Testability Assessment

| Area | Score (0–2) | Notes |
|---|---|---|
| **UI** | 1 | The interaction flow (checkbox → contact selection → generate) is described. The contact types and VCP list columns are specified. However: screen/page name is not stated, button labels are inferred ("Generate," "Send via email"), field labels are not confirmed, and error message text is absent for all 3 error paths. |
| **API / Config** | 1 | The concept of a Lightning mail template metadata record is described (AC 1.1), but: the Custom Metadata Type (CMT) API name is not given, the merge field set is not defined, the email delivery mechanism (e.g., Apex `Messaging.sendEmail`, Salesforce Flow, Platform Event) is not specified, and the Activity entry type (EmailMessage object vs. Task) is not stated. |
| **Data** | 1 | Four standard contact roles (Sold-to, Main Installed-at, Bill-to, Remote Services) and Service Contract VCPs are listed. However: test data matrix (language × BU × country combinations for template matching) is absent; edge cases for contacts with no email are described in AC 4.2.3 but no test data set is provided; "duplicate email" deduplication logic is mentioned but not concretely defined (case-sensitive? domain-normalised?). |
| **Performance** | 0 | No performance requirements stated. Given email generation is triggered synchronously from a UI action, latency expectations should be defined (especially for large VCP lists or heavy report files). |
| **Total** | **3/8** | ❌ Does not meet minimum threshold of 7/8 |

---

## Root Cause of Quality Failures

### 1. Story is too large (primary blocker)
The story bundles at minimum three distinct delivery units: metadata configuration, UI changes, and backend email-sending logic. Splitting is required before sprint planning.

### 2. Mockup is inaccessible in plain text
AC 2 and AC 3 both rely on the UI layout described in the mockup image. Without a text description of field positions, labels, and interaction states, testers cannot write executable test cases.

### 3. Custom Metadata Type is unnamed
AC 1.1 refers to "a metadata" — this should specify the CMT developer name (e.g., `AMP_Email_Template__mdt`), the field names for Language, Country, BU, and Template, and the cardinality (one record per combination?).

### 4. Error messages not defined
Three distinct error paths are described (AC 4.2.1 — no recipient selected; AC 4.2.3 — no valid email addresses; implicit failure paths during report generation). None includes the exact message text, message location (toast? inline?), or user recovery steps.

### 5. Activity recording format unspecified
AC 4.2.7 says the email is "displayed in the Activity tab" but does not specify: EmailMessage record vs. Task, subject line format, relationship to the Service Contract record, or whether outbound emails are logged automatically or require explicit creation.

---

## Improved Acceptance Criteria

The original ACs are preserved. Proposed additions are marked **[Proposed]**.

| AC# | Status | Criterion |
|---|---|---|
| AC-1.1 | Original | A Custom Metadata Type record defines Language (optional), Country (optional), BU (optional) → Lightning Mail Template |
| AC-1.2 | Original | A fallback Lightning Mail Template (English) is defined when no match is found |
| AC-2 | Original | Report generation page offers a "Send via email" option (checkbox or equivalent) |
| AC-3.1–3.5 | Original | If "Send via email" is selected: contact selector shows Sold-to, Main Installed-at, Bill-to, Remote Services contacts, and an optionally-populated Service Contract VCP list |
| AC-4.1 | Original | If "Send via email" is not selected, report is generated as per current behavior (no email sent) |
| AC-4.2.1 | Original | If "Send via email" is selected: validate at least one recipient is selected; show error if none |
| AC-4.2.2–4.2.3 | Original | Generate report file; resolve email addresses; deduplicate/remove blanks; if no valid email remains, show error |
| AC-4.2.4–4.2.6 | Original | Attach file to record (if selected); resolve template via 4-tier fallback; build and send email |
| AC-4.2.7 | Original | Sent email appears in Activity tab of the Service Contract record |
| AC-5 | **[Proposed]** | The Custom Metadata Type developer name is `<TBD by dev team>`. Minimum fields: `Language__c`, `Country__c`, `Business_Unit__c`, `Lightning_Template__c`, `Is_Fallback__c`. Document this in the technical design. |
| AC-6 | **[Proposed]** | When "Send via email" is not selected, or when a report template other than "Account Maintenance Plan" or "Service Certificate with Site Visit Displayed" is selected, the contact selector section is hidden from the UI. |
| AC-7 | **[Proposed]** | Error message text for "no recipient selected" (AC 4.2.1): `"Please select at least one recipient before generating the report."` — displayed as an inline validation message. |
| AC-8 | **[Proposed]** | Error message text for "no valid email address after deduplication" (AC 4.2.3): `"None of the selected contacts have a valid email address. Please update contact records or select different contacts."` |
| AC-9 | **[Proposed]** | The Activity entry created in AC 4.2.7 is an EmailMessage record linked to the Service Contract. Subject line format: `"Account Maintenance Plan – [Contract Number] – [Date]"`. |
| AC-10 | **[Proposed]** | Template fallback resolution is logged (e.g., debug log or a field on the email message) so support can diagnose why a specific template was used. |
| AC-11 | **[Proposed]** | The contact selector section is not shown for report templates other than "Account Maintenance Plan" and "Service Certificate with Site Visit Displayed". |

---

## Risks & Gaps

| Risk | Impact | Probability | Mitigation |
|---|---|---|---|
| Dependency on BFOFS-11380 for the combined report path — if BFOFS-11380 is not complete, AC-2 is only partially implementable | High | Medium | Confirm BFOFS-11380 status before sprint start; scope this story to single-report path if BFOFS-11380 is not yet deployed |
| Custom Metadata Type design is undefined — dev team may make incompatible choices across stories | High | High | Define CMT API name, fields, and record structure in a Technical Design doc before development starts |
| Lightning Mail Template merge fields not catalogued — template author cannot build the email template until the field list is agreed | High | High | PO + dev to publish a merge field reference (e.g., Contract Number, Account Name, Contact Name, Report Date) before AC-1.1 is implemented |
| Email delivery method unknown — Apex, Flow, Platform Email, or third-party? — each has different limits and testability profiles | High | Medium | Include the sending mechanism in the Technical Design; agree on approach before sprint start |
| VCP list may be empty for most contracts — test coverage of AC-3.5 will require specific test data setup | Medium | Medium | Create a sandbox test dataset with Service Contracts that have at least one VCP record |
| No performance requirements for email send with large report attachments or many recipients | Medium | Low | Define max recipient count and file size limits; consider async processing for large payloads |
| Mockup image not accessible in plain text review — UI implementation may diverge from intent | Medium | High | PO to add a text description of the mockup to the story or share the image with the QA team |
| Duplicate email deduplication is case-sensitive status unclear — could cause duplicate sends for `User@Example.com` vs. `user@example.com` | Low | Medium | Specify case-insensitive deduplication in AC-4.2.3 |

---

## Split Recommendations

This story should be split into **three** sub-stories before sprint planning:

| Sub-Story | Scope | Dependencies |
|---|---|---|
| **BFOFS-11394-A** | Define and deploy the Custom Metadata Type for Lightning Mail Templates (AC 1.1, 1.2). Includes CMT field design, fallback template creation, and deployment to sandbox. | None |
| **BFOFS-11394-B** | UI changes to the report generation page: add "Send via email" checkbox, contact selector section, VCP list display, and generate-without-email path (AC 2, 3, 4.1). | BFOFS-11394-A (CMT must exist to identify report types for contextual display) |
| **BFOFS-11394-C** | Backend email logic: validate recipients, resolve template via 4-tier fallback, generate file, build/send email, log Activity entry (AC 4.2.1–4.2.7). | BFOFS-11394-A, BFOFS-11394-B, BFOFS-11380 (for combined report template path) |

---

## Open Questions (Must Resolve Before Development)

| # | Question | Owner | Priority |
|---|---|---|---|
| Q1 | What is the developer name of the Custom Metadata Type to be created for email template mapping? | Dev Lead / Neha Singh | 🔴 Blocker |
| Q2 | What merge fields will be available in the Lightning Mail Template? Please publish a full field catalog. | Ivan Gutierrez (PO) + Dev Lead | 🔴 Blocker |
| Q3 | Is BFOFS-11380 deployed or in the same sprint? Does this story depend on it to be considered "done"? | Ivan Gutierrez (PO) | 🔴 Blocker |
| Q4 | What is the email delivery mechanism to be used? (Apex `Messaging.sendEmail`, Flow Email Action, Enhanced Email, Platform Event?) | Dev Lead | 🔴 Blocker |
| Q5 | Can the mockup image be described in text in the story, or shared with the QA team separately? | Ivan Gutierrez (PO) | 🔴 Blocker |
| Q6 | Should email deduplication be case-insensitive? (e.g., `User@Domain.com` and `user@domain.com` treated as the same address?) | Ivan Gutierrez (PO) | 🟡 High |
| Q7 | What is the exact text and display location (toast/inline/modal) for the two error messages in AC 4.2.1 and AC 4.2.3? | Ivan Gutierrez (PO) | 🟡 High |
| Q8 | What format should the Activity entry subject line take (AC 4.2.7)? Is it an EmailMessage or a Task? | Dev Lead | 🟡 High |
| Q9 | Is attachment of the report to the Service Contract record (AC 4.2.4 "if selected") a user toggle in the same UI, or is it driven by an existing setting? | Ivan Gutierrez (PO) | 🟡 High |
| Q10 | Are there any performance constraints (max file size, max recipients, synchronous vs. async email sending)? | Ivan Gutierrez (PO) + Dev Lead | 🟢 Medium |

---

## Readiness & Handoff

| Metric | Score | Threshold | Result |
|---|---|---|---|
| INVEST Score | 6/10 | 8/10 | ❌ FAIL |
| Testability Score | 3/8 | 7/8 | ❌ FAIL |

**Verdict: Story is NOT ready for planning.**  
The story must be split (see Split Recommendations) and the 5 blocker questions (Q1–Q5) must be resolved before any sub-story proceeds to the Planner Agent.

---

## Next Steps

1. **PO (Ivan Gutierrez):** Answer Q1–Q10, prioritising the 5 blockers.
2. **PO:** Add a text description of the mockup to the story (or share it with QA separately).
3. **Dev Lead + PO:** Define and agree on the Custom Metadata Type design and merge field catalog.
4. **PO:** Confirm BFOFS-11380 status and its impact on the combined report path.
5. **PO:** Create sub-stories BFOFS-11394-A, BFOFS-11394-B, BFOFS-11394-C once blockers are resolved.
6. **Story Review Agent:** Re-review each sub-story independently once created.
