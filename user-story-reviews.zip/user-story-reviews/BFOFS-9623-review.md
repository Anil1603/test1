# User Story Review: BFOFS-9623 – Update AP_ServiceContract Class to Use Primary Location Instead of Covered Location

**Reviewed:** 2026-02-23  
**Reviewer:** User Story Review Agent  
**Story File:** `user-stories/BFOFS-9623_Update_AP_ServiceContract_Class_to_Use_Primary_Location_Instead_of_Covered_Locat.md`  
**Status:** BACKLOG | **Priority:** Medium | **Labels:** #PMPlan, #Project, #SiteAccLinkage  
**Assignee:** Uma Sankar Chukka | **Reporter:** Oscar Frigerio  

---

## Quick Health Check

| Check | Status | Notes |
|---|---|---|
| Story Title | ⚠️ Partial | Describes a code artifact — missing user context and business value |
| User Story Format | ❌ Missing | No "As a… I want… So that…" statement |
| Description | ❌ Critical | Body is only `AP_ServiceContract - ApexClass - 01p12000003IoErAAK` — no functional description |
| Acceptance Criteria | ❌ Missing | None present |
| Definition of Ready | ❌ Missing | No scenarios, constraints, or success conditions |
| Comments / Context | ❌ Missing | No supplementary detail captured |

---

## INVEST Evaluation

| Principle | Score (0–2) | Notes |
|---|---|---|
| **I**ndependent | 1 | Possibly self-contained, but dependencies on PM Plan / Site Account Linkage are unknown |
| **N**egotiable | 0 | No scope details to negotiate — intent is inferred from title only |
| **V**aluable | 1 | Value implied (Primary Location likely improves data accuracy) but never stated |
| **E**stimable | 0 | Apex class ID + one-line title cannot be estimated; logic and impact are entirely unknown |
| **S**mall | 1 | May be a focused field swap, but hidden complexity (triggers, batch, data migration) is unknown |
| **T**estable | 0 | No acceptance criteria, expected outputs, or measurable outcomes |
| **Total** | **3/10** | ❌ Minimum threshold: 8/10 |

---

## Testability Assessment

| Area | Score (0–2) | Notes |
|---|---|---|
| **UI** | 0 | No UI interactions described; unclear if there is any user-facing change |
| **API / Apex** | 0 | Only a class reference given — no method signatures, events, or behavior defined |
| **Data** | 0 | No field API names, object relationships, or example records provided |
| **Performance** | 0 | No volume or timing requirements stated |
| **Total** | **0/8** | ❌ Minimum threshold: 7/8 |

---

## Root Cause of Failures

This story is a **placeholder ticket**. The description field contains only the Salesforce metadata identifier for the Apex class — it was logged to track a known code artifact but was never evolved into a workable story.

**6 Critical Gaps:**
1. No definition of "Primary Location" vs "Covered Location" in this domain
2. No trigger / entry point for `AP_ServiceContract` (trigger, batch, invocable, button?)
3. No impacted SObjects identified (ServiceContract, Asset, WorkOrder, etc.)
4. No behavioral expectations — what does the class do *differently* after the change?
5. No downstream impact analysis — does this affect PM Plan coverage, billing, or entitlements?
6. No data migration strategy — do existing records need backfilling?

---

## Improved Story Draft

### User Story (Suggested)
> As a **Service Operations user**,  
> I want the `AP_ServiceContract` Apex class to derive location context from the **Primary Location** of the associated Account  
> So that PM Plan coverage, entitlement calculations, and related records consistently reflect the correct site — rather than a potentially stale Covered Location.

### Suggested Acceptance Criteria

| AC# | Criterion |
|---|---|
| AC-1 | `AP_ServiceContract` reads the **Primary Location** field (confirm API name) instead of Covered Location (confirm API name) when processing a Service Contract |
| AC-2 | When Primary Location is null, the class applies a defined fallback — [confirm: error, skip, or use Covered Location] |
| AC-3 | Existing Service Contracts with a mismatch are handled consistently — [confirm if reprocessing is triggered] |
| AC-4 | All Apex test classes for `AP_ServiceContract` pass with ≥ 75% code coverage post-change |
| AC-5 | No regression in PM Plan coverage for records processed by this class |
| AC-6 | Bulk execution of [N] Service Contract records completes without governor limit violations |

---

## Risks & Gaps

| Risk | Impact | Probability | Recommendation |
|---|---|---|---|
| Unknown field API names (Primary vs Covered Location) | High | High | PO/Dev to confirm before estimation |
| Unknown downstream impact on PM Plan / billing / entitlements | High | Medium | Perform impact analysis before sprint |
| No existing test coverage baseline | Medium | High | Run code coverage report on `AP_ServiceContract` first |
| Data migration / backfill unaddressed | Medium | Medium | Explicitly define in acceptance criteria |
| Governor limit risk in bulk execution | Medium | Low | Add bulk scenario to acceptance criteria |

---

## Split Recommendations

| Sub-Story | Scope |
|---|---|
| BFOFS-9623-A | Update `AP_ServiceContract` logic to use Primary Location (code + unit tests) |
| BFOFS-9623-B | Data migration / backfill for existing Service Contracts — if required |
| BFOFS-9623-C | Regression validation of PM Plan coverage after the change |

---

## Open Questions (Must Resolve Before Planning)

| # | Question | Owner |
|---|---|---|
| Q1 | What is the API name of the Primary Location field on Account? | Uma Sankar Chukka |
| Q2 | What is the API name of the Covered Location field currently used in `AP_ServiceContract`? | Uma Sankar Chukka |
| Q3 | What triggers `AP_ServiceContract` — trigger, batch, invocable action, or button? | Uma Sankar Chukka |
| Q4 | What is the fallback behavior when Primary Location is null? | Oscar Frigerio |
| Q5 | Do existing Service Contracts need reprocessing / data backfill? | Oscar Frigerio |
| Q6 | Which Salesforce sandbox is the target for testing? | Uma Sankar Chukka |
| Q7 | Should Work Orders auto-update location on reprocessing, or remain static? | Oscar Frigerio |

---

## Readiness & Handoff

| Metric | Score | Threshold | Result |
|---|---|---|---|
| INVEST Score | 3/10 | 8/10 | ❌ FAIL |
| Testability Score | 0/8 | 7/8 | ❌ FAIL |

**Story Ready:** ❌ **NOT READY**  
**Next Action:** `request-clarification` — return to Oscar Frigerio (PO) and Uma Sankar Chukka (Dev) to address Q1–Q7 above.

---

*Generated by User Story Review Agent on 2026-02-23.*
