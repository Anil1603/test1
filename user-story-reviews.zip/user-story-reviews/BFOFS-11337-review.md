# User Story Review: BFOFS-11337 – UAE BFS-SAP TR - Digital Entitlement - Country of Back Office (BO) & BO System

**Reviewed:** 2026-02-27  
**Reviewer:** User Story Review Agent  
**Story File:** `user-stories/BFOFS-11337_UAE_BFS-SAP_TR_-_Digital_Entitlement_-_Country_of_Back_Office_BO_BO_System.md`  
**Status:** Ready for UAT | **Priority:** Minor - Low | **Labels:** MEA, bFS  
**Assignee:** Sanjali Gupta | **Reporter:** Sanjali Gupta  

---

## Quick Health Check

| Check | Status | Notes |
|---|---|---|
| Story Title | ✅ Pass | Clearly identifies screen, fields, and region |
| User Story Format | ✅ Pass | "As an order manager… I want… So that…" is present |
| Description | ⚠️ Partial | Core value mapping (Country + BO System) is documented; field dependency behavior and existing translation issue are not addressed |
| Acceptance Criteria | ⚠️ Partial | 4 ACs cover the happy path; no negative scenarios, no dependency-filtering ACs, no profile requirements |
| Definition of Ready | ⚠️ Partial | Sufficient for basic estimation; open comment from PRANIESH V (2026-02-19) about picklist value format and field dependency is not formally closed |
| Comments / Context | ⚠️ Partial | PRANIESH V (2026-02-19) raised two important technical issues that remain unanswered: (1) API name display issue for existing values, (2) field dependency not yet configured |

> **⚠️ Open Technical Issue (Unanswered):** PRANIESH V flagged on 2026-02-19 that the `Country Of Back Office` field currently shows raw API names (no translation) and that no field dependency exists with `Back Office System`. Neither of these issues is addressed in the current ACs, and no formal response was provided. This is a blocker for testability.

---

## INVEST Evaluation

| Principle | Score (0–2) | Notes |
|---|---|---|
| **I**ndependent | 1 | UAE counterpart of BFOFS-11335 (KSA/TR/QA); deployable independently but shares the same field (`Country Of Back Office`) — concurrent changes risk metadata conflicts |
| **N**egotiable | 1 | Happy-path scope is clearly defined; field dependency behavior and translation fix scope are not yet formally bound |
| **V**aluable | 2 | Clear persona (order manager) and business value (Digital Entitlement management with bFS E2E automation) |
| **E**stimable | 2 | Specific field API names (`CountryOfBackOffice_c`, `BackOfficeSystem_c`), picklist value API name (`AE`), label (`United Arab Emirates`), and BO System (`TU_SAP`) are all stated — estimable as a standard Salesforce configuration task |
| **S**mall | 2 | Tightly scoped — one picklist value addition and one optional field dependency |
| **T**estable | 1 | 4 ACs exist and cover the happy path; no negative ACs, no dependency-filter validation, no profile/permission requirements, and PRANIESH V's raised issues (translation display + field dependency) are not reflected in ACs |
| **Total** | **9/10** | ✅ Meets minimum threshold of 8/10 |

---

## Testability Assessment

| Area | Score (0–2) | Notes |
|---|---|---|
| **UI** | 2 | Screen (`Digital Entitlement` tab), interaction pattern (create/edit), field labels, and exact picklist values are specified |
| **API / Config** | 1 | API names given (`AE`, `TU_SAP`, `CountryOfBackOffice_c`, `BackOfficeSystem_c`); field dependency configuration rules not defined; the existing translation bug for other values is not in scope or out-of-scope explicitly |
| **Data** | 1 | Record type (`Digital Entitlement`) and target field values are clear; org/sandbox target, user profile, and permission set requirements are absent; impact on existing records not addressed |
| **Performance** | 0 | Not applicable for a configuration-only story |
| **Total** | **4/8** | ❌ Does not meet minimum threshold of 7/8 |

---

## Root Cause of Testability Failures

The happy path is testable as written. The deficiency is that two technical issues surfaced in comments by PRANIESH V are **not reflected in the acceptance criteria** and therefore cannot be validated in UAT:

1. **Translation issue:** The `Country Of Back Office` field currently displays raw API names, not labels. Does this story include a fix for all existing values, or only for the new UAE value? ACs say nothing about checking the display format of other existing values.
2. **Field dependency:** PRANIESH V states no field dependency exists between `Country Of Back Office` and `Back Office System`. The story description implies a dependency is desired (the two-column table maps countries to systems). ACs only test that both values can be selected and saved independently — they do not test that selecting UAE filters the `Back Office System` options.

Without resolving these two points, testers in UAT will not know whether a dependency failure or a display-name issue constitutes a pass or fail.

---

## Improved Acceptance Criteria

The original 4 ACs are retained; the additions below are proposed:

| AC# | Original / Proposed | Criterion |
|---|---|---|
| AC-1 | Original | Create/Edit a Digital Entitlement record from the Digital Entitlement tab |
| AC-2 | Original | Able to select `Country Of Back Office` = "United Arab Emirates" (API name: `AE`) |
| AC-3 | Original | Able to select `Back Office System` = "SAP Turkey" (API: `TU_SAP`) |
| AC-4 | Original | Save succeeds with the selected values persisted |
| AC-5 | **Proposed** | The `Country Of Back Office` field displays "United Arab Emirates" (the label), not "AE" (the API name), in the UI [confirm: does fix apply to all existing values or only UAE?] |
| AC-6 | **Proposed** | When `Country Of Back Office` = "United Arab Emirates" is selected, the `Back Office System` field shows only UAE-applicable options — OR confirm this is **not** a dependency requirement and the fields are independent |
| AC-7 | **Proposed** | Selecting a `Country Of Back Office` value other than UAE does not expose `TU_SAP` in the `Back Office System` list [only if field dependency is in scope] |
| AC-8 | **Proposed** | Existing Digital Entitlement records for other regions remain unaffected |

---

## Risks & Gaps

| Risk | Impact | Probability | Mitigation |
|---|---|---|---|
| Field dependency scope unconfirmed — if required, implementation effort is broader than a simple picklist addition | High | High | PO to confirm whether a fieldDependency metadata record is in scope before sprint |
| Translation issue for existing values — unclear if fixing display names for all existing API-name-only values is in scope | Medium | High | PO to explicitly include or exclude from this story |
| BFOFS-11335 (KSA/TR/QA) concurrent changes to the same field — metadata conflict risk during deployment | Medium | Medium | Coordinate deployment order; confirm BFOFS-11335 is already deployed before merging this change |
| UAT environment not specified | Low | Medium | Confirm which sandbox/scratch org is the UAE UAT target |
| User profile / permission set not defined — UAT tester may not have access to the Digital Entitlement tab | Low | Low | Include profile name in AC-1 preconditions |

---

## Split Recommendations

The story is **small enough to remain a single story**. However, if AC-6 (field dependency) is confirmed in scope and requires Apex logic or a custom component rather than standard picklist dependency configuration, split as follows:

| Sub-Story | Scope |
|---|---|
| BFOFS-11337-A | Add UAE picklist value to `Country Of Back Office` (label: "United Arab Emirates", API: `AE`) with correct label display |
| BFOFS-11337-B | Configure field dependency between `Country Of Back Office` (UAE) and `Back Office System` |

---

## Open Questions (Must Resolve Before UAT)

| # | Question | Owner | Priority |
|---|---|---|---|
| Q1 | Is a field dependency between `Country Of Back Office` and `Back Office System` in scope for this story? If yes, which BO System values should appear when UAE is selected? | Sanjali Gupta (PO) | 🔴 Blocker |
| Q2 | Does the translation fix (displaying labels instead of API names) apply to ALL existing `Country Of Back Office` values, or only to the new UAE value? | Sanjali Gupta (PO) | 🔴 Blocker |
| Q3 | Has BFOFS-11335 been deployed to production/UAT? If yes, can UAE follow the same implementation pattern? | Dev Lead / SIDDHARTH KHANDELWAL | 🟡 High |
| Q4 | Which sandbox / UAT org is the target for UAE testing? | Sanjali Gupta | 🟡 High |
| Q5 | Which user profile should the UAT tester use to access the Digital Entitlement tab? | Sanjali Gupta | 🟢 Medium |

---

## Readiness & Handoff

| Metric | Score | Threshold | Result |
|---|---|---|---|
| INVEST Score | 9/10 | 8/10 | ✅ PASS |
| Testability Score | 4/8 | 7/8 | ❌ FAIL |

**Story Ready:** ❌ **NOT READY FOR PLANNING**  
**Primary Blocker:** Testability score 4/8 — PRANIESH V's two unanswered technical issues (translation display behavior + field dependency scope) must be resolved and added to acceptance criteria before the story is plannable or testable.

**Next Action:** `request-clarification` — Sanjali Gupta (PO) must respond to Q1 and Q2 above. Once AC-5 through AC-8 are confirmed and added, the story should be re-reviewed. INVEST score already passes; only testability needs to be corrected.

---

*Generated by User Story Review Agent on 2026-02-27.*
