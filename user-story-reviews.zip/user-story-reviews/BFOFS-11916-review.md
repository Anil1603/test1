# User Story Review: BFOFS-11916 – Add Sold-To Account VIP Flag, SoldToAccountLegacyId & CC Info in F2B WO

**Reviewed:** 2026-03-18  
**Reviewer:** User Story Review Agent  
**Story File:** `user-stories/BFOFS-11916_Add_Sold_to_Account_-_VIP_flag_SoldToAccountLegacyId_CC_Info_in_F2B_WO.md`  
**Status:** UAT Passed | **Priority:** Medium | **Labels:** #Project, UNIFY  
**Assignee:** Karun Kaushik | **Reporter:** Karun Kaushik  

> **⚠️ Status Note:** This story is marked **"UAT Passed"**. This review is therefore primarily for retroactive automation test planning (regression baseline) rather than pre-sprint quality gating. However, gaps identified below must be resolved to enable test case generation and automation.

---

## Quick Health Check

| Check | Status | Notes |
|---|---|---|
| Story Title | ✅ Pass | Title identifies the three change areas clearly |
| User Story Format | ⚠️ Partial | Item 1 follows "I want…so that…" format; items 2 and 3 are stated as directives without a persona or benefit clause |
| Description | ⚠️ Partial | Three separate features bundled with minimal detail on each. Cost Center Description popup behavior is entirely undefined. |
| Acceptance Criteria | ❌ Fail | AC-1 ("Create Work Order with Sold-To Account") and AC-2 ("Sync Work Order to Back Office") are headings with no actual testable criterion under them. AC-3 through AC-6 exist but lack field API names, example values, and negative scenarios. |
| Definition of Ready | ❌ Fail | Story was implemented and UAT-passed without formal AC detail. Retroactive documentation is incomplete. |
| Comments / Context | ⚠️ Partial | Single comment (Karun Kaushik, 2026-02-27) acknowledges it as a placeholder with detail to be added — that detail was never added. |

> **⚠️ Critical Gap:** AC-1 and AC-2 contain no acceptance criteria — they are section headings only. Any automation test plan built from this story would be missing testable criteria for Work Order creation with a Sold-To Account and BO sync verification.

---

## INVEST Evaluation

| Principle | Score (0–2) | Notes |
|---|---|---|
| **I**ndependent | 1 | Story bundles 3 distinct features: (1) VIP Status in F2B responses, (2) `soldToAccountLegacyId` in POST API, (3) Cost Center Description sync from popup. Each could be developed, deployed, and tested independently. As written, a failure in one blocks the whole story. |
| **N**egotiable | 1 | The core API contract (VIP Status fields, `soldToAccountLegacyId__c`) is partially defined; Cost Center Description behavior is entirely open to interpretation. |
| **V**aluable | 2 | Clear business value: VIP customer visibility across WO lifecycle, legacy ID mapping for B2F integration, and CC Description accuracy for BO sync. |
| **E**stimable | 0 | AC-1 and AC-2 are empty. Cost Center popup behavior is undefined (which popup? what triggers it? what field is updated?). VIP Status API field path (`SoldToAccount.VIPStatus`) given but no API request/response schema. No Apex class or REST resource names provided. |
| **S**mall | 0 | Three distinct features across 5+ F2B endpoints + POST API + UI popup = medium-to-large scope. Each feature deserves its own story for independent delivery and testing. |
| **T**estable | 0 | AC-1 and AC-2 are blank. No negative scenarios. No test values for VIP statuses. CC Description popup is undefined. No user profile or environment requirements. "Correctly populated" is not a measurable criterion. |
| **Total** | **4/10** | ❌ Does NOT meet minimum threshold of 8/10 |

---

## Testability Assessment

| Area | Score (0–2) | Notes |
|---|---|---|
| **UI** | 1 | Cost Center Description popup is mentioned but completely undefined: no screen name, no button, no field API name on WO, no values. VIP Status field rendering in WO UI is not specified. |
| **API / Config** | 1 | GET WO API: `SoldToAccount.bFOId` and `SoldToAccount.VIPStatus` fields named. POST WO API: `soldToAccountLegacyId__c` field named. However, no API endpoint paths, no request/response schema, no HTTP methods or example payloads provided. |
| **Data** | 0 | No example VIP Status values. No example legacy IDs. No CC Description example values. No test record types or org/sandbox target specified. |
| **Performance** | 0 | Not mentioned. |
| **Total** | **2/8** | ❌ Does NOT meet minimum threshold of 7/8 |

---

## Root Causes of Testability Failures

1. **AC-1 and AC-2 are empty headings** — No testable criterion exists for Work Order creation with a Sold-To Account or BO sync. These were never filled in after the placeholder comment.
2. **Cost Center Description popup is undefined** — Which screen? Which button? What is the Salesforce field API name on the WO that gets updated? What is the flow: create WO → open popup → select CC → click what action → field updates?
3. **"Correctly populated" is not measurable** — VIP Status must be tested with specific values (e.g., VIP, Standard, null). Without example values, a Pass/Fail determination is impossible.
4. **No negative scenarios** — What happens when Sold-To Account has no VIP Status? What happens when `soldToAccountLegacyId` is absent in the POST payload? What if CC Description popup is dismissed without a selection?
5. **No F2B interface response schema** — The five F2B responses (Create, Update, Release, ReleasePO, Debrief) that must include VIP Status are not documented. No JSON schema, no field path, no example.
6. **Three features in one story** — VIP Status, `soldToAccountLegacyId`, and CC Description are unrelated features whose bundling makes coverage traceability difficult.

---

## Feature Breakdown

The story covers three technically distinct changes. For automation purposes:

| Feature | Interface | Salesforce Field | Status |
|---|---|---|---|
| **A** — VIP Status in F2B responses | GET WO API, 5× F2B responses | `SoldToAccount.VIPStatus`, `SoldToAccount.bFOId` | Partially defined |
| **B** — soldToAccountLegacyId in POST API | POST WO API (B2F) | `soldToAccountLegacyId__c` | Field named; no schema |
| **C** — Cost Center Description sync | UI popup → WO field → BO sync | Unknown field API name | Completely undefined |

---

## Improved Acceptance Criteria

Original ACs are retained and gaps are called out. Proposed additions are marked.

| AC# | Source | Criterion |
|---|---|---|
| AC-1 | **Proposed** *(original was empty)* | A Work Order can be created with a Sold-To Account populated in the [specify field: `SoldToAccount__c` or equivalent]. The Sold-To Account is a valid Account record with VIP Status set. |
| AC-2 | **Proposed** *(original was empty)* | When the WO is synced to Back Office (via [specify button/action]), the sync completes successfully and the BO receives the expected payload including `SoldToAccount.bFOId` and `SoldToAccount.VIPStatus`. |
| AC-3 | Original | The GET WO API response includes `SoldToAccount.bFOId` and `SoldToAccount.VIPStatus` fields populated from the Sold-To Account linked to the Work Order. **[Proposed addition: provide example response: `"VIPStatus": "VIP"`, `"bFOId": "12345"`]** |
| AC-4 | Original | VIP Status is present and correctly populated in all downstream F2B interface responses: Create, Update, Release, ReleasePO, Debrief. **[Proposed addition: define "correctly populated" — e.g., matches the `VIPStatus` value on the Account record, not empty, not null when Account has a VIP status set]** |
| AC-5 | Original | The `soldToAccountLegacyId` attribute can be passed in the POST WO API request body and is persisted to `soldToAccountLegacyId__c` on the Work Order record. **[Proposed addition: confirm field is optional or mandatory in POST payload]** |
| AC-6 | Original | The Cost Center Description on the Work Order is updated when a Cost Center is selected from the [specify popup name/screen] during WO Create or the Sync WO to BO action. **[Proposed addition: specify which WO field is updated, API name, and what triggers the popup]** |
| AC-7 | **Proposed** | When the Sold-To Account has no VIP Status set (blank/null), the GET API response returns `"VIPStatus": null` (or an agreed default). The F2B interfaces handle this gracefully without error. |
| AC-8 | **Proposed** | When `soldToAccountLegacyId` is not included in the POST WO API request, the WO is created successfully with `soldToAccountLegacyId__c` = null. No validation error. |
| AC-9 | **Proposed** | When the Cost Center Description popup is dismissed without a selection, the `[CC Description field API name]` on the WO remains unchanged. |
| AC-10 | **Proposed** | VIP Status in F2B responses reflects the most current value from the Sold-To Account at the time of the response (not a cached value from WO creation). |

---

## Split Recommendations

The story should be split into three separate stories for independent delivery, sizing, and testing:

| Sub-Story | Scope | Complexity |
|---|---|---|
| BFOFS-11916-A | VIP Status of Sold-To Account surfaced in GET WO API and all 5 F2B interface responses | Medium |
| BFOFS-11916-B | `soldToAccountLegacyId` attribute added to POST WO API → persisted to `soldToAccountLegacyId__c` on WO | Small |
| BFOFS-11916-C | Cost Center Description sync from UI popup to WO field during Create/Sync WO to BO | Small–Medium (undefined) |

---

## Risks & Gaps

| Risk | Impact | Probability | Mitigation |
|---|---|---|---|
| AC-1 and AC-2 never completed — WO creation and BO sync criteria entirely absent | High | Confirmed | PO to document what "Create WO with Sold-To Account" and "Sync WO to BO" means as testable criteria |
| Cost Center Description popup is undefined — developer and tester have no shared understanding | High | Confirmed | PO to describe the popup: screen name, trigger, field on WO, expected behavior |
| "Correctly populated" not measurable — testers cannot determine pass/fail without example values | High | Confirmed | Define VIP Status test values (e.g., "VIP", "Standard", null) in ACs |
| Story status is "UAT Passed" but ACs are incomplete — it is unclear what was actually tested in UAT | High | Confirmed | Retrospectively document what was validated in UAT to build regression baseline |
| 5 F2B interface responses must all carry VIP Status — integration test scope is broad | Medium | Medium | Confirm if all 5 F2B interfaces have automated integration tests or require new coverage |
| No org/sandbox target specified for automation | Low | High | Specify target environment in ACs or test data |

---

## Open Questions (Must Resolve Before Automation)

| # | Question | Owner | Priority |
|---|---|---|---|
| Q1 | What are the actual testable acceptance criteria for AC-1 (Create WO with Sold-To Account) and AC-2 (Sync to BO)? | Karun Kaushik | 🔴 Blocker |
| Q2 | What is the Cost Center Description popup: which screen, what triggers it, which field API name on WO is updated? | Karun Kaushik | 🔴 Blocker |
| Q3 | What are the valid VIP Status values on the Account object? (e.g., "VIP", "Standard", null) | Karun Kaushik / Dev | 🔴 Blocker |
| Q4 | What is the POST WO API request schema? Is `soldToAccountLegacyId` optional or required? | Karun Kaushik / Dev | 🔴 Blocker |
| Q5 | What does the GET WO API response look like with `SoldToAccount.VIPStatus`? Provide example JSON. | Dev (Ajay Sikhwal?) | 🔴 Blocker |
| Q6 | What was actually tested in UAT for this story? Is there a test record or UAT report? | Karun Kaushik | 🟡 High |
| Q7 | Which Salesforce profile / permission set should the automation tester use? | Karun Kaushik | 🟡 High |
| Q8 | Which sandbox or UAT org is this story validated in? | Karun Kaushik | 🟡 High |
| Q9 | Is `soldToAccountLegacyId__c` the exact API name for the WO field, or is it a different object? | Dev | 🟡 High |
| Q10 | Does VIP Status need to be re-fetched from Account at response time, or is it stored on the WO? | Dev | 🟢 Medium |

---

## Readiness & Handoff Decision

| Metric | Score | Threshold | Result |
|---|---|---|---|
| INVEST Score | 4/10 | 8/10 | ❌ FAIL |
| Testability Score | 2/8 | 7/8 | ❌ FAIL |
| **Story Ready** | — | — | ❌ **NOT READY — Stakeholder clarification and retroactive documentation required** |

**Blockers (4):**
1. AC-1 and AC-2 have no acceptance criteria (placeholders never completed)
2. Cost Center Description popup is entirely undefined
3. VIP Status test values not specified ("correctly populated" is not measurable)
4. POST WO API request schema and field optionality not provided

Story should be returned to reporter (Karun Kaushik) with a request to retrospectively complete the ACs and answer the open questions above before automation test planning begins.
