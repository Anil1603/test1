# User Story Review: BFOFS-10725 – Search and Create Installed Products Component v2 (Adjust to New Data Model)

## Quick Health Check
- **Story Title:** Clear and specific.
- **Description:** Provides context, field changes, and UI/UX requirements, but contains open questions and references to external confirmations.
- **Acceptance Criteria:** Not explicitly listed; requirements are embedded in the description.
- **Comments:** Some requirements are pending confirmation; toggle/deployment requirements are noted.

---

## INVEST Evaluation
| Principle      | Score (0-2) | Notes |
|---------------|-------------|-------|
| **I**ndependent   | 1 | Some dependencies on data model updates and external confirmation. |
| **N**egotiable    | 1 | Some requirements are open for confirmation; not all details are finalized. |
| **V**aluable      | 2 | Clear value in aligning with new data model and improving UX. |
| **E**stimable     | 1 | Most requirements are clear, but open questions reduce estimability. |
| **S**mall         | 2 | Scope is focused, but backend and toggle logic add complexity. |
| **T**estable      | 1 | Testable if acceptance criteria are clarified and open questions resolved. |
| **Total**         | **8/12** |  |

---

## Testability Assessment
| Area         | Score (0-2) | Notes |
|--------------|-------------|-------|
| **UI**       | 2 | UI changes and field mapping are described and can be validated. |
| **API**      | 1 | Backend logic changes are required, but details are not fully specified. |
| **Data**     | 1 | Data model changes are described, but some values are pending confirmation. |
| **Perf.**    | 1 | No explicit performance requirements, but toggle logic and migration may impact rollout. |
| **Total**    | **5/8**     | |

---

## Improved Story Draft
### Description
As a user, I want the Search and Create Installed Products component (v2) to align with the new data model, so that I can accurately search for and create Installed Product records with the correct fields and logic.

### Acceptance Criteria (Suggested)
1. The component replaces "Installed at Account" with "Owned By" and adds a "Managed By" field in all relevant UI sections.
2. The component replaces "Location" with "Installation Site" and adds an optional "Installation Sub Location" field.
3. When creating a new Installed Product, either "Owned By" or "Managed By" must be filled, and "Installation Site" is required.
4. Prepopulated values for fields depend on the triggering record (Case, Work Order, Service Line) as described.
5. All backend logic is updated to use the new fields for search, creation, and display.
6. A toggle (Custom Metadata: BFS_GenericConfig SearchCreateIPV2) controls whether v2 is active; must be false in Production until data migration is complete.
7. Error handling: If required fields are missing or backend update fails, the user receives a clear error message.
8. All open questions (e.g., Opportunity Lines, field mapping) are resolved and documented before release.

---

## Risks & Gaps
- Some requirements are pending confirmation (field mapping, Opportunity Lines, etc.).
- No explicit test data or edge case handling described.
- Rollout depends on data migration and toggle logic.

---

## Split Recommendations
- Split into: (1) UI/UX changes, (2) Backend/data model logic, (3) Toggle/deployment logic, (4) UAT/confirmation of open questions.

---

## Next Steps
- Product owner/BA to confirm all open questions and finalize field mappings.
- Define explicit acceptance criteria and test scenarios.
- Document toggle logic and deployment plan.

---

## Readiness & Handoff
- **INVEST Score:** 8/12 (Threshold: 8)
- **Testability Score:** 5/8 (Threshold: 7)
- **Blockers:** Open questions and lack of explicit acceptance criteria.
- **Story Ready:** ❌

---

*This review was generated automatically. Please address the blockers and resubmit for review.*
