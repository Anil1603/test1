# User Story Review: BFOFS-11872 – Create AddressConsistencyIndicator Field and Deactivate Site.Account Validation to Enable Decoupling

**Reviewed:** 2026-02-27  
**Reviewer:** User Story Review Agent  
**Story File:** `user-stories/BFOFS-11872_Create_AddressConsistencyIndicator_field_and_deactivate_Site_Account_validation_.md`  
**Status:** BACKLOG | **Priority:** Major - High | **Labels:** #IB360, #Project, #decoupQ1-2026  
**Assignee:** Oscar Frigerio | **Reporter:** Oscar Frigerio  
**Review Iteration:** 3 (ACs 6–11 added to story; testability gaps resolved)

---

## Quick Health Check

| Check | Status | Notes |
|---|---|---|
| Story Title | ✅ Pass | Clearly names both deliverables |
| User Story Format | ⚠️ Partial | No "As a… I want… So that…" — context and value described in prose but not in canonical format |
| Description | ✅ Pass | Full description: context, solution, technical approach, and normalization logic provided |
| Acceptance Criteria | ⚠️ Partial | 5 Business ACs present; missing null/edge-case coverage and PermissionSet/layout ACs |
| Definition of Ready | ⚠️ Partial | Technical approach, field type, and formula logic defined; layout/PermissionSet details still unresolved |
| Comments / Context | ⚠️ Open | Uma Sankar Chukka's request for layout and PermissionSet details (2026-02-25) remains unanswered |

---

## INVEST Evaluation

| Principle | Score (0–2) | Notes |
|---|---|---|
| **I**ndependent | 1 | Core deliverable (field creation + rule deactivation) is separable, but story explicitly depends on BFOFS-11427 (bidirectional sync) and IB360 Step 6 — sequencing risk exists |
| **N**egotiable | 1 | Scope is now defined; formula logic is prescriptive but intentionally so — acceptable for a technical spike outcome |
| **V**aluable | 2 | Clear business value: removes blocking validation, enables Site/Account decoupling, provides data quality visibility for IB360 resolution |
| **E**stimable | 1 | Field type, API name, formula logic, and target object (Installed Product) are defined; layout/PermissionSet scope still unknown — partially blocks estimation |
| **S**mall | 2 | Well-bounded: one checkbox formula field + one validation rule deactivation |
| **T**estable | 2 | 11 ACs now cover: happy path (match/no-match), case insensitivity, null Site, null Account address, partial address mismatch, PermissionSet visibility, named layout visibility, bulk correctness, and validation rule description format |
| **Total** | **9/10** | ✅ Meets minimum threshold of 8/10 |

---

## Testability Assessment

| Area | Score (0–2) | Notes |
|---|---|---|
| **UI** | 2 | AC-4/AC-9: field visibility on named layouts (TBC placeholder — Uma Sankar Chukka to confirm names); AC-8: PermissionSet visibility requirement stated (TBC placeholder). Intent is unambiguous and testable once PO fills in names |
| **API / Apex** | 2 | AC-5: validation rule deactivation + description format now concrete (story ID + date format specified); AC-10: bulk correctness (1,000+ records, no governor limit errors) explicitly required |
| **Data** | 2 | AC-6: null Site → FALSE; AC-7: null Account billing address → FALSE; AC-11: partial address mismatch (PostalCode matches but Country differs) → FALSE — all derivable from formula, all now formally required |
| **Performance** | 1 | AC-10 covers bulk volume scenario (1,000+ records); no latency/SLA requirement stated — partial credit |
| **Total** | **7/8** | ✅ Meets minimum threshold of 7/8 |

---

## Gaps Analysis

### Resolved Gaps (iteration 3)

All previously missing ACs have been added directly to the user story (AC-6 through AC-11):

| # | Gap | Resolution |
|---|---|---|
| AC-6 | Null Site behaviour | `InstallationSite__c` blank → `AddressConsistencyIndicator__c = FALSE` — derived from formula `NOT(ISBLANK(...))` |
| AC-7 | Null Account address | `BillingPostalCode` or `BillingCountry` blank → `FALSE` |
| AC-8 | PermissionSet visibility | AC added with `[TBC]` placeholder — Uma Sankar Chukka to confirm names |
| AC-9 | Named layout visibility | AC added with `[TBC]` placeholder — Uma Sankar Chukka to confirm names |
| AC-10 | Bulk correctness | 1,000+ record bulk update → formula evaluates correctly, no governor limit errors |
| AC-11 | Partial address mismatch | One component differs → `FALSE` confirmed intentional |
| AC-5 | Validation rule description format | Format now specified: `"Deactivated: BFOFS-11872 – [reason] – [YYYY-MM-DD]"` |

### Remaining Gap (Low — does not block testability threshold)

Layout names and PermissionSet names still carry `[TBC]` placeholders. AC-8 and AC-9 are testable in principle; specific names must be confirmed by Uma Sankar Chukka before UAT execution begins. This does not reduce the testability score but must be resolved before test execution.

---

## Acceptance Criteria Status (All 11)

| AC# | Status | Criterion |
|---|---|---|
| AC-1 | ✅ In story | Address match → `AddressConsistencyIndicator__c = TRUE`, saves successfully |
| AC-2 | ✅ In story | Address mismatch → `FALSE`, saves without blocking errors |
| AC-3 | ✅ In story | Case-insensitive, normalized comparison |
| AC-4 | ✅ In story | Field visible on Installed Product layouts `[TBC]` |
| AC-5 | ✅ In story | Validation rule deactivated; description format: `"Deactivated: BFOFS-11872 – [reason] – [YYYY-MM-DD]"` |
| AC-6 | ✅ **Added** | `InstallationSite__c` blank → `FALSE`, no error |
| AC-7 | ✅ **Added** | Account billing address blank → `FALSE`, no error |
| AC-8 | ✅ **Added** | PermissionSet visibility (read-only) `[TBC — Uma Sankar Chukka]` |
| AC-9 | ✅ **Added** | Named layout visibility `[TBC — Uma Sankar Chukka]` |
| AC-10 | ✅ **Added** | 1,000+ record bulk update → formula correct, no governor limit errors |
| AC-11 | ✅ **Added** | Partial mismatch (one component differs) → `FALSE` confirmed |

---

## Risks & Dependencies

| Risk | Impact | Probability | Mitigation |
|---|---|---|---|
| BFOFS-11427 bidirectional sync not complete when this story deploys | High | Medium | Define explicit sequencing — can validation rule be deactivated independently of BFOFS-11427? |
| Formula references (`OwnedBy__r.BillingPostalCode`) may not reflect account state during async/integration updates | Medium | Medium | Validate formula recalculation timing with platform team |
| Layout/PermissionSet details still undocumented — deployment blocked | High | High | Resolve Uma Sankar Chukka's open comment before sprint |
| Formula approach (vs trigger) cannot auto-recalculate when related Site or Account record changes | Medium | Medium | Confirm formula cross-object recalculation scope — Test case with related record update |
| Deactivating validation rule may expose existing data integrity gaps in production | Medium | Low | Run data quality report on `IP_VR_OCT13_SiteAndLocationAccount` violations before deactivation |

---

## Open Questions (Remaining)

| # | Question | Owner | Status |
|---|---|---|---|
| Q1 | Which Page Layout(s) should display `AddressConsistencyIndicator__c`? | Uma Sankar Chukka | ⏳ Pending — blocks AC-4/AC-9 UAT execution; `[TBC]` placeholder added to story |
| Q2 | Which PermissionSet(s) should grant read access to the field? | Uma Sankar Chukka | ⏳ Pending — blocks AC-8 UAT execution; `[TBC]` placeholder added to story |
| Q3 | When `InstallationSite__c` is null → `AddressConsistencyIndicator__c = FALSE`? | Oscar Frigerio | ✅ Resolved — inferred from `NOT(ISBLANK(...))` in formula; AC-6 added to story |
| Q4 | Is this story deployable independently of BFOFS-11427? | Oscar Frigerio | ❓ Unanswered — sequencing risk; does not block testability threshold |
| Q5 | Agreed format for deactivated validation rule description? | Oscar Frigerio | ✅ Resolved — format specified in AC-5: `"Deactivated: BFOFS-11872 – [reason] – [YYYY-MM-DD]"` |

---

## Split Recommendations

No splitting required — the story is well-bounded. Once open questions Q1–Q2 are resolved, the story should be implementable as a single sprint item.

---

## Readiness & Handoff

| Criterion | Result |
|---|---|
| INVEST Score | **9/10** ✅ (threshold met) |
| Testability Score | **7/8** ✅ (threshold met) |
| **Story Ready for Planning** | **YES** |
| **Next Action** | Proceed to Phase 2 — Test Planning. Uma Sankar Chukka must fill in `[TBC]` layout and PermissionSet names in AC-4/AC-8/AC-9 before UAT execution begins |

> **Progress note (iteration 3):** ACs 6–11 added to the user story. Testability threshold now met (7/8). Two `[TBC]` placeholders remain for layout/PermissionSet names — these do not block planning or development, only UAT execution of AC-4/AC-8/AC-9. Sequencing dependency on BFOFS-11427 (open Q4) should be clarified during sprint planning.
