/*
 * @author Vivek
 * 
 * pageLocFixtures file
 * 
 * this file is used to store the locators instance of the all page
 * we have declared locators in json file
 * creating instance of the locators here and exporting it to the test files
 * this will help us to maintain the locators in a better way and also it will help us to avoid the duplicate code in the test files
 * included the lead page locators here and we can include the other page locators in the same way
 */



import leadPageLoc from "../pageLocators/leadPageLoc.json";

// Define the types for the page locators
type pageLocDetails = {
    leadPageLoc: typeof leadPageLoc;

}
// Export the page locators instance for use in test files
export const pageLocFixtures = {
    leadPageLoc: leadPageLoc,

} as pageLocDetails;