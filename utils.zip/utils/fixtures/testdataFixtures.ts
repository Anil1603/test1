/*
 * @author Vivek
 * 
 * testdataFixtures file
 * 
 * this file is used to store the test data instance of the all test data
 * we have declared test data in json file
 * creating instance of the test data here and exporting it to the test files
 * this will help us to maintain the test data in a better way and also it will help us to avoid the duplicate code in the test files
 * included the lead creation test data here and we can include the other test data in the same way
 */



import leadCreationTest from "..//testData/leadCreationTest.json";
// Define the types for the test data
type testDataDetails = {
    leadCreationTest: typeof leadCreationTest;
}
// Export the test data instance for use in test files
export const testdataFixtures = {
    leadCreationTest: leadCreationTest
} as testDataDetails;