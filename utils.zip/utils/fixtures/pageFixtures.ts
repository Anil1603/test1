/*
 * @author Vivek
 * 
 * pageFixtures file for playwright test
 * here we are declaring user name, password
 * we are also creating instance of lead page and opportunity page here
 * and we are setting session name to the test title at start and also setting pass/fail at end
 * this will help us to identify the test in browserstack dashboard
 * we are also setting the test status in browserstack dashboard based on the test result
 * this will help us to identify the failed test in browserstack dashboard
 * we are also setting the reason for failure in browserstack dashboard which will be the error message of the failed test
 */

import { test as pageReference } from "@playwright/test";
import leadPage from "../../pages/leadPage";
import opportunityPage from "../../pages/opportunityPage";

// Define the types for the page fixtures
type pageName = {
    leadPage: leadPage;
    opportunityPage: opportunityPage

}

// Extend the base test with our page fixtures
const pageReferenceExtended = pageReference.extend<pageName>({
    page: async ({ page }, use) => {
        await page.goto('https://test.salesforce.com/');
        await page.getByLabel('Username').fill(process.env.USER_NAME || 'leadmanagmentnrtuser@bridge-fo.com.uat25');
        await page.getByLabel('Password').fill(process.env.PASSWORD || 'SITprodnrtpass@001PPROD');
        await page.locator("//input[@name='Login']").click();
        await use(page);
    },
    // Create an instance of the lead page  and use it in the tests
    leadPage: async ({ page }, use) => {
        const leadPageInstance = new leadPage(page);
        await use(leadPageInstance);
    }
    ,
    // Create an instance of the opportunity page and use it in the tests
    opportunityPage: async ({ page }, use) => {
        const opportunityPageInstance = new opportunityPage(page);
        await use(opportunityPageInstance);
    }


})

// this founction is used to set the session name to the test title at start of the test and also setting pass/fail at end of the test in browserstack dashboard
pageReferenceExtended.beforeEach(async ({ page }, testInfo) => {
  // Optional: include retry index in the session name for visibility
  const sessionName = testInfo.retry? `${testInfo.title} (retry #${testInfo.retry})`: testInfo.title;
  await page.waitForLoadState('domcontentloaded').catch(() => { });

  async function setSessionNameSafely() {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await page.evaluate(
          () => {},
          `browserstack_executor: ${JSON.stringify({
            action: 'setSessionName',
            arguments: { name: sessionName },
          })}`
        );
        return; // success
      } catch (e: any) {
        const msg = String(e?.message || e);
        const isCtxDestroyed = /Execution context was destroyed/i.test(String(e));
        if (!isCtxDestroyed || attempt === 2) throw e; // rethrow non-matching or last attempt
        // Small backoff and wait again for stability
        await page.waitForTimeout(150);
        await page.waitForLoadState('domcontentloaded').catch(() => {});
      }
    }
  }

  await setSessionNameSafely();
});



function isBrowserStackRun() {
  // Adjust the condition to match how you signal BS runs (env var, capability, etc.)
  return !!process.env.PROJECT_NAME || !!process.env.SANDBOX_ENV;
}

pageReferenceExtended.afterEach(async ({ page }, testInfo) => {
  if (!isBrowserStackRun()) return; // skip locally

  // 1) Decide the effective status for BrowserStack
  // If the test failed but was *expected to fail* (marked with { expect: 'fail' }),
  // you can consider it 'passed' from infra POV, or report as 'failed' with a clear reason.
  const actuallyFailed = testInfo.status === 'failed';
  const expectedToFail = testInfo.expectedStatus === 'failed';

  const bsStatus =
    actuallyFailed && !expectedToFail
      ? 'failed'
      : (testInfo.status === 'passed' ? 'passed' : 'failed');

  // 2) Reason: prefer the error message; otherwise a compact generic
  let reason =
    testInfo.error?.message ||
    `Test ${bsStatus}${testInfo.status !== 'passed' ? ` (${testInfo.status})` : ''}`;

  // Normalize & truncate (BrowserStack UI displays short lines better)
  reason = String(reason)
    .replace(/\s+/g, ' ')
    .slice(0, 180);

  // 3) Evaluate safely: swallow context/page closure errors
  async function setSessionStatusSafely() {
    // up to 3 light retries if context is unstable
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await page.evaluate(
          () => {},
          `browserstack_executor: ${JSON.stringify({
            action: 'setSessionStatus',
            arguments: { status: bsStatus, reason },
          })}`
        );
        return;
      } catch (e: any) {
        const msg = String(e?.message || e);
        const transient =
          /Execution context was destroyed|Target closed|Protocol error/i.test(msg);
        if (!transient || attempt === 2) {
          // Last attempt or non-transient → stop retrying (but don't throw)
          break;
        }
        await page.waitForTimeout(120);
      }
    }
  }

  await setSessionStatusSafely();
});


// Export the extended test and expect for use in test files
export const test = pageReferenceExtended;
export const expect = pageReferenceExtended.expect;