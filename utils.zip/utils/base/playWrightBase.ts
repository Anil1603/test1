/*
 * @author Vivek
 * 
 * playWright Base file for playwright test
 * this file is used to store the common functions which are used in the test files
 * this page can be extend to all page 
 * 
 */

import{Locator, Page, test} from "@playwright/test";

 export default class playwrightBase{

    protected page: Page
    constructor(page: Page){
       this.page = page;
    }
    
    // this function helps to enter the text on textbox
    async enterText(locator : string, data : string){
        const element : Locator = await this.waitForElementLoad(locator);
        await element.click();
        await element.fill(data);
    }

    // this function helps to enter the text on last name textbox and appending the date time value to make it unique 
    async enterTextLastName(locator : string, data : string){
        const element : Locator = await this.waitForElementLoad(locator);
        await element.click();
        const dateValue: number = new Date().getTime();
        data =  data + " "+ dateValue;
        await element.fill(data);
    }
   // this function helps to click on the element
    async click(locator : string){
      const element : Locator = await this.waitForElementLoad(locator);
      await element.click();
    }

    // this function helps to click on the object tab
    // we can pass the opject name as parameter and it will click on the object tab
    async clickOnObject(locator:string){
        let tabName : string = "//a[@title='TITLE']"
        tabName = tabName.replace("TITLE",locator);
        const element : Locator = await this.waitForElementLoad(tabName);
        await element.click();
    }

    // this function helps to enter the text on the object tab
    // we can pass the opject name and data as parameter and it will enter the text on the object tab
    // it helps clear text and enter the number value in the text box
     async enterTextOnObject(locator:string, data: number){
      
      const element : Locator = await this.waitForElementLoad(locator);   
              await element.click();
       await this.page.locator(locator).clear();
       await this.page.locator(locator).pressSequentially(String(data) as any)

     }

     // this function helps to click on the button
     async clickonButton(locator:string){
      const element : Locator = await this.waitForElementLoad(locator);
      await element.click();
     }

     //this function helps to wait for the element to load and return the element
      async waitForElementLoad(locator:string){
            const element: Locator = this.page.locator(locator);
         await element.waitFor({state :'visible'});
         return element;
      }
        
      // this function helps to select the value from the dropdown
        async selectFromOption(Locator: string, data: string){
        const element : Locator = await this.waitForElementLoad(Locator);
        await element.click();
        let countryLocator : string = "//span[contains(text(),'TITLE')]"
        countryLocator = countryLocator.replace("TITLE",data);
         const element1 : Locator = await this.page.locator(countryLocator);
                   await  element1.click();
     }

      // this function helps to select the value from the dynamic dropdown by passing the label name and value
       async selectFromDropdown(label: string ,Locator: string, data: string){
        const element : Locator  = await this.waitForElementLoad(Locator);
        await element.click();
        let countryLocator : string = "//span[contains(text(),'TITLE')]"
         let selectList : string = "//div[contains(@aria-label,'TITLE')]//span[@title]";
        countryLocator = selectList.replace("TITLE",label);
         const element1 : Locator = this.page.locator(countryLocator,{hasText: data});
          await  element1.click();
     }
    
     // this function used to scroll down to the element
     async scrolldown(locator: string){
        const element : Locator = await this.page.locator(locator);
        await element.scrollIntoViewIfNeeded();
       
     }

     // this function helps to select the value from the static dropdown by passing the label name and value
       async selectFromStaticDropdown(Locator: string, data: string){
        const element : Locator  = await this.waitForElementLoad(Locator);
        await element.click();
        let selectList : string = "//div[contains(text(),'TITLE')]"
        let countryLocator = selectList.replace("TITLE",data);
         const element1 : Locator = await this.waitForElementLoad(countryLocator);
         await  element1.click();
     }

       async switchToFrameAndClick(locator:string, elementLocator: string){
        const element : Locator = await this.page.frameLocator(locator).locator(elementLocator);
        await element.click();
        }

       async switchToFrameAndEnterText(locator:string, elementLocator: string, data: string){
        const element : Locator = await this.page.frameLocator(locator).locator(elementLocator);
        await element.click();
        await element.fill(data);
        }

}