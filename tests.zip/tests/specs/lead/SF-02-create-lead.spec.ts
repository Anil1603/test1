/**
 * Test Specification: SF-02 Create Lead
 * Story: SF-02
 * Priority: HIGH
 * 
 * @description Complete lead creation workflow: Login → Home → Leads List → Create Lead
 * Uses self-healing locator strategy with page objects for each step
 */
import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/login-page';
import { HomePage } from '../../pages/home-page';
import { LeadsListPage } from '../../pages/leadslist-page';
import { LeadNewPage } from '../../pages/lead-new';
import testData from '../../data/SF-02_test_data.json';

// Credentials from environment or defaults
const USERNAME = process.env.USER_NAME || 'leadmanagmentnrtuser@bridge-fo.com.uat25';
const PASSWORD = process.env.PASSWORD || 'SITprodnrtpass@001PPROD';
const BASE_URL = 'https://test.salesforce.com/';

test.describe('SF-02 Create Lead - Full Flow', () => {
  test('TC1: Login → Navigate to Leads → Create new lead', async ({ page }) => {
    const data = testData.happy;

    // Step 1: Login
    const loginPage = new LoginPage(page, BASE_URL);
    await loginPage.login(USERNAME, PASSWORD);

    // Step 2: Navigate to Home and verify
    const homePage = new HomePage(page);
    await homePage.waitForLoad();
    const isLoggedIn = await homePage.isLoggedIn();
    expect(isLoggedIn).toBeTruthy();

    // Step 3: Navigate to Leads List
    await homePage.navigateToLeads();

    // Step 4: Open New Lead modal
    const leadsListPage = new LeadsListPage(page);
    await leadsListPage.waitForLoad();
    const isOnLeadsList = await leadsListPage.isOnLeadsList();
    expect(isOnLeadsList).toBeTruthy();
    
    await leadsListPage.clickNewLead();

    // Step 5: Fill lead form using self-healing locator strategy
    const leadNewPage = new LeadNewPage(page);
    await leadNewPage.fillField('salutation', data.salutation);
    await leadNewPage.fillField('firstName', data.firstName);
    await leadNewPage.fillField('lastName', data.lastName);
    await leadNewPage.fillField('company', data.company);
    await leadNewPage.fillField('phone', data.phone);
    
    // Optional fields
    if (data.projectName) {
      await leadNewPage.fillField('projectName', data.projectName);
    }
    if (data.classificationLevel) {
      await leadNewPage.fillField('classificationLevel', data.classificationLevel);
    }
    if (data.country) {
      await leadNewPage.fillField('country', data.country);
    }

    // Step 6: Save the lead
    await leadNewPage.save();
    await page.waitForTimeout(3000);

    // Step 7: Verify success (toast message)
    const toast = page.locator('role=alert').first();
    if (await toast.count() > 0) {
      await expect(toast).toContainText('created');
    }
  });

  test('TC2: Complete workflow with all fields verification', async ({ page }) => {
    const data = testData.happy;

    // Login flow
    const loginPage = new LoginPage(page, BASE_URL);
    await loginPage.navigate();
    await loginPage.fillUsername(USERNAME);
    await loginPage.fillPassword(PASSWORD);
    await loginPage.clickLogin();
    await page.waitForURL(/lightning\.force\.com/, { timeout: 30000 });

    // Home page navigation
    const homePage = new HomePage(page);
    await homePage.waitForLoad();
    await homePage.navigateToLeads();

    // Leads list page
    const leadsListPage = new LeadsListPage(page);
    await leadsListPage.clickNewLead();

    // Create lead with all fields
    const leadNewPage = new LeadNewPage(page);
    const fields = ['salutation', 'firstName', 'lastName', 'company', 'phone', 
                    'projectName', 'classificationLevel', 'country'];

    for (const fieldKey of fields) {
      const value = data[fieldKey as keyof typeof data];
      if (value) {
        await leadNewPage.fillField(fieldKey, value);
      }
    }

    // Save and verify
    await leadNewPage.save();
    await page.waitForTimeout(3000);
    
    const toast = page.locator('role=alert').first();
    if (await toast.count() > 0) {
      await expect(toast).toBeVisible();
    }
  });
});
