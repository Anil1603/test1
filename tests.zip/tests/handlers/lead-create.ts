import { Page } from '@playwright/test';
import { LeadNewPage } from '../pages/lead-new';

export async function createLead(page: Page, data: any) {
  const started = Date.now();
  const p = new LeadNewPage(page);
  try {
    await p.fillField('salutation', data.salutation || 'Mr.');
    await p.fillField('firstName', data.firstName);
    await p.fillField('lastName', data.lastName);
    await p.fillField('company', data.company);
    if (data.phone) await p.fillField('phone', data.phone);
    if (data.projectName) await p.fillField('projectName', data.projectName);
    if (data.classificationLevel) await p.fillField('classificationLevel', data.classificationLevel);
    if (data.country) await p.fillField('country', data.country);
    await p.save();
    const duration = Date.now() - started;
    console.log(JSON.stringify({ action: 'createLead', durationMs: duration }));
    return { success: true };
  } catch (err) {
    const duration = Date.now() - started;
    console.error(JSON.stringify({ action: 'createLead', durationMs: duration, error: String(err) }));
    return { success: false, error: String(err) };
  }
}

export default createLead;
