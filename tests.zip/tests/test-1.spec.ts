import { test, expect } from '@playwright/test';
import LoginPage from './pages/login-page';
import HomePage from './pages/home-page';
import LeadsListPage from './pages/leadslist-page';
import LeadNewPage from './pages/lead-new';
import { testdataFixtures } from '../utils/fixtures/testdataFixtures';

/**
 * Basic Lead Creation Test
 * 
 * This test creates a new lead with basic required fields using parameterized test data.
 * Test data is externalized in utils/testData/leadCreationTest.json
 */
test('basicLeadCreation', async ({ page }) => {
  // Get test data from fixtures
  const testData = testdataFixtures.leadCreationTest['basicLeadCreation'];
  
  // Login
  const loginPage = new LoginPage(page);
  await loginPage.login('leadmanagmentnrtuser@bridge-fo.com.uat25', 'SITprodnrtpass@001PPROD');

  // Navigate to Leads
  const homePage = new HomePage(page);
  await homePage.waitForLoad();
  await homePage.navigateToLeads();

  // Click New Lead button
  const leadsListPage = new LeadsListPage(page);
  await leadsListPage.clickNewLead();

  // Fill lead form with test data
  const leadNewPage = new LeadNewPage(page);
  await leadNewPage.fillField('salutation', testData.salutation);
  await leadNewPage.fillField('firstName', testData.firstName);
  await leadNewPage.fillField('lastName', testData.lastName);
  await leadNewPage.fillField('country', testData.country);
  await leadNewPage.fillField('phone', testData.phone);
  await leadNewPage.fillField('email', testData.email);
  
  // Save the lead
  await leadNewPage.save();

});