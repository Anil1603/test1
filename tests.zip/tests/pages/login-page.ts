import { Page } from '@playwright/test';
import { resolveLocator } from '../helpers/locators/SF-02-login-locators';

export class LoginPage {
  readonly page: Page;
  readonly baseUrl: string;

  constructor(page: Page, baseUrl: string = 'https://test.salesforce.com/') {
    this.page = page;
    this.baseUrl = baseUrl;
  }

  async navigate() {
    await this.page.goto(this.baseUrl);
    await this.page.waitForLoadState('domcontentloaded');
  }

  async fillUsername(username: string) {
    const locator = await resolveLocator(this.page, 'username');
    if (!locator) throw new Error('Username field not found');
    await locator.fill(username);
  }

  async fillPassword(password: string) {
    const locator = await resolveLocator(this.page, 'password');
    if (!locator) throw new Error('Password field not found');
    await locator.fill(password);
  }

  async clickLogin() {
    const locator = await resolveLocator(this.page, 'loginButton');
    if (!locator) throw new Error('Login button not found');
    await locator.click();
  }

  async login(username: string, password: string) {
    await this.navigate();
    await this.fillUsername(username);
    await this.fillPassword(password);
    await this.clickLogin();
    // Wait for navigation to complete
    await this.page.waitForURL(/lightning\.force\.com/, { timeout: 30000 });
    await this.page.waitForLoadState('domcontentloaded');
  }
}

export default LoginPage;
