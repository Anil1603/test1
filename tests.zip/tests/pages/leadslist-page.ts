import { Page } from '@playwright/test';
import { resolveLocator } from '../helpers/locators/SF-02-leadslist-locators';

export class LeadsListPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForLoad() {
    await this.page.waitForLoadState('domcontentloaded');
    // Wait for list view to initialize
    await this.page.waitForTimeout(2000);
  }

  async clickNewLead() {
    await this.waitForLoad();
    const locator = await resolveLocator(this.page, 'newLeadButton');
    if (!locator) throw new Error('New Lead button not found');
    await locator.click();
    // Wait for modal to appear
    await this.page.waitForTimeout(1500);
  }

  async isOnLeadsList(): Promise<boolean> {
    const url = this.page.url();
    return url.includes('/lightning/o/Lead/');
  }

  async getLeadCount(): Promise<number> {
    const locator = await resolveLocator(this.page, 'leadsTableRows');
    if (!locator) return 0;
    return await locator.count();
  }

  async searchLeads(searchTerm: string) {
    const locator = await resolveLocator(this.page, 'listViewSelector');
    if (locator) {
      await locator.fill(searchTerm);
      await this.page.keyboard.press('Enter');
      await this.page.waitForTimeout(1000);
    }
  }
}

export default LeadsListPage;
