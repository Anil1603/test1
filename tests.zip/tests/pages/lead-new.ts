import { Page, Locator } from '@playwright/test';
import { 
  resolveLocator 
} from '../helpers/locators/SF-02-newlead-locators';
import { 
  detectValidationErrors, 
  closeValidationErrorDialog 
} from '../helpers/self-healing-locator';

export class LeadNewPage {
  readonly page: Page;
  private fieldValues: Map<string, string> = new Map(); // Store field values for retry

  constructor(page: Page) { this.page = page; }

  /**
   * Fill a form field using self-healing locator strategy
   * Automatically retries with fallback locators if primary fails
   */
  async fillField(key: string, value: string) {
    console.log(`\n[LeadNewPage] Filling field "${key}" with value "${value}"`);
    
    // Store field value for potential retry on validation error
    this.fieldValues.set(key, value);
    
    const locator = await resolveLocator(this.page, key, {
      maxRetries: 3,
      retryDelayMs: 500,
      visibilityTimeout: 10000,
      logAttempts: true,
      waitForStability: true,
      scrollIntoView: true,
    });
    
    if (!locator) {
      throw new Error(
        `[Self-Healing Failed] Could not locate element "${key}" using any available strategy. ` +
        `Check locator definitions in SF-02-newlead-locators.ts`
      );
    }

    try {
      const role = await locator.getAttribute('role').catch(() => null);
      const tag = await locator.evaluate((el: any) => el.tagName);
      
      // Handle combobox fields (like Country, Salutation)
      if (role === 'combobox' || key === 'country' || key === 'salutation') {
        await this.fillCombobox(locator, key, value);
      } else if (/INPUT|TEXTAREA/i.test(tag)) {
        await locator.fill(value);
        await this.page.waitForTimeout(300); // Brief wait for field to register value
        console.log(`[LeadNewPage] ✓ Successfully filled "${key}" using standard fill`);
      } else {
        // Handle other custom elements
        await locator.click({ force: true, timeout: 5000 });
        await this.page.keyboard.type(value, { delay: 100 });
        await this.page.keyboard.press('Enter');
        console.log(`[LeadNewPage] ✓ Successfully filled "${key}" using click + type`);
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      throw new Error(`[LeadNewPage] Failed to fill field "${key}": ${msg}`);
    }
  }

  private async fillCombobox(locator: Locator, key: string, value: string) {
    try {
      console.log(`[LeadNewPage] Filling combobox "${key}" with value "${value}"`);
      
      await locator.waitFor({ state: 'visible', timeout: 5000 });
      await locator.scrollIntoViewIfNeeded();
      
      const tagName = await locator.evaluate((el: any) => el.tagName.toLowerCase());
      const role = await locator.getAttribute('role').catch(() => null);
      
      console.log(`[LeadNewPage] Combobox element: tag=${tagName}, role=${role}`);
      
      if (tagName === 'button' && role === 'combobox') {
        await this.fillLightningCombobox(locator, key, value);
      } else if (tagName === 'input') {
        await this.fillInputCombobox(locator, key, value);
      } else {
        throw new Error(`Unexpected combobox element type: ${tagName} with role ${role}`);
      }
      
      console.log(`[LeadNewPage] ✓ Successfully filled combobox "${key}"`);
      
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      throw new Error(`[LeadNewPage] Failed to fill combobox "${key}": ${msg}`);
    }
  }

  private async fillLightningCombobox(buttonLocator: Locator, key: string, value: string) {
    // Click button to open dropdown
    await buttonLocator.click({ timeout: 5000 });
    console.log(`[LeadNewPage] Opened Lightning combobox for "${key}"`);
    await this.page.waitForTimeout(500);
    
    // Wait for input field to appear
    const inputLocator = this.page.locator('input[placeholder*="Search"]').first();
    await inputLocator.waitFor({ state: 'visible', timeout: 5000 });
    
    // Type value to filter options
    await inputLocator.fill(value);
    console.log(`[LeadNewPage] Typed "${value}" into search field`);
    await this.page.waitForTimeout(1000);
    
    // Try to select matching option
    const optionSelectors = [
      `lightning-base-combobox-item:has-text("${value}")`,
      `div[role="option"]:has-text("${value}")`,
      `div[role="listbox"] span:has-text("${value}")`,
      `[data-value="${value}"]`,
      `span.slds-truncate:has-text("${value}")`
    ];
    
    let optionClicked = false;
    
    for (const selector of optionSelectors) {
      const option = this.page.locator(selector).first();
      const isVisible = await option.isVisible({ timeout: 2000 }).catch(() => false);
      
      if (isVisible) {
        await option.click();
        console.log(`[LeadNewPage] Selected option using selector: ${selector}`);
        optionClicked = true;
        break;
      }
    }
    
    // Fallback: keyboard navigation
    if (!optionClicked) {
      console.log(`[LeadNewPage] No visible option found, using keyboard navigation`);
      await this.page.waitForTimeout(500);
      await this.page.keyboard.press('ArrowDown');
      await this.page.waitForTimeout(300);
      await this.page.keyboard.press('Enter');
    }
    
    await this.page.waitForTimeout(500);
  }

  private async fillInputCombobox(inputLocator: Locator, key: string, value: string) {
    await inputLocator.click({ force: true, timeout: 5000 });
    await this.page.waitForTimeout(300);
    
    await inputLocator.fill('');
    await this.page.waitForTimeout(200);
    
    await inputLocator.fill(value);
    await this.page.waitForTimeout(1000);
    
    const optionSelectors = [
      `lightning-base-combobox-item[data-value*="${value.toLowerCase()}"]`,
      `div[role="option"]:has-text("${value}")`,
      `div[role="listbox"] span:has-text("${value}")`,
      `[data-value="${value}"]`,
    ];
    
    let optionClicked = false;
    
    for (const selector of optionSelectors) {
      const option = this.page.locator(selector).first();
      const isVisible = await option.isVisible({ timeout: 2000 }).catch(() => false);
      
      if (isVisible) {
        await option.click();
        console.log(`[LeadNewPage] Selected option using selector: ${selector}`);
        optionClicked = true;
        break;
      }
    }
    
    if (!optionClicked) {
      await this.page.waitForTimeout(500);
      await this.page.keyboard.press('ArrowDown');
      await this.page.waitForTimeout(200);
      await this.page.keyboard.press('Enter');
    }
    
    await this.page.waitForTimeout(500);
  }

  async save() {
    console.log(`\n[LeadNewPage] Clicking Save button`);
    
    const save = await resolveLocator(this.page, 'saveButton', {
      maxRetries: 3,
      retryDelayMs: 500,
      visibilityTimeout: 10000,
      logAttempts: true,
      waitForStability: true,
      scrollIntoView: true,
    });
    
    if (!save) {
      throw new Error(
        '[Self-Healing Failed] Could not locate Save button using any available strategy'
      );
    }

    try {
      await save.click({ timeout: 5000 });
      console.log(`[LeadNewPage] ✓ Successfully clicked Save button`);
      
      // Wait for validation or navigation
      await this.page.waitForTimeout(2000);
      
      // Check for validation errors
      const errorFields = await detectValidationErrors(this.page);
      
      if (errorFields.length > 0) {
        console.log(`[LeadNewPage] ⚠️ Validation errors detected for: ${errorFields.join(', ')}`);
        await this.handleValidationErrors(errorFields);
        
        // Retry save after fixing validation errors
        console.log(`[LeadNewPage] Retrying Save after fixing validation errors`);
        await save.scrollIntoViewIfNeeded().catch(() => {});
        await save.click({ timeout: 5000 });
        await this.page.waitForTimeout(2000);
        
        // Check if errors persist
        const persistingErrors = await detectValidationErrors(this.page);
        if (persistingErrors.length > 0) {
          throw new Error(
            `[LeadNewPage] Validation errors persist after retry: ${persistingErrors.join(', ')}`
          );
        }
      }
      
      // Wait for navigation or save completion
      console.log(`[LeadNewPage] Waiting for save completion...`);
      await Promise.race([
        this.page.waitForURL(/\/view$/, { timeout: 15000 }),
        this.page.waitForLoadState('networkidle', { timeout: 15000 }),
      ]).catch(() => {
        console.log(`[LeadNewPage] Navigation/load detection timed out (may be normal)`);
      });
      
      console.log(`[LeadNewPage] ✓ Form saved successfully`);
      
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      throw new Error(`[LeadNewPage] Failed to click Save: ${msg}`);
    }
  }

  private async handleValidationErrors(errorFields: string[]) {
    try {
      console.log(`[LeadNewPage] Handling ${errorFields.length} validation error(s)`);
      
      // Close the error dialog
      await closeValidationErrorDialog(this.page);
      
      // Retry filling each field that had an error
      for (const fieldName of errorFields) {
        // Normalize field name to match stored keys
        const fieldKey = this.normalizeFieldKey(fieldName);
        const storedValue = this.fieldValues.get(fieldKey);
        
        if (storedValue) {
          console.log(`[LeadNewPage] Re-filling field "${fieldKey}" with value "${storedValue}"`);
          await this.fillField(fieldKey, storedValue);
        } else {
          console.log(`[LeadNewPage] ⚠️ No stored value found for field "${fieldKey}"`);
          
          // Try to handle known fields with default behavior
          if (fieldKey === 'country') {
            console.log(`[LeadNewPage] Applying special retry for Country field`);
            await this.retryCountryField();
          }
        }
      }
      
      console.log(`[LeadNewPage] ✓ Completed validation error recovery`);
      
    } catch (error) {
      console.error(`[LeadNewPage] Error handling validation errors:`, error);
      throw error;
    }
  }

  /**
   * Normalize field display name to internal key
   */
  private normalizeFieldKey(displayName: string): string {
    const normalized = displayName.toLowerCase().trim();
    
    // Map common display names to internal keys
    const fieldMap: Record<string, string> = {
      'country': 'country',
      'first name': 'firstName',
      'last name': 'lastName',
      'phone': 'phone',
      'email': 'email',
      'salutation': 'salutation',
      'company': 'company',
    };
    
    return fieldMap[normalized] || normalized;
  }

  private async retryCountryField() {
    try {
      const storedValue = this.fieldValues.get('country') || 'India';
      
      console.log(`[LeadNewPage] Retrying Country field with value: ${storedValue}`);
      
      const locator = await resolveLocator(this.page, 'country', {
        maxRetries: 3,
        retryDelayMs: 500,
        visibilityTimeout: 10000,
        logAttempts: false, // Reduce noise
        scrollIntoView: true,
      });
      
      if (!locator) {
        throw new Error('Could not locate Country field');
      }
      
      // Use the fillCombobox method
      await this.fillCombobox(locator, 'country', storedValue);
      
      console.log(`[LeadNewPage] ✓ Successfully retried Country field`);
      
    } catch (error) {
      console.error(`[LeadNewPage] Failed to retry Country field:`, error);
      throw error;
    }
  }
}

export default LeadNewPage;
