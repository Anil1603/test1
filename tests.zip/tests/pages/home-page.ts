import { Page } from '@playwright/test';
import { resolveLocator } from '../helpers/locators/SF-02-home-locators';

export class HomePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForLoad() {
    await this.page.waitForLoadState('domcontentloaded');
    // Wait for Lightning components to initialize
    await this.page.waitForTimeout(2000);
  }

  async clickAppLauncher() {
    const locator = await resolveLocator(this.page, 'appLauncher');
    if (!locator) throw new Error('App Launcher not found');
    await locator.click();
  }

  async searchGlobal(searchTerm: string) {
    const locator = await resolveLocator(this.page, 'globalSearch');
    if (!locator) throw new Error('Global search not found');
    await locator.fill(searchTerm);
    await this.page.keyboard.press('Enter');
  }

  async navigateToLeads() {
    await this.waitForLoad();
    const locator = await resolveLocator(this.page, 'leadsNavLink');
    if (!locator) {
      // Fallback: try navigating directly
      await this.page.goto(this.page.url().replace(/\/one\/one\.app.*/, '/lightning/o/Lead/home'));
    } else {
      await locator.click();
    }
    await this.page.waitForURL(/\/lightning\/o\/Lead/, { timeout: 20000 });
    await this.page.waitForLoadState('domcontentloaded');
  }

  async isLoggedIn(): Promise<boolean> {
    const url = this.page.url();
    return url.includes('lightning.force.com');
  }
}

export default HomePage;
