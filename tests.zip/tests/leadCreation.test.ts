 /*
 * @author Vivek
 * 
 * lead creation test
 * this file used create test for lead creation 
 * we can include all lead creation related test in this file
 * 
 */
 
 import{test, expect} from "..//utils//fixtures//pageFixtures";
import { testdataFixtures } from "../utils/fixtures/testdataFixtures";
import {pageLocFixtures} from "../utils/fixtures/pageLocFixtures";

    test("leadCreationDemo", async({leadPage, page})=>{
       await leadPage.clickOnObject("Leads");
       // calling the lead creation function and passing the test data as parameter
        const createdLeadName = await leadPage.leadCreation(testdataFixtures.leadCreationTest["leadCreationDemo"]);
        expect(createdLeadName).not.toBe(null);

        // verifying the lead status after lead creation
        await expect(page.locator(pageLocFixtures.leadPageLoc.notReadyToConvert)).toBeVisible();
        await leadPage.clickOnDetailsTab()

        // editing the project name and saving the changes
        await leadPage.editProjectName(testdataFixtures.leadCreationTest.leadCreationDemo.projectName);

        // verifying the lead status after editing the project name
        await expect(page.locator(pageLocFixtures.leadPageLoc.readyToConvert)).toBeVisible();
    });

     test("convertLeadToOppty", async({leadPage, page})=>{
       await leadPage.clickOnObject("Leads");
       // calling the lead creation function and passing the test data as parameter
        const createdLeadName = await leadPage.leadCreation(testdataFixtures.leadCreationTest["convertLeadToOppty"]);
        expect(createdLeadName).not.toBe(null);

        // verifying the lead status after lead creation
        await expect(page.locator(pageLocFixtures.leadPageLoc.notReadyToConvert)).toBeVisible();
        await leadPage.clickOnDetailsTab()

        // editing the project name and saving the changes
        await leadPage.editProjectNameAndLevel(testdataFixtures.leadCreationTest.convertLeadToOppty.projectName, 
            testdataFixtures.leadCreationTest.convertLeadToOppty.classificationLevel);

        // verifying the lead status after editing the project name
        await expect(page.locator(pageLocFixtures.leadPageLoc.readyToConvert)).toBeVisible();

        await expect(page.locator(pageLocFixtures.leadPageLoc.convert)).toBeVisible();

        // converting the lead to opportunity and verifying the opportunity name after conversion
        const createdOpptyName = await leadPage.convertLeadToOppty(testdataFixtures.leadCreationTest.convertLeadToOppty);
        expect(createdOpptyName).not.toBe(null);
    });

 