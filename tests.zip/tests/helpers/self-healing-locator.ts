import { Page, Locator } from '@playwright/test';

/**
 * Self-Healing Locator Utility
 * 
 * Provides robust locator resolution with retry logic and fallback strategies.
 * Implements primary, secondary, and tertiary locator attempts with configurable retries.
 */

export interface LocatorAttempt {
  selector: string;
  success: boolean;
  error?: string;
  attemptNumber: number;
  strategyName: string;
}

export interface SelfHealingConfig {
  maxRetries: number;
  retryDelayMs: number;
  visibilityTimeout: number;
  logAttempts: boolean;
  waitForStability?: boolean; // Wait for element to be stable before returning
  scrollIntoView?: boolean;   // Scroll element into view
}

export const DEFAULT_CONFIG: SelfHealingConfig = {
  maxRetries: 3,
  retryDelayMs: 500,
  visibilityTimeout: 5000,
  logAttempts: true,
  waitForStability: true,
  scrollIntoView: true,
};

/**
 * Normalize selector strings to Playwright Locator objects
 */
export function normalizeSelector(page: Page, sel: string): Locator {
  if (sel.startsWith('label=')) {
    return page.getByLabel(sel.slice(6));
  }
  
  if (sel.startsWith('role=')) {
    const rest = sel.slice(5);
    // Match patterns like: role=button[name="Save"] or role=textbox[name*="Search"]
    const m = rest.match(/^([a-z-]+)(?:\[name([~*]?)=(?:"|')(.+)(?:"|')\])?$/i);
    if (m) {
      const [, role, operator, name] = m;
      if (name) {
        // Support partial matching with *= operator
        const namePattern = operator === '*' ? new RegExp(name, 'i') : name;
        return page.getByRole(role as any, { name: namePattern });
      }
      return page.getByRole(role as any);
    }
    return page.getByRole(rest as any);
  }
  
  if (sel.startsWith('xpath=')) {
    return page.locator(sel.slice(6));
  }
  
  // Default to CSS selector or other Playwright selector syntax
  return page.locator(sel);
}

/**
 * Sleep utility for retry delays
 */
async function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Self-healing locator resolver with retry logic
 * 
 * Tries primary, secondary, and tertiary locators with configurable retries.
 * Logs all attempts for debugging and provides detailed error messages.
 * 
 * @param page - Playwright Page object
 * @param key - Locator key to resolve
 * @param locators - Record of locator arrays by key
 * @param config - Optional configuration overrides
 * @returns Resolved Locator or null if all strategies fail
 */
export async function resolveSelfHealingLocator(
  page: Page,
  key: string,
  locators: Record<string, string[]>,
  config: Partial<SelfHealingConfig> = {}
): Promise<Locator | null> {
  const mergedConfig = { ...DEFAULT_CONFIG, ...config };
  const list = locators[key];

  if (!list || list.length === 0) {
    console.error(`[Self-Healing] No locators defined for key: ${key}`);
    return null;
  }

  const attempts: LocatorAttempt[] = [];
  let attemptNumber = 0;

  // Try each locator strategy (primary, secondary, tertiary, etc.)
  for (let locatorIndex = 0; locatorIndex < list.length; locatorIndex++) {
    const sel = list[locatorIndex];
    const strategyName =
      locatorIndex === 0 ? 'Primary' :
      locatorIndex === 1 ? 'Secondary' :
      locatorIndex === 2 ? 'Tertiary' :
      `Fallback-${locatorIndex}`;

    // Retry each locator strategy multiple times
    for (let retry = 0; retry < mergedConfig.maxRetries; retry++) {
      attemptNumber++;

      try {
        if (mergedConfig.logAttempts) {
          console.log(
            `[Self-Healing] Attempt ${attemptNumber}: Trying ${strategyName} locator for "${key}"`
          );
          console.log(`  Selector: ${sel}`);
        }

        const locator = normalizeSelector(page, sel);

        // Wait for element to be visible and attached to DOM
        await locator.first().waitFor({
          state: 'visible',
          timeout: mergedConfig.visibilityTimeout,
        });

        const count = await locator.count();

        if (count > 0) {
          const element = locator.first();
          
          // Scroll into view if configured
          if (mergedConfig.scrollIntoView) {
            await element.scrollIntoViewIfNeeded().catch(() => {
              // Ignore scroll errors
            });
          }
          
          // Wait for element stability (brief pause for animations/transitions)
          if (mergedConfig.waitForStability) {
            await page.waitForTimeout(300);
          }
          
          attempts.push({
            selector: sel,
            success: true,
            attemptNumber,
            strategyName,
          });

          if (mergedConfig.logAttempts) {
            console.log(
              `[Self-Healing] ✓ Success with ${strategyName} locator on attempt ${attemptNumber}`
            );
            if (locatorIndex > 0) {
              console.log(
                `[Self-Healing] WARNING: Primary locator failed. Consider updating the primary locator for "${key}".`
              );
            }
          }

          return element;
        }
      } catch (e) {
        const errorMsg = e instanceof Error ? e.message : String(e);
        attempts.push({
          selector: sel,
          success: false,
          error: errorMsg,
          attemptNumber,
          strategyName,
        });

        if (mergedConfig.logAttempts) {
          console.log(`[Self-Healing] ✗ Failed: ${errorMsg}`);
        }

        // Wait before retry (except on last retry of last locator)
        const isLastRetry = retry === mergedConfig.maxRetries - 1;
        const isLastLocator = locatorIndex === list.length - 1;
        
        if (!isLastRetry || !isLastLocator) {
          if (mergedConfig.logAttempts && !isLastRetry) {
            console.log(
              `[Self-Healing] Waiting ${mergedConfig.retryDelayMs}ms before retry...`
            );
          }
          await sleep(mergedConfig.retryDelayMs);
        }
      }
    }

    // Move to next locator strategy
    if (locatorIndex < list.length - 1 && mergedConfig.logAttempts) {
      console.log(`[Self-Healing] Moving to next locator strategy...`);
    }
  }

  // All attempts exhausted
  if (mergedConfig.logAttempts) {
    console.error(`[Self-Healing] ✗ All locator strategies exhausted for "${key}"`);
    console.error(`[Self-Healing] Total attempts: ${attemptNumber}`);
    console.error('[Self-Healing] Attempted selectors:', list);
    console.error('[Self-Healing] Detailed attempts:', attempts);
  }

  return null;
}

/**
 * Helper to detect and handle validation error dialogs
 */
export async function detectValidationErrors(page: Page): Promise<string[]> {
  const errorDialog = page.locator('div[role="dialog"].forceFormPageError');
  const isVisible = await errorDialog.isVisible({ timeout: 2000 }).catch(() => false);

  if (!isVisible) {
    return [];
  }

  console.log('[Self-Healing] Validation error dialog detected');

  // Extract error field names
  const errorLinks = errorDialog.locator('ul.errorsList li a');
  const errorCount = await errorLinks.count();
  const errorFields: string[] = [];

  for (let i = 0; i < errorCount; i++) {
    const fieldName = await errorLinks.nth(i).textContent();
    if (fieldName) {
      errorFields.push(fieldName.trim());
    }
  }

  return errorFields;
}

/**
 * Helper to close validation error dialog
 */
export async function closeValidationErrorDialog(page: Page): Promise<boolean> {
  const errorDialog = page.locator('div[role="dialog"].forceFormPageError');
  const isVisible = await errorDialog.isVisible({ timeout: 1000 }).catch(() => false);

  if (!isVisible) {
    return false;
  }

  const closeButton = errorDialog.locator('button[title="Close error dialog"], lightning-button-icon button');
  const closeVisible = await closeButton.first().isVisible().catch(() => false);

  if (closeVisible) {
    await closeButton.first().click();
    await page.waitForTimeout(500);
    console.log('[Self-Healing] Closed validation error dialog');
    return true;
  }

  return false;
}

/**
 * Export a factory function to create resolveLocator for specific locator maps
 */
export function createLocatorResolver(locators: Record<string, string[]>) {
  return async (
    page: Page,
    key: string,
    config?: Partial<SelfHealingConfig>
  ): Promise<Locator | null> => {
    return resolveSelfHealingLocator(page, key, locators, config);
  };
}
