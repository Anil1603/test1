import { createLocatorResolver } from '../self-healing-locator';

const locators: Record<string, string[]> = {
  username: [
    '#username',
    'input[name="username"]',
    'input[placeholder="Username"]',
    'input[type="email"]',
  ],
  password: [
    '#password',
    'input[name="password"]',
    'input[type="password"]',
  ],
  loginButton: [
    '#Login',
    'input[type="submit"][value="Log In"]',
    'button:has-text("Log In")',
    'input[id="Login"]',
  ],
};

export const resolveLocator = createLocatorResolver(locators);
