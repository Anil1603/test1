import { createLocatorResolver } from '../self-healing-locator';

const locators: Record<string, string[]> = {
  salutation: [
    'button[name="salutation"]',
    'select[name="salutation"]',
    'div[data-field="salutation"] button',
    'lightning-combobox[data-field="salutation"] button',
  ],
  firstName: [
    'input[placeholder="First Name"]',
    'input[name="firstName"]',
    'input[data-field="firstName"]',
    'label:has-text("First Name") ~ div input',
  ],
  lastName: [
    'input[placeholder="Last Name"]',
    'input[name="lastName"]',
    'input[data-field="lastName"]',
    'label:has-text("Last Name") ~ div input',
  ],
  company: [
    'input[placeholder="Company"]',
    'input[name="Company"]',
    'input[data-field="Company"]',
    'label:has-text("Company") ~ div input',
  ],
  phone: [
    'input[placeholder="Phone"]',
    'input[name="Phone"]',
    'input[type="tel"]',
    'label:has-text("Phone") ~ div input',
  ],
  email: [
    'input[placeholder="Email"]',
    'input[name="Email"]',
    'input[type="email"]',
    'label:has-text("Email") ~ div input',
  ],
  projectName: [
    'input[name="SGL_Project_Name__c"]',
    'input[placeholder*="Project Name"]',
    'label:has-text("Project Name") ~ div input',
  ],
  classificationLevel: [
    'button[name="SGL_Classification_Level__c"]',
    'div[data-field="SGL_Classification_Level__c"] button',
    'lightning-combobox[data-field="SGL_Classification_Level__c"] button',
    'label:has-text("Classification Level") ~ div button',
  ],
  country: [
    'button[name="MailingCountry"]',
    'input[placeholder="Country"]',
    'input[name="MailingCountry"]',
    'label:has-text("Country") ~ div button',
    'label:has-text("Country") ~ div input',
  ],
  saveButton: [
    'button[name="SaveEdit"]',
    'button[title="Save"]',
    'button:has-text("Save")',
    'div.slds-modal__footer button:has-text("Save")',
    'footer button:has-text("Save")',
  ],
};

export const resolveLocator = createLocatorResolver(locators);
