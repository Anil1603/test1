import { createLocatorResolver } from '../self-healing-locator';

const locators: Record<string, string[]> = {
  newLeadButton: [
    'a[title="New"]',
    'div.slds-page-header a[title="New"]',
    'button:has-text("New")',
    'a.forceNewRecordButton',
  ],
  leadsTableRows: [
    'table tbody tr.slds-hint-parent',
    'table[aria-label*="Leads"] tbody tr',
    'tbody tr[data-row-key-value]',
    'c-list-view-manager-item',
  ],
  listViewSelector: [
    'input.filterInput',
    'input[placeholder="Filter list views"]',
    'input[aria-label*="Search this list"]',
    '.slds-input.filterInput',
  ],
};

export const resolveLocator = createLocatorResolver(locators);
