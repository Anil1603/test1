import { createLocatorResolver } from '../self-healing-locator';

const locators: Record<string, string[]> = {
  appLauncher: [
    'div.slds-icon-waffle',
    'button[title="App Launcher"]',
    '[aria-label="App Launcher"]',
    '.waffle',
  ],
  globalSearch: [
    'input.global-header-search-input',
    'input[placeholder="Search Salesforce"]',
    'input[placeholder="Search..."]',
    '.slds-global-header__search input',
    'input[type="search"]',
  ],
  leadsNavLink: [
    'a[title="Leads"]',
    'one-app-nav-bar-item-root a[data-label="Leads"]',
    'nav a:has-text("Leads")',
    '[data-label="Leads"] a',
  ],
};

export const resolveLocator = createLocatorResolver(locators);
