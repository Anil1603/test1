# Using Collections in RAG MCP Server

## Overview
The RAG MCP Server now supports multiple collections, allowing you to organize documents into separate namespaces. For example, you can have a "pes" collection for PES-related documents and a "poc" collection for proof-of-concept documents.

## Collection Management

### Creating a Collection
Collections are created automatically when you first add documents to them or query them. Simply specify the `collection_name` parameter.

### Default Collection
If you don't specify a `collection_name`, the server uses the default collection specified in `config.json` (typically "poc").

## Using Collections

### 1. Ingest Documents to a Specific Collection

```bash
# Ingest PES confluence pages into the "pes" collection
@workspace Use ingest_documents with directory "../pxs/confluence-pages" and collection_name "pes"

# Ingest to default collection
@workspace Use ingest_documents with directory "../rag-database/documents"
```

### 2. Query a Specific Collection

```bash
# Query the "pes" collection
@workspace Use query_rag to search for "architecture" in collection_name "pes"

# Query the default collection
@workspace Use query_rag to search for "machine learning"
```

### 3. Ask Copilot with a Specific Collection

```bash
# Ask about PES architecture using the "pes" collection
@workspace Use rag_ask_copilot to answer "What is the PES architecture?" with collection_name "pes"

# Use default collection
@workspace Use rag_ask_copilot to answer "What is ChromaDB?"
```

### 4. Add Single Document to a Collection

```bash
@workspace Use add_document with content "PES system handles..." and collection_name "pes"
```

## Example Workflow: Setting up PES Collection

1. **Create and populate the PES collection:**
   ```bash
   @workspace Use ingest_documents with directory "/Users/rahulvennapusa/Documents/codebase/PES/pxs/confluence-pages" and collection_name "pes"
   ```

2. **Query PES-specific information:**
   ```bash
   @workspace Use rag_ask_copilot to answer "How does PES rendering work?" with collection_name "pes"
   ```

3. **Check database stats:**
   ```bash
   @workspace Use get_database_stats
   ```

## Testing Script

Use the provided `create_pes_collection.py` script to verify the collection functionality:

```bash
cd /Users/rahulvennapusa/Documents/codebase/CaaS/CaaS
python3 create_pes_collection.py
```

This script will:
- Create the "pes" collection
- Add a test document
- Query the collection
- List all available collections

## Collection Best Practices

1. **Organize by project/domain**: Create separate collections for different projects (e.g., "pes", "caas", "poc")
2. **Use descriptive names**: Collection names should be lowercase and descriptive
3. **Check stats regularly**: Use `get_database_stats` to monitor collection sizes
4. **Consistent naming**: Use the same collection name across related operations

## Available Collections

After running the setup, you should have:
- `pes` - PES project documentation
- `poc` - Default/proof-of-concept collection
- `rag_docs` - General RAG documentation

## Troubleshooting

If a collection doesn't exist and you query it, it will be created automatically with 0 documents. Always ingest documents first before querying.
