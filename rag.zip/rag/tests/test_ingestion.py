"""
Unit tests for document processing module.
"""

import os
import tempfile
from typing import Any, Dict, List

import pytest

# Import will work after package install; for now use path manipulation
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "rag-database", "common"))

from ingestion import DocumentProcessor


class TestDocumentProcessor:
    """Tests for DocumentProcessor class."""
    
    def test_init_default_values(self) -> None:
        """Test default initialization values."""
        processor = DocumentProcessor()
        assert processor.chunk_size == 1000
        assert processor.chunk_overlap == 200
    
    def test_init_custom_values(self) -> None:
        """Test custom initialization values."""
        processor = DocumentProcessor(chunk_size=500, chunk_overlap=100)
        assert processor.chunk_size == 500
        assert processor.chunk_overlap == 100
    
    def test_chunk_text_small(self) -> None:
        """Test chunking text smaller than chunk size."""
        processor = DocumentProcessor(chunk_size=1000, chunk_overlap=200)
        text = "Short text"
        chunks = processor.chunk_text(text)
        
        assert len(chunks) == 1
        assert chunks[0] == text
    
    def test_chunk_text_with_overlap(self) -> None:
        """Test chunking creates proper overlap."""
        processor = DocumentProcessor(chunk_size=100, chunk_overlap=20)
        text = "A" * 150  # Should create 2 chunks with overlap
        chunks = processor.chunk_text(text)
        
        assert len(chunks) == 2
        assert len(chunks[0]) == 100
        # Second chunk starts at position 80 (100 - 20 overlap)
        assert len(chunks[1]) == 70  # Remaining 150 - 80 = 70
    
    def test_chunk_text_exact_size(self) -> None:
        """Test chunking text exactly chunk size."""
        processor = DocumentProcessor(chunk_size=100, chunk_overlap=0)
        text = "A" * 100
        chunks = processor.chunk_text(text)
        
        assert len(chunks) == 1
        assert chunks[0] == text
    
    def test_process_documents(self, sample_documents: List[Dict[str, Any]]) -> None:
        """Test processing documents into chunks."""
        processor = DocumentProcessor(chunk_size=50, chunk_overlap=10)
        documents, metadatas, ids = processor.process_documents(sample_documents)
        
        # Should have multiple chunks
        assert len(documents) > len(sample_documents)
        assert len(metadatas) == len(documents)
        assert len(ids) == len(documents)
        
        # All IDs should be unique
        assert len(set(ids)) == len(ids)
        
        # Metadata should have required fields
        for meta in metadatas:
            assert "source" in meta
            assert "filename" in meta
            assert "chunk_index" in meta
    
    def test_load_file_nonexistent(self) -> None:
        """Test loading a file that doesn't exist."""
        processor = DocumentProcessor()
        result = processor.load_file("/nonexistent/path/file.txt")
        assert result is None
    
    def test_load_file_text(self, temp_dir: str) -> None:
        """Test loading a text file."""
        processor = DocumentProcessor()
        
        # Create a test file
        test_file = os.path.join(temp_dir, "test.txt")
        content = "This is test content."
        with open(test_file, "w") as f:
            f.write(content)
        
        result = processor.load_file(test_file)
        
        assert result is not None
        assert result["content"] == content
        assert result["filename"] == "test.txt"
        assert result["source"] == test_file
    
    def test_load_file_markdown(self, temp_dir: str) -> None:
        """Test loading a markdown file."""
        processor = DocumentProcessor()
        
        test_file = os.path.join(temp_dir, "test.md")
        content = "# Heading\n\nSome content."
        with open(test_file, "w") as f:
            f.write(content)
        
        result = processor.load_file(test_file)
        
        assert result is not None
        assert result["content"] == content
        assert result["filename"] == "test.md"
    
    def test_load_directory(self, temp_dir: str) -> None:
        """Test loading multiple files from directory."""
        processor = DocumentProcessor()
        
        # Create test files
        for i in range(3):
            with open(os.path.join(temp_dir, f"doc{i}.txt"), "w") as f:
                f.write(f"Content of document {i}")
        
        docs = processor.load_directory(temp_dir)
        
        assert len(docs) == 3
        for doc in docs:
            assert "content" in doc
            assert "source" in doc
            assert "filename" in doc
    
    def test_load_directory_recursive(self, temp_dir: str) -> None:
        """Test loading files from nested directories."""
        processor = DocumentProcessor()
        
        # Create nested structure
        subdir = os.path.join(temp_dir, "subdir")
        os.makedirs(subdir)
        
        with open(os.path.join(temp_dir, "root.txt"), "w") as f:
            f.write("Root content")
        with open(os.path.join(subdir, "nested.txt"), "w") as f:
            f.write("Nested content")
        
        docs = processor.load_directory(temp_dir)
        
        assert len(docs) == 2


class TestChunkingEdgeCases:
    """Edge case tests for text chunking."""
    
    def test_empty_text(self) -> None:
        """Test chunking empty text returns empty list."""
        processor = DocumentProcessor()
        chunks = processor.chunk_text("")
        assert chunks == []  # Empty text produces no chunks
    
    def test_whitespace_only(self) -> None:
        """Test chunking whitespace-only text."""
        processor = DocumentProcessor(chunk_size=10, chunk_overlap=0)
        chunks = processor.chunk_text("   \n\t  ")
        assert len(chunks) == 1
    
    def test_unicode_text(self) -> None:
        """Test chunking text with unicode characters."""
        processor = DocumentProcessor(chunk_size=10, chunk_overlap=0)
        text = "Hello 世界! 🌍"
        chunks = processor.chunk_text(text)
        
        # Should chunk properly
        assert len(chunks) >= 1
        # Full text should be recoverable
        assert "".join(chunks[:2]).startswith(text[:10])
