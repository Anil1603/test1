"""
Test fixtures and configuration for CaaS tests.
"""

import os
import sys
import tempfile
from typing import Generator

import pytest

# Add project root to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def temp_dir() -> Generator[str, None, None]:
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_documents() -> list[dict]:
    """Sample documents for testing."""
    return [
        {
            "content": "This is the first test document about Python programming.",
            "source": "/test/doc1.txt",
            "filename": "doc1.txt"
        },
        {
            "content": "This is the second document discussing machine learning concepts.",
            "source": "/test/doc2.txt",
            "filename": "doc2.txt"
        },
        {
            "content": "A third document covering database design patterns and best practices.",
            "source": "/test/doc3.txt",
            "filename": "doc3.txt"
        }
    ]


@pytest.fixture
def sample_text() -> str:
    """Sample text for chunking tests."""
    return "A" * 500 + "B" * 500 + "C" * 500
