"""
Unit tests for exception classes.
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "caas"))

from exceptions import (
    CaaSError,
    DatabaseConnectionError,
    CollectionNotFoundError,
    InvalidCollectionNameError,
    DocumentProcessingError,
    ConfigurationError,
    QueryError,
    IngestionError,
)


class TestCaaSExceptions:
    """Tests for CaaS exception classes."""
    
    def test_base_error_message_only(self) -> None:
        """Test base error with message only."""
        error = CaaSError("Something went wrong")
        assert str(error) == "Something went wrong"
        assert error.message == "Something went wrong"
        assert error.details is None
    
    def test_base_error_with_details(self) -> None:
        """Test base error with details."""
        error = CaaSError("Connection failed", "Host unreachable")
        assert str(error) == "Connection failed: Host unreachable"
        assert error.message == "Connection failed"
        assert error.details == "Host unreachable"
    
    def test_database_connection_error(self) -> None:
        """Test database connection error."""
        error = DatabaseConnectionError("Cannot connect", "Port 5432 refused")
        assert isinstance(error, CaaSError)
        assert "Cannot connect" in str(error)
    
    def test_collection_not_found_error(self) -> None:
        """Test collection not found error."""
        error = CollectionNotFoundError("Collection 'test' not found")
        assert isinstance(error, CaaSError)
    
    def test_invalid_collection_name_error(self) -> None:
        """Test invalid collection name error."""
        error = InvalidCollectionNameError("Invalid name", "Contains special chars")
        assert isinstance(error, CaaSError)
    
    def test_document_processing_error(self) -> None:
        """Test document processing error."""
        error = DocumentProcessingError("Failed to process PDF")
        assert isinstance(error, CaaSError)
    
    def test_configuration_error(self) -> None:
        """Test configuration error."""
        error = ConfigurationError("Missing config", "config.json not found")
        assert isinstance(error, CaaSError)
    
    def test_query_error(self) -> None:
        """Test query error."""
        error = QueryError("Query failed", "Invalid SQL")
        assert isinstance(error, CaaSError)
    
    def test_ingestion_error(self) -> None:
        """Test ingestion error."""
        error = IngestionError("Ingestion failed")
        assert isinstance(error, CaaSError)
    
    def test_exception_inheritance(self) -> None:
        """Test all exceptions inherit from CaaSError and Exception."""
        exceptions = [
            DatabaseConnectionError,
            CollectionNotFoundError,
            InvalidCollectionNameError,
            DocumentProcessingError,
            ConfigurationError,
            QueryError,
            IngestionError,
        ]
        
        for exc_class in exceptions:
            error = exc_class("Test")
            assert isinstance(error, CaaSError)
            assert isinstance(error, Exception)
    
    def test_exception_can_be_raised_and_caught(self) -> None:
        """Test exceptions work in try/except blocks."""
        with pytest.raises(CollectionNotFoundError) as exc_info:
            raise CollectionNotFoundError("Collection not found", "aws")
        
        assert "Collection not found" in str(exc_info.value)
    
    def test_catch_base_class(self) -> None:
        """Test catching by base class."""
        with pytest.raises(CaaSError):
            raise DatabaseConnectionError("Connection failed")
