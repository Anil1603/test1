/**
 * GitHub Copilot Account Information Helper
 */

import { CopilotClient } from "@github/copilot-sdk";
import { readFileSync } from "fs";
import { join } from "path";

export interface CopilotAccountInfo {
  user?: string;
  model?: string;
  timestamp: string;
  connected: boolean;
}

// Cache model name to avoid repeated file reads
let cachedModel: string | undefined;

function getModelFromConfig(): string {
  if (cachedModel) return cachedModel;
  try {
    const config = JSON.parse(readFileSync(join(process.cwd(), "client", "config.json"), "utf-8"));
    cachedModel = config.model || "gpt-4.1";
  } catch {
    cachedModel = "gpt-4.1";
  }
  return cachedModel!;
}

/**
 * Get Copilot session information
 * 
 * Note: The CopilotClient doesn't expose user info via its API.
 * User identification comes from environment variables:
 * - COPILOT_USER (preferred) - Set this to override the default user
 * - USER (fallback) - System username from environment
 * 
 * To set a specific user: COPILOT_USER=your-username npm run query-rag ...
 */
export function getCopilotSessionInfo(_client: CopilotClient): CopilotAccountInfo {
  // Prefer COPILOT_USER env variable, fallback to USER
  let user: string | undefined;
  if (process.env.COPILOT_USER) {
    user = process.env.COPILOT_USER;
  } else if (process.env.USER) {
    user = process.env.USER;
  }
  return {
    timestamp: new Date().toISOString(),
    connected: true,
    user: user ? `@${user}` : undefined,
    model: getModelFromConfig()
  };
}

/**
 * Display account information (compact)
 */
export function displayAccountInfo(info: CopilotAccountInfo): void {
  const parts = [
    info.connected ? "✅ Connected" : "❌ Disconnected",
    info.user && `👤 ${info.user}`,
    info.model && `🤖 ${info.model}`
  ].filter(Boolean);
  
  console.log(`📊 Copilot: ${parts.join(" | ")}\n`);
}
