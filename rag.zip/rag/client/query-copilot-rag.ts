/**
 * Query RAG ChromaDB and pass query + RAG output to Copilot SDK
 * Usage:
 *   npm run query-rag "your query here" [--collection=name] [--n=number] [--instruction=filename]
 *   npx tsx client/query-copilot-rag.ts "Explain the rag setup guidelines"
 *   npx tsx client/query-copilot-rag.ts "Data architecture" --collection=ai-docs --n=15
 *   npx tsx client/query-copilot-rag.ts "System design" --collection=research --n=20 --instruction=high-level-design.instructions.md
 */

import { CopilotClient } from "@github/copilot-sdk";
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from "fs";
import { join } from "path";
import { getCopilotSessionInfo, displayAccountInfo } from "./account-info.js";

// Load configuration from JSON file with environment variable overrides
interface Config {
  model: string;
  ragApiUrl: string;
  defaultCollection: string | null;
  defaultNResults: number;
  outputFolder: string;
  instructionFolder: string;
  timeout: number;
}

function loadConfig(): Config {
  const configPath = join(process.cwd(), "client", "config.json");
  let fileConfig: Partial<Config> = {};
  
  try {
    fileConfig = JSON.parse(readFileSync(configPath, "utf-8"));
  } catch {
    console.warn("⚠️  Could not load client/config.json, using defaults");
  }
  
  // Environment variables override config file
  return {
    model: fileConfig.model || "gpt-4.1",
    ragApiUrl: process.env.RAG_API_URL || fileConfig.ragApiUrl || "http://localhost:8000",
    defaultCollection: process.env.RAG_COLLECTION || fileConfig.defaultCollection || null,
    defaultNResults: fileConfig.defaultNResults ?? 10,
    outputFolder: fileConfig.outputFolder || "./data/output",
    instructionFolder: fileConfig.instructionFolder || "./.github/instructions",
    timeout: fileConfig.timeout ?? 300000, // 5 minutes for large prompts with instructions
  };
}

const CONFIG = loadConfig();

function getModelName(): string {
  return CONFIG.model;
}

interface RAGResult {
  content: string;
  source: string;
  similarity: number;
  metadata: Record<string, any>;
}

interface RAGQueryResponse {
  query: string;
  collection: string;
  results: RAGResult[];
  total_results: number;
}

interface RAGDocument {
  rank: number;
  filename: string;
  relevance_score: number;
  content_preview: string;
  size: number;
}

interface ParsedArgs {
  query: string;
  instructionFile?: string;
  collection?: string;
  nResults?: number;
}

/**
 * Parse command line arguments
 */
function parseArgs(): ParsedArgs {
  const args = process.argv.slice(2);
  let query = "";
  let instructionFile: string | undefined;
  let collection: string | undefined;
  let nResults: number | undefined;

  for (const arg of args) {
    if (arg.startsWith("--instruction=")) {
      instructionFile = arg.slice(14); // "--instruction=".length
    } else if (arg.startsWith("--collection=")) {
      collection = arg.slice(13); // "--collection=".length
    } else if (arg.startsWith("--n=")) {
      const value = parseInt(arg.slice(4), 10);
      if (isNaN(value) || value < 1) {
        console.error(`❌ Error: --n must be a positive integer\n`);
        process.exit(1);
      }
      nResults = value;
    } else if (!arg.startsWith("--")) {
      query = query ? `${query} ${arg}` : arg;
    }
  }

  if (!query) {
    console.error("❌ Error: No query provided\n");
    console.log("Usage: npm run query-rag -- \"<query>\" [--collection=<name>] [--n=<number>] [--instruction=<filename>]");
    console.log("\nIMPORTANT: Note the '--' separator after 'query-rag' when using npm run!");
    console.log("\nExamples:");
    console.log("  npm run query-rag -- \"Explain the data architecture\"");
    console.log("  npm run query-rag -- \"Pipeline architecture\" --collection=ai-docs");
    console.log("  npm run query-rag -- \"AWS setup\" --collection=research --n=15");
    console.log("  npm run query-rag -- \"System design\" --collection=research --n=20 --instruction=high-level-design.instructions.md");
    console.log("\nOr use npx tsx directly:");
    console.log("  npx tsx client/query-copilot-rag.ts \"AWS setup\" --collection=research --n=15");
    console.log("\nOr set RAG_COLLECTION environment variable:");
    console.log("  RAG_COLLECTION=aws npm run query-rag -- \"AWS guidelines\"");
    console.log("\nAvailable instruction files:");
    listInstructionFiles();
    process.exit(1);
  }

  // Use environment variable as fallback for collection
  collection ??= CONFIG.defaultCollection ?? undefined;

  return { query, instructionFile, collection, nResults };
}

/**
 * List available instruction files
 */
function listInstructionFiles(): void {
  const instructionPath = join(process.cwd(), CONFIG.instructionFolder);
  if (!existsSync(instructionPath)) {
    console.log("  (Instruction folder not found)");
    return;
  }
  const files = readdirSync(instructionPath).filter(f => f.endsWith(".md"));
  if (files.length === 0) {
    console.log("  (No instruction files found)");
    return;
  }
  files.forEach(f => console.log(`  - ${f}`));
}

/**
 * Load instruction file content
 */
function loadInstruction(filename: string): string {
  const instructionPath = join(process.cwd(), CONFIG.instructionFolder, filename);
  
  if (!existsSync(instructionPath)) {
    console.error(`❌ Error: Instruction file not found: ${instructionPath}`);
    console.log("\nAvailable instruction files:");
    listInstructionFiles();
    process.exit(1);
  }

  const content = readFileSync(instructionPath, "utf-8");
  console.log(`📋 Loaded instruction: ${filename} (${content.length} chars)\n`);
  return content;
}

interface RAGRequestBody {
  query: string;
  n_results: number;
  collection_name?: string;
}

/**
 * Query RAG database via API
 */
async function queryRAG(query: string, nResults: number = CONFIG.defaultNResults, collection?: string): Promise<RAGQueryResponse> {
  console.log(`\n🔍 Querying RAG database...`);
  console.log(`   Query: "${query}"`);
  console.log(`   Max results: ${nResults}`);
  if (collection) console.log(`   Collection: ${collection}`);
  console.log();

  const body: RAGRequestBody = { query, n_results: nResults };
  if (collection) body.collection_name = collection;

  const response = await fetch(`${CONFIG.ragApiUrl}/query`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    throw new Error(`RAG API failed: ${response.status} - ${await response.text()}`);
  }

  return response.json() as Promise<RAGQueryResponse>;
}

/**
 * Convert RAG API response to document format
 */
function convertToDocuments(ragResults: RAGQueryResponse): RAGDocument[] {
  return ragResults.results.map((result, index) => ({
    rank: index + 1,
    filename: result.source,
    relevance_score: result.similarity,
    content_preview: result.content,
    size: result.content.length
  }));
}

/**
 * Display RAG search results
 */
function displayRAGResults(ragResults: RAGQueryResponse): void {
  console.log("📊 RAG Search Results:");
  console.log("─".repeat(60));
  console.log(`   Query: "${ragResults.query}"`);
  console.log(`   Collection: ${ragResults.collection}`);
  console.log(`   Documents found: ${ragResults.total_results}`);
  console.log("─".repeat(60));

  if (ragResults.total_results === 0) {
    console.log("\n❌ No relevant documents found.");
    process.exit(1);
  }

  console.log("\n📄 Retrieved Documents:\n");
  ragResults.results.forEach((result, index) => {
    console.log(`   ${index + 1}. ${result.source}`);
    console.log(`      Relevance: ${result.similarity.toFixed(3)} | Size: ${result.content.length} chars`);
  });
  console.log();
}

/**
 * Build prompt with RAG context and optional instruction
 */
function buildPrompt(query: string, documents: RAGDocument[], instruction?: string): string {
  let documentsContext = "";
  
  documents.forEach((doc, index) => {
    documentsContext += `\n### Source Document ${index + 1}: ${doc.filename}\n`;
    documentsContext += `Relevance Score: ${doc.relevance_score.toFixed(3)}\n\n`;
    documentsContext += `\`\`\`\n${doc.content_preview}\n\`\`\`\n`;
  });

  // If instruction is provided, use it as the template
  if (instruction) {
    return `${instruction}

---

## User Query / Topic
${query}

---

## Source Documents from RAG Database (${documents.length} documents)

The following documents were retrieved from the RAG database as relevant sources.
Analyze these thoroughly to extract system details, components, data entities, flows, and architecture patterns.

${documentsContext}

---

## Generate Output

Based on the instruction template above and the source documents provided, generate a comprehensive response.
Infer missing details using best practices and clearly mark assumptions.`;
  }

  // Default prompt without instruction
  return `You are a helpful AI assistant with expertise in software architecture and technical documentation. Use the following context from relevant documents to answer the user's question accurately and comprehensively.

CONTEXT FROM RELEVANT DOCUMENTS (${documents.length} documents):
${documentsContext}

---

USER QUESTION:
${query}

---

INSTRUCTIONS:
- Base your answer primarily on the provided context from the documents
- Cite specific documents when referencing information (e.g., "According to [document name]...")
- If the context doesn't contain enough information to fully answer the question, acknowledge this limitation
- Provide a clear, well-structured response with proper formatting
- Use bullet points or numbered lists when appropriate
- Include code examples or technical details from the documents when relevant

Please provide a comprehensive answer:`;
}

/**
 * Run Copilot query with RAG context
 */
async function runCopilotQuery(prompt: string, client: CopilotClient): Promise<string> {
  const session = await client.createSession({ 
    model: getModelName(), 
    streaming: true 
  });

  try {
    let charCount = 0;
    
    // Listen to streaming events
    session.on("assistant.message_delta", (event) => {
      charCount += event.data.deltaContent.length;
      if (charCount % 100 === 0) process.stdout.write(".");
    });

    // Send and wait for completion
    const result = await session.sendAndWait({ prompt }, CONFIG.timeout);
    return result?.data?.content || "No response generated";
  } finally {
    // Clean up session
    await session.destroy();
  }
}

/**
 * Ensure output folder exists
 */
function ensureOutputFolder(): void {
  if (!existsSync(CONFIG.outputFolder)) {
    mkdirSync(CONFIG.outputFolder, { recursive: true });
  }
}

/**
 * Generate output filename from query
 */
function generateOutputFilename(query: string): string {
  const sanitized = query
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, "-")
    .substring(0, 40);
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  return `rag-query-${sanitized}-${timestamp}.md`;
}

/**
 * Save output with metadata
 */
function saveOutput(
  filename: string,
  content: string,
  documents: RAGDocument[],
  query: string,
  model: string,
  instructionFile?: string
): void {
  const outputPath = join(CONFIG.outputFolder, filename);
  
  const sourceDocs = documents
    .map((doc, idx) => `  ${idx + 1}. ${doc.filename} (relevance: ${doc.relevance_score.toFixed(3)})`)
    .join("\n");
  
  const instructionInfo = instructionFile ? `**Instruction Template:** ${instructionFile}  \n` : '';
  
  const metadata = `# RAG + Copilot Query Response

---

**Generated:** ${new Date().toISOString()}  
**Query:** ${query}  
**Model:** ${model}  
${instructionInfo}**RAG Documents Used:** ${documents.length}  
**API Endpoint:** ${CONFIG.ragApiUrl}

## Source Documents

${sourceDocs}

---

## Response

${content}

---

*Generated by RAG + GitHub Copilot Query Tool*
`;
  
  writeFileSync(outputPath, metadata, "utf-8");
  console.log(`\n\n${"═".repeat(60)}`);
  console.log(`✅ Response saved to: ${outputPath}`);
  console.log(`   Size: ${((metadata.length) / 1024).toFixed(1)} KB`);
  console.log(`${"═".repeat(60)}`);
}

/**
 * Main function
 */
async function main() {
  console.log("\n" + "═".repeat(60));
  console.log("  🤖 RAG + GitHub Copilot Query Tool");
  console.log("  Query ChromaDB and get AI-powered responses");
  console.log("═".repeat(60) + "\n");

  // Parse command line arguments
  const { query, instructionFile, collection, nResults } = parseArgs();
  const model = getModelName();
  const numResults = nResults || CONFIG.defaultNResults;

  console.log(`📝 Query: "${query}"`);
  console.log(`🤖 Model: ${model}`);
  console.log(`🌐 RAG API: ${CONFIG.ragApiUrl}`);
  console.log(`📊 Max Results: ${numResults}`);
  if (collection) {
    console.log(`📚 Collection: ${collection}`);
  }
  if (instructionFile) {
    console.log(`📋 Instruction: ${instructionFile}`);
  }
  console.log();

  // Load instruction if provided
  let instruction: string | undefined;
  if (instructionFile) {
    instruction = loadInstruction(instructionFile);
  }

  // Create client - auto-starts CLI server
  const client = new CopilotClient();
  
  try {
    // Step 1: Query RAG database
    const ragResults = await queryRAG(query, numResults, collection);
    displayRAGResults(ragResults);

    // Convert to document format
    const documents = convertToDocuments(ragResults);

    // Step 2: Build prompt with RAG context and optional instruction
    const prompt = buildPrompt(query, documents, instruction);
    console.log(`📊 Prompt size: ${(prompt.length / 1024).toFixed(1)} KB\n`);

    // Ensure output folder exists
    ensureOutputFolder();

    // Step 3: Create Copilot session
    console.log("🔌 Creating Copilot session...\n");
    displayAccountInfo(getCopilotSessionInfo(client));

    console.log("🤖 Generating response with Copilot...\n");

    // Step 4: Get Copilot response
    const response = await runCopilotQuery(prompt, client);

    console.log(" Done!");
    console.log(`\n📝 Response generated: ${response.length} characters\n`);

    // Step 5: Save to file
    const outputFilename = generateOutputFilename(query);
    saveOutput(outputFilename, response, documents, query, model, instructionFile);
  } catch (error) {
    console.error("\n❌ Error:", error instanceof Error ? error.message : String(error));
    if (error instanceof Error && error.stack) {
      console.error("\nStack trace:", error.stack);
    }
    process.exit(1);
  } finally {
    // Clean up - stop client
    await client.stop();
  }
}

main();
