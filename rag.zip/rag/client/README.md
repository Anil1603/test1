# CaaS Client

📖 **[Server Setup Guide → ../RUNBOOK.md](../RUNBOOK.md#server-commands)** - How to start servers with backend selection

GitHub Copilot SDK integration for querying RAG database and generating AI-powered responses.

## Overview

The CaaS client queries the RAG database and passes the retrieved context to GitHub Copilot SDK to generate comprehensive, context-aware answers.

## Files

- `query-copilot-rag.ts` - Main query script that integrates RAG + Copilot SDK
- `account-info.ts` - Helper for displaying Copilot session information

## Usage

### Basic Query

```bash
npm run query-rag -- "your question here"
```

### Query with Collection

```bash
npm run query-rag -- "your question" --collection=ai-docs
```

### Query with Instruction Template

```bash
npm run query-rag -- "Data architecture" --instruction=high-level-design.instructions.md
```

### Query with Collection and Instruction

```bash
npm run query-rag -- "explain order flow, zipcode selection and how to handle multiseller basket or order and split payment" --collection=ecomm --instruction=high-level-design.instructions.md
```

### Direct Execution

```bash
npx tsx client/query-copilot-rag.ts "Explain the RAG setup"
npx tsx client/query-copilot-rag.ts "API architecture" --collection=api-docs
npx tsx client/query-copilot-rag.ts "System design" --collection=docs --instruction=high-level-design.instructions.md
```

## How It Works

1. **Query RAG Database** - Retrieves relevant documents from ChromaDB
2. **Build Prompt** - Combines RAG results with optional instruction template
3. **Call Copilot SDK** - Sends prompt to GitHub Copilot for response generation
4. **Save Output** - Writes formatted markdown response to `./data/output/`

## Configuration

### Environment Variables

```bash
RAG_API_URL=http://localhost:8000  # RAG API endpoint
```

### package.json

```json
{
  "model": "gpt-4.1"  // Copilot model to use
}
```

## Instruction Templates

Place instruction files in `.github/instructions/`:
- `high-level-design.instructions.md` - Generate HLD documents
- Custom templates for specific document types

The script will:
- List available instructions if no query provided
- Load and apply instruction template to RAG context
- Pass combined prompt to Copilot

## Output

Responses are saved to `./data/output/` with:
- Timestamp and query metadata
- Source documents used
- Model and configuration info
- Full Copilot response

Example: `rag-query-data-architecture-2026-01-21T10-30-00.md`

## Requirements

- Node.js 18+
- GitHub Copilot SDK access
- Running RAG API server (`python servers/api.py`)

## Examples

```bash
# Architecture documentation
npm run query-rag "Explain the system architecture" --instruction=high-level-design.instructions.md

# Query specific collection
npm run query-rag "Authentication flow" --collection=api-docs

# Technical queries
npm run query-rag "How does ChromaDB work?"

# Code-related questions with collection
npm run query-rag "Explain the ingestion pipeline" --collection=codebase

# Complex query with collection and instruction
npm run query-rag "Data pipeline design" --collection=architecture --instruction=high-level-design.instructions.md
```
