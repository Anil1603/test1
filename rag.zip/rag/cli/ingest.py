#!/usr/bin/env python3
"""
RAG Database CLI - Ingest Command

Ingest documents into the RAG database.

Usage:
    python cli/ingest.py <path> [--collection <name>] [--chunk-size <n>] [--reset]
"""

import sys
import os
import argparse

# Add rag-database to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rag-database"))

from src.database import RagDatabase
from src.ingestion import DocumentProcessor


def main():
    parser = argparse.ArgumentParser(
        description="Ingest documents into the RAG database",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python cli/ingest.py ./documents
    python cli/ingest.py ./docs --collection research
    python cli/ingest.py paper.pdf --collection papers --chunk-size 500
    python cli/ingest.py ./data --reset --collection fresh_start
        """
    )
    parser.add_argument("path", help="Path to file or directory to ingest")
    parser.add_argument("--collection", "-c", help="Target collection name")
    parser.add_argument("--chunk-size", type=int, default=1000, help="Chunk size (default: 1000)")
    parser.add_argument("--chunk-overlap", type=int, default=200, help="Chunk overlap (default: 200)")
    parser.add_argument("--reset", action="store_true", help="Reset collection before ingesting")
    
    args = parser.parse_args()
    
    path = os.path.expanduser(args.path)
    if not os.path.exists(path):
        print(f"❌ Path not found: {path}")
        sys.exit(1)
    
    # Initialize
    db = RagDatabase()
    processor = DocumentProcessor(chunk_size=args.chunk_size, chunk_overlap=args.chunk_overlap)
    
    collection_name = args.collection.strip() if args.collection else None
    
    # Reset if requested
    if args.reset and collection_name:
        print(f"🗑️  Resetting collection '{collection_name}'...")
        db.delete_collection(collection_name)
    
    # Load documents
    print(f"📂 Loading documents from: {path}")
    if os.path.isfile(path):
        docs = [processor.load_file(path)]
        docs = [d for d in docs if d is not None]
    else:
        docs = processor.load_directory(path)
    
    if not docs:
        print("❌ No valid documents found")
        sys.exit(1)
    
    print(f"📄 Found {len(docs)} document(s)")
    
    # Process and ingest
    documents, metadatas, ids = processor.process_documents(docs)
    db.add_documents(documents, metadatas, ids, collection_name=collection_name)
    
    target = collection_name or db.default_collection_name
    print(f"✅ Ingested {len(docs)} files ({len(documents)} chunks) into '{target}'")


if __name__ == "__main__":
    main()
