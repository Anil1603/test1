#!/usr/bin/env python3
"""
RAG Database CLI - Stats Command

Display RAG database statistics.

Usage:
    python cli/stats.py [--collection <name>] [--json]
"""

import sys
import os
import argparse

# Add rag-database to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rag-database"))

from src.database import RagDatabase


def main():
    parser = argparse.ArgumentParser(
        description="Display RAG database statistics",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python cli/stats.py
    python cli/stats.py --collection research
    python cli/stats.py --json
        """
    )
    parser.add_argument("--collection", "-c", help="Show stats for specific collection")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Initialize
    db = RagDatabase()
    
    if args.collection:
        # Single collection stats
        collection_name = args.collection.strip()
        count = db.get_collection_count(collection_name)
        
        if args.json:
            import json
            print(json.dumps({
                "collection": collection_name,
                "document_count": count
            }, indent=2))
        else:
            print(f"\n📚 Collection: {collection_name}")
            print(f"📄 Documents: {count}")
    else:
        # All collections stats
        stats = db.get_all_collections_stats()
        
        if args.json:
            import json
            print(json.dumps(stats, indent=2))
        else:
            print("\n📊 RAG Database Statistics")
            print("=" * 40)
            print(f"Total Documents: {stats['total_documents']}")
            print(f"Total Collections: {stats['total_collections']}")
            print(f"Default Collection: {stats['default_collection']}")
            print(f"Embedding Model: {stats['embedding_model']}")
            print(f"Storage: {stats['persist_directory']}")
            print()
            print("Collections:")
            for col in stats["collections"]:
                print(f"  • {col['name']}: {col['document_count']} documents")
            print()


if __name__ == "__main__":
    main()
