#!/usr/bin/env python3
"""
RAG Database CLI - Query Command

Query the RAG database for similar documents.

Usage:
    python cli/query.py "your query" [--collection <name>] [--n <results>]
"""

import sys
import os
import argparse

# Add rag-database to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rag-database"))

from src.database import RagDatabase


def main():
    parser = argparse.ArgumentParser(
        description="Query the RAG database",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python cli/query.py "What is RAG?"
    python cli/query.py "machine learning" --collection research --n 10
    python cli/query.py "authentication flow" -c api-docs
        """
    )
    parser.add_argument("query", help="Search query text")
    parser.add_argument("--collection", "-c", help="Collection to query")
    parser.add_argument("--n", type=int, default=5, help="Number of results (default: 5)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    # Initialize
    db = RagDatabase()
    collection_name = args.collection.strip() if args.collection else None
    
    # Query
    results = db.query(args.query, n_results=args.n, collection_name=collection_name)
    
    if not results.get("documents") or not results["documents"][0]:
        print(f"No results found for: {args.query}")
        sys.exit(0)
    
    target = collection_name or db.default_collection_name
    
    if args.json:
        import json
        output = {
            "query": args.query,
            "collection": target,
            "results": []
        }
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ):
            output["results"].append({
                "content": doc,
                "source": meta.get("source", "unknown"),
                "similarity": round(1 - dist, 4),
                "metadata": meta
            })
        print(json.dumps(output, indent=2))
    else:
        print(f"\n🔍 Query: \"{args.query}\"")
        print(f"📚 Collection: {target}")
        print(f"📊 Results: {len(results['documents'][0])}\n")
        print("=" * 60)
        
        for i, (doc, meta, dist) in enumerate(zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ), 1):
            similarity = 1 - dist
            source = meta.get("source", "unknown")
            print(f"\n[{i}] {source} ({similarity:.1%} match)")
            print("-" * 40)
            # Truncate long content
            content = doc[:500] + "..." if len(doc) > 500 else doc
            print(content)
            print()


if __name__ == "__main__":
    main()
