#!/usr/bin/env python3
"""
RAG Database MCP Server

Model Context Protocol server for VS Code GitHub Copilot integration.

Usage:
    python servers/rag_mcp_server.py [--chroma-db-path PATH]
    
    Or via MCP Inspector:
    npx @modelcontextprotocol/inspector python servers/rag_mcp_server.py [--chroma-db-path PATH]
    
Arguments:
    --chroma-db-path: Path to ChromaDB persist directory (default: rag-database/data/chromadb)
"""

import sys
import os
import json
import ssl
import certifi
import importlib.util
import argparse

# Parse command line arguments
parser = argparse.ArgumentParser(description='RAG Database MCP Server')
parser.add_argument(
    '--chroma-db-path',
    type=str,
    default=None,
    help='Path to ChromaDB persist directory (default: rag-database/data/chromadb)'
)
args = parser.parse_args()

# SSL workarounds for macOS
os.environ['SSL_CERT_FILE'] = certifi.where()
os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()

# Get backend type from environment variable
RAG_DB_TYPE = os.getenv("RAG_DB_TYPE", "chromadb").lower()
if RAG_DB_TYPE not in ["chromadb", "postgresql"]:
    print(f"❌ Invalid RAG_DB_TYPE: {RAG_DB_TYPE}. Using 'chromadb' as default.")
    RAG_DB_TYPE = "chromadb"

print(f"🔌 Backend: {RAG_DB_TYPE.upper()}")

# Add rag-database to path
rag_db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rag-database")
sys.path.insert(0, rag_db_path)
sys.path.insert(0, os.path.join(rag_db_path, RAG_DB_TYPE))
sys.path.insert(0, os.path.join(rag_db_path, "common"))

from mcp.server.fastmcp import FastMCP

# Dynamically import the correct backend database module
database_module_path = os.path.join(rag_db_path, RAG_DB_TYPE, "database.py")
spec = importlib.util.spec_from_file_location("database", database_module_path)
database_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(database_module)
RagDatabase = database_module.RagDatabase

from ingestion import DocumentProcessor

# Initialize MCP server
mcp = FastMCP("rag-server")


def load_config():
    """Load configuration from config.json."""
    # Check for custom config path from environment
    custom_config = os.getenv("RAG_DB_CONFIG")
    
    if custom_config and os.path.exists(custom_config):
        config_path = custom_config
        print(f"📄 Using custom config: {config_path}")
    else:
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "rag-database", RAG_DB_TYPE, "config.json"
        )
    
    # Default persist directory for ChromaDB
    default_persist_dir = args.chroma_db_path if args.chroma_db_path else os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "rag-database", "data", "chromadb"
    )
    
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Override persist_directory with CLI argument if provided and backend is ChromaDB
        if RAG_DB_TYPE == "chromadb" and args.chroma_db_path:
            if 'database' not in config:
                config['database'] = {}
            config['database']['persist_directory'] = os.path.abspath(args.chroma_db_path)
            print(f"📁 Using ChromaDB path from CLI: {args.chroma_db_path}")
        elif RAG_DB_TYPE == "chromadb" and 'database' in config and 'persist_directory' in config['database']:
            # Convert relative path to absolute path based on config file location
            persist_dir = config['database']['persist_directory']
            if not os.path.isabs(persist_dir):
                # Resolve relative to the config file's directory
                config_dir = os.path.dirname(config_path)
                config['database']['persist_directory'] = os.path.abspath(os.path.join(config_dir, persist_dir))
        
        return config
    
    # Default config if file not found (ChromaDB only)
    if RAG_DB_TYPE == "chromadb":
        return {
            "database": {
                "persist_directory": os.path.abspath(default_persist_dir),
                "collection_name": "poc"
            }
        }
    else:
        raise Exception(f"PostgreSQL backend requires config.json at {config_path}")


config = load_config()

# Initialize database and processor with config
if RAG_DB_TYPE == "chromadb":
    db = RagDatabase(
        persist_directory=config.get('database', {}).get('persist_directory', config.get('persist_directory')),
        collection_name=config.get('database', {}).get('collection_name', config.get('collection_name', 'poc'))
    )
else:  # postgresql
    db = RagDatabase(config=config)

processor = DocumentProcessor()


@mcp.tool()
def query_rag(query: str, n_results: int = 5, collection_name: str = None) -> str:
    """
    Query the RAG database for relevant documents.
    Returns the most similar documents based on semantic search.
    
    Args:
        query: Search query
        n_results: Number of results to return (default: 5)
        collection_name: Name of the collection to query (default: uses default collection from config)
    """
    try:
        # Use provided collection or default from config
        collection = collection_name.strip() if collection_name else config['database']['collection_name']
        
        # Validate collection exists
        all_collections = [col.name for col in db.client.list_collections()]
        if collection not in all_collections:
            available = ", ".join(all_collections) if all_collections else "none"
            return f"❌ Collection '{collection}' not found. Available collections: {available}"
        
        results = db.query(query, n_results=n_results, collection_name=collection)
        
        if not results.get("documents") or not results["documents"][0]:
            return f"No results found for query: {query}"
        
        output = []
        for i, (doc, meta, dist) in enumerate(zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ), 1):
            similarity = 1 - dist
            source = meta.get("source", "unknown")
            output.append(f"[{i}] Source: {source} (similarity: {similarity:.2%})\n{doc}\n")
        
        return f"Found {len(results['documents'][0])} results for '{query}':\n\n" + "\n---\n".join(output)
    
    except Exception as e:
        return f"Error querying database: {str(e)}"


@mcp.tool()
def rag_ask_copilot(question: str, n_results: int = 5, collection_name: str = None) -> str:
    """
    Query RAG database and use GitHub Copilot to generate a contextual answer 
    based on retrieved documents. This combines semantic search with AI to 
    provide accurate, context-aware responses.
    
    Args:
        question: Question to answer
        n_results: Number of documents to retrieve (default: 5)
        collection_name: Name of the collection to query (default: uses default collection from config)
    """
    try:
        # Use provided collection or default from config
        collection = collection_name.strip() if collection_name else config.get('database', {}).get('collection_name', config.get('collection_name', 'poc'))
        
        # Validate collection exists (ChromaDB only)
        if RAG_DB_TYPE == "chromadb":
            all_collections = [col.name for col in db.client.list_collections()]
            if collection not in all_collections:
                available = ", ".join(all_collections) if all_collections else "none"
                return f"❌ Collection '{collection}' not found. Available collections: {available}"
        
        results = db.query(question, n_results=n_results, collection_name=collection)
        
        if not results.get("documents") or not results["documents"][0]:
            return f"No relevant documents found for: {question}"
        
        # Build context from retrieved documents
        context_parts = []
        for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
            source = meta.get("source", "unknown")
            context_parts.append(f"[Source: {source}]\n{doc}")
        
        context = "\n\n---\n\n".join(context_parts)
        
        return f"""Based on the following context from {len(results['documents'][0])} documents, answer: {question}

CONTEXT:
{context}

Please provide a comprehensive answer based on the above context."""
    
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.tool()
def ingest_documents(directory: str, collection_name: str = None) -> str:
    """
    Ingest documents from a directory into the RAG database.
    Supports .txt, .md, .pdf, .docx, .py, .json, .css, .js, and .html files.
    
    Args:
        directory: Path to the directory containing documents
        collection_name: Name of the collection to add documents to (default: uses default collection from config)
    """
    try:
        path = os.path.expanduser(directory)
        if not os.path.exists(path):
            return f"❌ Directory not found: {path}"
        
        collection = collection_name.strip() if collection_name else config.get('database', {}).get('collection_name', config.get('collection_name', 'poc'))
        
        # Load and process documents
        if os.path.isfile(path):
            docs = [processor.load_file(path)]
            docs = [d for d in docs if d is not None]
        else:
            docs = processor.load_directory(path)
        
        if not docs:
            return f"No valid documents found in: {path}"
        
        # Process and add to database
        documents, metadatas, ids = processor.process_documents(docs)
        db.add_documents(documents, metadatas, ids, collection_name=collection)
        
        return f"✅ Successfully ingested {len(docs)} files ({len(documents)} chunks) into collection '{collection}'"
    
    except Exception as e:
        return f"Error ingesting documents: {str(e)}"


@mcp.tool()
def add_document(content: str, source: str = "manual", filename: str = "document.txt", collection_name: str = None) -> str:
    """
    Add a single document with text content to the RAG database.
    
    Args:
        content: Document text content
        source: Source identifier (default: "manual")
        filename: Filename for the document (default: "document.txt")
        collection_name: Name of the collection to add the document to (default: uses default collection from config)
    """
    try:
        collection = collection_name.strip() if collection_name else config.get('database', {}).get('collection_name', config.get('collection_name', 'poc'))
        
        # Chunk the content
        chunks = processor.chunk_text(content)
        
        documents = []
        metadatas = []
        ids = []
        
        for i, chunk in enumerate(chunks):
            documents.append(chunk)
            metadatas.append({
                "source": source,
                "filename": filename,
                "chunk_index": i,
                "total_chunks": len(chunks)
            })
            import hashlib
            ids.append(hashlib.md5(f"{filename}_{i}_{chunk[:50]}".encode()).hexdigest())
        
        db.add_documents(documents, metadatas, ids, collection_name=collection)
        
        return f"✅ Added document '{filename}' ({len(chunks)} chunks) to collection '{collection}'"
    
    except Exception as e:
        return f"Error adding document: {str(e)}"


@mcp.tool()
def get_database_stats() -> str:
    """
    Get statistics about the RAG database including document count per collection.
    Returns detailed stats for each collection and overall database information.
    """
    try:
        stats = db.get_all_collections_stats()
        
        output = [
            f"📊 RAG Database Statistics",
            f"Backend: {RAG_DB_TYPE.upper()}",
            f"{'=' * 40}",
            f"Total Documents: {stats['total_documents']}",
            f"Total Collections: {stats['total_collections']}",
            f"Default Collection: {stats['default_collection']}",
            f"Embedding Model: {stats['embedding_model']}",
            f"",
            f"Collections:"
        ]
        
        for col in stats["collections"]:
            output.append(f"  • {col['name']}: {col['document_count']} documents")
        
        return "\n".join(output)
    
    except Exception as e:
        return f"Error getting stats: {str(e)}"


@mcp.tool()
def reset_database() -> str:
    """
    Clear all documents from the RAG database.
    This will permanently delete all stored documents and embeddings.
    """
    try:
        db.reset_database()
        return "✅ Database reset successfully. All collections have been cleared."
    except Exception as e:
        return f"Error resetting database: {str(e)}"


if __name__ == "__main__":
    print(f"🚀 Backend: {RAG_DB_TYPE.upper()}")
    if hasattr(db, 'persist_directory'):
        absolute_path = os.path.abspath(db.persist_directory)
        print(f"📁 Database: {absolute_path}")
        if args.chroma_db_path:
            print(f"   (from CLI argument)")
        else:
            print(f"   (from config file)")
        print(f"📚 Default collection: {db.default_collection_name}")
    else:
        print(f"🗄️  PostgreSQL Database: {config.get('postgres', {}).get('database', 'N/A')}")
        print(f"📚 Default collection: {db.default_collection_name}")
    mcp.run()
