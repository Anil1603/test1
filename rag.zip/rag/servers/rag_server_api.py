#!/usr/bin/env python3
"""
RAG Database REST API Server

FastAPI server exposing the RAG database via HTTP endpoints.

Usage:
    python servers/api.py [--port 8000] [--reload]
"""

import sys
import os
import argparse
import importlib.util
from typing import Optional, List
from contextlib import asynccontextmanager

# Get backend type from environment variable
RAG_DB_TYPE = os.getenv("RAG_DB_TYPE", "chromadb").lower()
if RAG_DB_TYPE not in ["chromadb", "postgresql"]:
    print(f"❌ Invalid RAG_DB_TYPE: {RAG_DB_TYPE}. Using 'chromadb' as default.")
    RAG_DB_TYPE = "chromadb"

# Add rag-database to path
rag_db_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rag-database")
sys.path.insert(0, rag_db_path)
sys.path.insert(0, os.path.join(rag_db_path, RAG_DB_TYPE))
sys.path.insert(0, os.path.join(rag_db_path, "common"))

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# Dynamically import the correct backend database module
database_module_path = os.path.join(rag_db_path, RAG_DB_TYPE, "database.py")
spec = importlib.util.spec_from_file_location("database", database_module_path)
database_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(database_module)
RagDatabase = database_module.RagDatabase

# Import ingestion from common
from ingestion import DocumentProcessor

# Global instances
db: Optional[RagDatabase] = None
processor: Optional[DocumentProcessor] = None
persist_directory_override: Optional[str] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize database on startup."""
    global db, processor
    
    # Check for custom config path from environment
    custom_config = os.getenv("RAG_DB_CONFIG")
    
    # Load config based on backend type
    if custom_config and os.path.exists(custom_config):
        config_path = custom_config
        print(f"📄 Using custom config: {config_path}")
    else:
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "rag-database", RAG_DB_TYPE, "config.json"
        )
    
    if os.path.exists(config_path):
        import json
        with open(config_path, 'r') as f:
            config = json.load(f)
        print(f"✅ Loaded config from: {config_path}")
    else:
        print(f"⚠️  Config not found at {config_path}, using defaults")
        # Default config for ChromaDB
        if RAG_DB_TYPE == "chromadb":
            # Use command-line arg if provided, otherwise default
            default_persist_dir = persist_directory_override or os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "rag-database", "data"
            )
            config = {
                "database": {
                    "persist_directory": default_persist_dir,
                    "collection_name": "poc"
                }
            }
        else:
            raise Exception(f"PostgreSQL backend requires config.json at {config_path}")
    
    # Initialize database based on backend type
    print(f"🔌 Initializing {RAG_DB_TYPE.upper()} backend...")
    
    if RAG_DB_TYPE == "chromadb":
        # Override persist_directory if provided via command-line
        persist_dir = persist_directory_override or config.get('database', {}).get('persist_directory', config.get('persist_directory'))
        db = RagDatabase(
            persist_directory=persist_dir,
            collection_name=config.get('database', {}).get('collection_name', config.get('collection_name', 'poc'))
        )
        print(f"✅ ChromaDB initialized: {db.persist_directory}")
        print(f"📚 Default collection: {db.default_collection_name}")
    else:  # postgresql
        db = RagDatabase(config_path=config_path)
        print(f"✅ PostgreSQL backend initialized")
        print(f"🗄️  Database: {config.get('postgres', {}).get('database', 'N/A')}")
        print(f"🔌 Host: {config.get('postgres', {}).get('host', 'N/A')}")
    
    processor = DocumentProcessor()
    yield
    print("👋 Shutting down RAG API server")


app = FastAPI(
    title="RAG Database API",
    description="REST API for RAG database operations - query, ingest, and manage documents",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============== Request/Response Models ==============

class QueryRequest(BaseModel):
    query: str = Field(..., description="Search query text")
    n_results: int = Field(default=5, ge=1, le=100, description="Number of results")
    collection_name: Optional[str] = Field(default=None, description="Collection to query")


class QueryResult(BaseModel):
    content: str
    source: str
    similarity: float
    metadata: dict


class QueryResponse(BaseModel):
    query: str
    collection: str
    results: List[QueryResult]
    total_results: int


class IngestRequest(BaseModel):
    documents_path: str = Field(..., description="Path to documents directory or file")
    collection_name: Optional[str] = Field(default=None, description="Target collection")
    chunk_size: int = Field(default=1000, description="Chunk size for splitting")
    chunk_overlap: int = Field(default=200, description="Overlap between chunks")


class IngestResponse(BaseModel):
    status: str
    documents_ingested: int
    chunks_created: int
    collection: str
    path: str


class StatsResponse(BaseModel):
    total_documents: int
    total_collections: int
    default_collection: str
    embedding_model: str
    collections: List[dict]
    backend_type: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    database: str
    collections: int


# ============== API Endpoints ==============

@app.get("/", tags=["Info"])
async def root():
    """API information."""
    return {
        "name": "RAG Database API",
        "version": "1.0.0",
        "endpoints": {
            "GET /health": "Health check",
            "GET /stats": "Database statistics",
            "POST /query": "Query the database",
            "POST /ingest": "Ingest documents"
        }
    }


@app.get("/health", response_model=HealthResponse, tags=["Info"])
async def health():
    """Health check endpoint."""
    stats = db.get_all_collections_stats()
    db_location = db.persist_directory if hasattr(db, 'persist_directory') else f"{RAG_DB_TYPE} database"
    return HealthResponse(
        status="healthy",
        database=db_location,
        collections=stats["total_collections"]
    )


@app.get("/stats", response_model=StatsResponse, tags=["Database"])
async def get_stats():
    """Get database statistics."""
    stats = db.get_all_collections_stats()
    stats["backend_type"] = RAG_DB_TYPE
    return StatsResponse(
        total_documents=stats["total_documents"],
        total_collections=stats["total_collections"],
        default_collection=stats["default_collection"],
        embedding_model=stats["embedding_model"],
        collections=stats["collections"]
    )


@app.post("/query", response_model=QueryResponse, tags=["Query"])
async def query_database(request: QueryRequest):
    """
    Query the RAG database for similar documents.
    
    Returns semantically similar documents based on the query.
    """
    collection_name = request.collection_name.strip() if request.collection_name else None
    
    # Validate collection exists (ChromaDB only)
    if collection_name and RAG_DB_TYPE == "chromadb":
        all_collections = [col.name for col in db.client.list_collections()]
        if collection_name not in all_collections:
            raise HTTPException(
                status_code=404,
                detail=f"Collection '{collection_name}' not found. Available: {', '.join(all_collections)}"
            )
    
    try:
        results = db.query(
            query_text=request.query,
            n_results=request.n_results,
            collection_name=collection_name
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
    # Format results
    query_results = []
    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]
    
    for doc, meta, dist in zip(documents, metadatas, distances):
        query_results.append(QueryResult(
            content=doc,
            source=meta.get("source", "unknown"),
            similarity=round(1 - dist, 4),
            metadata=meta
        ))
    
    return QueryResponse(
        query=request.query,
        collection=collection_name or db.default_collection_name,
        results=query_results,
        total_results=len(query_results)
    )


@app.post("/ingest", response_model=IngestResponse, tags=["Ingestion"])
async def ingest_documents(request: IngestRequest):
    """
    Ingest documents from a directory or file into the database.
    
    Supports: .txt, .md, .pdf, .docx, .py, .json, .css, .js, .html
    """
    path = os.path.expanduser(request.documents_path)
    collection_name = request.collection_name.strip() if request.collection_name else None
    
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail=f"Path not found: {path}")
    
    # Validate chunk parameters
    if request.chunk_size <= 0:
        raise HTTPException(status_code=400, detail="chunk_size must be positive")
    if request.chunk_overlap < 0:
        raise HTTPException(status_code=400, detail="chunk_overlap cannot be negative")
    if request.chunk_overlap >= request.chunk_size:
        raise HTTPException(status_code=400, detail="chunk_overlap must be less than chunk_size")
    
    try:
        # Update processor settings
        processor.chunk_size = request.chunk_size
        processor.chunk_overlap = request.chunk_overlap
        
        # Load documents
        if os.path.isfile(path):
            docs = [processor.load_file(path)]
            docs = [d for d in docs if d is not None]
        else:
            docs = processor.load_directory(path)
        
        if not docs:
            raise HTTPException(status_code=400, detail="No valid documents found")
        
        # Process and add to database
        documents, metadatas, ids = processor.process_documents(docs)
        db.add_documents(documents, metadatas, ids, collection_name=collection_name)
        
        return IngestResponse(
            status="success",
            documents_ingested=len(docs),
            chunks_created=len(documents),
            collection=collection_name or db.default_collection_name,
            path=path
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/collection/{collection_name}", tags=["Database"])
async def delete_collection(collection_name: str):
    """Delete a collection from the database."""
    if RAG_DB_TYPE == "postgresql":
        raise HTTPException(
            status_code=501,
            detail="Collection deletion not supported for PostgreSQL backend"
        )
    
    collection_name = collection_name.strip()
    
    # Validate collection exists
    all_collections = [col.name for col in db.client.list_collections()]
    if collection_name not in all_collections:
        raise HTTPException(
            status_code=404,
            detail=f"Collection '{collection_name}' not found. Available: {', '.join(all_collections)}"
        )
    
    # Prevent deleting default collection
    if collection_name == db.default_collection_name:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete default collection '{collection_name}'"
        )
    
    try:
        if db.delete_collection(collection_name):
            return {"status": "success", "message": f"Collection '{collection_name}' deleted"}
        else:
            raise HTTPException(status_code=500, detail="Failed to delete collection")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def main():
    """Run the API server."""
    global persist_directory_override
    
    parser = argparse.ArgumentParser(description="RAG Database API Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument(
        "--chromadb-path",
        type=str,
        help="Path to ChromaDB persist directory (e.g., /path/to/data/chromadb)"
    )
    args = parser.parse_args()
    
    # Set global persist directory if provided
    if args.chromadb_path:
        persist_directory_override = os.path.abspath(os.path.expanduser(args.chromadb_path))
        print(f"📂 Using ChromaDB path: {persist_directory_override}")
    
    print(f"🚀 Starting RAG API server on http://{args.host}:{args.port}")
    uvicorn.run(
        "servers.api:app" if args.reload else app,
        host=args.host,
        port=args.port,
        reload=args.reload
    )


if __name__ == "__main__":
    main()
