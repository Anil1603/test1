"""
CaaS Servers

Multiple interfaces to access the RAG database:
- rag_server_api.py: FastAPI REST API server
- rag_mcp_server.py: MCP server for VS Code Copilot integration

Usage:
  # Start REST API server
  python3 servers/rag_server_api.py
  
  # Start MCP server (for VS Code)
  python3 servers/rag_mcp_server.py
  
  # Or use MCP Inspector for debugging
  npx @modelcontextprotocol/inspector python3 servers/rag_mcp_server.py
"""
