# CaaS Servers - RAG Database Interfaces

📖 **[Complete Command Reference → ../RUNBOOK.md](../RUNBOOK.md#server-commands)** - All server commands with backend selection

Multiple server interfaces to access the RAG database:
- **rag_mcp_server.py**: MCP (Model Context Protocol) server for VS Code Copilot integration
- **rag_server_api.py**: FastAPI REST API server for HTTP access

## 📋 Prerequisites

**Backend Selection:** Both servers support ChromaDB and PostgreSQL backends. Set with `RAG_DB_TYPE`:
```bash
export RAG_DB_TYPE=chromadb    # or postgresql
```
See [RUNBOOK.md - Backend Selection](../RUNBOOK.md#backend-selection) for details.

1. **Install RAG database dependencies first:**
   ```bash
   cd ../rag-database/chromadb    # or postgresql
   pip install -r requirements.txt
   ```

2. **Install server dependencies:**
   ```bash
   cd ../../servers
   pip install -r requirements.txt
   ```

3. **Ensure database is initialized and has data:**
   ```bash
   cd ../rag-database/chromadb    # or postgresql
   python3 setup.py
   ```

## 🚀 Usage
# ChromaDB backend (default)
RAG_DB_TYPE=chromadb python3 servers/rag_mcp_server.py

# PostgreSQL backend
RAG_DB_TYPE=postgresql 
### MCP Server (VS Code Copilot Integration)

Start the API server for GitHub Copilot integration:

```bash

python3 servers/rag_server_api.py --chromadb-path /Users/rahulvennapusa/Documents/codebase/automation-poc-workshop/automation-poc/rag/rag-database/data/chromadb --port 8000
```

Or use MCP Inspector for debugging:
```bash
npx @modelcontextprotocol/inspector python3 servers/rag_mcp_server.py
```

#### Available MCP Tools:

1. **query_rag** - Query the database for similar documents
2. **rag_ask_copilot** - Get AI-generated answers based on RAG context
3. **ingest_documents** - Add new documents to the database
4. **add_document** - Add a single text document
5. **get_database_stats** - View database statistics
6. **reset_database** - Clear all collections

### REST API Server

Start the FastAPI server:

```bash
# ChromaDB backend (default)
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py

# PostgreSQL backend
RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py

# Production mode with specific port
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py --host 0.0.0.0 --port 8000
```

Access the interactive API docs at: **http://localhost:8000/docs**

#### API Endpoints:

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API information |
| GET | `/health` | Health check |
| GET | `/stats` | Database statistics |
| POST | `/query` | Query similar documents |
| POST | `/ingest` | Ingest documents from path |
| DELETE | `/collection/{name}` | Delete a collection |

## 📊 Example API Usage

### Query Documents
```bash
curl -X POST "http://localhost:8000/query" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "AWS architecture",
    "n_results": 5,
    "collection_name": "aws"
  }'
```

### Ingest Documents
```bash
curl -X POST "http://localhost:8000/ingest" \
  -H "Content-Type: application/json" \
  -d '{
    "documents_path": "/path/to/documents",
    "collection_name": "aws",
    "chunk_size": 1000,
    "chunk_overlap": 200
  }'
```

### Get Statistics
```bash
curl "http://localhost:8000/stats"
```

## ⚙️ Configuration

Both servers load configuration from:
```
../rag-database/chromadb/config.json
```

Default configuration:
```json
{
  "database": {
    "persist_directory": "../rag-database/data/chromadb",
    "collection_name": "poc"
  }
}
```

## 🔧 Troubleshooting

### Import Errors
Make sure you're running from the correct directory:
```bash
cd /path/to/CaaS
python3 servers/rag_server_api.py
```

### Database Not Found
Check the paths in config.json and ensure the database exists:
```bash
ls -la rag-database/data/chromadb/
```

### Port Already in Use
Change the port for the REST API:
```bash
python3 servers/rag_server_api.py --port 8001
```

### SSL Certificate Errors
The servers include SSL workarounds for macOS. If issues persist, check:
```bash
python3 -c "import certifi; print(certifi.where())"
```

## 📝 Development

### Testing the MCP Server
```bash
# Use MCP Inspector
npx @modelcontextprotocol/inspector python3 servers/rag_mcp_server.py

# Test individual tools
# The inspector provides a UI to test each tool
```

### Testing the REST API
```bash
# Start server with auto-reload
python3 servers/rag_server_api.py --reload

# Access interactive docs
open http://localhost:8000/docs

# Run API tests
curl http://localhost:8000/health
```

## 🔐 Security Notes

- The REST API currently allows CORS from all origins (`*`) for development
- For production, restrict CORS in [rag_server_api.py](rag_server_api.py#L45-L51)
- Add authentication middleware if exposing publicly
- Validate all input paths to prevent directory traversal

## 📚 Additional Resources

- [MCP Documentation](https://modelcontextprotocol.io/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [ChromaDB Documentation](https://docs.trychroma.com/)

## 🆘 Support

For issues or questions:
1. Check the RAG database README: `../rag-database/README.md`
2. Review configuration in `config.json`
3. Check server logs for detailed error messages
