# CaaS Platform Runbook

**Complete Command Reference for Container-as-a-Service Platform**

This runbook contains all commands needed to set up, run, and maintain the CaaS platform with ChromaDB or PostgreSQL vector database backends.

---

## Table of Contents

- [Quick Start](#quick-start)
- [Backend Selection](#backend-selection)
- [Server Commands](#server-commands)
- [Database Setup](#database-setup)
- [Data Ingestion](#data-ingestion)
- [Query & Testing](#query--testing)
- [Client SDK Usage](#client-sdk-usage)
- [Configuration Files](#configuration-files)
- [Troubleshooting](#troubleshooting)

---

## Quick Start

**Minimum steps to get running:**

```bash
# 1. Navigate to inner CaaS directory (where requirements.txt is located)
# If you're at the workspace root, run:
cd rag

# Create a virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate


# 2. Install dependencies

pip install -r requirements.txt

# 3. Set up database (choose one)

# Option A: ChromaDB (quickest - single command)
cd rag-database/chromadb 
python3 ingest.py --docs-dir /Users/rahulvennapusa/Documents/codebase/automation-poc-workshop/confluence-pages-ecommerce --collection ecomm
cd ../..

# Option B: PostgreSQL (two steps - setup then ingest)
cd rag-database/postgresql
python3 setup.py  # First time only: creates DB + enables pgvector
python3 ingest.py --docs-dir ../../../confluence-pages --collection aws  # Load data
cd ../..

# 4. Start server from the CaaS/ directory (containing requirements.txt)
# Make sure you're in CaaS/ directory (if not, cd back: cd ../..)

# For ChromaDB backend:
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py --port 8000 --chromadb-path ../data/chromadb

# For PostgreSQL backend:
RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py --port 8000
```

---

## Starting Servers with Different Backends

### Option 1: Start Server with ChromaDB Backend

**Step-by-step process:**

1. **Navigate to inner CaaS directory (where requirements.txt and servers/ are located):**
   ```bash
   cd /path/to/CaaS/CaaS
   ```

2. **Install dependencies (first time only):**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up ChromaDB database (first time only):**
   ```bash
   cd rag-database/chromadb
   pip install -r requirements.txt
   python3 ingest.py --docs-dir ../../confluence-pages --collection aws
   cd ../..
   ```

4. **Start REST API server connected to ChromaDB:**
   ```bash
   RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py --port 8000
   ```
   
   **Or start MCP server connected to ChromaDB:**
   ```bash
   RAG_DB_TYPE=chromadb python3 servers/rag_mcp_server.py
   ```

5. **Verify connection:**
   ```bash
   # In another terminal
   curl http://localhost:8000/stats
   # Should show ChromaDB backend information
   ```

### Option 2: Start Server with PostgreSQL Backend

**Step-by-step process:**

1. **Navigate to inner CaaS directory (where requirements.txt and servers/ are located):**
   ```bash
   # From workspace root:
   cd CaaS
   ```

2. **Install dependencies (first time only):**
   ```bash
   pip install -r requirements.txt
   ```

3. **Ensure PostgreSQL is running:**
   ```bash
   # Check PostgreSQL status
   pg_isready
   # or
   brew services list | grep postgresql  # macOS
   sudo systemctl status postgresql      # Linux
   ```

4. **Set up PostgreSQL database (first time only):**
   ```bash
   cd rag-database/postgresql
   pip install -r requirements.txt
   
   # Edit config.json with your PostgreSQL credentials
   nano config.json  # or use your preferred editor
   
   # Initialize database (creates DB, enables pgvector extension)
   python3 setup.py
   
   # Load data
   python3 ingest.py --docs-dir ../../confluence-pages --collection aws
   cd ../..
   ```

5. **Start REST API server connected to PostgreSQL:**
   ```bash
   RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py --port 8000
   ```
   
   **Or start MCP server connected to PostgreSQL:**
   ```bash
   RAG_DB_TYPE=postgresql python3 servers/rag_mcp_server.py
   ```

6. **Verify connection:**
   ```bash
   # In another terminal
   curl http://localhost:8000/stats
   # Should show PostgreSQL backend information with connection details
   ```

### Option 3: Switch Between Backends

You can switch backends by simply changing the `RAG_DB_TYPE` environment variable:

```bash
# Currently running with ChromaDB? Stop server (Ctrl+C) and restart with PostgreSQL:
RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py --port 8000

# Or vice versa:
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py --port 8000
```

**Important:** The backend must have data already ingested. Switching backends doesn't migrate data automatically.

### Option 4: Using Custom Config Files

```bash
# ChromaDB with custom config
RAG_DB_TYPE=chromadb \
RAG_DB_CONFIG=/path/to/custom-chroma-config.json \
python3 servers/rag_server_api.py --port 8000

# PostgreSQL with custom config (e.g., production database)
RAG_DB_TYPE=postgresql \
RAG_DB_CONFIG=./rag-database/postgresql/prod-config.json \
python3 servers/rag_server_api.py --port 8000
```

---

## Backend Selection

The CaaS platform supports two vector database backends. Choose based on your requirements:

### ChromaDB (Default)
- **Use Case**: Local development, prototyping, smaller datasets
- **Pros**: Zero infrastructure, fast setup, file-based persistence
- **Cons**: Single-machine only, limited scalability

### PostgreSQL + pgvector
- **Use Case**: Production deployments, multi-user access, larger datasets
- **Pros**: ACID compliance, SQL queries, horizontal scaling, enterprise features
- **Cons**: Requires PostgreSQL 15+ with pgvector extension

### Setting Backend

Use the `RAG_DB_TYPE` environment variable:

```bash
# ChromaDB
export RAG_DB_TYPE=chromadb
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py

# PostgreSQL
export RAG_DB_TYPE=postgresql
RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py
```

**Optional:** Override config file location:
```bash
RAG_DB_TYPE=postgresql \
RAG_DB_CONFIG=/custom/path/config.json \
python3 servers/rag_server_api.py
```

---

## Server Commands

All commands assume you're in the `CaaS/` directory.

### REST API Server (FastAPI)

**Start server:**
```bash
# ChromaDB backend
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py --port 8000

# PostgreSQL backend
RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py --port 8000

# Custom config
RAG_DB_TYPE=postgresql \
RAG_DB_CONFIG=./rag-database/postgresql/prod-config.json \
python3 servers/rag_server_api.py --port 8000
```

**Available endpoints:**
- `GET /health` - Health check
- `POST /query` - Semantic search query
- `GET /stats` - Database statistics
- `GET /collections` - List collections (ChromaDB only)

**Test server:**
```bash
curl http://localhost:8000/health
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "AWS container architecture", "n_results": 5}'
```

### MCP Server (VS Code Copilot)

**Start MCP server:**
```bash
# ChromaDB backend
RAG_DB_TYPE=chromadb python3 servers/rag_mcp_server.py

# PostgreSQL backend
RAG_DB_TYPE=postgresql python3 servers/rag_mcp_server.py
```

**Configure in VS Code `mcp-server/config.json`:**
```json
{
  "mcpServers": {
    "caas-rag": {
      "command": "python3",
      "args": ["/path/to/CaaS/servers/rag_mcp_server.py"],
      "env": {
        "RAG_DB_TYPE": "chromadb"
      }
    }
  }
}
```

---

## Database Setup

### ChromaDB Setup

```bash
cd rag-database/chromadb

# Install dependencies
pip install -r requirements.txt

# Load documents (creates persist/ directory)
python3 ingest.py --docs-dir ../../confluence-pages --collection aws

# Verify setup
python3 query.py "AWS architecture"
```

**Directory structure after setup:**
```
chromadb/
├── persist/           # ChromaDB persisted data
│   └── chroma.sqlite3
├── config.json        # Configuration
├── ingest.py          # Data ingestion script
├── query.py           # Query testing script
└── database.py        # Database implementation
```

### PostgreSQL Setup

**Prerequisites:**
- PostgreSQL 15+ installed
- pgvector extension available
- Database user with CREATE permissions

```bash
cd rag-database/postgresql

# Install Python dependencies
pip install -r requirements.txt

# Configure database connection
# Edit config.json with your PostgreSQL details:
# {
#   "postgres": {
#     "host": "localhost",
#     "port": 5432,
#     "database": "rag_db",
#     "user": "postgres",
#     "password": "your_password"
#   }
# }

# Initialize database (creates database, enables pgvector extension)
python3 setup.py

# Load data into database
python3 ingest.py --docs-dir ../../confluence-pages --collection aws

# Verify setup
python3 query.py "AWS architecture"
```

**Database schema** (created automatically on first ingest):
```sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS rag_documents (
    id SERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    metadata JSONB,
    embedding vector(1536),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ON rag_documents USING ivfflat (embedding vector_cosine_ops);
```

---

## Data Ingestion

### Ingest Confluence Pages

Both backends support ingesting markdown files from `confluence-pages/`:

```bash
# From CaaS/ directory

# ChromaDB ingestion
cd rag-database/chromadb
python3 ingest.py --docs-dir ../../confluence-pages --collection aws

# PostgreSQL ingestion
cd rag-database/postgresql
python3 ingest.py --docs-dir ../../confluence-pages --collection aws
```

### Ingest Custom Files

```python
# Using database module directly
from rag_database.chromadb.database import RagDatabase
# OR
from rag_database.postgresql.database import RagDatabase

db = RagDatabase(config_path="config.json")

# Single file
db.load_file("path/to/document.md")

# Directory
for file in os.listdir("docs/"):
    if file.endswith(".md"):
        db.load_file(f"docs/{file}")
```

### Bulk Ingestion

```bash
# Ingest multiple directories (from rag-database/chromadb or postgresql directory)
python3 ingest.py --docs-dir ../../confluence-pages --collection aws
python3 ingest.py --docs-dir ../../additional-docs --collection extras
python3 ingest.py --docs-dir ../../third-party-docs --collection external

# Reset and re-ingest
python3 ingest.py --docs-dir ../../confluence-pages --collection aws --reset

# Use custom config
python3 ingest.py --docs-dir ../../docs --collection mydata --config prod-config.json
```

**Available Arguments:**
- `--docs-dir <path>` - Directory containing documents to ingest (required or uses default)
- `--collection <name>` - Collection/table name for the data (required or uses config default)
- `--reset` - Clear the collection before ingesting new data
- `--config <path>` - Custom config file path (default: config.json)

**Examples:**
```bash
# ChromaDB: Ingest with specific collection
cd rag-database/chromadb
python3 ingest.py --docs-dir ../../confluence-pages --collection aws

# PostgreSQL: Reset and ingest
cd rag-database/postgresql
python3 ingest.py --docs-dir ../../confluence-pages --collection aws --reset
```

---

## Query & Testing

### Direct Database Queries

**ChromaDB:**
```bash
cd rag-database/chromadb
python3 query.py "AWS container architecture"
python3 query.py "Rancher cluster management" --n_results 10
```

**PostgreSQL:**
```bash
cd rag-database/postgresql
python3 query.py "AWS container architecture"
python3 query.py "Rancher cluster management" --n_results 10
```

### Server-Based Queries

```bash
# Assuming server is running on localhost:8000

# Basic query
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{
    "query": "How do I create a Kubernetes namespace?",
    "n_results": 5
  }'

# Check database stats
curl http://localhost:8000/stats

# Health check
curl http://localhost:8000/health
```

### Python Client SDK

```python
from client.caas_client import CaasClient

# Initialize client
client = CaasClient(base_url="http://localhost:8000")

# Query
results = client.query(
    query="AWS container reference architecture",
    n_results=5
)

for doc in results["documents"]:
    print(f"Source: {doc['metadata']['source']}")
    print(f"Content: {doc['content'][:200]}...")
    print()
```

---

## Client SDK Usage

### Installation

```bash
cd client
pip install -r requirements.txt
```

### Basic Usage

```python
from caas_client import CaasClient

# Connect to server
client = CaasClient(base_url="http://localhost:8000")

# Semantic search
results = client.query("Rancher cluster setup", n_results=3)

# Get server stats
stats = client.get_stats()
print(f"Documents: {stats['total_documents']}")
print(f"Backend: {stats['backend_type']}")
```

### Advanced Usage

```python
# Custom timeout
client = CaasClient(base_url="http://localhost:8000", timeout=60)

# Error handling
try:
    results = client.query("my query")
except Exception as e:
    print(f"Query failed: {e}")

# Batch queries
queries = ["AWS architecture", "Kubernetes security", "Cost governance"]
results = [client.query(q, n_results=3) for q in queries]
```

---

## Configuration Files

### ChromaDB Config: `rag-database/chromadb/config.json`

```json
{
  "persist_directory": "./persist",
  "collection_name": "confluence_docs",
  "embedding_model": "text-embedding-ada-002",
  "chunk_size": 1000,
  "chunk_overlap": 200
}
```

**Parameters:**
- `persist_directory`: Where ChromaDB stores data (relative or absolute path)
- `collection_name`: Name of the ChromaDB collection
- `embedding_model`: OpenAI embedding model (requires `OPENAI_API_KEY`)
- `chunk_size`: Text chunk size for splitting documents
- `chunk_overlap`: Overlap between consecutive chunks

### PostgreSQL Config: `rag-database/postgresql/config.json`

```json
{
  "postgres": {
    "host": "localhost",
    "port": 5432,
    "database": "rag_db",
    "user": "postgres",
    "password": "your_password"
  },
  "embedding_model": "text-embedding-ada-002",
  "chunk_size": 1000,
  "chunk_overlap": 200,
  "table_name": "rag_documents"
}
```

**Parameters:**
- `postgres.*`: PostgreSQL connection details
- `embedding_model`: OpenAI embedding model (requires `OPENAI_API_KEY`)
- `table_name`: PostgreSQL table name for documents
- `chunk_size`: Text chunk size for splitting documents
- `chunk_overlap`: Overlap between consecutive chunks

### Environment Variables

```bash
# Required for embeddings
export OPENAI_API_KEY="sk-..."

# Backend selection
export RAG_DB_TYPE="chromadb"  # or "postgresql"

# Optional config override
export RAG_DB_CONFIG="/path/to/custom/config.json"

# Server settings
export RAG_SERVER_PORT=8000
export RAG_SERVER_HOST="0.0.0.0"
```

---

## Troubleshooting

### Server Returns Wrong Backend Data

**Problem:** Server returns ChromaDB stats when PostgreSQL is configured.

**Solution:** Ensure `RAG_DB_TYPE` is set when starting server:
```bash
# Explicit backend selection
RAG_DB_TYPE=postgresql python3 servers/rag_server_api.py
```

**Root cause:** Python's import system may resolve ambiguous imports to the wrong backend. Always use the environment variable.

### PostgreSQL Connection Errors

**Error:** `psycopg2.OperationalError: could not connect to server`

**Solutions:**
1. Verify PostgreSQL is running: `pg_isready`
2. Check connection details in `config.json`
3. Test connection manually:
   ```bash
   psql -h localhost -U postgres -d rag_db
   ```
4. Ensure pgvector extension is installed:
   ```sql
   CREATE EXTENSION IF NOT EXISTS vector;
   ```

### ChromaDB Permission Errors

**Error:** `PermissionError: [Errno 13] Permission denied: 'persist/'`

**Solutions:**
1. Check directory permissions: `ls -la persist/`
2. Fix ownership: `sudo chown -R $USER:$USER persist/`
3. Or delete persist/ and re-ingest: `rm -rf persist/ && python3 ingest.py --docs-dir ../../confluence-pages --collection aws`

### Embedding API Errors

**Error:** `openai.error.AuthenticationError: Incorrect API key`

**Solutions:**
1. Set API key: `export OPENAI_API_KEY="sk-..."`
2. Verify key is valid: `echo $OPENAI_API_KEY`
3. Check OpenAI account has credits/quota

### Import Errors

**Error:** `ModuleNotFoundError: No module named 'chromadb'`

**Solutions:**
1. Install dependencies: `pip install -r requirements.txt`
2. Activate virtual environment if using one
3. Check Python version: `python3 --version` (requires 3.9+)

### Port Already in Use

**Error:** `OSError: [Errno 48] Address already in use`

**Solutions:**
1. Find process using port: `lsof -i :8000`
2. Kill process: `kill -9 <PID>`
3. Or use different port: `python3 servers/rag_server_api.py --port 8001`

### Query Returns No Results

**Problem:** Valid queries return empty results.

**Debug steps:**
1. Check database has data:
   ```bash
   curl http://localhost:8000/stats
   ```
2. Test direct database query:
   ```bash
   cd rag-database/chromadb  # or postgresql
   python3 query.py "test query"
   ```
3. Verify backend selection matches your data:
   ```bash
   # If data is in ChromaDB but server uses PostgreSQL
   RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py
   ```

---

## Common Workflows

### Local Development Setup

```bash
# 1. Navigate to inner CaaS directory and install
# From workspace root:
cd CaaS
pip install -r requirements.txt

# 2. Set up ChromaDB (quickest for dev)
cd rag-database/chromadb
pip install -r requirements.txt
python3 ingest.py --docs-dir ../../confluence-pages --collection aws
cd ../..

# 3. Start server
RAG_DB_TYPE=chromadb python3 servers/rag_server_api.py --port 8000

# 4. Test in another terminal
curl http://localhost:8000/health
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "test", "n_results": 1}'
```

### Production Deployment

```bash
# 1. Navigate to inner CaaS directory
# From workspace root:
cd CaaS

# 2. Set up PostgreSQL backend
cd rag-database/postgresql
pip install -r requirements.txt
# Edit config.json with production DB credentials
python3 setup.py  # Creates database and enables pgvector extension

# 3. Ingest production data
python3 ingest.py --docs-dir ../../confluence-pages --collection production

# 4. Start server with production config
cd ../..  # back to CaaS/CaaS/
RAG_DB_TYPE=postgresql \
RAG_DB_CONFIG=./rag-database/postgresql/prod-config.json \
python3 servers/rag_server_api.py --port 8000 --host 0.0.0.0

# 5. Run behind reverse proxy (nginx/traefik)
```

### Migrating from ChromaDB to PostgreSQL

```bash
# 1. Export ChromaDB data (if needed)
cd rag-database/chromadb
python3 export.py > data.json

# 2. Set up PostgreSQL
cd ../postgresql
# Edit config.json
python3 setup.py

# 3. Re-ingest source documents
python3 ingest.py --docs-dir ../../confluence-pages --collection aws

# 4. Update server startup
RAG_DB_TYPE=postgresql python3 ../../servers/rag_server_api.py
```

### Adding New Documentation

```bash
# 1. Add markdown files to confluence-pages/
cp new-docs/*.md confluence-pages/

# 2. Re-run ingestion
cd rag-database/chromadb  # or postgresql
python3 ingest.py --docs-dir ../../confluence-pages --collection aws

# 3. Restart server (if running)
# Server will automatically use updated database
```

---

## Related Documentation

- [Main README](README.md) - Project overview
- [Server Documentation](servers/README.md) - Server architecture details
- [Database Documentation](rag-database/README.md) - Database implementation details
- [Client SDK Documentation](client/README.md) - Python client library usage
- [ChromaDB Implementation](rag-database/chromadb/README.md)
- [PostgreSQL Implementation](rag-database/postgresql/README.md)

---

**Last Updated:** February 2, 2026  
**Maintainer:** CaaS Platform Team
