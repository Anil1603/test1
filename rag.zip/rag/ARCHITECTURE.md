# CaaS RAG System - Architecture Documentation

## System Overview

The CaaS (Container-as-a-Service) RAG system provides intelligent document retrieval and query capabilities using vector embeddings. The system ingests Confluence documentation and enables semantic search through multiple interfaces.

---

## 🏗️ High-Level Architecture

```mermaid
graph TB
    subgraph "Data Sources"
        CONF[Confluence Pages<br/>353+ Markdown Files]
        DOCS[Other Documents<br/>PDF, DOCX, TXT]
    end
    
    subgraph "Ingestion Layer"
        CLI[CLI Ingestion<br/>ingest.py]
        API_ING[REST API<br/>/ingest endpoint]
        MCP_ING[MCP Server<br/>ingest_documents]
        
        PROC[Document Processor<br/>common/ingestion.py]
        CHUNK[Text Chunker<br/>1000 chars, 200 overlap]
        EMBED[Embedding Model<br/>all-MiniLM-L6-v2]
    end
    
    subgraph "Storage Layer"
        CHROMA[(ChromaDB<br/>Vector Database)]
        COLL_AWS[Collection: aws<br/>1111 chunks]
        COLL_POC[Collection: poc]
        COLL_OTHER[Collection: others]
    end
    
    subgraph "Query Layer"
        REST[FastAPI Server<br/>Port 8000]
        MCP[MCP Server<br/>VS Code Integration]
    end
    
    subgraph "Client Layer"
        CURL[HTTP Clients<br/>curl, Postman]
        VSCODE[VS Code<br/>GitHub Copilot]
        PYTHON[Python SDK]
    end
    
    %% Data Flow - Ingestion
    CONF --> CLI
    CONF --> API_ING
    CONF --> MCP_ING
    DOCS --> CLI
    DOCS --> API_ING
    
    CLI --> PROC
    API_ING --> PROC
    MCP_ING --> PROC
    
    PROC --> CHUNK
    CHUNK --> EMBED
    EMBED --> CHROMA
    
    CHROMA --> COLL_AWS
    CHROMA --> COLL_POC
    CHROMA --> COLL_OTHER
    
    %% Query Flow
    CURL --> REST
    PYTHON --> REST
    VSCODE --> MCP
    
    REST --> CHROMA
    MCP --> CHROMA
    
    style CHROMA fill:#4CAF50,stroke:#2E7D32,stroke-width:3px,color:#fff
    style REST fill:#2196F3,stroke:#1565C0,stroke-width:2px,color:#fff
    style MCP fill:#2196F3,stroke:#1565C0,stroke-width:2px,color:#fff
    style CONF fill:#FF9800,stroke:#E65100,stroke-width:2px
```

---

## 📊 Component Architecture

```mermaid
graph LR
    subgraph "rag-database/"
        subgraph "chromadb/"
            DB_PY[database.py<br/>RagDatabase Class]
            ING_PY[ingest.py<br/>CLI Tool]
            QRY_PY[query.py<br/>Query Tool]
            CFG[config.json<br/>Configuration]
        end
        
        subgraph "common/"
            PROC_PY[ingestion.py<br/>DocumentProcessor]
        end
        
        subgraph "data/"
            PERSIST[chromadb/<br/>Persistent Storage]
        end
    end
    
    subgraph "servers/"
        API[rag_server_api.py<br/>FastAPI Server]
        MCP_SRV[rag_mcp_server.py<br/>MCP Server]
    end
    
    ING_PY --> DB_PY
    ING_PY --> PROC_PY
    QRY_PY --> DB_PY
    
    API --> DB_PY
    API --> PROC_PY
    MCP_SRV --> DB_PY
    MCP_SRV --> PROC_PY
    
    DB_PY --> CFG
    DB_PY --> PERSIST
    
    style DB_PY fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
    style PROC_PY fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
    style API fill:#2196F3,stroke:#1565C0,stroke-width:2px
    style MCP_SRV fill:#2196F3,stroke:#1565C0,stroke-width:2px
```

---

## 🔄 Data Flow - Document Ingestion

```mermaid
sequenceDiagram
    participant User
    participant API as FastAPI Server
    participant Processor as DocumentProcessor
    participant Embedder as SentenceTransformer
    participant DB as ChromaDB
    participant Storage as Disk Storage
    
    User->>API: POST /ingest<br/>{documents_path, collection}
    API->>API: Validate path & parameters
    API->>Processor: load_directory(path)
    
    loop For each file
        Processor->>Processor: Detect file type
        Processor->>Processor: Extract text content
        Processor->>Processor: chunk_text(content)
    end
    
    Processor-->>API: Return documents[]
    
    API->>Processor: process_documents(docs)
    
    loop For each chunk
        Processor->>Embedder: encode(chunk_text)
        Embedder-->>Processor: vector embedding
        Processor->>Processor: Create metadata
    end
    
    Processor-->>API: documents[], metadatas[], ids[]
    
    API->>DB: add_documents(docs, meta, ids, collection)
    DB->>DB: Create/get collection
    DB->>Storage: Persist vectors & metadata
    Storage-->>DB: Success
    DB-->>API: Ingestion complete
    
    API-->>User: 200 OK<br/>{status, docs_count, chunks_count}
```

---

## 🔍 Query Flow - Semantic Search

```mermaid
sequenceDiagram
    participant Client
    participant Server as REST/MCP Server
    participant DB as RagDatabase
    participant ChromaDB as ChromaDB Client
    participant Embedder as Embedding Model
    
    Client->>Server: Query Request<br/>"AWS architecture"
    Server->>Server: Validate collection exists
    
    Server->>DB: query(text, n_results, collection)
    
    DB->>Embedder: Generate query embedding
    Embedder-->>DB: Query vector [384 dims]
    
    DB->>ChromaDB: collection.query()<br/>vector similarity search
    
    ChromaDB->>ChromaDB: Cosine similarity<br/>IVFFlat indexing
    ChromaDB->>ChromaDB: Rank by distance
    ChromaDB->>ChromaDB: Filter top N results
    
    ChromaDB-->>DB: {documents[], metadatas[], distances[]}
    
    DB->>DB: Format results<br/>Calculate similarity scores
    
    DB-->>Server: Query results
    
    Server->>Server: Enhance with source info
    Server-->>Client: Formatted response<br/>with similarity scores
```

---

## 🗄️ Database Schema

```mermaid
erDiagram
    COLLECTION ||--o{ DOCUMENT : contains
    DOCUMENT ||--o{ CHUNK : split_into
    CHUNK ||--|| EMBEDDING : has
    CHUNK ||--|| METADATA : has
    
    COLLECTION {
        string name PK
        string embedding_function
        datetime created_at
        int document_count
    }
    
    DOCUMENT {
        string source_path
        string filename
        string file_type
        datetime ingested_at
        int total_chunks
    }
    
    CHUNK {
        string id PK
        string content
        int chunk_index
        int chunk_size
    }
    
    EMBEDDING {
        string id PK
        float[] vector "384 dimensions"
        string model "all-MiniLM-L6-v2"
    }
    
    METADATA {
        string id PK
        string source
        string filename
        int chunk_index
        int total_chunks
        json custom_fields
    }
```

---

## 🌐 REST API Architecture

```mermaid
graph TB
    subgraph "FastAPI Application"
        LIFESPAN[Lifespan Manager<br/>Initialize DB & Processor]
        
        subgraph "Endpoints"
            ROOT[GET /<br/>API Info]
            HEALTH[GET /health<br/>Health Check]
            STATS[GET /stats<br/>Database Stats]
            QUERY[POST /query<br/>Semantic Search]
            INGEST[POST /ingest<br/>Document Ingestion]
            DELETE[DELETE /collection/:name<br/>Remove Collection]
        end
        
        subgraph "Middleware"
            CORS[CORS Middleware<br/>Allow Origins: *]
            VALID[Request Validation<br/>Pydantic Models]
            ERROR[Error Handler<br/>HTTPException]
        end
        
        subgraph "Business Logic"
            DB_LOGIC[RagDatabase<br/>Vector Operations]
            PROC_LOGIC[DocumentProcessor<br/>Text Processing]
            CONFIG[Config Loader<br/>chromadb/config.json]
        end
    end
    
    CLIENT[HTTP Client]
    
    CLIENT --> CORS
    CORS --> VALID
    VALID --> ROOT
    VALID --> HEALTH
    VALID --> STATS
    VALID --> QUERY
    VALID --> INGEST
    VALID --> DELETE
    
    QUERY --> DB_LOGIC
    INGEST --> PROC_LOGIC
    INGEST --> DB_LOGIC
    STATS --> DB_LOGIC
    DELETE --> DB_LOGIC
    
    LIFESPAN --> CONFIG
    CONFIG --> DB_LOGIC
    CONFIG --> PROC_LOGIC
    
    PROC_LOGIC --> DB_LOGIC
    
    ERROR -.-> QUERY
    ERROR -.-> INGEST
    ERROR -.-> DELETE
    
    style CLIENT fill:#FF9800,stroke:#E65100,stroke-width:2px
    style DB_LOGIC fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
    style PROC_LOGIC fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
```

---

## 🔌 MCP Server Architecture

```mermaid
graph TB
    subgraph "MCP Server (FastMCP)"
        INIT[Server Initialization<br/>rag-server]
        
        subgraph "MCP Tools"
            T1[query_rag<br/>Search documents]
            T2[rag_ask_copilot<br/>AI-enhanced answers]
            T3[ingest_documents<br/>Add documents]
            T4[add_document<br/>Add single doc]
            T5[get_database_stats<br/>View statistics]
            T6[reset_database<br/>Clear all data]
        end
        
        DB_MCP[RagDatabase Instance]
        PROC_MCP[DocumentProcessor Instance]
        CFG_MCP[Config Loader]
    end
    
    VSCODE[VS Code<br/>GitHub Copilot]
    
    VSCODE <-->|Model Context Protocol| INIT
    
    INIT --> CFG_MCP
    CFG_MCP --> DB_MCP
    CFG_MCP --> PROC_MCP
    
    T1 --> DB_MCP
    T2 --> DB_MCP
    T3 --> PROC_MCP
    T3 --> DB_MCP
    T4 --> PROC_MCP
    T4 --> DB_MCP
    T5 --> DB_MCP
    T6 --> DB_MCP
    
    style VSCODE fill:#007ACC,stroke:#005A9E,stroke-width:3px,color:#fff
    style DB_MCP fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
    style PROC_MCP fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
```

---

## 🔐 Security Architecture

```mermaid
graph TB
    subgraph "Security Layers"
        subgraph "Network Security"
            CORS_SEC[CORS Policy<br/>Development: *<br/>Production: Restrict]
            SSL[SSL/TLS<br/>Certificate Verification]
        end
        
        subgraph "Input Validation"
            PATH_VAL[Path Validation<br/>Prevent Directory Traversal]
            PARAM_VAL[Parameter Validation<br/>Pydantic Models]
            COLL_VAL[Collection Validation<br/>Existence Check]
            CHUNK_VAL[Chunk Size Validation<br/>Positive & Reasonable]
        end
        
        subgraph "Access Control"
            AUTH[Authentication<br/>TODO: Add middleware]
            AUTHZ[Authorization<br/>TODO: Role-based]
            RATE[Rate Limiting<br/>TODO: Add throttling]
        end
        
        subgraph "Data Protection"
            SANITIZE[Input Sanitization<br/>Strip malicious content]
            BACKUP[Data Backup<br/>ChromaDB persistence]
            DELETE_PROT[Delete Protection<br/>Prevent default collection]
        end
    end
    
    REQUEST[Client Request]
    
    REQUEST --> CORS_SEC
    REQUEST --> SSL
    CORS_SEC --> PARAM_VAL
    SSL --> PARAM_VAL
    
    PARAM_VAL --> PATH_VAL
    PATH_VAL --> COLL_VAL
    COLL_VAL --> CHUNK_VAL
    
    CHUNK_VAL --> AUTH
    AUTH --> AUTHZ
    AUTHZ --> RATE
    
    RATE --> SANITIZE
    SANITIZE --> DELETE_PROT
    DELETE_PROT --> BACKUP
    
    style AUTH fill:#FFC107,stroke:#FF8F00,stroke-width:2px
    style AUTHZ fill:#FFC107,stroke:#FF8F00,stroke-width:2px
    style RATE fill:#FFC107,stroke:#FF8F00,stroke-width:2px
```

---

## 📦 Technology Stack

```mermaid
graph LR
    subgraph "Frontend/Client"
        CLI_TECH[CLI Tools<br/>Python argparse]
        HTTP_TECH[HTTP Clients<br/>curl, requests]
        IDE_TECH[VS Code<br/>with Copilot]
    end
    
    subgraph "API Layer"
        FAST[FastAPI 0.104+<br/>REST Framework]
        UVICORN[Uvicorn<br/>ASGI Server]
        MCP_TECH[FastMCP 0.2+<br/>MCP Protocol]
        PYDANTIC[Pydantic 2.5+<br/>Validation]
    end
    
    subgraph "Business Logic"
        PYTHON[Python 3.12<br/>Core Language]
        LANGCHAIN[LangChain<br/>Document Loading]
    end
    
    subgraph "ML/AI Layer"
        SENTENCE[SentenceTransformers<br/>all-MiniLM-L6-v2]
        EMBED_SIZE[Embedding Size<br/>384 dimensions]
    end
    
    subgraph "Storage Layer"
        CHROMADB[ChromaDB 0.4+<br/>Vector Database]
        SQLITE[SQLite<br/>chroma.sqlite3]
        PERSIST[File System<br/>Persistent Storage]
    end
    
    subgraph "Infrastructure"
        SSL_TECH[certifi<br/>SSL Certificates]
        CORS_MID[CORS Middleware<br/>Cross-Origin Support]
    end
    
    CLI_TECH --> PYTHON
    HTTP_TECH --> FAST
    IDE_TECH --> MCP_TECH
    
    FAST --> PYDANTIC
    FAST --> UVICORN
    MCP_TECH --> PYTHON
    
    PYTHON --> LANGCHAIN
    PYTHON --> SENTENCE
    
    LANGCHAIN --> CHROMADB
    SENTENCE --> EMBED_SIZE
    EMBED_SIZE --> CHROMADB
    
    CHROMADB --> SQLITE
    CHROMADB --> PERSIST
    
    FAST --> CORS_MID
    PYTHON --> SSL_TECH
    
    style CHROMADB fill:#4CAF50,stroke:#2E7D32,stroke-width:3px
    style SENTENCE fill:#FF5722,stroke:#D84315,stroke-width:2px
    style FAST fill:#009688,stroke:#00695C,stroke-width:2px
```

---

## 📈 Scalability Considerations

| Component | Current State | Scalability Path |
|-----------|--------------|------------------|
| **ChromaDB** | Single instance, file-based | → Distributed ChromaDB / pgvector |
| **API Server** | Single Uvicorn process | → Multiple workers, Load balancer |
| **Embeddings** | On-demand generation | → Pre-computed, cached embeddings |
| **Storage** | Local filesystem | → S3/Cloud storage, CDN |
| **Collections** | Manual management | → Auto-sharding, partitioning |

---

## 🎯 Data Flow Summary

**Ingestion Pipeline:**
```
Documents → Load → Extract Text → Chunk (1000 chars) → 
Generate Embeddings (384D) → Store in ChromaDB → Return Stats
```

**Query Pipeline:**
```
Query Text → Generate Query Embedding → Cosine Similarity Search → 
Rank Results → Format with Metadata → Return Top N Results
```

---

## 🔧 Configuration Management

```mermaid
graph TB
    subgraph "Configuration Files"
        CFG_CHROMA[chromadb/config.json]
        CFG_PG[postgresql/config.json]
        REQ_CHROMA[chromadb/requirements.txt]
        REQ_SERVER[servers/requirements.txt]
    end
    
    subgraph "Runtime Configuration"
        PERSIST_DIR[persist_directory<br/>../rag-database/data/chromadb]
        COLL_NAME[collection_name<br/>Default: poc]
        EMBED_MODEL[embedding_model<br/>all-MiniLM-L6-v2]
        CHUNK_CFG[chunk_size: 1000<br/>chunk_overlap: 200]
    end
    
    subgraph "Environment Variables"
        SSL_ENV[SSL_CERT_FILE]
        CERT_ENV[REQUESTS_CA_BUNDLE]
        ANON_ENV[ANONYMIZED_TELEMETRY]
    end
    
    CFG_CHROMA --> PERSIST_DIR
    CFG_CHROMA --> COLL_NAME
    CFG_CHROMA --> EMBED_MODEL
    
    CFG_PG -.-> PERSIST_DIR
    
    REQ_CHROMA --> EMBED_MODEL
    REQ_SERVER -.-> EMBED_MODEL
    
    CHUNK_CFG -.-> CFG_CHROMA
    
    SSL_ENV --> CERT_ENV
    CERT_ENV --> ANON_ENV
    
    style CFG_CHROMA fill:#2196F3,stroke:#1565C0,stroke-width:2px
```

---

## 📊 Performance Metrics

| Metric | Current Value | Notes |
|--------|--------------|-------|
| **Documents Ingested** | 353 files | Confluence pages |
| **Total Chunks** | 1,111 | Avg 3.1 chunks/doc |
| **Embedding Dimensions** | 384 | MiniLM-L6-v2 |
| **Chunk Size** | 1000 chars | Configurable |
| **Chunk Overlap** | 200 chars | Configurable |
| **Collections** | 3 (aws, poc, others) | Expandable |
| **Query Time** | ~100-500ms | Depends on collection size |
| **Ingestion Rate** | ~10-20 docs/sec | Varies by file size |

---

## 🚀 Deployment Architecture

```mermaid
graph TB
    subgraph "Development"
        DEV_API[FastAPI Server<br/>localhost:8000<br/>--reload]
        DEV_MCP[MCP Server<br/>MCP Inspector]
        DEV_DB[(ChromaDB<br/>Local Storage)]
    end
    
    subgraph "Production (Future)"
        LB[Load Balancer<br/>NGINX/ALB]
        
        subgraph "API Instances"
            API1[FastAPI #1]
            API2[FastAPI #2]
            API3[FastAPI #N]
        end
        
        subgraph "Database Layer"
            PRIM[(Primary DB<br/>PostgreSQL + pgvector)]
            REPLICA[(Read Replicas)]
        end
        
        CACHE[Redis Cache<br/>Embedding Cache]
        MONITOR[Monitoring<br/>Prometheus + Grafana]
    end
    
    DEV_API --> DEV_DB
    DEV_MCP --> DEV_DB
    
    LB --> API1
    LB --> API2
    LB --> API3
    
    API1 --> CACHE
    API2 --> CACHE
    API3 --> CACHE
    
    CACHE --> PRIM
    PRIM --> REPLICA
    
    API1 --> MONITOR
    API2 --> MONITOR
    API3 --> MONITOR
    
    style DEV_API fill:#4CAF50,stroke:#2E7D32,stroke-width:2px
    style LB fill:#FF9800,stroke:#E65100,stroke-width:2px
    style PRIM fill:#2196F3,stroke:#1565C0,stroke-width:3px
```

---

## 📝 Key Design Decisions

1. **ChromaDB Choice**: Selected for ease of setup and prototyping; PostgreSQL+pgvector available for production
2. **Embedding Model**: all-MiniLM-L6-v2 chosen for balance of speed and accuracy
3. **Chunking Strategy**: 1000 char chunks with 200 char overlap to preserve context
4. **API Framework**: FastAPI for modern async support and auto-documentation
5. **MCP Integration**: Direct VS Code Copilot integration for enhanced developer experience
6. **Collection-based Organization**: Separate collections for different document sets (aws, poc)
7. **SSL Workarounds**: macOS-specific SSL handling for corporate environments

---

**Architecture Version**: 1.0  
**Last Updated**: February 2, 2026  
**Maintained By**: CaaS Team
