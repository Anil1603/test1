# Context-as-a-Service (CaaS)

**Supercharge your AI assistant with relevant context from your documents.**

📖 **[Complete Command Reference → RUNBOOK.md](RUNBOOK.md)** - All setup, server, and database commands in one place

A RAG (Retrieval-Augmented Generation) system with three access methods:
- **REST API** - HTTP endpoints for any application
- **MCP Server** - VS Code GitHub Copilot integration
- **Copilot Client** - GitHub Copilot SDK with RAG augmentation

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Context-as-a-Service                     │
└─────────────────────────────────────────────────────────────┘

                         rag-database/
                    ┌───────────────────┐
Your Documents ───> │ ChromaDB Vector   │
.txt .md .pdf       │ Store + Embeddings│
.docx .py .json     └─────────┬─────────┘
                              │
            ┌─────────────────┼─────────────────┐
            │                 │                 │
            ▼                 ▼                 ▼
    ┌───────────────┐ ┌───────────────┐ ┌───────────────┐
    │  servers/     │ │  servers/     │ │  client/      │
    │  rag_server_  │ │  rag_mcp_     │ │  query-       │
    │  api.py       │ │  server.py    │ │  copilot-rag  │
    │  REST API     │ │  MCP Server   │ │               │
    └───────┬───────┘ └───────┬───────┘ └───────┬───────┘
            │                 │                 │
            ▼                 ▼                 ▼
       HTTP/JSON         VS Code           GitHub Copilot
       Clients           Copilot           SDK + RAG
```

## Project Structure

```
CaaS/
├── rag-database/           # Core RAG library
│   ├── src/
│   │   ├── database.py     # ChromaDB wrapper
│   │   └── ingestion.py    # Document processing
│   ├── data/               # Vector storage
│   └── documents/          # Source docs
│
├── servers/                # Access interfaces
│   ├── rag_server_api.py   # FastAPI REST server
│   └── rag_mcp_server.py   # MCP server for Copilot
│
├── client/                 # GitHub Copilot SDK
│   ├── query-copilot-rag.ts  # RAG + Copilot query
│   └── account-info.ts       # Session helpers
│
├── cli/                    # Command-line tools
│   ├── ingest.py           # Ingest documents
│   ├── query.py            # Query database
│   └── stats.py            # View statistics
│
├── requirements.txt        # Python dependencies
├── package.json            # Node.js dependencies
└── tsconfig.json           # TypeScript config
```

## Quick Start

### 1. Install Dependencies

```bash
# Python dependencies
pip install -r requirements.txt

# Node.js dependencies (for Copilot SDK)
npm install
```

### 2. Ingest Documents

```bash
# Using CLI
python cli/ingest.py ./documents --collection my_docs

# Or via API
curl -X POST http://localhost:8000/ingest \
  -H "Content-Type: application/json" \
  -d '{"documents_path": "./documents", "collection_name": "my_docs"}'
```

### 3. Choose Your Access Method

#### Option A: REST API

```bash
# Start server
python servers/rag_server_api.py --port 8000

# Query
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What is RAG?", "n_results": 5}'

# Stats
curl http://localhost:8000/stats
```

#### Option B: MCP Server (VS Code Copilot)

```bash
# Start MCP server (usually auto-started by VS Code)
python servers/rag_mcp_server.py

# Or test with inspector
npx @modelcontextprotocol/inspector python servers/rag_mcp_server.py
```

In VS Code Copilot Chat:
```
@workspace Use query_rag to search for "machine learning"
@workspace Use rag_ask_copilot to answer "What is the architecture?"
```

#### Option C: Copilot Client (GitHub Copilot SDK + RAG)

```bash
# Start API server first
python servers/rag_server_api.py &

# Query with RAG context and Copilot SDK
npm run query-rag "Explain the data pipeline"

# Query with instruction template
npm run query-rag "System architecture" --instruction=high-level-design.instructions.md

# Direct execution
npx tsx client/query-copilot-rag.ts "How does ChromaDB work?"
```

This method:
- Queries RAG database for relevant documents
- Builds a comprehensive prompt with RAG context
- Uses GitHub Copilot SDK for AI-powered response generation
- Optionally applies instruction templates for structured outputs (e.g., HLD documents)
- Saves formatted responses to `./data/output/`

## CLI Commands

### Ingest
```bash
python cli/ingest.py <path> [options]

Options:
  --collection, -c    Target collection name
  --chunk-size        Chunk size (default: 1000)
  --chunk-overlap     Overlap between chunks (default: 200)
  --reset             Reset collection before ingesting

Examples:
  python cli/ingest.py ./documents
  python cli/ingest.py paper.pdf --collection research
  python cli/ingest.py ./data --reset --collection fresh
```

### Query
```bash
python cli/query.py "your query" [options]

Options:
  --collection, -c    Collection to query
  --n                 Number of results (default: 5)
  --json              Output as JSON

Examples:
  python cli/query.py "What is RAG?"
  python cli/query.py "authentication" -c api-docs --n 10
```

### Stats
```bash
python cli/stats.py [options]

Options:
  --collection, -c    Show specific collection stats
  --json              Output as JSON

Examples:
  python cli/stats.py
  python cli/stats.py --collection research --json
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API information |
| GET | `/health` | Health check |
| GET | `/stats` | Database statistics |
| POST | `/query` | Query for documents |
| POST | `/ingest` | Ingest documents |
| DELETE | `/collection/{name}` | Delete collection |

## MCP Tools

| Tool | Description |
|------|-------------|
| `query_rag` | Search for similar documents |
| `rag_ask_copilot` | Query with context for Copilot |
| `ingest_documents` | Ingest from directory |
| `add_document` | Add single document |
| `get_database_stats` | Database statistics |
| `reset_database` | Clear all data |

## Configuration

### VS Code MCP Configuration

Add to `.vscode/mcp.json`:

```json
{
  "servers": {
    "rag-server": {
      "command": "python",
      "args": ["servers/rag_mcp_server.py"],
      "env": {
        "PYTHONPATH": "${workspaceFolder}"
      }
    }
  }
}
```

### Environment Variables

```bash
# For Copilot SDK
export RAG_API_URL=http://localhost:8000
export RAG_COLLECTION=documents
export ANTHROPIC_API_KEY=your_key_here
```

## Supported Document Formats

- Text: `.txt`, `.md`
- Code: `.py`, `.js`, `.ts`, `.json`, `.css`, `.html`
- Documents: `.pdf`, `.docx`

## Documentation

- [RAG Database README](rag-database/README.md) - Core database details
- [Collections Guide](COLLECTIONS_GUIDE.md) - Working with collections

## License

MIT
