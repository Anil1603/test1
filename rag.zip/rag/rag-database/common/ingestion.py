"""
Document processing module for CaaS.

Handles loading, chunking, and processing documents for RAG ingestion.
"""

import logging
import os
import uuid
from typing import Any, Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing

logger = logging.getLogger(__name__)

# Supported file extensions for text-based files
TEXT_EXTENSIONS: tuple[str, ...] = (
    ".txt", ".md", ".py", ".json", ".css", ".js", ".tsx", ".ts",
    ".php", ".html", ".svelte", ".xml", ".csv", ".yaml", ".yml", ".ini"
)


class DocumentProcessor:
    """Processes documents for RAG database ingestion."""
    
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200, max_workers: Optional[int] = None) -> None:
        """
        Initialize document processor.
        
        Args:
            chunk_size: Maximum characters per chunk
            chunk_overlap: Overlap between consecutive chunks
            max_workers: Max parallel workers (defaults to CPU count)
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.max_workers = max_workers or min(multiprocessing.cpu_count(), 8)
    
    def load_file(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Load a single file.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Document dict with content, source, filename or None if failed
        """
        if not os.path.exists(file_path):
            logger.warning("File not found: %s", file_path)
            return None
        
        filename = os.path.basename(file_path)
        content = None
        
        try:
            if filename.endswith(TEXT_EXTENSIONS):
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
            elif filename.endswith(".pdf"):
                content = self._load_pdf(file_path)
            elif filename.endswith(".docx"):
                content = self._load_docx(file_path)
            
            if content:
                return {
                    "content": content,
                    "source": file_path,
                    "filename": filename
                }
        except Exception as e:
            logger.error("Error reading file %s: %s", file_path, e)
        
        return None

    def load_directory(self, directory_path: str) -> List[Dict[str, Any]]:
        """
        Load documents from a directory recursively using parallel processing.
        
        Args:
            directory_path: Path to directory
            
        Returns:
            List of document dicts
        """
        documents: List[Dict[str, Any]] = []
        
        # Collect all file paths first
        file_paths = []
        for root, _, files in os.walk(directory_path):
            for file in files:
                file_paths.append(os.path.join(root, file))
        
        total_files = len(file_paths)
        processed = 0
        
        # Process files in parallel
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_path = {executor.submit(self.load_file, path): path for path in file_paths}
            
            for future in as_completed(future_to_path):
                processed += 1
                doc = future.result()
                if doc:
                    documents.append(doc)
                
                # Show progress every 10 files or at the end
                if processed % 10 == 0 or processed == total_files:
                    print(f"Loading files: {processed}/{total_files} ({len(documents)} valid)", end='\r')
        
        print()  # New line after progress
        logger.info("Loaded %d documents from %s", len(documents), directory_path)
        return documents
    
    def _load_pdf(self, file_path: str) -> Optional[str]:
        """
        Load content from a PDF file.
        
        Args:
            file_path: Path to PDF file
            
        Returns:
            Extracted text content or None
        """
        try:
            from pypdf import PdfReader
            reader = PdfReader(file_path)
            content = ""
            for page in reader.pages:
                content += page.extract_text() + "\n"
            return content
        except ImportError:
            logger.warning("pypdf not installed. Install with: pip install pypdf")
            return None
        except Exception as e:
            logger.error("Error reading PDF %s: %s", file_path, e)
            return None
    
    def _load_docx(self, file_path: str) -> Optional[str]:
        """
        Load content from a DOCX file.
        
        Args:
            file_path: Path to DOCX file
            
        Returns:
            Extracted text content or None
        """
        try:
            from docx import Document
            doc = Document(file_path)
            content = "\n".join([paragraph.text for paragraph in doc.paragraphs])
            return content
        except ImportError:
            logger.warning("python-docx not installed. Install with: pip install python-docx")
            return None
        except Exception as e:
            logger.error("Error reading DOCX %s: %s", file_path, e)
            return None

    def chunk_text(self, text: str) -> List[str]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Text to chunk
            
        Returns:
            List of text chunks
        """
        chunks: List[str] = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = start + self.chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            start += self.chunk_size - self.chunk_overlap
        
        return chunks

    def process_documents(
        self, raw_docs: List[Dict[str, Any]]
    ) -> Tuple[List[str], List[Dict[str, Any]], List[str]]:
        """
        Process raw documents into chunks, metadata, and IDs using parallel processing.
        
        Args:
            raw_docs: List of document dicts with content, source, filename
            
        Returns:
            Tuple of (documents, metadatas, ids)
        """
        documents: List[str] = []
        metadatas: List[Dict[str, Any]] = []
        ids: List[str] = []
        
        total_docs = len(raw_docs)
        processed = 0

        # Process in batches to reduce memory overhead
        batch_size = 100
        for batch_start in range(0, total_docs, batch_size):
            batch_end = min(batch_start + batch_size, total_docs)
            batch_docs = raw_docs[batch_start:batch_end]
            
            # Process batch in parallel
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {executor.submit(self._process_single_doc, doc): doc for doc in batch_docs}
                
                for future in as_completed(futures):
                    doc_chunks, doc_metas, doc_ids = future.result()
                    documents.extend(doc_chunks)
                    metadatas.extend(doc_metas)
                    ids.extend(doc_ids)
                    processed += 1
                    
                    # Show progress every 10 docs or at the end
                    if processed % 10 == 0 or processed == total_docs:
                        print(f"Chunking: {processed}/{total_docs} docs ({len(documents)} chunks)", end='\r')
        
        print()  # New line after progress
        logger.info("Processed %d documents into %d chunks", len(raw_docs), len(documents))
        return documents, metadatas, ids
    
    def _process_single_doc(self, doc: Dict[str, Any]) -> Tuple[List[str], List[Dict[str, Any]], List[str]]:
        """
        Process a single document into chunks.
        
        Args:
            doc: Document dict with content, source, filename
            
        Returns:
            Tuple of (chunks, metadatas, ids) for this document
        """
        chunks = self.chunk_text(doc["content"])
        doc_chunks = []
        doc_metas = []
        doc_ids = []
        
        for i, chunk in enumerate(chunks):
            doc_chunks.append(chunk)
            doc_metas.append({
                "source": doc["source"],
                "filename": doc["filename"],
                "chunk_index": i,
                "total_chunks": len(chunks)
            })
            doc_ids.append(str(uuid.uuid4()))
        
        return doc_chunks, doc_metas, doc_ids
