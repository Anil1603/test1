import os
import sys
import json
import argparse

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from postgresql.database import RagDatabasePostgres

def load_config(config_path="config.json"):
    """Load configuration from JSON file."""
    with open(config_path, 'r') as f:
        return json.load(f)

def main():
    parser = argparse.ArgumentParser(description="Test query against PostgreSQL RAG database.")
    parser.add_argument("query", type=str, help="Query text.")
    parser.add_argument("--config", type=str, default="config.json", help="Path to config file.")
    parser.add_argument("--collection", type=str, help="Collection name to query.")
    parser.add_argument("--n-results", type=int, default=5, help="Number of results to return.")
    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)
    collection_name = args.collection or config['database']['collection_name']

    # Initialize database
    print("Connecting to PostgreSQL database...")
    db = RagDatabasePostgres(
        host=config['database']['host'],
        port=config['database']['port'],
        database=config['database']['database'],
        user=config['database']['user'],
        password=config['database']['password'],
        collection_name=collection_name,
        embedding_model=config['database']['embedding_model']
    )

    print(f"\nQuerying collection '{collection_name}'...")
    print(f"Query: {args.query}\n")
    
    results = db.query(args.query, n_results=args.n_results, collection_name=collection_name)

    print(f"Found {len(results['ids'][0])} results:\n")
    
    for i, (doc_id, document, metadata, distance) in enumerate(zip(
        results['ids'][0],
        results['documents'][0],
        results['metadatas'][0],
        results['distances'][0]
    )):
        print(f"Result {i+1}:")
        print(f"  ID: {doc_id}")
        print(f"  Distance: {distance:.4f}")
        print(f"  Metadata: {metadata}")
        print(f"  Document preview: {document[:200]}...")
        print()
    
    # Show collection stats
    stats = db.get_all_collections_stats()
    print("\n=== Database Statistics ===")
    print(f"Total documents: {stats['total_documents']}")
    print(f"Total collections: {stats['total_collections']}")
    print(f"Embedding model: {stats['embedding_model']}")
    
    db.close()

if __name__ == "__main__":
    main()
