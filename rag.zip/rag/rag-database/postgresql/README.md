# PostgreSQL Implementation

📖 **[Complete Command Reference → ../../RUNBOOK.md](../../RUNBOOK.md#postgresql-setup)** - All PostgreSQL and server commands

This directory contains the PostgreSQL + pgvector implementation for the RAG system.

## 📁 Files

- **database.py** - PostgreSQL database class with pgvector
- **ingest.py** - Document ingestion script
- **query.py** - Query testing script
- **setup.py** - Database initialization and migration
- **setup.sh** - Bash setup script
- **config.json** - Configuration file
- **requirements.txt** - Python dependencies
- **docker/** - Docker Compose setup

## 🚀 Quick Start

### Option 1: Using Docker (Recommended)

```bash
# Start PostgreSQL with pgvector
cd docker
docker-compose up -d
cd ..

# Install dependencies
pip install -r requirements.txt

# Setup database
python setup.py

# Ingest documents
python ingest.py --docs-dir ../documents

# Query
python query.py "your search query"
```

### Option 2: Local PostgreSQL

```bash
# Install PostgreSQL and pgvector (see below)

# Setup database
python setup.py

# OR use bash script
./setup.sh

# Ingest and query as above
```

## 📦 Prerequisites

### PostgreSQL Installation

**macOS:**
```bash
brew install postgresql@15 pgvector
brew services start postgresql@15
```

**Linux:**
```bash
sudo apt install postgresql postgresql-contrib
# Install pgvector from source
git clone https://github.com/pgvector/pgvector.git
cd pgvector && make && sudo make install
```

**Windows:**
Download from https://www.postgresql.org/download/windows/

### Create Database

```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE rag_db;

# Enable pgvector
\c rag_db
CREATE EXTENSION vector;
\q
```

## 📝 Usage

### Setup

```bash
# Initialize database
python setup.py

# Migrate from ChromaDB
python setup.py --migrate --chroma-config ../chromadb/config.json
```

### Ingestion

```bash
# Basic ingestion
python ingest.py

# Custom documents directory
python ingest.py --docs-dir /path/to/docs

# Reset database before ingesting
python ingest.py --reset

# Custom collection
python ingest.py --collection my_docs
```

### Querying

```bash
# Basic query
python query.py "machine learning"

# More results
python query.py "neural networks" --n-results 10

# Query specific collection
python query.py "python code" --collection my_docs
```

## 🔧 Configuration

Edit `config.json`:

```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "database": "rag_db",
    "user": "postgres",
    "password": "postgres",
    "collection_name": "poc",
    "embedding_model": "all-MiniLM-L6-v2"
  }
}
```

## 🐳 Docker Setup

The `docker/` directory contains:
- **docker-compose.yml** - PostgreSQL + pgvector container
- **init.sql** - Database initialization

```bash
cd docker

# Start
docker-compose up -d

# Stop
docker-compose down

# View logs
docker-compose logs -f

# Access database
docker-compose exec postgres psql -U postgres -d rag_db
```

## 📚 API Usage

```python
from postgresql.database import RagDatabasePostgres

# Initialize
db = RagDatabasePostgres(
    host="localhost",
    database="rag_db",
    user="postgres",
    password="postgres",
    collection_name="my_collection"
)

# Add documents
db.add_documents(documents, metadatas, ids)

# Query
results = db.query("search text", n_results=5)

# Get stats
stats = db.get_all_collections_stats()

# Cleanup
db.close()
```

## ✨ Features

- ✅ Production-ready RDBMS
- ✅ ACID compliance
- ✅ Fast vector similarity search (IVFFlat index)
- ✅ SQL query support
- ✅ Multiple collection support
- ✅ Built-in backup and replication
- ✅ Multi-user support
- ✅ Excellent scalability

## 🎯 Embedding Models

Default: `all-MiniLM-L6-v2` (384 dimensions)

Other options:
- `all-mpnet-base-v2` (768 dims) - Better quality
- `multi-qa-mpnet-base-dot-v1` (768 dims) - Optimized for Q&A
- Custom SentenceTransformer models

## 🔍 Supported File Formats

Same as ChromaDB implementation:
- Text: .txt, .md
- Code: .py, .js, .ts, .tsx, .jsx, .java, .cpp, .c, .php, .html, .css
- Documents: .pdf, .docx
- Data: .json, .csv, .yaml, .yml, .xml

## ⚡ Performance

PostgreSQL + pgvector is optimized for:
- Production deployments
- Large datasets (millions of vectors)
- Multi-user concurrent access
- Complex queries with SQL
- High availability setups

## 🆚 When to Use PostgreSQL

**Choose PostgreSQL when:**
- Production environment
- Large datasets (> 1M documents)
- Multi-user application
- Need ACID compliance
- Want SQL query capabilities
- Existing PostgreSQL infrastructure
- Need backup/replication

**Consider ChromaDB when:**
- Quick prototyping
- Small datasets
- Single-user development
- No server setup desired

## 🔧 Performance Tuning

### Index Optimization

```sql
-- Rebuild index with more lists for better accuracy
DROP INDEX poc_embedding_idx;
CREATE INDEX poc_embedding_idx 
ON poc USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 200);

-- Vacuum and analyze
VACUUM ANALYZE poc;
```

### Query Performance

```sql
-- Check query plan
EXPLAIN ANALYZE 
SELECT * FROM poc 
ORDER BY embedding <=> '[...]'::vector 
LIMIT 5;
```

## 🐛 Troubleshooting

### Cannot Connect to PostgreSQL

```bash
# Check if running
pg_isready -h localhost -p 5432

# Start PostgreSQL
brew services start postgresql@15  # macOS
sudo systemctl start postgresql    # Linux
```

### pgvector Extension Not Found

```sql
-- Check if installed
SELECT * FROM pg_available_extensions WHERE name = 'vector';

-- Install
CREATE EXTENSION IF NOT EXISTS vector;
```

### Slow Queries

- Increase index lists parameter
- Run VACUUM ANALYZE
- Check query plans with EXPLAIN
- Consider connection pooling

### Out of Memory

- Reduce batch size in ingestion
- Use smaller embedding model
- Increase PostgreSQL memory settings

## 📖 More Information

- pgvector: https://github.com/pgvector/pgvector
- PostgreSQL Docs: https://www.postgresql.org/docs/
- Parent README: ../README.md
- Full Guide: ../docs/POSTGRES_GUIDE.md
- Docker Guide: ../docs/DOCKER_SETUP.md
