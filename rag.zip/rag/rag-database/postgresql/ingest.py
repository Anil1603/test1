import os
import sys
import json
import argparse

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from postgresql.database import RagDatabasePostgres
from common.ingestion import DocumentProcessor

def load_config(config_path="config.json"):
    """Load configuration from JSON file."""
    with open(config_path, 'r') as f:
        return json.load(f)

def main():
    parser = argparse.ArgumentParser(description="Ingest documents into the PostgreSQL RAG database.")
    parser.add_argument("--docs-dir", type=str, default="../documents", help="Directory containing documents to ingest.")
    parser.add_argument("--reset", action="store_true", help="Reset the database before ingestion.")
    parser.add_argument("--config", type=str, default="config.json", help="Path to config file.")
    parser.add_argument("--collection", type=str, help="Collection name (overrides config).")
    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)
    
    # Override collection name if provided (support both 'default_table' and 'collection_name')
    collection_name = args.collection or config['database'].get('default_table') or config['database'].get('collection_name', 'poc')
    
    # Initialize components with config values
    print("Connecting to PostgreSQL database...")
    # Get embedding model from embedding section or database section
    embedding_model = config.get('embedding', {}).get('model') or config['database'].get('embedding_model', 'all-MiniLM-L6-v2')
    
    db = RagDatabasePostgres(
        host=config['database']['host'],
        port=config['database']['port'],
        database=config['database']['database'],
        user=config['database']['user'],
        password=config['database']['password'],
        collection_name=collection_name,
        embedding_model=embedding_model
    )
    
    processor = DocumentProcessor(
        chunk_size=config['ingestion']['chunk_size'],
        chunk_overlap=config['ingestion']['chunk_overlap']
    )

    if args.reset:
        print(f"Resetting collection '{collection_name}'...")
        db.reset_database(collection_name)
        print("Database reset complete.")

    print(f"Loading documents from {args.docs_dir}...")
    raw_docs = processor.load_directory(args.docs_dir)
    print(f"Found {len(raw_docs)} documents.")

    if not raw_docs:
        print("No documents found. Exiting.")
        db.close()
        return

    print("Processing documents...")
    documents, metadatas, ids = processor.process_documents(raw_docs)
    print(f"Generated {len(documents)} chunks.")

    print(f"Adding to PostgreSQL collection '{collection_name}'...")
    db.add_documents(documents, metadatas, ids, collection_name)
    
    # Show stats
    count = db.get_collection_count(collection_name)
    print(f"\nIngestion complete!")
    print(f"Total documents in '{collection_name}': {count}")
    
    db.close()

if __name__ == "__main__":
    main()
