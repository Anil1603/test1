#!/bin/bash

# PostgreSQL RAG Database Setup Script
# This script helps set up the PostgreSQL database and pgvector extension

set -e

echo "========================================="
echo "PostgreSQL RAG Database Setup"
echo "========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Default values
DB_NAME="rag_db"
DB_USER="postgres"
DB_HOST="localhost"
DB_PORT="5432"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --db-name)
            DB_NAME="$2"
            shift 2
            ;;
        --db-user)
            DB_USER="$2"
            shift 2
            ;;
        --db-host)
            DB_HOST="$2"
            shift 2
            ;;
        --db-port)
            DB_PORT="$2"
            shift 2
            ;;
        --help)
            echo "Usage: ./setup_postgres.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --db-name   Database name (default: rag_db)"
            echo "  --db-user   Database user (default: postgres)"
            echo "  --db-host   Database host (default: localhost)"
            echo "  --db-port   Database port (default: 5432)"
            echo "  --help      Show this help message"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

echo "Configuration:"
echo "  Database: $DB_NAME"
echo "  User: $DB_USER"
echo "  Host: $DB_HOST"
echo "  Port: $DB_PORT"
echo ""

# Check if PostgreSQL is installed
echo "Checking PostgreSQL installation..."
if ! command -v psql &> /dev/null; then
    echo -e "${RED}❌ PostgreSQL is not installed${NC}"
    echo ""
    echo "Install PostgreSQL:"
    echo "  macOS:   brew install postgresql@15"
    echo "  Linux:   sudo apt install postgresql postgresql-contrib"
    echo "  Windows: Download from https://www.postgresql.org/download/"
    exit 1
fi
echo -e "${GREEN}✓ PostgreSQL is installed${NC}"

# Check if PostgreSQL is running
echo "Checking if PostgreSQL is running..."
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" &> /dev/null; then
    echo -e "${YELLOW}⚠ PostgreSQL is not running${NC}"
    echo ""
    echo "Start PostgreSQL:"
    echo "  macOS:   brew services start postgresql@15"
    echo "  Linux:   sudo systemctl start postgresql"
    echo "  Windows: Start from Services panel"
    exit 1
fi
echo -e "${GREEN}✓ PostgreSQL is running${NC}"

# Create database
echo ""
echo "Creating database '$DB_NAME'..."
psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -tc "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'" | grep -q 1 || \
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -c "CREATE DATABASE $DB_NAME"
echo -e "${GREEN}✓ Database '$DB_NAME' ready${NC}"

# Enable pgvector extension
echo "Enabling pgvector extension..."
psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "CREATE EXTENSION IF NOT EXISTS vector" &> /dev/null
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ pgvector extension enabled${NC}"
else
    echo -e "${RED}❌ Failed to enable pgvector extension${NC}"
    echo ""
    echo "Install pgvector:"
    echo "  macOS:   brew install pgvector"
    echo "  Linux:   See https://github.com/pgvector/pgvector#installation"
    exit 1
fi

# Verify pgvector
echo "Verifying pgvector installation..."
VECTOR_VERSION=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -tAc "SELECT extversion FROM pg_extension WHERE extname = 'vector'")
if [ -n "$VECTOR_VERSION" ]; then
    echo -e "${GREEN}✓ pgvector version $VECTOR_VERSION is installed${NC}"
else
    echo -e "${RED}❌ pgvector verification failed${NC}"
    exit 1
fi

# Install Python dependencies
echo ""
echo "Installing Python dependencies..."
if [ -f "requirements_postgres.txt" ]; then
    pip install -r requirements_postgres.txt > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Python dependencies installed${NC}"
    else
        echo -e "${YELLOW}⚠ Some dependencies may have failed to install${NC}"
        echo "Try manually: pip install -r requirements_postgres.txt"
    fi
else
    echo -e "${YELLOW}⚠ requirements_postgres.txt not found${NC}"
fi

echo ""
echo "========================================="
echo -e "${GREEN}Setup Complete!${NC}"
echo "========================================="
echo ""
echo "Next steps:"
echo "  1. Update config_postgres.json with your database credentials"
echo "  2. Place documents in the ./documents directory"
echo "  3. Run: python ingest_postgres.py"
echo "  4. Test: python test_query_postgres.py 'your query'"
echo ""
