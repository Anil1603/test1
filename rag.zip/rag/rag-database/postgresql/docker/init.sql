-- Initialize PostgreSQL database for RAG system
-- This script is automatically run when the Docker container starts

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create initial poc collection table (optional, will be created automatically if not exists)
-- Uncomment if you want to create it here
-- CREATE TABLE IF NOT EXISTS poc (
--     id TEXT PRIMARY KEY,
--     document TEXT NOT NULL,
--     embedding vector(384),
--     metadata JSONB,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );

-- Create index for vector similarity search (optional, created by app)
-- CREATE INDEX IF NOT EXISTS poc_embedding_idx 
-- ON poc USING ivfflat (embedding vector_cosine_ops)
-- WITH (lists = 100);

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON DATABASE rag_db TO postgres;

-- Show installed extensions
SELECT extname, extversion FROM pg_extension;
