"""
PostgreSQL Database Initialization Script

This script helps initialize the PostgreSQL database for the RAG system.
It can also migrate data from ChromaDB to PostgreSQL.
"""

import os
import sys
import json
import argparse
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def check_postgresql_connection(host, port, user, password):
    """Check if PostgreSQL is accessible."""
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database='postgres'  # Connect to default database
        )
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Cannot connect to PostgreSQL: {e}")
        return False


def create_database(host, port, user, password, database):
    """Create database if it doesn't exist."""
    try:
        # Connect to default postgres database
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database='postgres'
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s",
            (database,)
        )
        exists = cursor.fetchone()
        
        if not exists:
            cursor.execute(f'CREATE DATABASE {database}')
            print(f"✓ Created database '{database}'")
        else:
            print(f"✓ Database '{database}' already exists")
        
        cursor.close()
        conn.close()
        return True
    
    except Exception as e:
        print(f"❌ Error creating database: {e}")
        return False


def enable_pgvector(host, port, user, password, database):
    """Enable pgvector extension."""
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database
        )
        
        cursor = conn.cursor()
        cursor.execute("CREATE EXTENSION IF NOT EXISTS vector")
        conn.commit()
        
        # Verify installation
        cursor.execute(
            "SELECT extversion FROM pg_extension WHERE extname = 'vector'"
        )
        version = cursor.fetchone()
        
        if version:
            print(f"✓ pgvector extension enabled (version {version[0]})")
        else:
            print("⚠ pgvector extension status unknown")
        
        cursor.close()
        conn.close()
        return True
    
    except Exception as e:
        print(f"❌ Error enabling pgvector: {e}")
        print("\nInstall pgvector:")
        print("  macOS:   brew install pgvector")
        print("  Linux:   https://github.com/pgvector/pgvector#installation")
        return False


def migrate_from_chromadb(chroma_config_path, postgres_config_path="config.json"):
    """Migrate data from ChromaDB to PostgreSQL."""
    print("\n=== Migrating from ChromaDB to PostgreSQL ===\n")
    
    try:
        # Import required modules
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from chromadb.database import RagDatabase
        from postgresql.database import RagDatabasePostgres
        
        # Load configurations
        with open(chroma_config_path, 'r') as f:
            chroma_config = json.load(f)
        
        with open(postgres_config_path, 'r') as f:
            pg_config = json.load(f)
        
        # Initialize ChromaDB
        print("Connecting to ChromaDB...")
        chroma_db = RagDatabase(
            persist_directory=chroma_config['database']['persist_directory'],
            collection_name=chroma_config['database']['collection_name']
        )
        
        # Get all collections
        collections = chroma_db.list_collections()
        print(f"Found {len(collections)} collection(s) in ChromaDB: {collections}")
        
        # Initialize PostgreSQL
        print("\nConnecting to PostgreSQL...")
        # Get config values with fallbacks
        collection_name = pg_config['database'].get('default_table') or pg_config['database'].get('collection_name', 'poc')
        embedding_model = pg_config.get('embedding', {}).get('model') or pg_config['database'].get('embedding_model', 'all-MiniLM-L6-v2')
        
        pg_db = RagDatabasePostgres(
            host=pg_config['database']['host'],
            port=pg_config['database']['port'],
            database=pg_config['database']['database'],
            user=pg_config['database']['user'],
            password=pg_config['database']['password'],
            collection_name=collection_name,
            embedding_model=embedding_model
        )
        
        # Migrate each collection
        for collection_name in collections:
            print(f"\nMigrating collection: {collection_name}")
            
            # Get all documents from ChromaDB
            chroma_collection = chroma_db.get_collection(collection_name)
            data = chroma_collection.get()
            
            if not data['ids']:
                print(f"  ⚠ Collection '{collection_name}' is empty, skipping")
                continue
            
            total_docs = len(data['ids'])
            print(f"  Found {total_docs} documents")
            
            # Add to PostgreSQL
            pg_db.add_documents(
                documents=data['documents'],
                metadatas=data['metadatas'],
                ids=data['ids'],
                collection_name=collection_name
            )
            
            print(f"  ✓ Migrated {total_docs} documents to PostgreSQL")
        
        # Close connections
        pg_db.close()
        
        print("\n✓ Migration complete!")
        
        # Show stats
        pg_db = RagDatabasePostgres(
            host=pg_config['database']['host'],
            port=pg_config['database']['port'],
            database=pg_config['database']['database'],
            user=pg_config['database']['user'],
            password=pg_config['database']['password'],
            collection_name=collection_name,
            embedding_model=embedding_model
        )
        stats = pg_db.get_all_collections_stats()
        print(f"\nPostgreSQL Database Stats:")
        print(f"  Total collections: {stats['total_collections']}")
        print(f"  Total documents: {stats['total_documents']}")
        pg_db.close()
        
        return True
        
    except Exception as e:
        print(f"❌ Migration failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Initialize PostgreSQL database for RAG system"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.json",
        help="Path to PostgreSQL config file"
    )
    parser.add_argument(
        "--migrate",
        action="store_true",
        help="Migrate data from ChromaDB to PostgreSQL"
    )
    parser.add_argument(
        "--chroma-config",
        type=str,
        default="./config.json",
        help="Path to ChromaDB config file (for migration)"
    )
    
    args = parser.parse_args()
    
    print("=" * 50)
    print("PostgreSQL RAG Database Initialization")
    print("=" * 50)
    
    # Load config
    try:
        with open(args.config, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"❌ Config file not found: {args.config}")
        sys.exit(1)
    
    db_config = config['database']
    host = db_config['host']
    port = db_config['port']
    user = db_config['user']
    password = db_config['password']
    database = db_config['database']
    
    print(f"\nConfiguration:")
    print(f"  Host: {host}:{port}")
    print(f"  Database: {database}")
    print(f"  User: {user}")
    print()
    
    # Step 1: Check PostgreSQL connection
    print("Step 1: Checking PostgreSQL connection...")
    if not check_postgresql_connection(host, port, user, password):
        print("\nMake sure PostgreSQL is installed and running:")
        print("  macOS:   brew services start postgresql@15")
        print("  Linux:   sudo systemctl start postgresql")
        sys.exit(1)
    print("✓ PostgreSQL is accessible\n")
    
    # Step 2: Create database
    print("Step 2: Creating database...")
    if not create_database(host, port, user, password, database):
        sys.exit(1)
    print()
    
    # Step 3: Enable pgvector
    print("Step 3: Enabling pgvector extension...")
    if not enable_pgvector(host, port, user, password, database):
        sys.exit(1)
    print()
    
    # Step 4: Migrate if requested
    if args.migrate:
        if not migrate_from_chromadb(args.chroma_config, args.config):
            sys.exit(1)
    
    print("=" * 50)
    print("✓ Setup Complete!")
    print("=" * 50)
    print("\nNext steps:")
    print("  1. Place documents in ./documents directory")
    print("  2. Run: python ingest.py")
    print("  3. Query your database using the RagDatabasePostgres class")
    
    if not args.migrate:
        print("\nTo migrate existing ChromaDB data:")
        print(f"  python setup.py --migrate --chroma-config ../chromadb/config.json")
    print()


if __name__ == "__main__":
    main()
