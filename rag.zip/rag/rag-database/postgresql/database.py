import os
import re
import psycopg2
from psycopg2.extras import execute_values
from psycopg2.extensions import register_adapter, AsIs
from psycopg2 import sql
import numpy as np
from sentence_transformers import SentenceTransformer
import json


def adapt_numpy_array(numpy_array):
    """Adapter for numpy arrays to PostgreSQL arrays."""
    return AsIs(f"'{numpy_array.tolist()}'::vector")


# Register the adapter
register_adapter(np.ndarray, adapt_numpy_array)


def validate_table_name(table_name: str) -> str:
    """
    Validate and sanitize table/collection name to prevent SQL injection.
    
    Rules:
    - Only alphanumeric characters, underscores, and hyphens allowed
    - Must start with a letter or underscore
    - Maximum length of 63 characters (PostgreSQL limit)
    - Cannot be a PostgreSQL reserved keyword
    
    Args:
        table_name: The table name to validate
        
    Returns:
        Validated table name
        
    Raises:
        ValueError: If table name is invalid
    """
    if not table_name:
        raise ValueError("Table name cannot be empty")
    
    # Check length
    if len(table_name) > 63:
        raise ValueError(f"Table name too long (max 63 chars): {table_name}")
    
    # Check format: alphanumeric, underscore, hyphen only, must start with letter or underscore
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_-]*$', table_name):
        raise ValueError(
            f"Invalid table name '{table_name}'. Must start with letter or underscore "
            "and contain only alphanumeric characters, underscores, and hyphens."
        )
    
    # Check against PostgreSQL reserved keywords (common ones)
    reserved_keywords = {
        'select', 'insert', 'update', 'delete', 'drop', 'create', 'alter',
        'table', 'database', 'index', 'view', 'user', 'grant', 'revoke',
        'all', 'and', 'or', 'not', 'null', 'true', 'false', 'where', 'from',
        'join', 'on', 'as', 'order', 'by', 'group', 'having', 'limit', 'offset'
    }
    
    if table_name.lower() in reserved_keywords:
        raise ValueError(f"Table name '{table_name}' is a reserved SQL keyword")
    
    return table_name


class RagDatabasePostgres:
    """
    PostgreSQL-based RAG database using pgvector extension for vector similarity search.
    """
    
    def __init__(self, 
                 host=None,
                 port=None,
                 database=None,
                 user=None,
                 password=None,
                 collection_name=None,
                 embedding_model=None,
                 config_path=None):
        """
        Initialize PostgreSQL RAG database.
        
        Can be initialized either with individual parameters or a config file path.
        
        Args:
            host: PostgreSQL host
            port: PostgreSQL port
            database: Database name
            user: Database user
            password: Database password
            collection_name: Collection/table name for documents
            embedding_model: Model name for SentenceTransformer
            config_path: Path to config JSON file (alternative to individual params)
        """
        # Load from config file if provided
        if config_path:
            with open(config_path, 'r') as f:
                config = json.load(f)
            
            # Try 'database' key first (new format), then 'postgres' (old format), then root
            if 'database' in config:
                db_config = config['database']
            elif 'postgres' in config:
                db_config = config['postgres']
            else:
                db_config = config
            
            self.host = db_config.get('host', 'localhost')
            self.port = db_config.get('port', 5432)
            self.database = db_config.get('database', 'rag_db')
            self.user = db_config.get('user', 'postgres')
            self.password = db_config.get('password', 'postgres')
            # Support both 'default_table' and 'collection_name' keys
            self.default_collection_name = db_config.get('default_table') or db_config.get('collection_name', 'poc')
            # Embedding model can be in 'embedding' section or 'database' section
            if 'embedding' in config:
                self.embedding_model_name = config['embedding'].get('model', 'all-MiniLM-L6-v2')
            else:
                self.embedding_model_name = db_config.get('embedding_model', 'all-MiniLM-L6-v2')
        else:
            # Use provided parameters or defaults
            self.host = host or "localhost"
            self.port = port or 5432
            self.database = database or "rag_db"
            self.user = user or "postgres"
            self.password = password or "postgres"
            self.default_collection_name = collection_name or "poc"
            self.embedding_model_name = embedding_model or "all-MiniLM-L6-v2"
        
        # Initialize embedding model
        print(f"Loading embedding model: {self.embedding_model_name}")
        self.embedding_model = SentenceTransformer(self.embedding_model_name)
        self.embedding_dim = self.embedding_model.get_sentence_embedding_dimension()
        
        # Connect to database
        self.conn = self._connect()
        self._ensure_extensions()
        self._create_collection_table(self.default_collection_name)
    
    def _connect(self):
        """Create database connection."""
        try:
            conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password
            )
            conn.autocommit = False
            return conn
        except psycopg2.OperationalError as e:
            raise Exception(f"Failed to connect to PostgreSQL: {str(e)}")
    
    def _ensure_extensions(self):
        """Ensure required PostgreSQL extensions are installed."""
        try:
            with self.conn.cursor() as cur:
                cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to ensure extensions: {str(e)}")
    
    def _create_collection_table(self, collection_name):
        """Create a collection table if it doesn't exist."""
        # Validate table name to prevent SQL injection
        validated_name = validate_table_name(collection_name)
        
        try:
            with self.conn.cursor() as cur:
                # Use sql.Identifier for safe table name interpolation
                create_table_query = sql.SQL("""
                    CREATE TABLE IF NOT EXISTS {} (
                        id TEXT PRIMARY KEY,
                        document TEXT NOT NULL,
                        embedding vector({dim}),
                        metadata JSONB,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """).format(
                    sql.Identifier(validated_name),
                    dim=sql.Literal(self.embedding_dim)
                )
                cur.execute(create_table_query)
                
                # Create index for vector similarity search
                create_index_query = sql.SQL("""
                    CREATE INDEX IF NOT EXISTS {index_name}
                    ON {table_name} USING ivfflat (embedding vector_cosine_ops)
                    WITH (lists = 100);
                """).format(
                    index_name=sql.Identifier(f"{validated_name}_embedding_idx"),
                    table_name=sql.Identifier(validated_name)
                )
                cur.execute(create_index_query)
                
                self.conn.commit()
        except ValueError as e:
            raise Exception(f"Invalid collection name: {str(e)}")
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to create collection table: {str(e)}")
    
    def get_collection(self, collection_name=None):
        """
        Get or create a collection by name.
        Returns the validated collection name.
        """
        if collection_name is None:
            collection_name = self.default_collection_name
        
        # Validate before creating
        validated_name = validate_table_name(collection_name)
        self._create_collection_table(validated_name)
        return validated_name
    
    def add_documents(self, documents, metadatas, ids, collection_name=None):
        """
        Add documents to the collection with embeddings.
        
        Args:
            documents: List of document texts
            metadatas: List of metadata dictionaries
            ids: List of unique document IDs
            collection_name: Target collection name
        """
        if collection_name is None:
            collection_name = self.default_collection_name
        
        # Validate collection name
        validated_name = validate_table_name(collection_name)
        
        try:
            # Generate embeddings for all documents
            print(f"Generating embeddings for {len(documents)} documents...")
            embeddings = self.embedding_model.encode(documents, show_progress_bar=True)
            
            # Prepare data for insertion
            data = []
            for i in range(len(documents)):
                data.append((
                    ids[i],
                    documents[i],
                    embeddings[i].tolist(),  # Convert to list for JSON serialization
                    json.dumps(metadatas[i]) if metadatas[i] else None
                ))
            
            # Insert in batches
            batch_size = 1000
            total_docs = len(data)
            
            with self.conn.cursor() as cur:
                for i in range(0, total_docs, batch_size):
                    batch_end = min(i + batch_size, total_docs)
                    batch = data[i:batch_end]
                    
                    # Use sql.Identifier for safe table name and execute_values for data
                    insert_query = sql.SQL("""
                        INSERT INTO {} (id, document, embedding, metadata)
                        VALUES %s
                        ON CONFLICT (id) DO UPDATE 
                        SET document = EXCLUDED.document,
                            embedding = EXCLUDED.embedding,
                            metadata = EXCLUDED.metadata;
                    """).format(sql.Identifier(validated_name))
                    
                    execute_values(
                        cur,
                        insert_query,
                        batch,
                        template="(%s, %s, %s::vector, %s::jsonb)"
                    )
                    
                    print(f"Inserted batch {i//batch_size + 1}/{(total_docs-1)//batch_size + 1}")
            
            self.conn.commit()
            print(f"Successfully added {len(documents)} documents to {validated_name}")
        except ValueError as e:
            raise Exception(f"Invalid collection name: {str(e)}")
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to add documents: {str(e)}")
    
    def query(self, query_text, n_results=5, collection_name=None):
        """
        Query the collection using vector similarity search.
        
        Args:
            query_text: Query string
            n_results: Number of results to return
            collection_name: Collection to query
            
        Returns:
            Dictionary with query results in ChromaDB-compatible format
        """
        if collection_name is None:
            collection_name = self.default_collection_name
        
        # Validate collection name
        validated_name = validate_table_name(collection_name)
        
        try:
            # Generate embedding for query
            query_embedding = self.embedding_model.encode([query_text])[0]
            
            with self.conn.cursor() as cur:
                # Use sql.Identifier for safe table name interpolation
                query_sql = sql.SQL("""
                    SELECT 
                        id,
                        document,
                        metadata,
                        1 - (embedding <=> %s::vector) as similarity
                    FROM {}
                    ORDER BY embedding <=> %s::vector
                    LIMIT %s;
                """).format(sql.Identifier(validated_name))
                
                cur.execute(
                    query_sql,
                    (query_embedding.tolist(), query_embedding.tolist(), n_results)
                )
                
                results = cur.fetchall()
            
            self.conn.commit()
            
            # Format results in ChromaDB-compatible format
            formatted_results = {
                'ids': [[r[0] for r in results]],
                'documents': [[r[1] for r in results]],
                'metadatas': [[r[2] if r[2] else {} for r in results]],  # Metadata is already a dict from JSONB
                'distances': [[1 - r[3] for r in results]]  # Convert similarity back to distance
            }
            
            return formatted_results
        except ValueError as e:
            raise Exception(f"Invalid collection name: {str(e)}")
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Query failed: {str(e)}")
    
    def reset_database(self, collection_name=None):
        """
        Clear all documents from the collection.
        """
        if collection_name is None:
            collection_name = self.default_collection_name
        
        # Validate collection name
        validated_name = validate_table_name(collection_name)
        
        try:
            with self.conn.cursor() as cur:
                truncate_query = sql.SQL("TRUNCATE TABLE {};").format(
                    sql.Identifier(validated_name)
                )
                cur.execute(truncate_query)
            self.conn.commit()
            return True
        except ValueError as e:
            raise Exception(f"Invalid collection name: {str(e)}")
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to reset database: {str(e)}")
    
    def list_collections(self):
        """List all collection names (tables)."""
        try:
            with self.conn.cursor() as cur:
                cur.execute("""
                    SELECT table_name 
                    FROM information_schema.tables 
                    WHERE table_schema = 'public' 
                    AND table_type = 'BASE TABLE'
                    AND table_name != 'spatial_ref_sys';
                """)
                result = [row[0] for row in cur.fetchall()]
            self.conn.commit()
            return result
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to list collections: {str(e)}")
    
    def get_all_collections_stats(self):
        """Get statistics for all collections."""
        try:
            collections = self.list_collections()
            stats = {
                "total_collections": len(collections),
                "default_collection": self.default_collection_name,
                "embedding_model": self.embedding_model_name,
                "database": self.database,
                "host": self.host,
                "collections": []
            }
            
            total_docs = 0
            with self.conn.cursor() as cur:
                for col in collections:
                    try:
                        # Validate collection name before querying
                        validated_name = validate_table_name(col)
                        count_query = sql.SQL("SELECT COUNT(*) FROM {};").format(
                            sql.Identifier(validated_name)
                        )
                        cur.execute(count_query)
                        count = cur.fetchone()[0]
                        total_docs += count
                        stats["collections"].append({
                            "name": col,
                            "document_count": count
                        })
                    except ValueError as e:
                        print(f"Skipping invalid collection name {col}: {e}")
                        continue
                    except Exception as e:
                        print(f"Error getting stats for {col}: {e}")
                        self.conn.rollback()  # Rollback on individual collection error
            
            self.conn.commit()
            stats["total_documents"] = total_docs
            stats["collections"] = sorted(
                stats["collections"], 
                key=lambda x: x["document_count"], 
                reverse=True
            )
            
            return stats
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to get stats: {str(e)}")
    
    def delete_collection(self, collection_name):
        """Delete a specific collection (drop table)."""
        # Validate collection name
        try:
            validated_name = validate_table_name(collection_name)
        except ValueError as e:
            print(f"Invalid collection name {collection_name}: {e}")
            return False
        
        try:
            with self.conn.cursor() as cur:
                drop_query = sql.SQL("DROP TABLE IF EXISTS {} CASCADE;").format(
                    sql.Identifier(validated_name)
                )
                cur.execute(drop_query)
            self.conn.commit()
            return True
        except Exception as e:
            self.conn.rollback()
            print(f"Error deleting collection {collection_name}: {e}")
            return False
    
    def get_collection_count(self, collection_name=None):
        """Get document count for a collection."""
        if collection_name is None:
            collection_name = self.default_collection_name
        
        # Validate collection name
        validated_name = validate_table_name(collection_name)
        
        try:
            with self.conn.cursor() as cur:
                count_query = sql.SQL("SELECT COUNT(*) FROM {};").format(
                    sql.Identifier(validated_name)
                )
                cur.execute(count_query)
                result = cur.fetchone()[0]
            self.conn.commit()
            return result
        except ValueError as e:
            raise Exception(f"Invalid collection name: {str(e)}")
        except Exception as e:
            self.conn.rollback()
            raise Exception(f"Failed to get collection count: {str(e)}")
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
    
    def __del__(self):
        """Cleanup on deletion."""
        self.close()


# Alias for consistency with ChromaDB backend
RagDatabase = RagDatabasePostgres
