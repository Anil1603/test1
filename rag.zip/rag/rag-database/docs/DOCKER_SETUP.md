# Using Docker for PostgreSQL + pgvector

This directory contains Docker Compose configuration to quickly set up PostgreSQL with pgvector extension for the RAG system.

## Quick Start

### 1. Start PostgreSQL

```bash
# Start PostgreSQL container
docker-compose up -d

# Check if running
docker-compose ps

# View logs
docker-compose logs -f
```

### 2. Verify Setup

```bash
# Connect to PostgreSQL
docker-compose exec postgres psql -U postgres -d rag_db

# In psql, verify pgvector is installed:
SELECT extname, extversion FROM pg_extension WHERE extname = 'vector';

# Exit psql
\q
```

### 3. Update Configuration

The default configuration in [config_postgres.json](config_postgres.json) should work with Docker:

```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "database": "rag_db",
    "user": "postgres",
    "password": "postgres",
    "collection_name": "poc"
  }
}
```

### 4. Run Ingestion

```bash
# Install Python dependencies (one time)
pip install -r requirements_postgres.txt

# Ingest documents
python ingest_postgres.py

# Test queries
python test_query_postgres.py "your query here"
```

## Docker Commands

### Start/Stop
```bash
# Start in background
docker-compose up -d

# Stop containers
docker-compose stop

# Stop and remove containers
docker-compose down

# Stop and remove containers + volumes (deletes all data!)
docker-compose down -v
```

### Monitoring
```bash
# View logs
docker-compose logs postgres

# Follow logs in real-time
docker-compose logs -f postgres

# Check container status
docker-compose ps

# Check resource usage
docker stats rag-postgres
```

### Database Access
```bash
# Connect via psql
docker-compose exec postgres psql -U postgres -d rag_db

# Run SQL directly
docker-compose exec postgres psql -U postgres -d rag_db -c "SELECT COUNT(*) FROM poc;"

# Backup database
docker-compose exec postgres pg_dump -U postgres rag_db > backup.sql

# Restore database
docker-compose exec -T postgres psql -U postgres -d rag_db < backup.sql
```

## Configuration Options

### Environment Variables

You can customize database credentials using environment variables:

```yaml
# docker-compose.yml
environment:
  POSTGRES_USER: myuser
  POSTGRES_PASSWORD: mypassword
  POSTGRES_DB: my_rag_db
```

Then update [config_postgres.json](config_postgres.json) accordingly.

### Port Mapping

To use a different port:

```yaml
# docker-compose.yml
ports:
  - "5433:5432"  # Host:Container
```

Then update `config_postgres.json`:
```json
{
  "database": {
    "port": 5433
  }
}
```

### Data Persistence

Data is stored in a Docker volume named `postgres_data`. To view:

```bash
docker volume ls
docker volume inspect rag-database_postgres_data
```

To backup the volume:
```bash
docker run --rm -v rag-database_postgres_data:/data -v $(pwd):/backup \
  ubuntu tar czf /backup/postgres-backup.tar.gz /data
```

## Production Considerations

For production use, consider:

1. **Use strong passwords**: Don't use default credentials
2. **Persistent storage**: Use named volumes or bind mounts
3. **Resource limits**: Add CPU and memory limits
4. **Networking**: Use custom networks for isolation
5. **Monitoring**: Add monitoring containers (pgadmin, prometheus)
6. **Backup**: Implement regular backup strategy

Example with resource limits:

```yaml
services:
  postgres:
    # ... other config ...
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 4G
        reservations:
          cpus: '1'
          memory: 2G
```

## Troubleshooting

### Container won't start

```bash
# Check logs
docker-compose logs postgres

# Remove old containers and volumes
docker-compose down -v
docker-compose up -d
```

### Connection refused

```bash
# Check if container is running
docker-compose ps

# Check if port is exposed
docker-compose port postgres 5432

# Test connection from host
psql -h localhost -U postgres -d rag_db
```

### Out of disk space

```bash
# Check Docker disk usage
docker system df

# Clean up unused Docker resources
docker system prune

# Remove specific volume
docker volume rm rag-database_postgres_data
```

## Using with pgAdmin

Add pgAdmin4 to access database via web UI:

```yaml
# Add to docker-compose.yml
services:
  pgadmin:
    image: dpage/pgadmin4:latest
    container_name: rag-pgadmin
    environment:
      PGADMIN_DEFAULT_EMAIL: admin@admin.com
      PGADMIN_DEFAULT_PASSWORD: admin
    ports:
      - "5050:80"
    depends_on:
      - postgres
    restart: unless-stopped
```

Then access pgAdmin at http://localhost:5050

Add server in pgAdmin:
- Host: postgres (container name)
- Port: 5432
- Username: postgres
- Password: postgres
- Database: rag_db

## Cleanup

To completely remove everything:

```bash
# Stop and remove containers, networks, volumes
docker-compose down -v

# Remove Docker image
docker rmi pgvector/pgvector:pg15

# Remove dangling volumes
docker volume prune
```
