# PostgreSQL Vector Database Implementation - Complete Guide

## Overview

This guide covers the PostgreSQL-based vector database implementation as an alternative to ChromaDB for the RAG (Retrieval-Augmented Generation) system.

## What Was Created

### Core Files

1. **[src/database_postgres.py](src/database_postgres.py)** - PostgreSQL database class
   - Vector storage using pgvector extension
   - Embedding generation with SentenceTransformers
   - Collection (table) management
   - Query and ingestion methods
   - Compatible API with ChromaDB implementation

2. **[ingest_postgres.py](ingest_postgres.py)** - Ingestion script
   - CLI for document ingestion
   - Batch processing
   - Collection management
   - Uses existing DocumentProcessor from `src/ingestion.py`

3. **[test_query_postgres.py](test_query_postgres.py)** - Query testing script
   - Test vector similarity search
   - View results and metadata
   - Database statistics

4. **[config_postgres.json](config_postgres.json)** - PostgreSQL configuration
   - Database connection settings
   - Embedding model configuration
   - Ingestion parameters

### Setup & Utilities

5. **[setup_postgres.sh](setup_postgres.sh)** - Bash setup script (Unix/macOS)
   - Checks PostgreSQL installation
   - Creates database
   - Enables pgvector extension
   - Installs Python dependencies

6. **[setup_postgres_db.py](setup_postgres_db.py)** - Python setup script (cross-platform)
   - Database initialization
   - Extension enablement
   - ChromaDB to PostgreSQL migration
   - Verification and testing

7. **[benchmark.py](benchmark.py)** - Performance comparison
   - Compare ChromaDB vs PostgreSQL
   - Ingestion speed benchmarks
   - Query performance metrics
   - Saves detailed results

### Documentation

8. **[requirements_postgres.txt](requirements_postgres.txt)** - Python dependencies
   - psycopg2-binary (PostgreSQL adapter)
   - pgvector (vector operations)
   - sentence-transformers (embeddings)
   - Document processing libraries

9. **[README_POSTGRES.md](README_POSTGRES.md)** - Complete PostgreSQL documentation
   - Installation instructions
   - Usage examples
   - Architecture details
   - Troubleshooting guide

## Quick Start

### 1. Install PostgreSQL

**macOS:**
```bash
brew install postgresql@15 pgvector
brew services start postgresql@15
```

**Linux:**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
# Install pgvector - see https://github.com/pgvector/pgvector
```

### 2. Initialize Database

**Option A: Using Bash Script (Unix/macOS)**
```bash
cd /Users/rahulvennapusa/Documents/codebase/CaaS/CaaS/rag-database
./setup_postgres.sh
```

**Option B: Using Python Script (Cross-platform)**
```bash
python setup_postgres_db.py
```

**Option C: Manual Setup**
```bash
# Create database
psql -U postgres -c "CREATE DATABASE rag_db;"

# Enable pgvector
psql -U postgres -d rag_db -c "CREATE EXTENSION vector;"

# Install dependencies
pip install -r requirements_postgres.txt
```

### 3. Configure Database

Edit [config_postgres.json](config_postgres.json) with your credentials:

```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "database": "rag_db",
    "user": "postgres",
    "password": "your_password",
    "collection_name": "poc",
    "embedding_model": "all-MiniLM-L6-v2"
  }
}
```

### 4. Ingest Documents

```bash
# Basic ingestion
python ingest_postgres.py

# Custom documents directory
python ingest_postgres.py --docs-dir ./my-documents

# Reset and re-ingest
python ingest_postgres.py --reset

# Use different collection
python ingest_postgres.py --collection my_collection
```

### 5. Query Documents

```bash
# Basic query
python test_query_postgres.py "machine learning algorithms"

# Get more results
python test_query_postgres.py "neural networks" --n-results 10

# Query specific collection
python test_query_postgres.py "python code" --collection my_collection
```

## Migration from ChromaDB

If you have existing ChromaDB data, migrate it to PostgreSQL:

```bash
python setup_postgres_db.py --migrate
```

This will:
1. Connect to both databases
2. Read all collections from ChromaDB
3. Transfer documents with embeddings to PostgreSQL
4. Preserve all metadata
5. Show migration statistics

## Performance Benchmarking

Compare ChromaDB vs PostgreSQL performance:

```bash
# Default benchmark (1000 docs, 20 queries)
python benchmark.py

# Custom benchmark
python benchmark.py --docs 5000 --queries 50

# Results saved to benchmark_results_<timestamp>.json
```

Benchmark includes:
- **Ingestion speed**: documents per second
- **Query latency**: average, min, max, std dev
- **Comparison**: relative performance metrics

## Architecture Comparison

### ChromaDB Implementation
- **Storage**: Local file-based (SQLite + custom format)
- **Embedding**: On-the-fly or pre-computed
- **Search**: Specialized vector index
- **Best for**: Prototyping, small to medium datasets

### PostgreSQL Implementation  
- **Storage**: PostgreSQL database with pgvector
- **Embedding**: Pre-computed with SentenceTransformers
- **Search**: IVFFlat index on vector column
- **Best for**: Production, large datasets, existing PostgreSQL infrastructure

## Key Differences

| Feature | ChromaDB | PostgreSQL |
|---------|----------|------------|
| Setup | Simple (no server) | Requires PostgreSQL server |
| Scaling | Limited | Excellent |
| ACID | Partial | Full ACID compliance |
| Backup | File copy | Standard DB backup tools |
| Querying | Vector only | Vector + SQL joins |
| Metadata | Limited filtering | Full SQL queries |
| Replication | Manual | Built-in replication |
| Multi-user | Limited | Excellent |

## Database Schema

PostgreSQL creates one table per collection:

```sql
CREATE TABLE collection_name (
    id TEXT PRIMARY KEY,               -- Document ID
    document TEXT NOT NULL,            -- Document text
    embedding vector(384),             -- Vector embedding
    metadata JSONB,                    -- Metadata as JSON
    created_at TIMESTAMP DEFAULT NOW() -- Creation timestamp
);

-- Vector similarity index
CREATE INDEX collection_name_embedding_idx 
ON collection_name USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);
```

## Advanced Usage

### Using Different Collections

```python
from src.database_postgres import RagDatabasePostgres

db = RagDatabasePostgres(
    host="localhost",
    database="rag_db",
    collection_name="default"
)

# Add to specific collection
db.add_documents(docs, metas, ids, collection_name="products")

# Query specific collection  
results = db.query("search text", collection_name="products")

# List all collections
collections = db.list_collections()

# Get statistics
stats = db.get_all_collections_stats()
```

### Custom Embedding Models

```python
db = RagDatabasePostgres(
    host="localhost",
    database="rag_db",
    embedding_model="sentence-transformers/all-mpnet-base-v2"  # 768 dims
)
```

Popular models:
- `all-MiniLM-L6-v2` (384 dims) - Fast, good quality [DEFAULT]
- `all-mpnet-base-v2` (768 dims) - Better quality, slower
- `multi-qa-mpnet-base-dot-v1` (768 dims) - Optimized for Q&A

### PostgreSQL Query Optimization

```sql
-- Check index usage
EXPLAIN ANALYZE 
SELECT * FROM poc 
ORDER BY embedding <=> '[0.1, 0.2, ...]'::vector 
LIMIT 5;

-- Rebuild index with more lists (better for large datasets)
DROP INDEX poc_embedding_idx;
CREATE INDEX poc_embedding_idx 
ON poc USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 200);  -- Increase for better accuracy

-- Vacuum and analyze for better performance
VACUUM ANALYZE poc;
```

## Troubleshooting

### Connection Issues

```python
# Test connection
import psycopg2
conn = psycopg2.connect(
    host="localhost",
    database="rag_db", 
    user="postgres",
    password="your_password"
)
print("Connected successfully!")
conn.close()
```

### pgvector Not Found

```bash
# Check if installed
psql -U postgres -d rag_db -c "SELECT * FROM pg_available_extensions WHERE name = 'vector';"

# Install on macOS
brew install pgvector

# Install on Linux
git clone https://github.com/pgvector/pgvector.git
cd pgvector
make
sudo make install
```

### Slow Queries

- Increase index lists: `WITH (lists = 200)`
- Use connection pooling
- Run `VACUUM ANALYZE` regularly
- Consider partitioning for very large datasets

## Production Considerations

### Security
- Use strong passwords
- Enable SSL/TLS connections
- Use environment variables for credentials
- Restrict database access by IP
- Regular security updates

### Performance
- Use connection pooling (pgbouncer)
- Monitor query performance
- Optimize index parameters based on dataset size
- Consider read replicas for query scaling

### Backup
```bash
# Backup database
pg_dump -U postgres rag_db > rag_db_backup.sql

# Restore database
psql -U postgres -d rag_db < rag_db_backup.sql
```

### Monitoring
```sql
-- Check database size
SELECT pg_size_pretty(pg_database_size('rag_db'));

-- Check table sizes
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename))
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Check index usage
SELECT * FROM pg_stat_user_indexes WHERE schemaname = 'public';
```

## Next Steps

1. **Test with your data**: Run ingestion with a small dataset first
2. **Performance tuning**: Run benchmarks and optimize based on results
3. **Integration**: Update your application to use PostgreSQL database class
4. **Monitoring**: Set up monitoring for production use
5. **Backup strategy**: Implement regular backup procedures

## Resources

- [pgvector Documentation](https://github.com/pgvector/pgvector)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [SentenceTransformers](https://www.sbert.net/)
- [PostgreSQL Performance Tuning](https://wiki.postgresql.org/wiki/Performance_Optimization)

## Support

For issues or questions:
1. Check the [README_POSTGRES.md](README_POSTGRES.md) documentation
2. Review troubleshooting section above
3. Check PostgreSQL and pgvector GitHub issues
4. Verify configuration in [config_postgres.json](config_postgres.json)
