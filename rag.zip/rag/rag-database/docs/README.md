# RAG Database

> **⚠️ Note:** This is legacy documentation. For current multi-backend implementation, see:  
> - **Current Database Docs:** [../README.md](../README.md)  
> - 📖 **[Complete Command Reference → ../../RUNBOOK.md](../../RUNBOOK.md#database-setup)**

Vector database for document storage and retrieval using ChromaDB.

## Setup

```bash
pip install -r requirements.txt
```

## Usage

### Ingest Documents

```bash
# Basic ingestion (uses ./documents folder)
python ingest.py

# Reset database before ingesting
python ingest.py --reset

# Ingest from custom directory
python ingest.py --docs-dir /path/to/documents
```

### Query Database

```bash
# Run test query
python test_query.py
```

Or programmatically:

```python
from src.database import RagDatabase

# Initialize database
db = RagDatabase(persist_directory="./data")

# Query for relevant documents
results = db.query("your query", n_results=5)

# Get database stats
count = db.collection.count()
print(f"Total documents: {count}")

# Reset database (clear all data)
db.reset_database()
```

### Manage ChromaDB

ChromaDB runs in-process with persistent storage in `./data/`:

**View statistics:**
```python
from src.database import RagDatabase
db = RagDatabase()
print(f"Documents: {db.collection.count()}")
```

**Clear all data:**
```bash
python ingest.py --reset
```

**Add documents programmatically:**
```python
from src.database import RagDatabase
from src.ingestion import DocumentProcessor

db = RagDatabase()
processor = DocumentProcessor()

# Load documents
docs = processor.load_directory("./documents")
documents, metadatas, ids = processor.process_documents(docs)

# Add to database
db.add_documents(documents, metadatas, ids)
```

## Structure

```
rag-database/
├── src/
│   ├── database.py       # ChromaDB wrapper
│   └── ingestion.py      # Document processing
├── data/                 # ChromaDB persistent storage
├── documents/            # Documents to ingest
├── logs/                 # Application logs
├── config.json           # Configuration
├── ingest.py             # Ingestion script
├── test_query.py         # Query test script
├── requirements.txt      # Dependencies
└── README.md
```

## Supported Document Formats

- Text files: `.txt`, `.md`, `.py`, `.json`, `.css`, `.js`, `.html`
- PDFs: `.pdf` (requires `pypdf`)
- Word documents: `.docx` (requires `python-docx`)
