# PostgreSQL RAG - Quick Reference

## Setup Commands

### Option 1: Docker (Easiest)
```bash
docker-compose up -d
pip install -r requirements_postgres.txt
```

### Option 2: Local PostgreSQL
```bash
# macOS
brew install postgresql@15 pgvector
brew services start postgresql@15

# Setup
./setup_postgres.sh
# OR
python setup_postgres_db.py
```

## Daily Usage

### Ingest Documents
```bash
python ingest_postgres.py                    # Basic
python ingest_postgres.py --reset            # Reset first
python ingest_postgres.py --docs-dir ./docs  # Custom dir
python ingest_postgres.py --collection name  # Custom collection
```

### Query Documents
```bash
python test_query_postgres.py "search text"
python test_query_postgres.py "text" --n-results 10
python test_query_postgres.py "text" --collection name
```

### Migration
```bash
python setup_postgres_db.py --migrate  # ChromaDB → PostgreSQL
```

### Benchmarking
```bash
python benchmark.py                    # Compare ChromaDB vs PostgreSQL
python benchmark.py --docs 5000        # Custom benchmark
```

## Python API

### Basic Usage
```python
from src.database_postgres import RagDatabasePostgres

# Initialize
db = RagDatabasePostgres(
    host="localhost",
    database="rag_db",
    user="postgres",
    password="postgres",
    collection_name="poc"
)

# Add documents
db.add_documents(documents, metadatas, ids)

# Query
results = db.query("search text", n_results=5)

# Stats
stats = db.get_all_collections_stats()

# Cleanup
db.close()
```

### Multiple Collections
```python
# List collections
collections = db.list_collections()

# Add to collection
db.add_documents(docs, metas, ids, collection_name="products")

# Query collection
results = db.query("text", collection_name="products")

# Delete collection
db.delete_collection("products")
```

## PostgreSQL Commands

### Access Database
```bash
# Docker
docker-compose exec postgres psql -U postgres -d rag_db

# Local
psql -U postgres -d rag_db
```

### Common SQL Queries
```sql
-- List collections (tables)
\dt

-- Count documents in collection
SELECT COUNT(*) FROM poc;

-- Show table schema
\d+ poc

-- List indexes
\di+

-- Check pgvector version
SELECT extversion FROM pg_extension WHERE extname = 'vector';

-- Database size
SELECT pg_size_pretty(pg_database_size('rag_db'));

-- Table sizes
SELECT 
    tablename,
    pg_size_pretty(pg_total_relation_size(tablename::text))
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(tablename::text) DESC;
```

### Performance Tuning
```sql
-- Rebuild index with more lists
DROP INDEX poc_embedding_idx;
CREATE INDEX poc_embedding_idx 
ON poc USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 200);

-- Vacuum and analyze
VACUUM ANALYZE poc;

-- Check query plan
EXPLAIN ANALYZE 
SELECT * FROM poc 
ORDER BY embedding <=> '[...]'::vector 
LIMIT 5;
```

## Docker Commands

```bash
# Start/Stop
docker-compose up -d          # Start
docker-compose stop           # Stop
docker-compose down           # Stop + remove
docker-compose down -v        # Stop + remove + delete data

# Monitoring
docker-compose logs -f        # View logs
docker-compose ps             # Status
docker stats rag-postgres     # Resource usage

# Backup/Restore
docker-compose exec postgres pg_dump -U postgres rag_db > backup.sql
docker-compose exec -T postgres psql -U postgres -d rag_db < backup.sql
```

## Configuration Files

- **config_postgres.json** - Database config
- **requirements_postgres.txt** - Python dependencies
- **docker-compose.yml** - Docker setup
- **init.sql** - Database initialization

## File Structure

```
rag-database/
├── src/
│   ├── database.py              # ChromaDB implementation
│   ├── database_postgres.py     # PostgreSQL implementation ⭐
│   └── ingestion.py             # Document processor (shared)
├── ingest.py                    # ChromaDB ingestion
├── ingest_postgres.py           # PostgreSQL ingestion ⭐
├── test_query.py                # ChromaDB query test
├── test_query_postgres.py       # PostgreSQL query test ⭐
├── config.json                  # ChromaDB config
├── config_postgres.json         # PostgreSQL config ⭐
├── requirements.txt             # ChromaDB deps
├── requirements_postgres.txt    # PostgreSQL deps ⭐
├── setup_postgres.sh            # Bash setup ⭐
├── setup_postgres_db.py         # Python setup ⭐
├── benchmark.py                 # Performance comparison ⭐
├── docker-compose.yml           # Docker setup ⭐
├── README.md                    # ChromaDB docs
├── README_POSTGRES.md           # PostgreSQL docs ⭐
├── POSTGRES_GUIDE.md            # Complete guide ⭐
└── DOCKER_SETUP.md              # Docker guide ⭐
```

⭐ = New PostgreSQL files

## Troubleshooting

### Can't connect
```bash
# Check PostgreSQL is running
pg_isready -h localhost -p 5432 -U postgres
# OR
docker-compose ps

# Test connection
psql -h localhost -U postgres -d rag_db -c "SELECT 1;"
```

### pgvector missing
```sql
-- Check extension
SELECT * FROM pg_available_extensions WHERE name = 'vector';

-- Install extension
CREATE EXTENSION vector;
```

### Slow queries
- Increase index lists: `WITH (lists = 200)`
- Run `VACUUM ANALYZE`
- Check query plan with `EXPLAIN ANALYZE`

### Out of memory
- Reduce batch size in ingestion
- Increase Docker memory limits
- Use smaller embedding model

## Environment Variables

Create `.env` file:
```bash
PG_HOST=localhost
PG_PORT=5432
PG_DATABASE=rag_db
PG_USER=postgres
PG_PASSWORD=your_secure_password
```

Use in code:
```python
import os
from dotenv import load_dotenv

load_dotenv()

db = RagDatabasePostgres(
    host=os.getenv('PG_HOST'),
    port=int(os.getenv('PG_PORT')),
    database=os.getenv('PG_DATABASE'),
    user=os.getenv('PG_USER'),
    password=os.getenv('PG_PASSWORD')
)
```

## Comparison: ChromaDB vs PostgreSQL

| Feature | ChromaDB | PostgreSQL |
|---------|----------|------------|
| Setup | ✅ Easy | ⚠️ Requires server |
| Production Ready | ⚠️ Limited | ✅ Yes |
| Scalability | ⚠️ Limited | ✅ Excellent |
| ACID | ⚠️ Partial | ✅ Full |
| SQL Queries | ❌ No | ✅ Yes |
| Backup | ⚠️ Manual | ✅ Built-in |
| Multi-user | ⚠️ Limited | ✅ Excellent |
| Speed | ✅ Fast | ✅ Fast |

**Choose ChromaDB for:** Quick prototypes, small datasets, simple setups

**Choose PostgreSQL for:** Production apps, large datasets, existing PG infrastructure

## Key Metrics

- **Embedding Model**: all-MiniLM-L6-v2 (384 dimensions)
- **Batch Size**: 1000 documents per batch
- **Index Type**: IVFFlat with 100 lists
- **Distance Metric**: Cosine distance
- **Default Results**: 5 per query

## Next Steps

1. **Install**: Use Docker or local PostgreSQL
2. **Configure**: Edit `config_postgres.json`
3. **Ingest**: Add your documents
4. **Query**: Test vector search
5. **Optimize**: Tune based on performance

## Resources

- [README_POSTGRES.md](README_POSTGRES.md) - Full documentation
- [POSTGRES_GUIDE.md](POSTGRES_GUIDE.md) - Complete guide
- [DOCKER_SETUP.md](DOCKER_SETUP.md) - Docker instructions
- [pgvector GitHub](https://github.com/pgvector/pgvector)
- [PostgreSQL Docs](https://www.postgresql.org/docs/)
