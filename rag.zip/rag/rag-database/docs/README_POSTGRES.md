# RAG Database with PostgreSQL + pgvector

> **⚠️ Note:** This is legacy documentation. For current PostgreSQL implementation, see:  
> - **Current PostgreSQL Docs:** [../postgresql/README.md](../postgresql/README.md)  
> - 📖 **[Complete Command Reference → ../../RUNBOOK.md](../../RUNBOOK.md#postgresql-setup)**

This is an alternative implementation of the RAG (Retrieval-Augmented Generation) database using PostgreSQL with the pgvector extension for vector similarity search.

## Features

- **PostgreSQL Backend**: Uses PostgreSQL as the vector database instead of ChromaDB
- **pgvector Extension**: Leverages pgvector for efficient vector similarity search
- **SentenceTransformers**: Uses the same embedding model (all-MiniLM-L6-v2) for compatibility
- **Batch Operations**: Efficient batch insertion and querying
- **Collection Management**: Support for multiple collections (tables)
- **Compatible API**: Similar API to ChromaDB implementation for easy switching

## Prerequisites

### 1. Install PostgreSQL

**macOS:**
```bash
brew install postgresql@15
brew services start postgresql@15
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

**Windows:**
Download and install from [postgresql.org](https://www.postgresql.org/download/windows/)

### 2. Install pgvector Extension

**macOS:**
```bash
brew install pgvector
```

**Linux:**
```bash
cd /tmp
git clone --branch v0.5.1 https://github.com/pgvector/pgvector.git
cd pgvector
make
sudo make install
```

**Windows:**
Follow instructions at [pgvector GitHub](https://github.com/pgvector/pgvector)

### 3. Create Database

```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE rag_db;

# Connect to the database
\c rag_db

# Enable pgvector extension
CREATE EXTENSION vector;

# Exit
\q
```

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements_postgres.txt
```

2. Configure database connection in `config_postgres.json`:
```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "database": "rag_db",
    "user": "postgres",
    "password": "your_password",
    "collection_name": "poc",
    "embedding_model": "all-MiniLM-L6-v2"
  }
}
```

## Usage

### Ingest Documents

```bash
# Basic ingestion
python ingest_postgres.py

# With custom documents directory
python ingest_postgres.py --docs-dir ./my-docs

# Reset database before ingestion
python ingest_postgres.py --reset

# Use custom collection
python ingest_postgres.py --collection my_collection

# Use custom config
python ingest_postgres.py --config my_config.json
```

### Query Documents

```bash
# Basic query
python test_query_postgres.py "What is machine learning?"

# Query specific collection
python test_query_postgres.py "explain transformers" --collection my_collection

# Get more results
python test_query_postgres.py "python code examples" --n-results 10
```

## Architecture

### Database Schema

Each collection is stored as a PostgreSQL table with the following schema:

```sql
CREATE TABLE collection_name (
    id TEXT PRIMARY KEY,
    document TEXT NOT NULL,
    embedding vector(384),  -- Dimension depends on embedding model
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- IVFFlat index for fast similarity search
CREATE INDEX collection_name_embedding_idx 
ON collection_name USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);
```

### Components

1. **RagDatabasePostgres** (`src/database_postgres.py`):
   - Manages PostgreSQL connection
   - Handles vector operations
   - Provides collection management
   - Compatible with ChromaDB API

2. **DocumentProcessor** (`src/ingestion.py`):
   - Same as ChromaDB implementation
   - Loads and chunks documents
   - Supports multiple file formats

3. **Ingestion Script** (`ingest_postgres.py`):
   - CLI for document ingestion
   - Batch processing
   - Collection management

## Performance Considerations

### Indexing

The implementation uses IVFFlat indexing for fast approximate nearest neighbor search:
- **lists parameter**: Controls the number of clusters (default: 100)
- Larger values = slower build, faster search
- Smaller values = faster build, slower search

### Batch Size

Documents are inserted in batches of 1000 for optimal performance:
- Reduces transaction overhead
- Balances memory usage
- Can be adjusted in the code if needed

### Embedding Generation

Embeddings are generated using SentenceTransformers:
- Model: `all-MiniLM-L6-v2` (384 dimensions)
- Cached after first load
- Batch encoding for efficiency

## Comparison with ChromaDB

### Advantages of PostgreSQL
- ✅ Production-ready RDBMS
- ✅ ACID compliance
- ✅ Advanced querying with SQL
- ✅ Better for large-scale deployments
- ✅ Native support for metadata filtering
- ✅ Robust backup and replication

### Advantages of ChromaDB
- ✅ Simpler setup (no database server)
- ✅ Built-in metadata filtering
- ✅ Faster for prototyping
- ✅ Lighter weight

## Troubleshooting

### Connection Errors

If you get connection errors:
```bash
# Check PostgreSQL is running
pg_isready

# Check connection
psql -U postgres -d rag_db -c "SELECT 1;"
```

### pgvector Not Found

```sql
-- Connect to database
psql -U postgres -d rag_db

-- Check if extension exists
SELECT * FROM pg_available_extensions WHERE name = 'vector';

-- Enable extension
CREATE EXTENSION IF NOT EXISTS vector;
```

### Performance Issues

If queries are slow:
```sql
-- Check index exists
\d+ collection_name

-- Rebuild index with more lists for better performance
DROP INDEX collection_name_embedding_idx;
CREATE INDEX collection_name_embedding_idx 
ON collection_name USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 200);
```

## Security Notes

⚠️ **Important**: The default configuration uses simple credentials. For production:

1. Use strong passwords
2. Enable SSL/TLS connections
3. Use environment variables for credentials
4. Restrict database access by IP
5. Use connection pooling for better performance

Example with environment variables:
```python
import os
db = RagDatabasePostgres(
    host=os.getenv('PG_HOST', 'localhost'),
    user=os.getenv('PG_USER', 'postgres'),
    password=os.getenv('PG_PASSWORD'),
    database=os.getenv('PG_DATABASE', 'rag_db')
)
```

## Future Enhancements

- [ ] Connection pooling
- [ ] Advanced metadata filtering in queries
- [ ] Hybrid search (vector + full-text)
- [ ] Automatic index optimization
- [ ] Migration script from ChromaDB to PostgreSQL
- [ ] Docker compose setup
- [ ] Async operations support
