#!/usr/bin/env python3
"""
Verification script for the new directory structure.
This ensures all imports, paths, and configurations are correct for the
separated ChromaDB and PostgreSQL implementations.
"""

import os
import sys
from pathlib import Path

def check_directory_structure():
    """Verify all expected directories exist."""
    print("=" * 60)
    print("Checking Directory Structure...")
    print("=" * 60)
    
    required_dirs = [
        'chromadb',
        'postgresql',
        'common',
        'data',
        'documents',
        'logs',
        'docs'
    ]
    
    missing_dirs = []
    for dir_name in required_dirs:
        if os.path.isdir(dir_name):
            print(f"✓ {dir_name}/ exists")
        else:
            print(f"✗ {dir_name}/ missing")
            missing_dirs.append(dir_name)
    
    return len(missing_dirs) == 0

def check_config_files():
    """Verify configuration files exist and are valid."""
    print("\n" + "=" * 60)
    print("Checking Configuration Files...")
    print("=" * 60)
    
    config_files = [
        'chromadb/config.json',
        'postgresql/config.json'
    ]
    
    missing_configs = []
    for config_file in config_files:
        if os.path.isfile(config_file):
            print(f"✓ {config_file} exists")
            # Try to parse JSON
            try:
                import json
                with open(config_file, 'r') as f:
                    json.load(f)
                print(f"  └─ Valid JSON")
            except Exception as e:
                print(f"  └─ ⚠ JSON parse error: {e}")
        else:
            print(f"✗ {config_file} missing")
            missing_configs.append(config_file)
    
    return len(missing_configs) == 0

def check_scripts():
    """Verify all scripts exist."""
    print("\n" + "=" * 60)
    print("Checking Implementation Scripts...")
    print("=" * 60)
    
    scripts = {
        'ChromaDB': [
            'chromadb/database.py',
            'chromadb/ingest.py',
            'chromadb/query.py'
        ],
        'PostgreSQL': [
            'postgresql/database.py',
            'postgresql/ingest.py',
            'postgresql/query.py',
            'postgresql/setup.py',
            'postgresql/setup.sh'
        ]
    }
    
    missing_scripts = []
    for impl, script_list in scripts.items():
        print(f"\n{impl}:")
        for script in script_list:
            if os.path.isfile(script):
                print(f"  ✓ {script}")
            else:
                print(f"  ✗ {script} missing")
                missing_scripts.append(script)
    
    return len(missing_scripts) == 0

def check_docs():
    """Verify documentation files exist."""
    print("\n" + "=" * 60)
    print("Checking Documentation...")
    print("=" * 60)
    
    docs = [
        'README.md',
        'MIGRATION_GUIDE.md',
        'chromadb/README.md',
        'postgresql/README.md',
        'docs/README.md',
        'docs/README_POSTGRES.md',
        'docs/POSTGRES_GUIDE.md',
        'docs/QUICK_REFERENCE.md',
        'docs/DOCKER_SETUP.md'
    ]
    
    missing_docs = []
    for doc in docs:
        if os.path.isfile(doc):
            print(f"✓ {doc} exists")
        else:
            print(f"✗ {doc} missing")
            missing_docs.append(doc)
    
    return len(missing_docs) == 0

def check_source_files():
    """Verify source code files exist."""
    print("\n" + "=" * 60)
    print("Checking Source Files...")
    print("=" * 60)
    
    source_files = [
        'chromadb/database.py',
        'postgresql/database.py',
        'common/ingestion.py'
    ]
    
    missing_sources = []
    for source in source_files:
        if os.path.isfile(source):
            print(f"✓ {source} exists")
        else:
            print(f"✗ {source} missing")
            missing_sources.append(source)
    
    return len(missing_sources) == 0

def check_imports():
    """Test if Python imports work correctly."""
    print("\n" + "=" * 60)
    print("Testing Python Imports...")
    print("=" * 60)
    
    tests = [
        ("chromadb.database", "RagDatabase"),
        ("postgresql.database", "RagDatabasePostgres"),
        ("common.ingestion", "DocumentProcessor")
    ]
    
    import_errors = []
    for module, class_name in tests:
        try:
            mod = __import__(module, fromlist=[class_name])
            getattr(mod, class_name)
            print(f"✓ from {module} import {class_name}")
        except Exception as e:
            print(f"✗ from {module} import {class_name}")
            print(f"  └─ Error: {e}")
            import_errors.append(module)
    
    return len(import_errors) == 0

def check_docker_files():
    """Verify Docker configuration files exist."""
    print("\n" + "=" * 60)
    print("Checking Docker Files...")
    print("=" * 60)
    
    docker_files = [
        'postgresql/docker/docker-compose.yml',
        'postgresql/docker/init.sql'
    ]
    
    missing_docker = []
    for docker_file in docker_files:
        if os.path.isfile(docker_file):
            print(f"✓ {docker_file} exists")
        else:
            print(f"✗ {docker_file} missing")
            missing_docker.append(docker_file)
    
    return len(missing_docker) == 0

def check_wrapper_script():
    """Verify the wrapper script exists and is executable."""
    print("\n" + "=" * 60)
    print("Checking Wrapper Script...")
    print("=" * 60)
    
    wrapper = 'rag.sh'
    if os.path.isfile(wrapper):
        print(f"✓ {wrapper} exists")
        if os.access(wrapper, os.X_OK):
            print(f"  └─ Executable")
            return True
        else:
            print(f"  └─ ⚠ Not executable (run: chmod +x {wrapper})")
            return False
    else:
        print(f"✗ {wrapper} missing")
        return False

def main():
    """Run all verification checks."""
    print("\n" + "╔" + "═" * 58 + "╗")
    print("║" + " " * 8 + "RAG Database Structure Verification" + " " * 14 + "║")
    print("║" + " " * 12 + "(Separate ChromaDB & PostgreSQL)" + " " * 13 + "║")
    print("╚" + "═" * 58 + "╝" + "\n")
    
    # Change to script directory
    script_dir = Path(__file__).resolve().parent
    os.chdir(script_dir)
    print(f"Working directory: {script_dir}\n")
    
    results = {
        "Directory Structure": check_directory_structure(),
        "Configuration Files": check_config_files(),
        "Implementation Scripts": check_scripts(),
        "Documentation": check_docs(),
        "Source Files": check_source_files(),
        "Python Imports": check_imports(),
        "Docker Files": check_docker_files(),
        "Wrapper Script": check_wrapper_script()
    }
    
    # Summary
    print("\n" + "=" * 60)
    print("Verification Summary")
    print("=" * 60)
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for check, result in results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status} - {check}")
    
    print("\n" + "=" * 60)
    if passed == total:
        print(f"🎉 All checks passed! ({passed}/{total})")
        print("=" * 60)
        print("\nYour rag-database structure is properly configured.")
        print("\nNext steps:")
        print("  ChromaDB:")
        print("    cd chromadb")
        print("    python ingest.py --docs-dir ../documents")
        print("    python query.py 'search query'")
        print("\n  PostgreSQL:")
        print("    ./rag.sh docker-up")
        print("    cd postgresql && python setup.py")
        print("    python ingest.py --docs-dir ../documents")
        print("    python query.py 'search query'")
        print("\n  Or use wrapper:")
        print("    ./rag.sh chroma-ingest")
        print("    ./rag.sh pg-setup && ./rag.sh pg-ingest")
        return 0
    else:
        print(f"⚠ Some checks failed ({passed}/{total} passed)")
        print("=" * 60)
        print("\nPlease review the errors above and fix any issues.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
