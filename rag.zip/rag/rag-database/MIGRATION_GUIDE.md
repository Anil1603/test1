# Migration Guide - Restructured Directory Layout

## What Changed

The rag-database directory has been reorganized for better maintainability and clarity.

### Old Structure → New Structure

```
OLD LAYOUT                          NEW LAYOUT
├── config.json                     ├── config/
├── config_postgres.json            │   ├── config.json
├── ingest.py                       │   └── config_postgres.json
├── ingest_postgres.py              ├── scripts/
├── test_query.py                   │   ├── ingest.py
├── test_query_postgres.py          │   ├── ingest_postgres.py
├── setup_postgres.sh               │   ├── test_query.py
├── setup_postgres_db.py            │   ├── test_query_postgres.py
├── benchmark.py                    │   ├── setup_postgres.sh
├── README.md                       │   ├── setup_postgres_db.py
├── README_POSTGRES.md              │   └── benchmark.py
├── POSTGRES_GUIDE.md               ├── docs/
├── QUICK_REFERENCE.md              │   ├── README.md
├── DOCKER_SETUP.md                 │   ├── README_POSTGRES.md
├── docker-compose.yml              │   ├── POSTGRES_GUIDE.md
├── init.sql                        │   ├── QUICK_REFERENCE.md
├── data/                           │   └── DOCKER_SETUP.md
├── documents/                      ├── docker/
├── logs/                           │   ├── docker-compose.yml
└── src/                            │   └── init.sql
                                    ├── rag.sh (NEW!)
                                    ├── README.md (NEW ROOT README)
                                    ├── requirements.txt
                                    ├── requirements_postgres.txt
                                    ├── data/
                                    ├── documents/
                                    ├── logs/
                                    └── src/
```

## 📝 Key Changes

### 1. **Configuration Files** → `config/`
- `config.json` → `config/config.json`
- `config_postgres.json` → `config/config_postgres.json`

### 2. **Scripts** → `scripts/`
All executable Python and shell scripts moved to `scripts/`:
- Ingestion scripts
- Query test scripts
- Setup scripts
- Benchmark script

### 3. **Documentation** → `docs/`
All markdown documentation (except root README) moved to `docs/`:
- Implementation guides
- Setup instructions
- Quick reference

### 4. **Docker Files** → `docker/`
Docker-related files moved to `docker/`:
- docker-compose.yml
- init.sql

### 5. **New Convenience Script** → `rag.sh`
Added a CLI wrapper for easier command execution from project root.

## 🔄 Updating Your Workflow

### If You Were Using Direct Commands

**Old way:**
```bash
python ingest_postgres.py --docs-dir documents
python test_query_postgres.py "query text"
```

**New way (Option 1 - Using wrapper):**
```bash
./rag.sh ingest-pg --docs-dir documents
./rag.sh query-pg "query text"
```

**New way (Option 2 - Direct):**
```bash
python scripts/ingest_postgres.py --docs-dir documents
python scripts/test_query_postgres.py "query text"
```

### If You Have Custom Scripts Importing From This Package

**Old imports still work:**
```python
from src.database import RagDatabase
from src.database_postgres import RagDatabasePostgres
from src.ingestion import DocumentProcessor
```

**Config file references updated:**
```python
# Old
config_path = "config.json"

# New (if running from project root)
config_path = "config/config.json"

# Or use the updated defaults in scripts
```

### If You Were Using Docker

**Old way:**
```bash
docker-compose up -d
```

**New way (Option 1 - Using wrapper):**
```bash
./rag.sh docker-up
```

**New way (Option 2 - Direct):**
```bash
cd docker
docker-compose up -d
cd ..
```

## ✅ Migration Checklist

- [ ] Update any custom scripts that reference config files
- [ ] Update any external scripts that call these scripts
- [ ] Update bookmarks or documentation pointing to old file locations
- [ ] If using CI/CD, update pipeline scripts
- [ ] Test ingestion and query with new structure
- [ ] Update any IDE run configurations

## 🆕 New Features

### CLI Wrapper Script (`rag.sh`)

Quick access to all commands:

```bash
# View help
./rag.sh help

# ChromaDB operations
./rag.sh ingest --docs-dir documents
./rag.sh query "search text"

# PostgreSQL operations
./rag.sh ingest-pg --docs-dir documents
./rag.sh query-pg "search text"

# Docker operations
./rag.sh docker-up
./rag.sh docker-down
./rag.sh docker-logs

# Benchmarking
./rag.sh benchmark --docs 1000
```

## 📚 Updated Documentation

All documentation has been updated to reflect the new structure:

- **[README.md](README.md)** - New root README with quick start
- **[docs/QUICK_REFERENCE.md](docs/QUICK_REFERENCE.md)** - Updated command paths
- **[docs/POSTGRES_GUIDE.md](docs/POSTGRES_GUIDE.md)** - Updated file references
- **[docs/DOCKER_SETUP.md](docs/DOCKER_SETUP.md)** - Updated Docker commands

## 🐛 Troubleshooting

### "Config file not found" Error

**Cause:** Running script from wrong directory or using old path

**Solution:**
```bash
# Option 1: Use wrapper from project root
./rag.sh ingest-pg

# Option 2: Specify full path
python scripts/ingest_postgres.py --config config/config_postgres.json

# Option 3: Scripts auto-detect relative paths when run from scripts/
cd scripts
python ingest_postgres.py  # Uses ../config/config_postgres.json
```

### Import Errors

**Cause:** Python can't find the `src` module

**Solution:** Run from project root:
```bash
cd /path/to/rag-database
python scripts/ingest_postgres.py
```

Or add to PYTHONPATH:
```bash
export PYTHONPATH="${PYTHONPATH}:/path/to/rag-database"
```

### Docker Compose Fails

**Cause:** docker-compose.yml moved to `docker/` directory

**Solution:**
```bash
# Use wrapper
./rag.sh docker-up

# Or cd to docker directory
cd docker && docker-compose up -d
```

## 💡 Best Practices

### Working Directory

**Recommended:** Always run from project root
```bash
cd /path/to/rag-database
./rag.sh ingest-pg
# or
python scripts/ingest_postgres.py
```

### Configuration Management

Edit configs in `config/` directory:
```bash
# Edit PostgreSQL config
nano config/config_postgres.json

# Or use your preferred editor
code config/config_postgres.json
```

### Adding Documents

Place documents in `documents/` directory as before:
```bash
cp my-docs/*.pdf documents/
./rag.sh ingest-pg
```

## 🚀 Quick Start with New Structure

### 1. First Time Setup

```bash
# Install dependencies
pip install -r requirements_postgres.txt

# Start PostgreSQL (Docker)
./rag.sh docker-up

# Setup database
python scripts/setup_postgres_db.py
```

### 2. Daily Usage

```bash
# Add documents to documents/ directory
cp *.pdf documents/

# Ingest
./rag.sh ingest-pg

# Query
./rag.sh query-pg "your search query"
```

### 3. View Documentation

```bash
# Quick reference
cat docs/QUICK_REFERENCE.md

# Complete guide
cat docs/POSTGRES_GUIDE.md
```

## 📞 Need Help?

- Check [docs/QUICK_REFERENCE.md](docs/QUICK_REFERENCE.md) for common commands
- Review [README.md](README.md) for project overview
- See [docs/POSTGRES_GUIDE.md](docs/POSTGRES_GUIDE.md) for detailed setup

## ✨ Benefits of New Structure

1. **Better Organization** - Related files grouped together
2. **Clearer Purpose** - Directory names indicate content
3. **Easier Navigation** - Logical folder hierarchy
4. **Simpler Commands** - Wrapper script for convenience
5. **Maintainability** - Easier to find and update files
6. **Scalability** - Room to grow without clutter

The new structure follows common best practices for Python projects and makes the codebase more professional and maintainable.
