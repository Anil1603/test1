import os
import sys
import json
import argparse
import time

# Disable ChromaDB telemetry to avoid errors
os.environ['ANONYMIZED_TELEMETRY'] = 'False'

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import RagDatabase
from common.ingestion import DocumentProcessor

def load_config(config_path="config.json"):
    """Load configuration from JSON file."""
    with open(config_path, 'r') as f:
        return json.load(f)

def main():
    start_time = time.time()
    
    parser = argparse.ArgumentParser(description="Ingest documents into the RAG database.")
    parser.add_argument("--docs-dir", type=str, default="../documents", help="Directory containing documents to ingest.")
    parser.add_argument("--reset", action="store_true", help="Reset the database before ingestion.")
    parser.add_argument("--config", type=str, default="config.json", help="Path to config file.")
    parser.add_argument("--collection", type=str, default=None, help="Collection name (overrides config file).")
    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)
    
    # Use command-line collection name if provided, otherwise use config
    collection_name = args.collection if args.collection else config['database']['collection_name']
    
    # Initialize components with config values
    chunking_config = config.get('ingestion', {})
    chunk_size = chunking_config.get('chunk_size', 1000)
    chunk_overlap = chunking_config.get('chunk_overlap', 200)
    
    db = RagDatabase(
        persist_directory=config['database']['persist_directory'],
        collection_name=collection_name
    )
    processor = DocumentProcessor(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap
    )

    if args.reset:
        print("Resetting database...")
        # ChromaDB client doesn't have a simple 'reset' for persistent, 
        # but we can delete the collection or just clear it.
        # For simplicity in this script, we'll just delete the collection if it exists and recreate it
        # However, RagDatabase init gets or creates. 
        # Let's just delete the items in the collection.
        ids = db.collection.get()['ids']
        if ids:
            db.collection.delete(ids)
        print("Database reset complete.")

    print(f"Loading documents from {args.docs_dir}...")
    raw_docs = processor.load_directory(args.docs_dir)
    print(f"Found {len(raw_docs)} documents.")

    if not raw_docs:
        print("No documents found. Exiting.")
        return

    print("Processing documents...")
    documents, metadatas, ids = processor.process_documents(raw_docs)
    print(f"Generated {len(documents)} chunks.")

    print("Adding to database...")
    # Increased batch size from 100 to 500 for better performance
    # ChromaDB internally handles batches of 5000, so this is safe
    batch_size = 500
    total_chunks = len(documents)
    
    for i in range(0, total_chunks, batch_size):
        batch_end = min(i + batch_size, total_chunks)
        batch_docs = documents[i:batch_end]
        batch_metas = metadatas[i:batch_end]
        batch_ids = ids[i:batch_end]
        
        db.add_documents(batch_docs, batch_metas, batch_ids)
        
        progress = (batch_end / total_chunks) * 100
        # Print progress for every batch
        print(f"Progress: {batch_end}/{total_chunks} chunks ({progress:.1f}%)")
    
    elapsed_time = time.time() - start_time
    
    print(f"\n{'='*60}")
    print(f"✓ Ingestion complete!")
    print(f"{'='*60}")
    print(f"Collection:      {collection_name}")
    print(f"Documents:       {len(raw_docs)}")
    print(f"Chunks created:  {total_chunks}")
    print(f"Time elapsed:    {elapsed_time:.2f}s")
    print(f"Chunks/second:   {total_chunks/elapsed_time:.1f}")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    main()
