import os
import sys
import json
import argparse

# Disable ChromaDB telemetry to avoid errors
os.environ['ANONYMIZED_TELEMETRY'] = 'False'

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import RagDatabase

def load_config(config_path="config.json"):
    """Load configuration from JSON file."""
    with open(config_path, 'r') as f:
        return json.load(f)

def main():
    parser = argparse.ArgumentParser(description="Test query against RAG database.")
    parser.add_argument("query", type=str, nargs='?', default="What database is used?", help="Query text.")
    parser.add_argument("--config", type=str, default="config.json", help="Path to config file.")
    parser.add_argument("--collection", type=str, help="Collection name to query.")
    parser.add_argument("--n-results", type=int, default=5, help="Number of results to return.")
    args = parser.parse_args()

    # Load configuration
    config = load_config(args.config)
    collection_name = args.collection or config['database']['collection_name']

    print("Initializing database...")
    db = RagDatabase(
        persist_directory=config['database']['persist_directory'],
        collection_name=collection_name
    )
    
    print(f"Querying: '{args.query}'")
    
    results = db.query(args.query, n_results=args.n_results, collection_name=collection_name)
    
    documents = results['documents'][0]
    if documents:
        print(f"\nFound {len(documents)} results:")
        for i, (doc, metadata) in enumerate(zip(documents, results['metadatas'][0])):
            print(f"\nResult {i+1}:")
            print(f"  Metadata: {metadata}")
            print(f"  Document preview: {doc[:200]}...")
    else:
        print("No documents found.")

if __name__ == "__main__":
    main()
