"""
ChromaDB RAG Database implementation.

Provides vector storage and similarity search using ChromaDB.
"""

import logging
import os
import ssl
import warnings
from typing import Any, Dict, List, Optional

# Disable ChromaDB telemetry to avoid errors
os.environ['ANONYMIZED_TELEMETRY'] = 'False'

logger = logging.getLogger(__name__)

# Check environment to determine SSL behavior
ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()
DISABLE_SSL_VERIFY = os.getenv("DISABLE_SSL_VERIFY", "false").lower() == "true"

# Only disable SSL in development or when explicitly requested
if ENVIRONMENT == "development" or DISABLE_SSL_VERIFY:
    logger.warning(
        "SSL verification is DISABLED. This should only be used in development environments."
    )
    
    # === SSL WORKAROUND: Only for development ===
    os.environ['HF_HUB_DISABLE_SSL_VERIFY'] = '1'
    os.environ['CURL_CA_BUNDLE'] = ''
    os.environ['REQUESTS_CA_BUNDLE'] = ''
    os.environ['SSL_CERT_FILE'] = ''
    
    # Create unverified SSL context
    ssl._create_default_https_context = ssl._create_unverified_context
    
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    # Monkey-patch requests to disable SSL verification
    import requests
    original_request = requests.Session.request
    def patched_request(self, *args, **kwargs):
        kwargs.setdefault('verify', False)
        return original_request(self, *args, **kwargs)
    requests.Session.request = patched_request
else:
    # Production: Use proper SSL with certifi
    import certifi
    os.environ['SSL_CERT_FILE'] = certifi.where()
    os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
    
    # Custom CA bundle path if provided
    custom_ca_bundle = os.getenv("SSL_CA_BUNDLE")
    if custom_ca_bundle and os.path.exists(custom_ca_bundle):
        os.environ['SSL_CERT_FILE'] = custom_ca_bundle
        os.environ['REQUESTS_CA_BUNDLE'] = custom_ca_bundle

# Disable ChromaDB/Posthog telemetry (privacy, not security)
os.environ['ANONYMIZED_TELEMETRY'] = 'False'
os.environ['POSTHOG_DISABLED'] = '1'

# Now import libraries that may trigger network requests
import chromadb
from chromadb.utils.embedding_functions import DefaultEmbeddingFunction


class RagDatabase:
    """ChromaDB-based RAG database for vector similarity search."""
    
    def __init__(
        self,
        persist_directory: str = "./data/chromadb",
        collection_name: str = "poc"
    ) -> None:
        """
        Initialize ChromaDB RAG database.
        
        Args:
            persist_directory: Directory for persistent storage
            collection_name: Default collection name
        """
        self.persist_directory = persist_directory
        self.client = chromadb.PersistentClient(path=persist_directory)
        
        # Use default embedding function
        self.embedding_fn = DefaultEmbeddingFunction()
        
        self.default_collection_name = collection_name
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self.embedding_fn
        )
        logger.info("ChromaDB initialized at %s", persist_directory)
    
    def get_collection(self, collection_name: Optional[str] = None) -> Any:
        """
        Get or create a collection by name.
        
        Args:
            collection_name: Collection name, or None for default
            
        Returns:
            ChromaDB collection
        """
        if collection_name is None:
            collection_name = self.default_collection_name
        
        return self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self.embedding_fn
        )

    def add_documents(
        self,
        documents: List[str],
        metadatas: List[Dict[str, Any]],
        ids: List[str],
        collection_name: Optional[str] = None
    ) -> None:
        """
        Add documents to the collection.
        
        Args:
            documents: List of document texts
            metadatas: List of metadata dicts
            ids: List of unique IDs
            collection_name: Target collection name
        """
        collection = self.get_collection(collection_name)
        
        # ChromaDB has a max batch size limit, split into chunks of 5000
        batch_size = 5000
        total_docs = len(documents)
        
        for i in range(0, total_docs, batch_size):
            batch_end = min(i + batch_size, total_docs)
            collection.add(
                documents=documents[i:batch_end],
                metadatas=metadatas[i:batch_end],
                ids=ids[i:batch_end]
            )
            logger.debug("Added batch %d-%d of %d", i, batch_end, total_docs)
        
        logger.info("Added %d documents to collection %s", total_docs, collection_name or self.default_collection_name)

    def query(
        self,
        query_text: str,
        n_results: int = 5,
        collection_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Query the collection for similar documents.
        
        Args:
            query_text: Search query
            n_results: Number of results to return
            collection_name: Collection to query
            
        Returns:
            Dict with documents, metadatas, distances, ids
        """
        collection = self.get_collection(collection_name)
        results = collection.query(
            query_texts=[query_text],
            n_results=n_results
        )
        logger.debug("Query returned %d results", len(results.get("documents", [[]])[0]))
        return results
    
    def reset_database(self) -> bool:
        """
        Clear all documents from the default collection.
        
        Returns:
            True on success
            
        Raises:
            Exception: If reset fails
        """
        collection_name = self.collection.name
        
        # Delete and recreate the collection
        self.client.delete_collection(name=collection_name)
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self.embedding_fn
        )
        logger.info("Database reset: collection %s cleared", collection_name)
        return True
    
    def list_collections(self) -> List[str]:
        """
        List all collection names.
        
        Returns:
            List of collection names
        """
        return [col.name for col in self.client.list_collections()]
    
    def get_all_collections_stats(self) -> Dict[str, Any]:
        """
        Get statistics for all collections.
        
        Returns:
            Dict with collection stats
        """
        collections = self.client.list_collections()
        stats: Dict[str, Any] = {
            "total_collections": len(collections),
            "default_collection": self.default_collection_name,
            "embedding_model": "all-MiniLM-L6-v2",
            "persist_directory": self.persist_directory,
            "collections": []
        }
        
        total_docs = 0
        for col in collections:
            count = col.count()
            total_docs += count
            stats["collections"].append({
                "name": col.name,
                "document_count": count
            })
        
        stats["total_documents"] = total_docs
        stats["collections"] = sorted(
            stats["collections"],
            key=lambda x: x["document_count"],
            reverse=True
        )
        
        return stats
    
    def delete_collection(self, collection_name: str) -> bool:
        """
        Delete a specific collection.
        
        Args:
            collection_name: Collection to delete
            
        Returns:
            True on success, False on failure
        """
        try:
            self.client.delete_collection(collection_name)
            logger.info("Deleted collection: %s", collection_name)
            return True
        except Exception as e:
            logger.error("Failed to delete collection %s: %s", collection_name, e)
            return False
    
    def get_collection_count(self, collection_name: Optional[str] = None) -> int:
        """
        Get document count for a collection.
        
        Args:
            collection_name: Collection name, or None for default
            
        Returns:
            Number of documents
        """
        collection = self.get_collection(collection_name)
        return collection.count()
