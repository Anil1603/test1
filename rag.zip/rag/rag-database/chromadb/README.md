# ChromaDB Implementation

📖 **[Complete Command Reference → ../../RUNBOOK.md](../../RUNBOOK.md#chromadb-setup)** - All ChromaDB and server commands

This directory contains the ChromaDB vector database implementation for the RAG system.

## 📁 Files

- **database.py** - ChromaDB database class
- **ingest.py** - Document ingestion script
- **query.py** - Query testing script
- **config.json** - Configuration file
- **requirements.txt** - Python dependencies

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure

Edit `config.json` if needed (default settings work out of the box):

```json
{
  "database": {
    "persist_directory": "../data/chromadb",
    "collection_name": "poc"
  }
}
```

### 3. Ingest Documents

```bash
cd chromadb
python ingest.py --docs-dir ../documents
```

### 4. Query

```bash
python query.py "your search query"
```

## 📝 Usage

### Ingestion

```bash
# Basic ingestion
python ingest.py

# Custom documents directory
python ingest.py --docs-dir /path/to/docs

# Reset database before ingesting
python ingest.py --reset

# Custom config
python ingest.py --config my_config.json
```

### Querying

```bash
# Basic query
python query.py "machine learning"

# More results
python query.py "neural networks" --n-results 10

# Query specific collection
python query.py "python code" --collection my_collection
```

## 🔧 Configuration Options

### Database Settings
- **persist_directory**: Where ChromaDB stores data
- **collection_name**: Default collection name
- **embedding_model**: Embedding model (default uses ChromaDB's built-in)

### Ingestion Settings
- **chunk_size**: Document chunk size (default: 1000)
- **chunk_overlap**: Overlap between chunks (default: 200)

## 📚 API Usage

```python
from chromadb.database import RagDatabase

# Initialize
db = RagDatabase(
    persist_directory="../data/chromadb",
    collection_name="my_collection"
)

# Add documents
db.add_documents(documents, metadatas, ids)

# Query
results = db.query("search text", n_results=5)

# Get stats
stats = db.get_all_collections_stats()
```

## ✨ Features

- ✅ Local file-based storage
- ✅ No server required
- ✅ Fast vector similarity search
- ✅ Multiple collection support
- ✅ Automatic embeddings
- ✅ Easy setup and use

## 🔍 Supported File Formats

- Text: .txt, .md
- Code: .py, .js, .ts, .tsx, .jsx, .java, .cpp, .c, .php, .html, .css
- Documents: .pdf, .docx
- Data: .json, .csv, .yaml, .yml, .xml

## ⚡ Performance

ChromaDB is optimized for:
- Fast prototyping
- Small to medium datasets (< 1M vectors)
- Local development
- Single-user applications

## 🆚 When to Use ChromaDB

**Choose ChromaDB when:**
- Quick setup is important
- Running locally/development
- No database server available
- Dataset < 1M documents
- Single user application

**Consider PostgreSQL when:**
- Production deployment
- Large datasets (> 1M documents)
- Multi-user environment
- Need SQL queries
- Existing PostgreSQL infrastructure

## 🐛 Troubleshooting

### SSL Certificate Issues

If you see SSL errors, the database.py file includes SSL bypass workarounds.

### Collection Not Found

Make sure you've run ingestion first:
```bash
python ingest.py --docs-dir ../documents
```

### No Results Returned

Check if documents were ingested:
```python
from chromadb.database import RagDatabase
db = RagDatabase()
print(db.collection.count())
```

## 📖 More Information

- ChromaDB Documentation: https://docs.trychroma.com/
- Parent README: ../README.md
- Full Guide: ../docs/README.md
