"""
Benchmark script to compare ChromaDB vs PostgreSQL performance

This script compares ingestion speed and query performance between
ChromaDB and PostgreSQL implementations.
"""

import os
import sys
import time
import json
import tempfile
from typing import List, Dict
import statistics

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def benchmark_ingestion(database, documents, metadatas, ids, collection_name="benchmark"):
    """Benchmark document ingestion."""
    start_time = time.time()
    database.add_documents(documents, metadatas, ids, collection_name)
    duration = time.time() - start_time
    
    docs_per_sec = len(documents) / duration if duration > 0 else 0
    
    return {
        'duration': duration,
        'documents': len(documents),
        'docs_per_second': docs_per_sec
    }


def benchmark_queries(database, queries: List[str], n_results=5, collection_name="benchmark"):
    """Benchmark query performance."""
    times = []
    
    for query in queries:
        start_time = time.time()
        results = database.query(query, n_results=n_results, collection_name=collection_name)
        duration = time.time() - start_time
        times.append(duration)
    
    return {
        'queries': len(queries),
        'avg_time': statistics.mean(times),
        'min_time': min(times),
        'max_time': max(times),
        'std_dev': statistics.stdev(times) if len(times) > 1 else 0,
        'total_time': sum(times)
    }
common

def generate_test_documents(num_docs=100, words_per_doc=100):
    """Generate synthetic test documents."""
    from src.ingestion import DocumentProcessor
    
    documents = []
    metadatas = []
    ids = []
    
    sample_words = [
        'machine', 'learning', 'artificial', 'intelligence', 'neural', 'network',
        'data', 'science', 'python', 'algorithm', 'model', 'training', 'inference',
        'vector', 'embedding', 'similarity', 'search', 'database', 'query', 'index',
        'deep', 'learning', 'transformer', 'attention', 'encoder', 'decoder',
        'classification', 'regression', 'clustering', 'optimization', 'gradient'
    ]
    
    import random
    for i in range(num_docs):
        # Generate random document
        doc_text = ' '.join(random.choices(sample_words, k=words_per_doc))
        documents.append(doc_text)
        metadatas.append({
            'doc_id': i,
            'type': 'synthetic',
            'words': words_per_doc
        })
        ids.append(f"doc_{i}")
    
    return documents, metadatas, ids


def generate_test_queries(num_queries=20):
    """Generate test queries."""
    queries = [
        "machine learning algorithms",
        "neural network architecture",
        "deep learning models",
        "data science techniques",
        "artificial intelligence applications",
        "vector embeddings",
        "similarity search",
        "transformer models",
        "attention mechanism",
        "optimization algorithms",
        "gradient descent",
        "classification methods",
        "regression analysis",
        "clustering techniques",
        "model training",
        "inference optimization",
        "database indexing",
        "query performance",
        "embedding similarity",
        "algorithm complexity"
    ]
    return queries[:num_queries]


def run_benchmark(chroma_config_path="chromadb/config.json", 
                 postgres_config_path="postgresql/config.json",
                 num_docs=1000,
                 num_queries=20):
    """Run comprehensive benchmark."""
    
    print("=" * 60)
    print("RAG Database Benchmark: ChromaDB vs PostgreSQL")
    print("=" * 60)
    print(f"\nTest configuration:")
    print(f"  Documents: {num_docs}")
    print(f"  Queries: {num_queries}")
    print(f"  Results per query: 5")
    print()
    
    # Generate test data
    print("Generating test data...")
    documents, metadatas, ids = generate_test_documents(num_docs)
    queries = generate_test_queries(num_queries)
    print(f"✓ Generated {len(documents)} documents and {len(queries)} queries\n")
    
    results = {
        'test_config': {
            'num_docs': num_docs,
            'num_queries': num_queries,
            'docs_per_query': 5
        },
        'chromadb': {},
        'postgresql': {}
    }
    
    # Benchmark ChromaDB
    print("-" * 60)
    print("Testing ChromaDB")
    print("-" * 60)
    try:
        from chromadb.database import RagDatabase
        
        with open(chroma_config_path, 'r') as f:
            chroma_config = json.load(f)
        
        # Use temporary directory for benchmark
        with tempfile.TemporaryDirectory() as tmpdir:
            chroma_db = RagDatabase(
                persist_directory=tmpdir,
                collection_name="benchmark"
            )
            
            # Benchmark ingestion
            print("Testing ingestion...")
            ingest_results = benchmark_ingestion(
                chroma_db, documents, metadatas, ids, "benchmark"
            )
            results['chromadb']['ingestion'] = ingest_results
            print(f"  Duration: {ingest_results['duration']:.2f}s")
            print(f"  Throughput: {ingest_results['docs_per_second']:.2f} docs/sec")
            
            # Benchmark queries
            print("\nTesting queries...")
            query_results = benchmark_queries(
                chroma_db, queries, n_results=5, collection_name="benchmark"
            )
            results['chromadb']['queries'] = query_results
            print(f"  Avg time: {query_results['avg_time']*1000:.2f}ms")
            print(f"  Min time: {query_results['min_time']*1000:.2f}ms")
            print(f"  Max time: {query_results['max_time']*1000:.2f}ms")
            print(f"  Std dev: {query_results['std_dev']*1000:.2f}ms")
        
        results['chromadb']['status'] = 'success'
        
    except Exception as e:
        print(f"❌ ChromaDB benchmark failed: {e}")
        results['chromadb']['status'] = 'failed'
        results['chromadb']['error'] = str(e)
    
    print()
    
    # Benchmark PostgreSQL
    print("-" * 60)
    print("Testing PostgreSQL")
    print("-" * 60)
    try:
        from postgresql.database import RagDatabasePostgres
        
        with open(postgres_config_path, 'r') as f:
            pg_config = json.load(f)
        
        pg_db = RagDatabasePostgres(
            host=pg_config['database']['host'],
            port=pg_config['database']['port'],
            database=pg_config['database']['database'],
            user=pg_config['database']['user'],
            password=pg_config['database']['password'],
            collection_name="benchmark_test",
            embedding_model=pg_config['database']['embedding_model']
        )
        
        # Clean up benchmark collection
        pg_db.delete_collection("benchmark_test")
        pg_db._create_collection_table("benchmark_test")
        
        # Benchmark ingestion
        print("Testing ingestion...")
        ingest_results = benchmark_ingestion(
            pg_db, documents, metadatas, ids, "benchmark_test"
        )
        results['postgresql']['ingestion'] = ingest_results
        print(f"  Duration: {ingest_results['duration']:.2f}s")
        print(f"  Throughput: {ingest_results['docs_per_second']:.2f} docs/sec")
        
        # Benchmark queries
        print("\nTesting queries...")
        query_results = benchmark_queries(
            pg_db, queries, n_results=5, collection_name="benchmark_test"
        )
        results['postgresql']['queries'] = query_results
        print(f"  Avg time: {query_results['avg_time']*1000:.2f}ms")
        print(f"  Min time: {query_results['min_time']*1000:.2f}ms")
        print(f"  Max time: {query_results['max_time']*1000:.2f}ms")
        print(f"  Std dev: {query_results['std_dev']*1000:.2f}ms")
        
        # Clean up
        pg_db.delete_collection("benchmark_test")
        pg_db.close()
        
        results['postgresql']['status'] = 'success'
        
    except Exception as e:
        print(f"❌ PostgreSQL benchmark failed: {e}")
        import traceback
        traceback.print_exc()
        results['postgresql']['status'] = 'failed'
        results['postgresql']['error'] = str(e)
    
    print()
    
    # Print comparison
    print("=" * 60)
    print("Benchmark Results Summary")
    print("=" * 60)
    
    if results['chromadb']['status'] == 'success' and results['postgresql']['status'] == 'success':
        print("\n📊 Ingestion Performance:")
        print(f"  ChromaDB:    {results['chromadb']['ingestion']['duration']:.2f}s "
              f"({results['chromadb']['ingestion']['docs_per_second']:.2f} docs/sec)")
        print(f"  PostgreSQL:  {results['postgresql']['ingestion']['duration']:.2f}s "
              f"({results['postgresql']['ingestion']['docs_per_second']:.2f} docs/sec)")
        
        if results['chromadb']['ingestion']['duration'] < results['postgresql']['ingestion']['duration']:
            speedup = results['postgresql']['ingestion']['duration'] / results['chromadb']['ingestion']['duration']
            print(f"  → ChromaDB is {speedup:.2f}x faster for ingestion")
        else:
            speedup = results['chromadb']['ingestion']['duration'] / results['postgresql']['ingestion']['duration']
            print(f"  → PostgreSQL is {speedup:.2f}x faster for ingestion")
        
        print("\n🔍 Query Performance (average):")
        print(f"  ChromaDB:    {results['chromadb']['queries']['avg_time']*1000:.2f}ms")
        print(f"  PostgreSQL:  {results['postgresql']['queries']['avg_time']*1000:.2f}ms")
        
        if results['chromadb']['queries']['avg_time'] < results['postgresql']['queries']['avg_time']:
            speedup = results['postgresql']['queries']['avg_time'] / results['chromadb']['queries']['avg_time']
            print(f"  → ChromaDB is {speedup:.2f}x faster for queries")
        else:
            speedup = results['chromadb']['queries']['avg_time'] / results['postgresql']['queries']['avg_time']
            print(f"  → PostgreSQL is {speedup:.2f}x faster for queries")
    
    # Save results
    output_file = f"benchmark_results_{int(time.time())}.json"
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\n✓ Detailed results saved to: {output_file}")
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Benchmark ChromaDB vs PostgreSQL")
    parser.add_argument("--docs", type=int, default=1000, help="Number of test documents")
    parser.add_argument("--queries", type=int, default=20, help="Number of test queries")
    parser.add_argument("--chroma-config", type=str, default="chromadb/config.json")
    parser.add_argument("--postgres-config", type=str, default="postgresql/config.json")
    
    args = parser.parse_args()
    
    run_benchmark(
        chroma_config_path=args.chroma_config,
        postgres_config_path=args.postgres_config,
        num_docs=args.docs,
        num_queries=args.queries
    )
