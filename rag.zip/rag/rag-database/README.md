# RAG Database - Vector Storage System

📖 **[Complete Command Reference → ../RUNBOOK.md](../RUNBOOK.md#database-setup)** - All database setup and server commands

A flexible Retrieval-Augmented Generation (RAG) database system with separate implementations for **ChromaDB** and **PostgreSQL** vector databases.

## 📁 Project Structure

```
rag-database/
├── chromadb/                   # ChromaDB Implementation
│   ├── database.py            # ChromaDB vector database class
│   ├── ingest.py              # Document ingestion script
│   ├── query.py               # Query testing script
│   ├── config.json            # ChromaDB configuration
│   ├── requirements.txt       # ChromaDB dependencies
│   └── README.md              # ChromaDB guide
│
├── postgresql/                 # PostgreSQL Implementation
│   ├── database.py            # PostgreSQL + pgvector class
│   ├── ingest.py              # Document ingestion script
│   ├── query.py               # Query testing script
│   ├── setup.py               # Database initialization
│   ├── setup.sh               # Bash setup script
│   ├── config.json            # PostgreSQL configuration
│   ├── requirements.txt       # PostgreSQL dependencies
│   ├── docker/                # Docker Compose setup
│   │   ├── docker-compose.yml
│   │   └── init.sql
│   └── README.md              # PostgreSQL guide
│
├── common/                     # Shared Code
│   └── ingestion.py           # Document processor (used by both)
│
├── data/                       # Database Storage
│   ├── chromadb/              # ChromaDB data
│   └── postgresql/            # PostgreSQL data (if local)
│
├── documents/                  # Source Documents
│   └── test_doc.md
│
├── docs/                       # Documentation
│   ├── README.md              # ChromaDB detailed guide
│   ├── README_POSTGRES.md     # PostgreSQL detailed guide
│   ├── POSTGRES_GUIDE.md      # Complete implementation guide
│   ├── QUICK_REFERENCE.md     # Command cheat sheet
│   └── DOCKER_SETUP.md        # Docker instructions
│
├── logs/                       # Application Logs
│
├── rag.sh                      # CLI Wrapper Script
├── README.md                   # This file
└── MIGRATION_GUIDE.md          # Restructure migration guide
```

## 🚀 Quick Start

### ChromaDB (Simpler, Local)

```bash
# Install dependencies
cd chromadb
pip install -r requirements.txt

# Ingest documents
python ingest.py --docs-dir ../documents

# Query
python query.py "your search query"
```

**OR use the wrapper:**
```bash
./rag.sh chroma-ingest --docs-dir documents
./rag.sh chroma-query "your search query"
```

### PostgreSQL (Production-Ready)

#### Using Docker (Recommended):
```bash
# Start PostgreSQL
./rag.sh docker-up

# Install dependencies
cd postgresql
pip install -r requirements.txt

# Setup database
python setup.py

# Ingest documents
python ingest.py --docs-dir ../documents

# Query
python query.py "your search query"
```

**OR use the wrapper:**
```bash
./rag.sh docker-up
./rag.sh pg-setup
./rag.sh pg-ingest --docs-dir documents
./rag.sh pg-query "your search query"
```

#### Using Local PostgreSQL:
```bash
# Install PostgreSQL and pgvector first (see postgresql/README.md)

cd postgresql
./setup.sh  # OR: python setup.py
python ingest.py
python query.py "search text"
```

## 🎯 Which Implementation Should You Use?

### Use **ChromaDB** when:
- ✅ Quick prototyping and development
- ✅ Small to medium datasets (< 1M vectors)
- ✅ Single-user application
- ✅ No database server setup desired
- ✅ Local/offline operation needed

### Use **PostgreSQL** when:
- ✅ Production environment
- ✅ Large datasets (> 1M vectors)
- ✅ Multi-user concurrent access
- ✅ ACID compliance required
- ✅ Need SQL query capabilities
- ✅ Existing PostgreSQL infrastructure
- ✅ Backup and replication needed

## 📋 CLI Wrapper Commands

The `rag.sh` script provides convenient access to both implementations:

### ChromaDB
```bash
./rag.sh chroma-ingest [options]       # Ingest documents
./rag.sh chroma-query "text" [options] # Query database
```

### PostgreSQL
```bash
./rag.sh pg-setup [options]            # Initialize database
./rag.sh pg-ingest [options]           # Ingest documents
./rag.sh pg-query "text" [options]     # Query database
```

### Docker
```bash
./rag.sh docker-up                     # Start PostgreSQL
./rag.sh docker-down                   # Stop PostgreSQL
./rag.sh docker-logs                   # View logs
./rag.sh docker-shell                  # Open psql shell
```

### Help
```bash
./rag.sh help                          # Show all commands
```

## 📚 Documentation

Each implementation has its own detailed README:

- **[chromadb/README.md](chromadb/README.md)** - ChromaDB setup, usage, and API
- **[postgresql/README.md](postgresql/README.md)** - PostgreSQL setup, Docker, and API
- **[docs/QUICK_REFERENCE.md](docs/QUICK_REFERENCE.md)** - Command cheat sheet
- **[docs/POSTGRES_GUIDE.md](docs/POSTGRES_GUIDE.md)** - Complete PostgreSQL guide
- **[docs/DOCKER_SETUP.md](docs/DOCKER_SETUP.md)** - Docker deployment guide
- **[MIGRATION_GUIDE.md](MIGRATION_GUIDE.md)** - Migration from old structure

## 💡 Features

### Both Implementations Support:
- ✨ Vector similarity search
- ✨ Document chunking and processing
- ✨ Multiple file format support (txt, md, pdf, docx, code files)
- ✨ Batch operations
- ✨ Collection management
- ✨ Metadata storage and filtering

### ChromaDB Specific:
- 🚀 Zero setup - works out of the box
- 🚀 File-based storage
- 🚀 Built-in embeddings
- 🚀 Perfect for prototyping

### PostgreSQL Specific:
- 🎯 Production-grade RDBMS
- 🎯 ACID compliance
- 🎯 SQL query support
- 🎯 IVFFlat vector indexing
- 🎯 Built-in backup/replication
- 🎯 Multi-user support
- 🎯 Excellent scalability

## 🔄 Migration Between Implementations

Migrate data from ChromaDB to PostgreSQL:

```bash
cd postgresql
python setup.py --migrate --chroma-config ../chromadb/config.json
```

## 🧪 Testing Your Setup

### ChromaDB
```bash
cd chromadb
python ingest.py --docs-dir ../documents
python query.py "test query"
```

### PostgreSQL
```bash
cd postgresql
python setup.py
python ingest.py --docs-dir ../documents
python query.py "test query"
```

## 🔧 Configuration

Each implementation has its own `config.json`:

**chromadb/config.json:**
```json
{
  "database": {
    "persist_directory": "../data/chromadb",
    "collection_name": "poc"
  }
}
```

**postgresql/config.json:**
```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "database": "rag_db",
    "user": "postgres",
    "password": "postgres",
    "collection_name": "poc",
    "embedding_model": "all-MiniLM-L6-v2"
  }
}
```

## 🔍 Supported File Formats

Both implementations support:
- **Text:** .txt, .md
- **Code:** .py, .js, .ts, .tsx, .jsx, .java, .cpp, .c, .php, .html, .css
- **Documents:** .pdf, .docx
- **Data:** .json, .csv, .yaml, .yml, .xml

## 📊 Performance Comparison

| Feature | ChromaDB | PostgreSQL |
|---------|----------|------------|
| Setup | ⭐⭐⭐⭐⭐ Easy | ⭐⭐⭐ Medium |
| Speed (Small) | ⭐⭐⭐⭐⭐ Fast | ⭐⭐⭐⭐ Fast |
| Speed (Large) | ⭐⭐⭐ Good | ⭐⭐⭐⭐⭐ Excellent |
| Scalability | ⭐⭐⭐ Limited | ⭐⭐⭐⭐⭐ Excellent |
| Multi-user | ⭐⭐ Limited | ⭐⭐⭐⭐⭐ Excellent |
| Production | ⭐⭐⭐ OK | ⭐⭐⭐⭐⭐ Excellent |
| SQL Queries | ❌ No | ✅ Yes |
| ACID | ⭐⭐ Partial | ⭐⭐⭐⭐⭐ Full |

## 🤝 Shared Components

The `common/` directory contains code shared between implementations:

- **ingestion.py** - Document loading, chunking, and preprocessing

This ensures consistency between ChromaDB and PostgreSQL implementations.

## 🐛 Troubleshooting

### ChromaDB Issues
See [chromadb/README.md](chromadb/README.md#troubleshooting)

### PostgreSQL Issues
See [postgresql/README.md](postgresql/README.md#troubleshooting)

### Import Errors
Make sure you're running from the correct directory:
```bash
cd chromadb  # or postgresql
python ingest.py
```

## 📖 Additional Resources

- **ChromaDB Docs:** https://docs.trychroma.com/
- **pgvector:** https://github.com/pgvector/pgvector
- **PostgreSQL:** https://www.postgresql.org/docs/
- **SentenceTransformers:** https://www.sbert.net/

## 🆘 Getting Help

1. Check the implementation-specific README
2. Review documentation in `docs/`
3. Check configuration files
4. Run `./rag.sh help` for command reference

## 🎓 Next Steps

1. Choose your implementation (ChromaDB for dev, PostgreSQL for prod)
2. Follow the Quick Start guide above
3. Read the implementation-specific README
4. Configure for your use case
5. Add your documents and start querying!

---

**Made with ❤️ for flexible vector database operations**
