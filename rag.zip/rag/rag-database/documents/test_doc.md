# RAG System Test Document

This is a test document to verify the RAG system.
The RAG system should be able to ingest this file and retrieve it when queried.

## Key Information
- The system uses ChromaDB.
- It uses SentenceTransformers for embeddings.
- It is exposed via an MCP server.

If you are reading this, the retrieval worked!
