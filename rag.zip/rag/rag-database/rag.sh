#!/bin/bash
# Convenient wrapper script for RAG database commands

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

case "$1" in
    # ChromaDB commands
    chroma-ingest|chromadb-ingest)
        shift
        cd chromadb && python ingest.py "$@"
        ;;
    chroma-query|chromadb-query)
        shift
        cd chromadb && python query.py "$@"
        ;;
    
    # PostgreSQL commands
    pg-ingest|postgresql-ingest)
        shift
        cd postgresql && python ingest.py "$@"
        ;;
    pg-query|postgresql-query)
        shift
        cd postgresql && python query.py "$@"
        ;;
    pg-setup|postgresql-setup)
        shift
        cd postgresql && python setup.py "$@"
        ;;
    
    # Docker commands
    docker-up)
        cd postgresql/docker && docker-compose up -d && cd ../..
        echo "✓ PostgreSQL is running"
        echo "  Use './rag.sh docker-down' to stop"
        ;;
    docker-down)
        cd postgresql/docker && docker-compose down && cd ../..
        echo "✓ PostgreSQL stopped"
        ;;
    docker-logs)
        cd postgresql/docker && docker-compose logs -f
        ;;
    docker-shell)
        cd postgresql/docker && docker-compose exec postgres psql -U postgres -d rag_db
        ;;
    
    # Benchmark
    benchmark)
        echo "Benchmark script needs to be updated for new structure"
        echo "Run manually from scripts/benchmark.py"
        ;;
    
    # Help
    help|--help|-h|"")
        cat << EOF
╔══════════════════════════════════════════════════════════╗
║              RAG Database CLI Tool                       ║
╚══════════════════════════════════════════════════════════╝

Usage: ./rag.sh <command> [options]

CHROMADB COMMANDS:
  chroma-ingest [options]       Ingest documents into ChromaDB
  chroma-query "text" [options] Query ChromaDB database

POSTGRESQL COMMANDS:
  pg-ingest [options]           Ingest documents into PostgreSQL
  pg-query "text" [options]     Query PostgreSQL database
  pg-setup [options]            Setup/initialize PostgreSQL database

DOCKER COMMANDS:
  docker-up                     Start PostgreSQL with Docker
  docker-down                   Stop PostgreSQL Docker container
  docker-logs                   View PostgreSQL logs
  docker-shell                  Open PostgreSQL shell

OPTIONS:
  Add --help after any command to see specific options

EXAMPLES:
  # ChromaDB
  ./rag.sh chroma-ingest --docs-dir documents
  ./rag.sh chroma-query "machine learning"

  # PostgreSQL (Docker)
  ./rag.sh docker-up
  ./rag.sh pg-setup
  ./rag.sh pg-ingest --docs-dir documents
  ./rag.sh pg-query "neural networks"
  
  # PostgreSQL (Local)
  ./rag.sh pg-setup
  ./rag.sh pg-ingest
  ./rag.sh pg-query "search text"

DIRECTORY STRUCTURE:
  chromadb/         ChromaDB implementation
  postgresql/       PostgreSQL implementation
  common/           Shared code (document processor)
  documents/        Source documents
  data/             Vector database storage
  docs/             Documentation

For detailed documentation:
  chromadb/README.md       - ChromaDB guide
  postgresql/README.md     - PostgreSQL guide
  docs/QUICK_REFERENCE.md  - Command reference
EOF
        ;;
    
    *)
        echo "Unknown command: $1"
        echo "Use './rag.sh help' for usage information"
        exit 1
        ;;
esac
