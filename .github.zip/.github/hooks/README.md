# Agent Lifecycle Hooks

Comprehensive hooks system for GitHub Copilot agents, integrating RAG (Retrieval-Augmented Generation) with the GitHub Copilot SDK for intelligent test automation.

---

## Overview

This hooks system extends GitHub Copilot agents with custom automation workflows, enabling:

- **RAG Integration**: Query ChromaDB for technical documentation
- **Copilot SDK**: Generate test plans using AI
- **Agent Orchestration**: Automated handoffs between agents
- **Quality Validation**: Artifact validation and metrics

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT WORKFLOW                                │
├─────────────────────────────────────────────────────────────────┤
│  Phase 1: Story Review (User Story Review Agent)                │
│     └─→ Review user story quality                               │
│                                                                   │
│  Phase 2: Test Planning (Planner Agent) ★ HOOKS ENABLED         │
│     ├─→ [PRE-HOOK] planner-pre-planning.sh                      │
│     │    ├─→ Query RAG for technical docs                       │
│     │    ├─→ Call GitHub Copilot SDK                            │
│     │    └─→ Generate test cases/steps/data                     │
│     ├─→ [AGENT] Planner Agent execution (optional)              │
│     └─→ [POST-HOOK] planner-post-planning.sh                    │
│          ├─→ Validate generated artifacts                       │
│          └─→ Generate quality metrics                           │
│                                                                   │
│  Phase 3: DOM Analysis (Explorer Agent)                         │
│     └─→ Analyze page structure and locators                     │
│                                                                   │
│  Phase 4: Code Generation (Generator Agent)                     │
│     └─→ Generate Playwright test code                           │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    RAG + COPILOT SDK FLOW                        │
├─────────────────────────────────────────────────────────────────┤
│  User Story → RAG Query → ChromaDB → Technical Docs             │
│                    ↓                                             │
│           Copilot SDK (GPT-4.1)                                  │
│                    ↓                                             │
│  Test Cases + Test Steps + Test Data + Handoff JSON             │
└─────────────────────────────────────────────────────────────────┘
```

### Planner Agent 3-Stage Execution Flow

```
┌──────────────────────────────────────────────────────────────────┐
│ USER: @Planner Agent AP-1 "Order Flow" https://url ecomm        │
└───────────────────────────┬──────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  STAGE 1: Pre-Planning Hook (planner-pre-planning.sh)          │
│  Duration: 1-3 minutes                                          │
├─────────────────────────────────────────────────────────────────┤
│  ✓ Health Check: RAG Server (http://localhost:8000)            │
│  ✓ Validate: user-stories/AP-1_Order_Flow.md exists            │
│  ✓ Duplication Check: Skip if test cases exist                 │
│  ✓ Execute: generate-test-plan-with-rag.ts                     │
│    ├─ Load: config.json (model: gpt-4.1)                       │
│    ├─ Load: user story (2,943 chars)                           │
│    ├─ Load: test-planning.instructions.md (12KB)               │
│    ├─ Query RAG: 15 documents from 'ecomm' collection          │
│    ├─ Build Prompt: Story + RAG Docs + Instructions (~50KB)    │
│    ├─ Copilot SDK: createSession(model: "gpt-4.1")             │
│    ├─ Generate: session.sendAndWait(timeout: 300s)             │
│    └─ Save: 5 artifact files                                   │
│  ✓ Verify: All artifacts created successfully                  │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  STAGE 2: Planner Agent (Optional)                             │
│  Duration: 0 seconds (hooks do the work)                       │
├─────────────────────────────────────────────────────────────────┤
│  • Agent can perform additional processing if needed           │
│  • In current implementation, pre-hook generates everything    │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  STAGE 3: Post-Planning Hook (planner-post-planning.sh)        │
│  Duration: 1-5 seconds                                          │
├─────────────────────────────────────────────────────────────────┤
│  ✓ Validate Required: test-cases.md, handoff JSON              │
│  ✓ Validate Optional: test-steps.json, test-data.json          │
│  ✓ Validate JSON Structure: handoffId, phases, storyId         │
│  ✓ Calculate Metrics: Test count=8, Steps=85, Words=3,500      │
│  ✓ Log Results: .github/hooks/logs/                            │
└───────────────────────────┬─────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  OUTPUT: ✅ Phase 2 Complete - Ready for Explorer Agent        │
└─────────────────────────────────────────────────────────────────┘
```

---

## Hook Configuration

### File: `.github/hooks/agent-hooks.json`

Defines all agent lifecycle hooks, including:
- **Trigger conditions**: When hooks execute
- **Script paths**: Hook implementations
- **Inputs/Outputs**: Expected parameters and artifacts
- **Environment**: Configuration and settings

**Key Sections:**
- `hooks.planner-agent.pre-planning`: RAG + Copilot integration
- `hooks.planner-agent.post-planning`: Validation and metrics
- `configuration.ragIntegration`: RAG server settings
- `configuration.copilotSdk`: Copilot SDK settings

---

## Planner Agent: Detailed Flow

The Planner Agent uses a **3-stage hook architecture** to generate comprehensive test plans through RAG + GitHub Copilot SDK integration.

---

## Stage 1: Pre-Planning Hook 🔄

**File**: `.github/hooks/scripts/planner-pre-planning.sh`  
**Trigger**: `on_agent_invoke` - Runs BEFORE the Planner Agent starts  
**Duration**: 1-3 minutes (depends on story complexity)

### Inputs

| Parameter | Description | Example | Required |
|-----------|-------------|---------|----------|
| `STORY_ID` | Issue key | `AP-1` | ✅ |
| `STORY_TITLE` | Story title | `"Order Flow"` | ✅ |
| `BASE_URL` | Application URL | `https://ecommerce-us-ppr.se.com` | ✅ |
| `COLLECTION` | RAG collection name | `ecomm` | Optional (default: `ecomm`) |

### Execution Steps

#### Step 1: Health Check (Lines 129-143)
```bash
# Verify RAG server is running
curl -s -f "${RAG_API_URL}/health"
```
**Exit 1** if RAG server not available

#### Step 2: Story Validation (Lines 145-158)
```bash
# Verify user story file exists
STORY_PATH="user-stories/${STORY_ID}_${STORY_TITLE}.md"
```
**Exit 2** if story file not found

#### Step 3: Duplication Check (Lines 160-170)
```bash
# Skip if test cases already generated
if [ -f "test-cases/${STORY_ID}-test-cases.md" ]; then
    exit 0  # Skip to avoid regeneration
fi
```

#### Step 4: Setup (Lines 172-186)
- Create output directories (`test-cases/`, `handoff-data/`)
- Install npm dependencies if needed

#### Step 5: Execute RAG Script (Lines 188-203)
```bash
npx tsx ../.github/hooks/scripts/generate-test-plan-with-rag.ts \
  "$STORY_ID" "$STORY_TITLE" "$BASE_URL" "$COLLECTION"
```

See **[Stage 2: RAG Script Execution](#stage-2-rag-script-execution)** below for details.

#### Step 6: Verify Outputs (Lines 205-241)
```bash
ARTIFACTS=(
    "test-cases/${STORY_ID}-test-cases.md"
    "test-cases/${STORY_ID}-test-steps.json"
    "test-cases/${STORY_ID}-test-data.json"
    "test-cases/${STORY_ID}-raw-output.md"
    "handoff-data/phase2-to-phase3-${STORY_ID}.json"
)

# Check all files exist and have minimum size (>100 bytes)
for artifact in "${ARTIFACTS[@]}"; do
    if [ -f "$artifact" ]; then
        SIZE=$(wc -c < "$artifact")
        echo "✅ Found: $artifact ($SIZE bytes)"
    fi
done
```

**Exit 3** if generation failed or artifacts missing

### Exit Codes

| Code | Meaning | Action |
|------|---------|--------|
| `0` | Success | All artifacts generated |
| `1` | RAG server not running | Start RAG server |
| `2` | User story not found | Check filename format |
| `3` | Generation failed | Check logs |
| `4` | Missing parameters | Provide required inputs |

### Usage Examples

```bash
# Method 1: Direct hook invocation
.github/hooks/scripts/planner-pre-planning.sh AP-1 "Order Flow" https://ecommerce-us-ppr.se.com ecomm

# Method 2: Via environment variables
export COPILOT_AGENT_STORY_ID=AP-1
export COPILOT_AGENT_STORY_TITLE="Order Flow"
export COPILOT_AGENT_BASE_URL=https://ecommerce-us-ppr.se.com
export COPILOT_AGENT_COLLECTION=ecomm
.github/hooks/scripts/planner-pre-planning.sh

# Method 3: Via Planner Agent (automatic)
@Planner Agent AP-1 "Order Flow" https://ecommerce-us-ppr.se.com
```

---

## Stage 2: RAG Script Execution 🤖

**File**: `.github/hooks/scripts/generate-test-plan-with-rag.ts`  
**Duration**: 1-3 minutes (AI generation time)  
**Language**: TypeScript (executed via `npx tsx`)

### Execution Flow

#### Step 1: Load Configuration (Lines 34-54)
```typescript
function loadConfig(): Config {
  return {
    model: "gpt-4.1",              // AI model
    ragApiUrl: "http://localhost:8000",
    timeout: 300000,               // 5 minutes
    userStoriesFolder: "user-stories",
    testCasesFolder: "test-cases",
    handoffDataFolder: "handoff-data",
    instructionFile: ".github/instructions/test-planning.instructions.md"
  };
}
```

#### Step 2: Load User Story (Lines 91-106)
```typescript
const story = loadUserStory(storyId, title);
// Reads: user-stories/AP-1_Order_Flow.md
// Example size: 2,943 characters
```

#### Step 3: Query RAG Database (Lines 111-149)
```typescript
const ragResults = await queryRAG(story.content, collection);
// POST http://localhost:8000/query
// Request Body:
{
  "query": "e-commerce marketplace order flow buyer seller checkout payment",
  "collection_name": "ecomm",
  "n_results": 15
}

// Response:
{
  "query": "...",
  "collection": "ecomm",
  "results": [
    {
      "content": "Order flow documentation...",
      "source": "169161862_Order_End_to_End_Integration_Testing.md",
      "similarity": 0.167
    },
    // ... 14 more documents
  ],
  "total_results": 15
}
```

**RAG retrieves the 15 most relevant documents** from the ChromaDB knowledge base based on semantic similarity.

#### Step 4: Load Test Planning Instructions (Lines 154-176)
```typescript
const instruction = loadInstruction();
// Reads: .github/instructions/test-planning.instructions.md
// Size: ~12KB
// Contains:
// - Test design techniques (BVA, EP, Decision Tables, State Transitions)
// - Playwright best practices
// - Test case structure and format
// - Locator strategies (role-based preferred)
// - Data modeling guidelines
```

#### Step 5: Build Comprehensive Prompt (Lines 181-239)
```typescript
const prompt = buildPrompt(story, ragResults, instruction, baseUrl);
// Combines:
// ┌─────────────────────────────────────────┐
// │ Test Planning Instructions (12KB)      │
// ├─────────────────────────────────────────┤
// │ User Story Content (2-5KB)             │
// ├─────────────────────────────────────────┤
// │ RAG Results: 15 Documents (20-40KB)    │
// │  - Document 1: Source + Content        │
// │  - Document 2: Source + Content        │
// │  - ... (15 total)                      │
// ├─────────────────────────────────────────┤
// │ Base URL Context                       │
// └─────────────────────────────────────────┘
// Total Prompt Size: ~30-50KB
```

#### Step 6: Initialize GitHub Copilot SDK (Lines 244-265)
```typescript
const client = new CopilotClient();
await client.start();

const session = await client.createSession({ 
  model: "gpt-4.1",           // Using GPT-4.1
  streaming: true             // Stream responses
});

console.log("🤖 Connected to GitHub Copilot SDK");
console.log("   Model: gpt-4.1");
console.log("   User: @rahulvennapusa");
```

#### Step 7: Generate Test Plan (Lines 267-280)
```typescript
const result = await session.sendAndWait({ prompt }, 300000);
// Timeout: 300 seconds (5 minutes)
// Streaming: Progress dots displayed every 200 characters
// Duration: 1-3 minutes depending on complexity
```

**AI Processing**:
- Analyzes user story requirements
- Reviews RAG-provided technical documentation
- Applies test design techniques (BVA, EP, Decision Tables)
- Generates comprehensive test cases, steps, and data
- Structures output in specified format

#### Step 8: Parse and Save Outputs (Lines 285-349)
```typescript
parseAndSaveOutputs(response, storyId, baseUrl);
```

**Creates 5 Files**:

##### 1. Test Cases Markdown
**File**: `test-cases/AP-1-test-cases.md`

```markdown
# Test Cases: AP-1 Order Flow

## Test Design Approach
- **Boundary Value Analysis**: Cart quantity limits (0, 1, 99, 100, 101)
- **Equivalence Partitioning**: User types (guest, logged-in, tax-exempt)
- **Decision Tables**: Payment methods × Shipping options
- **State Transitions**: Cart states (empty → items → checkout → order)

---

## Functional Area: Checkout Flow

#### TC-AP1-001: Guest User Checkout - Happy Path
- **ID**: TC-AP1-001
- **Priority**: High
- **Type**: E2E Happy Path
- **Preconditions**: 
  - User not logged in
  - Product available in catalog
- **Test Steps**:
  1. Navigate to product page
  2. Add product to cart
  3. Proceed to checkout as guest
  4. Enter shipping information
  5. Select payment method
  6. Complete order
- **Expected Results**:
  - Order confirmation displayed
  - Order ID generated
  - Email confirmation sent
- **Test Data References**: `testUsers.guest`, `products.single_seller`

#### TC-AP1-002: Logged-in User Checkout - Pre-saved Address
- **ID**: TC-AP1-002
- **Priority**: High
...
```

##### 2. Test Steps JSON
**File**: `test-cases/AP-1-test-steps.json`

```json
{
  "testCases": [
    {
      "id": "TC-AP1-001",
      "title": "Guest User Checkout - Happy Path",
      "steps": [
        {
          "stepNumber": 1,
          "action": "navigate",
          "target": "page.goto",
          "params": ["${baseUrl}/products/${productId}"],
          "data": null,
          "expectedOutcome": "Product page loads successfully"
        },
        {
          "stepNumber": 2,
          "action": "click",
          "target": "page.getByRole('button', { name: 'Add to Cart' })",
          "params": [],
          "data": null,
          "expectedOutcome": "Product added to cart, notification shown"
        },
        {
          "stepNumber": 3,
          "action": "click",
          "target": "page.getByRole('link', { name: 'Cart' })",
          "params": [],
          "data": null,
          "expectedOutcome": "Navigate to cart page"
        },
        {
          "stepNumber": 4,
          "action": "click",
          "target": "page.getByRole('button', { name: 'Checkout' })",
          "params": [],
          "data": null,
          "expectedOutcome": "Navigate to checkout page"
        },
        {
          "stepNumber": 5,
          "action": "fill",
          "target": "page.getByLabel('Email')",
          "params": ["${testData.email}"],
          "data": "testUsers.guest.email",
          "expectedOutcome": "Email field populated"
        }
        // ... more steps
      ]
    }
  ]
}
```

##### 3. Test Data JSON
**File**: `test-cases/AP-1-test-data.json`

```json
{
  "testUsers": [
    {
      "id": "guest_user_1",
      "type": "guest",
      "email": "guest.user@test.com",
      "firstName": "John",
      "lastName": "Doe",
      "phone": "+1-555-0123",
      "scenario": "happy-path"
    },
    {
      "id": "logged_in_user_1",
      "type": "registered",
      "email": "registered.user@test.com",
      "password": "Test@1234",
      "scenario": "pre-saved-address"
    }
  ],
  "products": [
    {
      "id": "single_seller_product",
      "name": "Wireless Mouse",
      "sku": "TECH-001",
      "price": 29.99,
      "seller": "ElectronicsPlus",
      "inStock": true,
      "category": "Electronics"
    }
  ],
  "shippingAddresses": [
    {
      "id": "us_address_1",
      "country": "United States",
      "state": "California",
      "city": "San Francisco",
      "zipCode": "94102",
      "addressLine1": "123 Market Street",
      "addressLine2": "Apt 4B"
    }
  ],
  "paymentMethods": [
    {
      "type": "credit_card",
      "cardNumber": "4111111111111111",
      "expiryMonth": "12",
      "expiryYear": "2027",
      "cvv": "123",
      "cardholderName": "John Doe"
    }
  ],
  "scenarios": {
    "happy_path": {
      "user": "guest_user_1",
      "product": "single_seller_product",
      "shipping": "us_address_1",
      "payment": "credit_card"
    }
  }
}
```

##### 4. Raw Output Markdown
**File**: `test-cases/AP-1-raw-output.md`

Contains the complete, unprocessed AI response for debugging and reference.

##### 5. Handoff Data JSON
**File**: `handoff-data/phase2-to-phase3-AP-1.json`

```json
{
  "handoffId": "phase-2-to-phase-3-AP-1",
  "timestamp": "2026-02-04T10:30:00.000Z",
  "sourcePhase": {
    "number": 2,
    "name": "Test Planning & Scenario Design",
    "agent": "planner"
  },
  "targetPhase": {
    "number": 3,
    "name": "DOM Analysis & Locator Strategy",
    "agent": "explorer"
  },
  "storyId": "AP-1",
  "context": {
    "artifacts": [
      "test-cases/AP-1-test-cases.md",
      "test-cases/AP-1-test-steps.json",
      "test-cases/AP-1-test-data.json"
    ],
    "baseUrl": "https://ecommerce-us-ppr.se.com"
  },
  "data": {
    "testCasesReady": true,
    "ragDocumentsUsed": true,
    "documentCount": 15,
    "testCaseCount": 8,
    "model": "gpt-4.1"
  },
  "validation": {
    "passed": true
  },
  "nextAction": "phase3-dom-analysis"
}
```

### Script Statistics

| Metric | Typical Value |
|--------|---------------|
| Prompt Size | 30-50 KB |
| RAG Documents | 15 |
| AI Response Time | 1-3 minutes |
| Test Cases Generated | 6-12 |
| Test Steps Generated | 50-150 |
| Output Files | 5 |
| Total Output Size | 20-80 KB |

---

## Stage 3: Post-Planning Hook ✅

**File**: `.github/hooks/scripts/planner-post-planning.sh`  
**Trigger**: `after_agent_complete` - Runs AFTER the Planner Agent finishes  
**Duration**: 1-5 seconds

### Validation Steps

#### Step 1: Validate Required Artifacts (Lines 66-88)
```bash
REQUIRED_ARTIFACTS=(
  "test-cases/${STORY_ID}-test-cases.md"
  "handoff-data/phase2-to-phase3-${STORY_ID}.json"
)

for artifact in "${REQUIRED_ARTIFACTS[@]}"; do
    if [ -f "$artifact" ]; then
        size=$(wc -c < "$artifact")
        echo "✅ Found: $artifact (${size} bytes)"
        
        # Validate minimum size
        if [ "$size" -lt 100 ]; then
            echo "⚠️  Warning: File too small"
        fi
    else
        echo "❌ Missing: $artifact"
        MISSING_REQUIRED=true
    fi
done
```

**Exit 1** if required artifacts missing

#### Step 2: Validate Optional Artifacts (Lines 90-104)
```bash
OPTIONAL_ARTIFACTS=(
  "test-cases/${STORY_ID}-test-steps.json"
  "test-cases/${STORY_ID}-test-data.json"
  "test-cases/${STORY_ID}-raw-output.md"
)

# Log warnings but don't fail if missing
```

#### Step 3: Validate Handoff JSON Structure (Lines 106-136)
```bash
HANDOFF_FILE="handoff-data/phase2-to-phase3-${STORY_ID}.json"

REQUIRED_FIELDS=(
  ".handoffId"
  ".timestamp"
  ".sourcePhase"
  ".targetPhase"
  ".storyId"
  ".nextAction"
)

# Using jq to validate JSON structure
for field in "${REQUIRED_FIELDS[@]}"; do
    if jq -e "$field" "$HANDOFF_FILE" > /dev/null 2>&1; then
        value=$(jq -r "$field" "$HANDOFF_FILE")
        echo "✅ $field: $value"
    else
        echo "❌ Missing field: $field"
        exit 2
    fi
done
```

**Exit 2** if handoff structure invalid

#### Step 4: Calculate Quality Metrics (Lines 138-166)
```bash
TEST_CASES_FILE="test-cases/${STORY_ID}-test-cases.md"

# Count test cases (lines starting with "#### TC-")
TC_COUNT=$(grep -c "^#### TC-" "$TEST_CASES_FILE")

# Count test steps (numbered lists after "Test Steps")
STEPS_COUNT=$(grep -A 100 "Test Steps" "$TEST_CASES_FILE" | grep -c "^[0-9]\.")

# Word count
WORDS=$(wc -w < "$TEST_CASES_FILE")

echo "📊 Quality Metrics:"
echo "  Test Cases: $TC_COUNT"
echo "  Test Steps: $STEPS_COUNT"
echo "  Documentation: $WORDS words"

# Warning if less than 3 test cases
if [ "$TC_COUNT" -lt 3 ]; then
    echo "⚠️  Warning: Low test case count"
fi
```

#### Step 5: Generate Summary (Lines 168-186)
```bash
echo "════════════════════════════════════════════════════"
echo "✅ Post-Planning Validation Complete"
echo "════════════════════════════════════════════════════"
echo ""
echo "Story: $STORY_ID"
echo "Status: Ready for Phase 3 (DOM Analysis)"
echo "Next Agent: Explorer Agent"
echo ""
echo "Log file: $LOG_FILE"
```

### Exit Codes

| Code | Meaning | Action |
|------|---------|--------|
| `0` | Validation passed | Proceed to next phase |
| `1` | Missing required artifacts | Re-run pre-planning hook |
| `2` | Invalid handoff data | Check handoff JSON structure |

### Typical Output Example

```
════════════════════════════════════════════════════════
  🪝 Agent Hook: Planner Post-Planning Validation
════════════════════════════════════════════════════════

📋 Checking required artifacts...
✅ Found: test-cases/AP-1-test-cases.md (45,230 bytes)
✅ Found: handoff-data/phase2-to-phase3-AP-1.json (1,245 bytes)

📋 Checking optional artifacts...
✅ Found: test-cases/AP-1-test-steps.json (23,450 bytes)
✅ Found: test-cases/AP-1-test-data.json (12,890 bytes)
✅ Found: test-cases/AP-1-raw-output.md (67,340 bytes)

🔍 Validating handoff data structure...
✅ .handoffId: phase-2-to-phase-3-AP-1
✅ .timestamp: 2026-02-04T10:30:00.000Z
✅ .sourcePhase: phase2-planner
✅ .targetPhase: phase3-explorer
✅ .storyId: AP-1
✅ .nextAction: phase3-dom-analysis

📊 Test Case Quality Metrics
  Test Cases: 8
  Test Steps: 85
  Documentation: 3,542 words

════════════════════════════════════════════════════════
✅ Post-Planning Validation Complete
════════════════════════════════════════════════════════

Story: AP-1
Status: Ready for Phase 3 (DOM Analysis)
Next Agent: Explorer Agent

Log file: .github/hooks/logs/planner-agent.post-planning-20260204-103005.log
```

---

## Complete Flow Summary

### Timeline

```
t=0s      User invokes Planner Agent
t=1s      Pre-hook: Health checks pass
t=2s      Pre-hook: Story validation complete
t=3s      Pre-hook: RAG script starts
t=5s      RAG Script: Configuration loaded
t=6s      RAG Script: Story loaded (2.9KB)
t=8s      RAG Script: Query RAG (15 docs retrieved)
t=10s     RAG Script: Instructions loaded (12KB)
t=12s     RAG Script: Prompt built (50KB)
t=15s     RAG Script: Copilot SDK connected
t=18s     RAG Script: AI generation started
t=120s    RAG Script: AI generation complete (1m 42s)
t=122s    RAG Script: Parsing response
t=125s    RAG Script: Saved 5 files
t=126s    Pre-hook: Verification complete
t=126s    Pre-hook: Exit 0 (success)
t=127s    Post-hook: Validation starts
t=128s    Post-hook: Artifacts validated
t=129s    Post-hook: Metrics calculated
t=130s    Post-hook: Exit 0 (success)
t=130s    ✅ Phase 2 Complete
```

**Total Duration**: ~2 minutes 10 seconds

### Key Success Factors

1. ✅ **RAG Server Running**: Must be healthy on port 8000
2. ✅ **ChromaDB Indexed**: 2,115 documents in 'ecomm' collection
3. ✅ **User Story Exists**: Proper filename format
4. ✅ **Copilot SDK**: Authenticated and accessible
5. ✅ **Configuration**: Valid config.json with model settings
6. ✅ **Instructions**: test-planning.instructions.md available

### Generated Artifacts

| File | Size | Purpose |
|------|------|---------|
| `test-cases/*.md` | 20-80 KB | Human-readable test cases |
| `test-cases/*.json` (steps) | 10-40 KB | Machine-readable steps |
| `test-cases/*.json` (data) | 5-20 KB | Test data structures |
| `test-cases/*.md` (raw) | 40-100 KB | Complete AI response |
| `handoff-data/*.json` | 1-3 KB | Phase transition data |

---

## RAG + Copilot SDK Integration

### Script: `.github/hooks/scripts/generate-test-plan-with-rag.ts`

TypeScript client that orchestrates:
1. User story loading
2. RAG database querying
3. Instruction template loading
4. GitHub Copilot SDK invocation
5. Response parsing and artifact generation

**Configuration**: `rag/client/config.json`

```json
{
  "model": "gpt-4.1",
  "ragApiUrl": "http://localhost:8000",
  "defaultNResults": 15,
  "instructionFolder": "../.github/instructions",
  "timeout": 300000
}
```

**Test Planning Instruction**: `.github/instructions/test-planning.instructions.md`

Comprehensive instruction template for AI test generation, including:
- Test design techniques (BVA, EP, Decision Tables, State Transitions)
- Playwright best practices
- Test case structure and format
- Locator strategies (role-based preferred)
- Data modeling guidelines

---

## Prerequisites

### 1. RAG Server Running

```bash
cd rag
./scripts/run-server.sh
# Or manually:
python3 servers/rag_server_api.py
```

**Health Check:**
```bash
curl http://localhost:8000/health
```

### 2. Documents Indexed in ChromaDB

```bash
cd rag
npm run ingest -- ../confluence-pages-ecommerce
```

### 3. GitHub Copilot SDK Configured

Ensure GitHub Copilot is authenticated and available.

### 4. Dependencies Installed

```bash
cd rag
npm install
```

---

## Usage Examples

### Example 1: Full Workflow with Planner Agent

```bash
# 1. Start RAG server
cd rag && ./scripts/run-server.sh &

# 2. Invoke Planner Agent (hooks run automatically)
# Via GitHub Copilot:
@Planner Agent create test plan for AP-1 "Order Flow" https://ecommerce-us-ppr.se.com

# 3. Hooks execute:
#    - Pre-planning: Queries RAG, generates with Copilot SDK
#    - Agent: Planner Agent logic
#    - Post-planning: Validates artifacts

# 4. Review outputs:
ls -la test-cases/AP-1-*
cat test-cases/AP-1-test-cases.md
cat handoff-data/phase2-to-phase3-AP-1.json
```

### Example 2: Manual Hook Invocation

```bash
# Run pre-planning hook manually
.github/hooks/scripts/planner-pre-planning.sh AP-1 "Order Flow" https://ecommerce-us-ppr.se.com

# Check logs
tail -f .github/hooks/logs/planner-agent.pre-planning-*.log

# Run post-planning validation
.github/hooks/scripts/planner-post-planning.sh AP-1
```

### Example 3: Using Shell Script (Recommended)

```bash
# Use the shell wrapper script (includes collection parameter)
./scripts/generate-test-plan-rag.sh AP-1 "Order Flow" https://ecommerce-us-ppr.se.com ecomm

# Or without explicit collection (defaults to 'ecomm')
./scripts/generate-test-plan-rag.sh AP-1 "Order Flow" https://ecommerce-us-ppr.se.com
```

### Example 4: Using npm script from rag folder

```bash
# From rag directory
cd rag
npm run generate-test-plan -- AP-1 "Order Flow" https://ecommerce-us-ppr.se.com ecomm
```

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `RAG_API_URL` | RAG server endpoint | `http://localhost:8000` |
| `COPILOT_AGENT_COLLECTION` | Collection name for hooks | `ecomm` |
| `COPILOT_AGENT_STORY_ID` | Story ID for hooks | - |
| `COPILOT_AGENT_STORY_TITLE` | Story title for hooks | - |
| `COPILOT_AGENT_BASE_URL` | Application URL | - |

---

## Logging

All hook executions are logged to:
```
.github/hooks/logs/
├── planner-agent.pre-planning-{timestamp}.log
└── planner-agent.post-planning-{timestamp}.log
```

**Log format:**
```
[timestamp] [level] message
```

**Levels:** INFO, SUCCESS, WARNING, ERROR, METRICS

---

## Troubleshooting

### RAG Server Not Running

**Symptom:** Hook fails with exit code 1

**Solution:**
```bash
cd rag
./scripts/run-server.sh
# Or:
python3 servers/rag_server_api.py
```

### User Story Not Found

**Symptom:** Hook fails with exit code 2

**Solution:**
```bash
# Check filename format: {STORY_ID}_{TITLE_WITH_UNDERSCORES}.md
ls user-stories/
# Example: AP-1_Order_Flow.md
```

### Test Plan Generation Failed

**Symptom:** Hook fails with exit code 3

**Solution:**
1. Check RAG server has documents indexed
2. Verify GitHub Copilot SDK authentication
3. Review log file for detailed errors
4. Check instruction template exists: `.github/instructions/test-planning.instructions.md`

### Missing Artifacts

**Symptom:** Post-planning validation fails

**Solution:**
1. Check pre-planning hook completed successfully
2. Review pre-planning log for errors
3. Verify disk space and write permissions

---

## Handoff Data Format

**File**: `handoff-data/phase2-to-phase3-{STORY_ID}.json`

```json
{
  "handoffId": "phase-2-to-phase-3-AP-1",
  "timestamp": "2026-02-04T12:00:00Z",
  "sourcePhase": {
    "number": 2,
    "name": "Test Planning & Scenario Design",
    "agent": "planner"
  },
  "targetPhase": {
    "number": 3,
    "name": "DOM Analysis & Locator Strategy",
    "agent": "explorer"
  },
  "storyId": "AP-1",
  "context": {
    "artifacts": [
      "test-cases/AP-1-test-cases.md",
      "test-cases/AP-1-test-steps.json",
      "test-cases/AP-1-test-data.json"
    ],
    "baseUrl": "https://ecommerce-us-ppr.se.com"
  },
  "data": {
    "testCasesReady": true,
    "ragDocumentsUsed": true
  },
  "validation": {
    "passed": true
  },
  "nextAction": "phase3-dom-analysis"
}
```

---

## Extending Hooks

### Adding a New Hook

1. **Define in `agent-hooks.json`:**

```json
{
  "hooks": {
    "your-agent": {
      "your-hook": {
        "description": "Hook description",
        "script": ".github/hooks/scripts/your-hook.sh",
        "timeout": 60000,
        "required": true,
        "actions": ["Action 1", "Action 2"]
      }
    }
  }
}
```

2. **Create script:**

```bash
#!/bin/bash
# .github/hooks/scripts/your-hook.sh

set -e

# Your hook logic here
echo "Hook executed!"
exit 0
```

3. **Make executable:**

```bash
chmod +x .github/hooks/scripts/your-hook.sh
```

### Hook Best Practices

1. ✅ Always set `-e` to fail fast
2. ✅ Log all actions with timestamps
3. ✅ Use meaningful exit codes
4. ✅ Validate inputs early
5. ✅ Create comprehensive error messages
6. ✅ Log to dedicated log files
7. ✅ Clean up temporary resources
8. ✅ Make hooks idempotent when possible

---

## Performance Metrics

Typical hook execution times:

| Hook | Duration | Description |
|------|----------|-------------|
| `planner-pre-planning` | 1-3 min | RAG query + AI generation |
| `planner-post-planning` | 1-5 sec | Validation only |

**Factors affecting performance:**
- RAG database size and index quality
- Number of documents retrieved (default: 15)
- Copilot SDK model and prompt size
- Network latency

---

## Security Considerations

1. **API Keys**: Never commit API keys or credentials
2. **Permissions**: Hooks run with user permissions
3. **Validation**: Always validate inputs and outputs
4. **Logging**: Sanitize sensitive data in logs
5. **Network**: Use secure connections (HTTPS)

---

## Future Enhancements

Planned improvements:

- [ ] Explorer Agent hook (DOM analysis with RAG)
- [ ] Generator Agent hook (code patterns from RAG)
- [ ] Parallel hook execution
- [ ] Hook dependency management
- [ ] Metrics dashboard
- [ ] Webhook notifications
- [ ] Cloud-based RAG server support

---

## Related Documentation

- [Agents Documentation](../../docs/AGENTS.md)
- [RAG Documentation](../../rag/README.md)
- [Test Planning Instructions](../instructions/test-planning.instructions.md)
- [GitHub Copilot Hooks](https://docs.github.com/en/copilot/concepts/agents/coding-agent/about-hooks)

---

## Support

For issues or questions:
1. Check logs in `.github/hooks/logs/`
2. Review this documentation
3. Contact QA Automation Team
4. File an issue in the repository

---

**Last Updated**: 2026-02-04  
**Version**: 2.0.0  
**Maintainer**: QA Automation Team
