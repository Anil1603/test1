#!/bin/bash
#
# Generator Agent Pre-Generation Hook
# 
# Builds self-healing locator strategies from DOM analysis artifacts
# before the Generator Agent creates test code.
#
# Usage: ./generator-pre-generation.sh <STORY_ID> [OPTIONS]
#
# Arguments:
#   STORY_ID          Issue key (e.g., AP-1) - required
#
# Options:
#   --healing-strategy   Self-healing strategy: aggressive | standard | conservative
#   --min-confidence     Minimum locator confidence threshold (default: 0.5)
#   --max-fallbacks      Maximum fallback locators per element (default: 3)
#   --format             Output format: typescript | json | both (default: both)
#

set -e

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Default values
STORY_ID=""
HEALING_STRATEGY="standard"
MIN_CONFIDENCE="0.5"
MAX_FALLBACKS="3"
OUTPUT_FORMAT="both"

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --healing-strategy)
      HEALING_STRATEGY="$2"
      shift 2
      ;;
    --min-confidence)
      MIN_CONFIDENCE="$2"
      shift 2
      ;;
    --max-fallbacks)
      MAX_FALLBACKS="$2"
      shift 2
      ;;
    --format)
      OUTPUT_FORMAT="$2"
      shift 2
      ;;
    *)
      if [[ -z "$STORY_ID" && ! "$1" =~ ^-- ]]; then
        STORY_ID="$1"
      fi
      shift
      ;;
  esac
done

# Validate required arguments
if [[ -z "$STORY_ID" ]]; then
  echo "Error: STORY_ID is required"
  echo "Usage: ./generator-pre-generation.sh <STORY_ID> [OPTIONS]"
  exit 1
fi

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║           Generator Agent Pre-Generation Hook                 ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "Story ID:         $STORY_ID"
echo "Healing Strategy: $HEALING_STRATEGY"
echo "Min Confidence:   $MIN_CONFIDENCE"
echo "Max Fallbacks:    $MAX_FALLBACKS"
echo "Output Format:    $OUTPUT_FORMAT"
echo ""

# Check for handoff file from Explorer Agent
HANDOFF_FILE="$PROJECT_ROOT/handoff-data/phase3-to-phase4-$STORY_ID.json"
if [[ -f "$HANDOFF_FILE" ]]; then
  echo "✓ Found Explorer Agent handoff: $HANDOFF_FILE"
else
  echo "⚠ Warning: Explorer Agent handoff not found: $HANDOFF_FILE"
  echo "  Continuing without handoff validation..."
fi

# Check for DOM snapshots
SNAPSHOTS_DIR="$PROJECT_ROOT/dom-analysis/dom-snapshots"
SNAPSHOT_COUNT=$(find "$SNAPSHOTS_DIR" -name "${STORY_ID}_*.json" 2>/dev/null | wc -l | tr -d ' ')
echo "✓ Found $SNAPSHOT_COUNT DOM snapshots for $STORY_ID"

if [[ "$SNAPSHOT_COUNT" -eq 0 ]]; then
  echo "Error: No DOM snapshots found. Run Explorer Agent first."
  exit 1
fi

# Create output directory
OUTPUT_DIR="$PROJECT_ROOT/tests/helpers/locators"
mkdir -p "$OUTPUT_DIR"

echo ""
echo "Running Locator Strategy Builder..."
echo "─────────────────────────────────────────────────────────────────"

# Run the locator strategy builder
cd "$PROJECT_ROOT"
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story "$STORY_ID" \
  --output-dir "tests/helpers/locators" \
  --dom-analysis "dom-analysis" \
  --format "$OUTPUT_FORMAT" \
  --min-confidence "$MIN_CONFIDENCE" \
  --max-fallbacks "$MAX_FALLBACKS" \
  --healing-strategy "$HEALING_STRATEGY"

BUILD_EXIT_CODE=$?

echo ""
echo "─────────────────────────────────────────────────────────────────"

if [[ $BUILD_EXIT_CODE -eq 0 ]]; then
  echo "✓ Locator strategy generation completed successfully"
  
  # List generated files
  echo ""
  echo "Generated files:"
  find "$OUTPUT_DIR" -name "${STORY_ID,,}*" -type f 2>/dev/null | while read -r file; do
    echo "  - $file"
  done
  
  # Validate manifest exists
  MANIFEST_FILE="$OUTPUT_DIR/${STORY_ID,,}-locator-manifest.json"
  if [[ -f "$MANIFEST_FILE" ]]; then
    echo ""
    echo "Manifest summary:"
    cat "$MANIFEST_FILE" | jq -r '.statistics | "  Pages: \(.totalPages), Elements: \(.totalElements), Avg Confidence: \(.overallAvgConfidence)"' 2>/dev/null || true
  fi
  
  echo ""
  echo "╔══════════════════════════════════════════════════════════════╗"
  echo "║              Pre-Generation Hook Complete                    ║"
  echo "╚══════════════════════════════════════════════════════════════╝"
  exit 0
else
  echo "✗ Locator strategy generation failed with exit code: $BUILD_EXIT_CODE"
  exit $BUILD_EXIT_CODE
fi
