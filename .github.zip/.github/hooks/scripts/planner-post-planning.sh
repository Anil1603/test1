#!/bin/bash

###############################################################################
# Planner Agent Post-Planning Hook
#
# This hook is triggered after the Planner Agent completes test case generation.
# It validates the generated artifacts and prepares handoff data.
#
# Trigger: after_agent_complete (Planner Agent)
# Phase: 2 (Test Planning & Scenario Design)
#
# Inputs:
#   - STORY_ID: Issue key (e.g., AP-1)
#
# Actions:
#   1. Validate all required artifacts exist
#   2. Check test case quality metrics
#   3. Verify handoff data structure
#   4. Generate summary report
#   5. Log completion metrics
#
# Exit Codes:
#   0: Success - validation passed
#   1: Error - Missing required artifacts
#   2: Error - Invalid handoff data
###############################################################################

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

HOOK_NAME="planner-agent.post-planning"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../" && pwd)"
LOG_DIR="$PROJECT_ROOT/.github/hooks/logs"
LOG_FILE="$LOG_DIR/${HOOK_NAME}-$(date +%Y%m%d-%H%M%S).log"

mkdir -p "$LOG_DIR"

log() {
    echo "[$1] $2" | tee -a "$LOG_FILE"
}

echo ""
echo "════════════════════════════════════════════════════════════════════"
echo -e "${BLUE}  🪝 Agent Hook: Planner Post-Planning Validation${NC}"
echo "════════════════════════════════════════════════════════════════════"
echo ""

# Get Story ID
STORY_ID="${1:-${COPILOT_AGENT_STORY_ID}}"

if [ -z "$STORY_ID" ]; then
    echo -e "${RED}❌ Error: STORY_ID not provided${NC}"
    exit 1
fi

log "INFO" "Validating artifacts for: $STORY_ID"

# Required artifacts
REQUIRED_ARTIFACTS=(
    "test-cases/${STORY_ID}-test-cases.md"
    "handoff-data/phase2-to-phase3-${STORY_ID}.json"
)

OPTIONAL_ARTIFACTS=(
    "test-cases/${STORY_ID}-test-steps.json"
    "test-cases/${STORY_ID}-test-data.json"
    "test-cases/${STORY_ID}-raw-output.md"
)

# Validate required artifacts
echo -e "${BLUE}📋 Checking required artifacts...${NC}"
MISSING_REQUIRED=false

for artifact in "${REQUIRED_ARTIFACTS[@]}"; do
    filepath="$PROJECT_ROOT/$artifact"
    if [ -f "$filepath" ]; then
        size=$(wc -c < "$filepath" | tr -d ' ')
        echo -e "${GREEN}✅ Found: $artifact (${size} bytes)${NC}"
        log "SUCCESS" "Required artifact found: $artifact"
        
        # Validate minimum size
        if [ "$size" -lt 100 ]; then
            echo -e "${YELLOW}⚠️  Warning: $artifact seems too small (${size} bytes)${NC}"
            log "WARNING" "Artifact too small: $artifact"
        fi
    else
        echo -e "${RED}❌ Missing: $artifact${NC}"
        log "ERROR" "Required artifact missing: $artifact"
        MISSING_REQUIRED=true
    fi
done

# Check optional artifacts
echo ""
echo -e "${BLUE}📋 Checking optional artifacts...${NC}"

for artifact in "${OPTIONAL_ARTIFACTS[@]}"; do
    filepath="$PROJECT_ROOT/$artifact"
    if [ -f "$filepath" ]; then
        size=$(wc -c < "$filepath" | tr -d ' ')
        echo -e "${GREEN}✅ Found: $artifact (${size} bytes)${NC}"
        log "INFO" "Optional artifact found: $artifact"
    else
        echo -e "${YELLOW}⚠️  Not found: $artifact (optional)${NC}"
        log "WARNING" "Optional artifact missing: $artifact"
    fi
done

# Fail if required artifacts are missing
if [ "$MISSING_REQUIRED" = true ]; then
    echo ""
    echo -e "${RED}❌ Validation failed: Missing required artifacts${NC}"
    log "ERROR" "Post-planning validation failed"
    exit 1
fi

# Validate handoff JSON structure
echo ""
echo -e "${BLUE}🔍 Validating handoff data structure...${NC}"

HANDOFF_FILE="$PROJECT_ROOT/handoff-data/phase2-to-phase3-${STORY_ID}.json"

if command -v jq &> /dev/null; then
    # Check required fields in handoff JSON
    REQUIRED_FIELDS=(
        ".handoffId"
        ".timestamp"
        ".sourcePhase"
        ".targetPhase"
        ".storyId"
        ".nextAction"
    )
    
    for field in "${REQUIRED_FIELDS[@]}"; do
        if jq -e "$field" "$HANDOFF_FILE" > /dev/null 2>&1; then
            value=$(jq -r "$field" "$HANDOFF_FILE")
            echo -e "${GREEN}✅ $field: $value${NC}"
        else
            echo -e "${RED}❌ Missing field: $field${NC}"
            log "ERROR" "Handoff missing field: $field"
            exit 2
        fi
    done
else
    echo -e "${YELLOW}⚠️  jq not installed, skipping JSON validation${NC}"
fi

# Quality metrics
echo ""
echo -e "${BLUE}📊 Test Case Quality Metrics${NC}"

TEST_CASES_FILE="$PROJECT_ROOT/test-cases/${STORY_ID}-test-cases.md"

if [ -f "$TEST_CASES_FILE" ]; then
    # Count test cases (lines starting with "#### TC-")
    TC_COUNT=$(grep -c "^#### TC-" "$TEST_CASES_FILE" || echo "0")
    
    # Count test steps (lines starting with numbered lists after "Test Steps")
    STEPS_COUNT=$(grep -A 100 "Test Steps" "$TEST_CASES_FILE" | grep -c "^[0-9]\." || echo "0")
    
    # Word count
    WORDS=$(wc -w < "$TEST_CASES_FILE" | tr -d ' ')
    
    echo "  Test Cases: $TC_COUNT"
    echo "  Test Steps: $STEPS_COUNT"
    echo "  Documentation: $WORDS words"
    
    log "METRICS" "Test cases: $TC_COUNT, Steps: $STEPS_COUNT, Words: $WORDS"
    
    if [ "$TC_COUNT" -lt 3 ]; then
        echo -e "${YELLOW}⚠️  Warning: Less than 3 test cases generated${NC}"
        log "WARNING" "Low test case count: $TC_COUNT"
    fi
else
    echo -e "${YELLOW}⚠️  Cannot calculate metrics: test cases file not found${NC}"
fi

# Summary
echo ""
echo "════════════════════════════════════════════════════════════════════"
echo -e "${GREEN}✅ Post-Planning Validation Complete${NC}"
echo "════════════════════════════════════════════════════════════════════"
echo ""
echo "Story: $STORY_ID"
echo "Status: Ready for Phase 3 (DOM Analysis)"
echo "Next Agent: Explorer Agent"
echo ""
echo "Log file: $LOG_FILE"
echo ""

log "SUCCESS" "Post-planning validation completed for $STORY_ID"
exit 0
