#!/bin/bash

###############################################################################
# Planner Agent Pre-Planning Hook
#
# This hook is triggered before the Planner Agent starts test case generation.
# It integrates with RAG (ChromaDB) + GitHub Copilot SDK to generate
# comprehensive test plans based on user stories and technical documentation.
#
# Integration Flow:
#   User Story → RAG Query → Copilot SDK → Test Cases/Steps/Data
#
# Trigger: on_agent_invoke (Planner Agent)
# Phase: 2 (Test Planning & Scenario Design)
#
# Inputs (from agent context):
#   - STORY_ID: Issue key (e.g., AP-1)
#   - STORY_TITLE: Story title (e.g., "Order Flow")
#   - BASE_URL: Application URL (e.g., https://ecommerce-us-ppr.se.com)
#
# Outputs:
#   - test-cases/{STORY_ID}-test-cases.md
#   - test-cases/{STORY_ID}-test-steps.json
#   - test-cases/{STORY_ID}-test-data.json
#   - test-cases/{STORY_ID}-raw-output.md
#   - handoff-data/phase2-to-phase3-{STORY_ID}.json
#
# Environment Variables:
#   - RAG_API_URL: RAG server endpoint (default: http://localhost:8000)
#   - RAG_COLLECTION: Collection name (optional)
#
# Exit Codes:
#   0: Success - test plan generated
#   1: Error - RAG server not available
#   2: Error - User story not found
#   3: Error - Test plan generation failed
#   4: Error - Missing required parameters
###############################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
HOOK_NAME="planner-agent.pre-planning"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../" && pwd)"
RAG_DIR="$PROJECT_ROOT/rag"
LOG_DIR="$PROJECT_ROOT/.github/hooks/logs"
LOG_FILE="$LOG_DIR/${HOOK_NAME}-$(date +%Y%m%d-%H%M%S).log"

# Ensure log directory exists
mkdir -p "$LOG_DIR"

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE"
}

log_info() {
    log "INFO" "$@"
    echo -e "${BLUE}ℹ  $@${NC}"
}

log_success() {
    log "SUCCESS" "$@"
    echo -e "${GREEN}✅ $@${NC}"
}

log_warning() {
    log "WARNING" "$@"
    echo -e "${YELLOW}⚠️  $@${NC}"
}

log_error() {
    log "ERROR" "$@"
    echo -e "${RED}❌ $@${NC}"
}

# Header
echo ""
echo "════════════════════════════════════════════════════════════════════"
echo -e "${CYAN}  🪝 Agent Hook: Planner Pre-Planning${NC}"
echo -e "${CYAN}  Phase 2: Test Planning with RAG + GitHub Copilot SDK${NC}"
echo "════════════════════════════════════════════════════════════════════"
echo ""

log_info "Hook started: $HOOK_NAME"
log_info "Project root: $PROJECT_ROOT"

# Parse inputs from environment or arguments
STORY_ID="${1:-${COPILOT_AGENT_STORY_ID}}"
STORY_TITLE="${2:-${COPILOT_AGENT_STORY_TITLE}}"
BASE_URL="${3:-${COPILOT_AGENT_BASE_URL}}"
COLLECTION="${4:-${COPILOT_AGENT_COLLECTION:-ecomm}}"  # Default to 'ecomm'

# Validate required parameters
if [ -z "$STORY_ID" ] || [ -z "$STORY_TITLE" ] || [ -z "$BASE_URL" ]; then
    log_error "Missing required parameters"
    echo ""
    echo "Usage: $0 <STORY_ID> \"<STORY_TITLE>\" <BASE_URL> [COLLECTION]"
    echo ""
    echo "Examples:"
    echo "  $0 AP-1 \"Order Flow\" https://ecommerce-us-ppr.se.com ecomm"
    echo "  $0 AP-1 \"Order Flow\" https://ecommerce-us-ppr.se.com"
    echo ""
    echo "Or set environment variables:"
    echo "  export COPILOT_AGENT_STORY_ID=AP-1"
    echo "  export COPILOT_AGENT_STORY_TITLE=\"Order Flow\""
    echo "  export COPILOT_AGENT_BASE_URL=https://ecommerce-us-ppr.se.com"
    echo "  export COPILOT_AGENT_COLLECTION=ecomm"
    echo ""
    exit 4
fi

log_info "Story ID: $STORY_ID"
log_info "Story Title: $STORY_TITLE"
log_info "Base URL: $BASE_URL"
log_info "Collection: $COLLECTION"

# Environment configuration
RAG_API_URL="${RAG_API_URL:-http://localhost:8000}"
log_info "RAG API URL: $RAG_API_URL"

# Step 1: Health check - RAG server
echo ""
log_info "Checking RAG server health..."
if ! curl -s -f "${RAG_API_URL}/health" > /dev/null 2>&1; then
    log_error "RAG server is not running at ${RAG_API_URL}"
    echo ""
    echo "Please start the RAG server first:"
    echo "  cd rag && ./scripts/run-server.sh"
    echo ""
    log_info "Hook failed with exit code 1"
    exit 1
fi
log_success "RAG server is healthy"

# Step 2: Verify user story file exists
STORY_FILENAME="${STORY_ID}_${STORY_TITLE// /_}.md"
STORY_PATH="$PROJECT_ROOT/user-stories/$STORY_FILENAME"

log_info "Checking user story file: $STORY_FILENAME"
if [ ! -f "$STORY_PATH" ]; then
    log_error "User story file not found: $STORY_PATH"
    echo ""
    echo "Available user stories:"
    ls -1 "$PROJECT_ROOT/user-stories/" 2>/dev/null || echo "  (none)"
    echo ""
    log_info "Hook failed with exit code 2"
    exit 2
fi
log_success "User story file found"

# Step 3: Check if test cases already exist (duplication check)
TEST_CASES_FILE="$PROJECT_ROOT/test-cases/${STORY_ID}-test-cases.md"
if [ -f "$TEST_CASES_FILE" ]; then
    log_warning "Test cases already exist for $STORY_ID"
    log_info "Skipping generation to avoid duplication"
    echo ""
    echo "Existing files:"
    ls -1 "$PROJECT_ROOT/test-cases/${STORY_ID}"* 2>/dev/null || true
    echo ""
    log_info "Hook completed with exit code 0 (no action needed)"
    exit 0
fi

# Step 4: Create output directories
mkdir -p "$PROJECT_ROOT/test-cases"
mkdir -p "$PROJECT_ROOT/handoff-data"
log_success "Output directories ready"

# Step 5: Navigate to RAG directory
cd "$RAG_DIR"

# Step 6: Install dependencies if needed
if [ ! -d "node_modules" ]; then
    log_info "Installing dependencies..."
    npm install --silent > /dev/null 2>&1
    log_success "Dependencies installed"
fi

# Step 7: Run RAG + Copilot SDK test plan generation
echo ""
echo "────────────────────────────────────────────────────────────────────"
log_info "Starting RAG + Copilot SDK test plan generation..."
log_info "Using: scripts/generate-test-plan-rag.sh"
log_info "This may take 1-3 minutes for complex stories..."
echo ""

START_TIME=$(date +%s)

# Execute the test plan generator shell script
if "$PROJECT_ROOT/scripts/generate-test-plan-rag.sh" "$STORY_ID" "$STORY_TITLE" "$BASE_URL" "$COLLECTION" 2>&1 | tee -a "$LOG_FILE"; then
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    
    log_success "Test plan generation completed in ${DURATION}s"
    
    # Step 8: Verify outputs
    cd "$PROJECT_ROOT"
    
    echo ""
    log_info "Verifying generated artifacts..."
    
    ARTIFACTS=(
        "test-cases/${STORY_ID}-test-cases.md"
        "test-cases/${STORY_ID}-test-steps.json"
        "test-cases/${STORY_ID}-test-data.json"
        "test-cases/${STORY_ID}-raw-output.md"
        "handoff-data/phase2-to-phase3-${STORY_ID}.json"
    )
    
    ALL_FOUND=true
    for artifact in "${ARTIFACTS[@]}"; do
        if [ -f "$artifact" ]; then
            SIZE=$(wc -c < "$artifact" | tr -d ' ')
            log_success "Found: $artifact ($SIZE bytes)"
        else
            log_warning "Missing: $artifact"
            ALL_FOUND=false
        fi
    done
    
    if [ "$ALL_FOUND" = true ]; then
        echo ""
        echo "════════════════════════════════════════════════════════════════════"
        log_success "Hook completed successfully!"
        echo "════════════════════════════════════════════════════════════════════"
        echo ""
        echo "Generated artifacts:"
        for artifact in "${ARTIFACTS[@]}"; do
            echo "  📄 $artifact"
        done
        echo ""
        echo "Next steps:"
        echo "  1. Review the generated test cases"
        echo "  2. Planner Agent will automatically proceed to Explorer Agent"
        echo "  3. Handoff data ready for Phase 3 (DOM Analysis)"
        echo ""
        log_info "Hook completed with exit code 0"
        exit 0
    else
        log_warning "Some artifacts are missing, but generation completed"
        log_info "Hook completed with exit code 0 (partial success)"
        exit 0
    fi
else
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    
    log_error "Test plan generation failed after ${DURATION}s"
    log_error "Check the log file for details: $LOG_FILE"
    echo ""
    echo "Troubleshooting:"
    echo "  1. Verify RAG server is running with documents indexed"
    echo "  2. Check GitHub Copilot SDK authentication"
    echo "  3. Review user story format and content"
    echo "  4. Check log file: $LOG_FILE"
    echo ""
    log_info "Hook failed with exit code 3"
    exit 3
fi
