#!/bin/bash
###############################################################################
# Explorer Agent Pre-Exploration Hook
# 
# This script is invoked before Explorer Agent starts DOM analysis.
# It captures DOM snapshots from the Playwright MCP browser and generates
# locator strategies for test automation.
#
# Usage:
#   ./explorer-pre-exploration.sh \
#     --story-id AP-1 \
#     --url https://example.com/page \
#     --step-number 5 \
#     --step-action "Click add to cart button"
#
# Environment Variables:
#   PLAYWRIGHT_BROWSER - Browser to use (default: chromium)
#   HEADLESS - Run browser in headless mode (default: true)
###############################################################################

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Default values
STORY_ID=""
CURRENT_URL=""
STEP_NUMBER=1
STEP_ACTION="Interaction captured"
OUTPUT_DIR="dom-analysis"
HEADLESS="${HEADLESS:-true}"
TIMEOUT="${TIMEOUT:-30000}"

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ ${NC}$1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Explorer Agent Pre-Exploration Hook${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}\n"
}

# Function to show usage
usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Required Options:
  --story-id <ID>          Story/Issue ID (e.g., AP-1)
  --url <URL>              Current page URL from MCP browser

Optional Options:
  --step-number <N>        Step number (default: 1)
  --step-action <text>     Step action description
  --output-dir <dir>       Output directory (default: dom-analysis)
  --help                   Show this help message

Environment Variables:
  PLAYWRIGHT_BROWSER       Browser to use (default: chromium)
  HEADLESS                 Run browser in headless mode (default: true)

Example:
  $0 \\
    --story-id AP-1 \\
    --url https://ecommerce-us-ppr.se.com/pro/us/en/cart \\
    --step-number 5 \\
    --step-action "Add product to cart"

EOF
    exit 1
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --story-id)
            STORY_ID="$2"
            shift 2
            ;;
        --url)
            CURRENT_URL="$2"
            shift 2
            ;;
        --step-number)
            STEP_NUMBER="$2"
            shift 2
            ;;
        --step-action)
            STEP_ACTION="$2"
            shift 2
            ;;
        --output-dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --help)
            usage
            ;;
        *)
            print_error "Unknown option: $1"
            usage
            ;;
    esac
done

# Validate required arguments
if [[ -z "$STORY_ID" ]]; then
    print_error "Missing required argument: --story-id"
    usage
fi

if [[ -z "$CURRENT_URL" ]]; then
    print_error "Missing required argument: --url"
    usage
fi

# Print header
print_header

# Print configuration
print_info "Configuration:"
echo "  Story ID: $STORY_ID"
echo "  Current URL: $CURRENT_URL"
echo "  Step Number: $STEP_NUMBER"
echo "  Step Action: $STEP_ACTION"
echo "  Output Directory: $OUTPUT_DIR"
echo "  Headless: $HEADLESS"
echo ""

# Change to project root
cd "$PROJECT_ROOT"

# Choose TypeScript script. Prefer Salesforce-specific extractor for Salesforce URLs
if echo "$CURRENT_URL" | grep -Ei "salesforce\.com|force\.com|my\.salesforce" &> /dev/null; then
    TS_SCRIPT="scripts/agents/explorer/salesforce-explorer-dom-extractor.ts"
else
    TS_SCRIPT="scripts/explorer-dom-extractor-mcp.ts"
fi

if [[ ! -f "$TS_SCRIPT" ]]; then
    print_error "TypeScript script not found: $TS_SCRIPT"
    exit 1
fi

print_info "Using explorer script: $TS_SCRIPT"

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    print_error "Node.js is not installed or not in PATH"
    exit 1
fi

print_success "Node.js is available: $(node --version)"

# Check if npx is available
if ! command -v npx &> /dev/null; then
    print_error "npx is not installed or not in PATH"
    exit 1
fi

print_success "npx is available"

# Check if tsx is available in node_modules
if [[ ! -d "node_modules/tsx" ]]; then
    print_warning "tsx is not installed. Installing..."
    npm install --no-save tsx
fi

print_success "tsx is available"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"
print_success "Output directory ready: $OUTPUT_DIR"

# Execute the TypeScript script
print_info "Executing DOM extraction..."
echo ""

set +e  # Don't exit on error, capture it instead

npx tsx "$TS_SCRIPT" \
    --story "$STORY_ID" \
    --url "$CURRENT_URL" \
    --step-number "$STEP_NUMBER" \
    --step-action "$STEP_ACTION" \
    --output "$OUTPUT_DIR"

EXIT_CODE=$?

set -e  # Re-enable exit on error

echo ""

# Check exit code
if [[ $EXIT_CODE -eq 0 ]]; then
    print_success "DOM extraction completed successfully!"
    
    # Check if output files were created
    LOCATOR_MANIFEST="${OUTPUT_DIR}/locators/${STORY_ID}_locators.json"
    if [[ -f "$LOCATOR_MANIFEST" ]]; then
        print_success "Locator manifest created: $LOCATOR_MANIFEST"
        
        # Show summary
        if command -v jq &> /dev/null; then
            print_info "Summary:"
            TOTAL_PAGES=$(jq -r '.summary.totalPages' "$LOCATOR_MANIFEST" 2>/dev/null || echo "N/A")
            TOTAL_INTERACTIONS=$(jq -r '.summary.totalInteractions' "$LOCATOR_MANIFEST" 2>/dev/null || echo "N/A")
            echo "  Total Pages: $TOTAL_PAGES"
            echo "  Total Interactions: $TOTAL_INTERACTIONS"
        fi
    else
        print_warning "Locator manifest not found at expected location"
    fi
    
    # Check if handoff file was created
    HANDOFF_FILE="handoff-data/phase3-to-phase4-${STORY_ID}.json"
    if [[ -f "$HANDOFF_FILE" ]]; then
        print_success "Handoff data created: $HANDOFF_FILE"
    fi
    
    echo ""
    print_success "Explorer Agent pre-exploration hook completed successfully!"
    exit 0
else
    print_error "DOM extraction failed with exit code: $EXIT_CODE"
    echo ""
    print_error "Explorer Agent pre-exploration hook failed!"
    exit $EXIT_CODE
fi
