---
name: Locators healing (shared guidance)
description: Strategies and practices for making tests resilient to UI changes and for automating locator repairs.
applyTo:  **/*

---

# Locators healing (shared guidance)

Purpose: Strategies and practices for making tests resilient to UI changes and for automating locator repairs.

Philosophy
- Design locators to fail loudly and be easy to fix.
- Use layered locators so a small change degrades gracefully.

Layered locator strategy
1. Primary: `data-*` stable test attribute.
2. Secondary: role/aria or unique visible label.
3. Tertiary: semantic path (container + data-key) with minimal reliance on classes/IDs.
4. Fallback: XPath or text-based match with conservative scope.

Self-healing practices
- Store canonical locator metadata (name, selector, rationale, last-updated) in a locators manifest.
- Implement a small heuristic repair helper used in CI post-failure that:
  - Searches for nearby nodes with similar text/structure, and suggests replacement selectors.
  - Logs candidate replacements for manual review rather than auto-committing changes.

Automated suggestions (CI step)
- On failed tests, run a locator-diagnostic script that:
  - Captures page DOM and candidate attributes.
  - Attempts to identify the closest matching element by text similarity and attribute overlap.
  - Produces a report with ranked suggestions and confidence scores.

Human-in-the-loop
- Always review automated suggestions; do not auto-apply without a PR.
- Require a short test demonstrating the new selector works on the failing scenario.

Operational rules
- Add reason and ticket link when changing a locator in the manifest.
- When removing or renaming `data-*` attributes, coordinate test update in the same change window to avoid wide breakage.

Implementation tips
- Keep locator utilities small and centralized (e.g., `utils/locators.ts`).
- Use descriptive names like `leadPage.saveButton` rather than inlining selectors everywhere.

Metrics
- Track locator-related failures and measure mean-time-to-fix (MTTF). Use the data to prioritize adding more stable attributes in the app.

Summary
- Prefer explicit test attributes, keep layered fallbacks, generate diagnostic suggestions on failure, and review changes via PRs.