---
name: Shared testing instructions (Salesforce automation)
description: Project-level testing conventions for Playwright-based Salesforce automation suites.
applyTo:  **/*

---
# Shared testing instructions (Salesforce automation)

Purpose: Project-level testing conventions for Playwright-based Salesforce automation suites.

Repository layout & naming
- Keep page objects in `pages/`, tests in `tests/`, and locator manifests in `locators/` or `pages/` files.
- Test files: `tests/<area>/<feature>.spec.ts` or `.spec.ts` with clear names. Use `describe` blocks to group behaviors.

Test design
- Each test should be independent and idempotent.
- Use fixtures for setup/teardown and test data isolation. Reset state via APIs where possible.
- Prefer small, focused tests over long end-to-end flows. Reserve a few smoke E2E flows for high-level validation.

Test data
- Manage test data via APIs (recommended) or dedicated test records with clear tagging (e.g., `data-testid-owner=test-automation`).
- Clean up created records after tests or use ephemeral sandboxes.

Environment & secrets
- Use `.env` or CI secret storage for credentials and base URLs. If `.env` does not exist, create `.env.example` with placeholders.
- Never commit real credentials. Add `.env` to `.gitignore`.

Retries & flakiness
- Configure minimal retries in CI (e.g., 1 retry) and focus on fixing root causes rather than masking flakiness.
- Use Playwright tracing, screenshots, and video on CI failure for diagnostics.

CI practices
- Run fast unit/contract tests on pull requests; run full E2E suites on scheduled or gated pipelines.
- Preserve artifacts (screenshots, traces, DOM snapshots) on failures and surface them in PRs.

Local dev experience
- Provide a small `README.md` section and npm scripts to run a subset of tests quickly (e.g., `npm run test:lead`).
- Mock external integrations where possible to keep local runs fast and deterministic.

Code quality
- Centralize waits, locators, and helpers to reduce duplication.
- Keep tests readable and avoid complex logic inside tests — push helpers into `utils/` or page objects.

Documentation
- Document all `data-*` attributes and testing hooks in a central doc (`confluence-pages/` or `.github/instructions`).
- When adding a new test hook, include a brief note in the component PR describing the test usage.

Onboarding checklist (for a new contributor)
1. Install dependencies: `npm install` and follow `confluence-pages/277744806_IDE_Setup.md`.
2. Create `.env` from `.env.example` and configure `BASE_URL` and credentials.
3. Run a focused test: `npx playwright test tests/area/example.spec.ts`.

Summary
- Keep tests small, use stable test hooks, centralize selectors and waits, and make CI produce actionable artifacts for failures.