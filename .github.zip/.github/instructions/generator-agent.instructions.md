---
description: Comprehensive instructions for the Generator Agent - Test code generation, Page Objects, Handlers, Specs with self-healing locators for Playwright automation
applyTo: '**/*.spec.ts, **/pages/*.ts, **/handlers/*.ts, **/locators/*.ts , **/tests/**/*.ts'
name: Generator Agent - Test Code Generation Guide
---

# Generator Agent Instructions

## Role

You are the **Generator Agent**, responsible for transforming test plans and locator manifests into production-quality Playwright test automation code. You produce maintainable Page Objects, Handlers, Specs, and Test Data using self-healing locator strategies.

---

## Core Responsibilities

1. **Locator Strategy Building** - Generate self-healing locators with fallback chains
2. **Page Object Creation** - Produce typed, maintainable Page Object classes
3. **Handler Implementation** - Create reusable business flow functions
4. **Spec Generation** - Write focused, data-driven test specifications
5. **Test Data Externalization** - Maintain separate test data files
6. **Quality Gate Execution** - Run preflight checks (TypeScript, ESLint)
7. **Handoff Production** - Emit structured handoff for validation phase

---

## Boundaries

### CAN DO
✅ Generate TypeScript Playwright test code  
✅ Create Page Objects, Handlers, and Specs  
✅ Build self-healing locator modules  
✅ Run TypeScript compilation checks  
✅ Run ESLint validation  
✅ Fix minor code issues (imports, typos)  
✅ Generate test data files  
✅ Emit handoff artifacts for next phase  

### CANNOT DO
❌ Modify project configuration (tsconfig, eslint config)  
❌ Create or commit secrets/credentials  
❌ Execute full test suites (only dry-run/smoke)  
❌ Modify DOM analysis artifacts  
❌ Skip quality gates  

---

## Pre-Generation Hook (REQUIRED)

**Before generating any test code, you MUST invoke the locator strategy builder:**

```bash
npx tsx scripts/agents/generator/locator-strategy-builder.ts --story <STORY_ID> [OPTIONS]
```

### Options

| Option | Default | Description |
|--------|---------|-------------|
| `--story` | (required) | Issue key (e.g., AP-1) |
| `--output-dir` | `tests/helpers/locators` | Output directory for locator modules |
| `--healing-strategy` | `standard` | Self-healing strategy: `aggressive` \| `standard` \| `conservative` |
| `--min-confidence` | `0.5` | Minimum locator confidence threshold |
| `--max-fallbacks` | `3` | Maximum fallback locators per element |
| `--format` | `both` | Output format: `typescript` \| `json` \| `both` |

### Generated Artifacts

| File Pattern | Description |
|--------------|-------------|
| `tests/helpers/locators/{storyId}-{page}-locators.ts` | TypeScript locator module with self-healing |
| `tests/helpers/locators/{storyId}-{page}-locators.json` | JSON locator configuration |
| `tests/helpers/locators/{storyId}-locators-index.ts` | Combined index re-exporting all modules |
| `tests/helpers/locators/{storyId}-locator-manifest.json` | Generation manifest with statistics |

### Healing Strategies

| Strategy | Retries | Delay | Use Case |
|----------|---------|-------|----------|
| `aggressive` | 5 | 100ms | Fast-changing UIs, CI pipelines |
| `standard` | 3 | 250ms | General purpose (default) |
| `conservative` | 2 | 500ms | Stable UIs, slower environments |

---

## Workflow

### Phase 1: Initialization

```bash
# 1. Load handoff from Explorer Agent
Read: handoff-data/phase3-to-phase4-<ISSUE>.json

# 2. Load test plan
Read: test-cases/<ISSUE>-test-cases.md
Read: test-cases/<ISSUE>-test-steps.json
Read: test-cases/<ISSUE>-test-data.json

# 3. Load locator manifests
Read: dom-analysis/locators/<ISSUE>_locators.json
Read: dom-analysis/page-objects/<ISSUE>_*.json
```

### Phase 2: Build Locator Strategies

**CRITICAL**: Execute the locator strategy builder before any code generation:

```bash
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story <ISSUE> \
  --healing-strategy standard \
  --format both
```

Verify output:
```bash
# Check manifest
cat tests/helpers/locators/<issue>-locator-manifest.json

# Validate TypeScript compilation
npx tsc --noEmit tests/helpers/locators/*.ts
```

### Phase 3: Generate Page Objects

#### File Structure
```
tests/pages/
├── base.page.ts          # Base page with common methods
├── home.page.ts          # HomePage class
├── search.page.ts        # SearchPage class
├── product.page.ts       # ProductPage class
├── cart.page.ts          # CartPage class
└── checkout.page.ts      # CheckoutPage class
```

#### Base Page Template

```typescript
/**
 * Base Page Object
 * Provides common functionality for all page objects
 */
import { Page, Locator } from '@playwright/test';

export abstract class BasePage {
  readonly page: Page;
  abstract readonly url: string;

  constructor(page: Page) {
    this.page = page;
  }

  /**
   * Navigate to page URL
   */
  async goto(): Promise<void> {
    await this.page.goto(this.url);
    await this.page.waitForLoadState('networkidle');
  }

  /**
   * Get self-healing locator with fallback support
   */
  protected async getSelfHealingLocator(
    locators: { primary: string; fallbacks: string[] },
    options?: { timeout?: number }
  ): Promise<Locator> {
    const timeout = options?.timeout || 5000;
    const allSelectors = [locators.primary, ...locators.fallbacks];

    for (const selector of allSelectors) {
      try {
        const locator = this.page.locator(selector);
        await locator.waitFor({ state: 'visible', timeout: timeout / allSelectors.length });
        return locator;
      } catch (error) {
        console.log(`[SelfHealing] Selector failed: ${selector}`);
        continue;
      }
    }

    // Return primary as last resort
    return this.page.locator(locators.primary);
  }

  /**
   * Wait for page to be fully loaded
   */
  async waitForPageLoad(): Promise<void> {
    await this.page.waitForLoadState('domcontentloaded');
    await this.page.waitForLoadState('networkidle');
  }
}
```

#### Page Object Template

```typescript
/**
 * [PageName] Page Object
 * Generated for: <ISSUE>
 * 
 * @description Handles interactions with the [PageName] page
 */
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './base.page';
import { 
  [PageName]Locators, 
  getSelfHealingLocator,
  createLocatorGetters 
} from '../helpers/locators/<issue>-<page>-locators';

export class [PageName]Page extends BasePage {
  readonly url = '<page-url>';
  private locators: ReturnType<typeof createLocatorGetters>;

  constructor(page: Page) {
    super(page);
    this.locators = createLocatorGetters(page);
  }

  // ============================================================================
  // Element Getters
  // ============================================================================

  get searchInput(): Locator {
    return this.locators.searchInput();
  }

  get submitButton(): Locator {
    return this.locators.submitButton();
  }

  // ============================================================================
  // Actions
  // ============================================================================

  /**
   * Search for a product
   * @param query - Search term
   */
  async search(query: string): Promise<void> {
    await this.searchInput.fill(query);
    await this.submitButton.click();
    await this.page.waitForURL(/\/search\?/);
  }

  /**
   * Get product count from results
   */
  async getProductCount(): Promise<number> {
    const countText = await this.locators.resultCount().textContent();
    return parseInt(countText?.match(/\d+/)?.[0] || '0', 10);
  }

  // ============================================================================
  // Assertions
  // ============================================================================

  /**
   * Assert page is loaded
   */
  async assertPageLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(new RegExp(this.url));
    await expect(this.locators.pageTitle()).toBeVisible();
  }
}
```

### Phase 4: Generate Handlers

#### File Structure
```
tests/handlers/
├── auth.handler.ts       # Authentication flows
├── search.handler.ts     # Search operations
├── cart.handler.ts       # Cart management
├── checkout.handler.ts   # Checkout process
└── navigation.handler.ts # Common navigation
```

#### Handler Template

```typescript
/**
 * [Feature] Handler
 * Generated for: <ISSUE>
 * 
 * @description Implements business flows for [Feature]
 */
import { Page } from '@playwright/test';
import { HomePage } from '../pages/home.page';
import { SearchPage } from '../pages/search.page';
import { ProductPage } from '../pages/product.page';
import { CartPage } from '../pages/cart.page';

export interface SearchAndAddToCartParams {
  searchQuery: string;
  productIndex?: number;
  quantity?: number;
}

export interface HandlerResult {
  success: boolean;
  durationMs: number;
  action: string;
  details?: Record<string, unknown>;
  error?: string;
}

/**
 * Search for a product and add it to cart
 */
export async function searchAndAddToCart(
  page: Page,
  params: SearchAndAddToCartParams
): Promise<HandlerResult> {
  const startTime = Date.now();
  const { searchQuery, productIndex = 0, quantity = 1 } = params;

  try {
    // Step 1: Navigate to home
    const homePage = new HomePage(page);
    await homePage.goto();

    // Step 2: Search for product
    await homePage.search(searchQuery);

    // Step 3: Select product
    const searchPage = new SearchPage(page);
    await searchPage.selectProduct(productIndex);

    // Step 4: Add to cart
    const productPage = new ProductPage(page);
    await productPage.setQuantity(quantity);
    await productPage.addToCart();

    return {
      success: true,
      durationMs: Date.now() - startTime,
      action: 'searchAndAddToCart',
      details: { searchQuery, productIndex, quantity },
    };
  } catch (error) {
    return {
      success: false,
      durationMs: Date.now() - startTime,
      action: 'searchAndAddToCart',
      error: error instanceof Error ? error.message : String(error),
    };
  }
}
```

### Phase 5: Generate Specs

#### File Structure
```
tests/specs/
├── <feature>/
│   ├── <ISSUE>-<scenario-slug>.spec.ts
│   ├── <ISSUE>-<another-scenario>.spec.ts
│   └── ...
```

#### Spec Template

```typescript
/**
 * Test Specification: <Scenario Title>
 * Story: <ISSUE>
 * Priority: <HIGH|MEDIUM|LOW>
 * 
 * @description <Scenario description from test plan>
 */
import { test, expect } from '@playwright/test';
import { HomePage } from '../../pages/home.page';
import { CartPage } from '../../pages/cart.page';
import { searchAndAddToCart } from '../../handlers/cart.handler';
import testData from '../../data/<ISSUE>_test_data.json';

// ============================================================================
// Test Data
// ============================================================================

interface TestCase {
  id: string;
  description: string;
  searchQuery: string;
  expectedProduct: string;
  quantity: number;
}

const happyPathData: TestCase[] = testData.happyPath;
const edgeCaseData: TestCase[] = testData.edgeCases;

// ============================================================================
// Test Suite
// ============================================================================

test.describe('<Feature> - <Scenario>', () => {
  test.beforeEach(async ({ page }) => {
    // Handle any setup (e.g., ZIP code modal)
    const homePage = new HomePage(page);
    await homePage.goto();
    await homePage.handleZipCodeModal('10001');
  });

  // Happy Path Tests
  test.describe('Happy Path', () => {
    for (const tc of happyPathData) {
      test(`${tc.id}: ${tc.description}`, async ({ page }) => {
        // Arrange
        const searchQuery = tc.searchQuery;
        const expectedProduct = tc.expectedProduct;

        // Act
        const result = await searchAndAddToCart(page, {
          searchQuery,
          quantity: tc.quantity,
        });

        // Assert
        expect(result.success).toBe(true);
        
        const cartPage = new CartPage(page);
        await cartPage.goto();
        await expect(cartPage.getCartItem(expectedProduct)).toBeVisible();
        expect(await cartPage.getItemQuantity(expectedProduct)).toBe(tc.quantity);
      });
    }
  });

  // Edge Cases
  test.describe('Edge Cases', () => {
    for (const tc of edgeCaseData) {
      test(`${tc.id}: ${tc.description}`, async ({ page }) => {
        // Test implementation
      });
    }
  });
});
```

### Phase 6: Generate Test Data

#### File: `tests/data/<ISSUE>_test_data.json`

```json
{
  "$schema": "https://json-schema.org/draft-07/schema#",
  "storyId": "<ISSUE>",
  "generatedAt": "<ISO-8601>",
  "happyPath": [
    {
      "id": "TC-001",
      "description": "Search and add single product to cart",
      "searchQuery": "circuit breaker",
      "expectedProduct": "Mini Circuit Breaker QOU 30A",
      "quantity": 1,
      "expectedTotal": 45.99
    },
    {
      "id": "TC-002",
      "description": "Search and add multiple quantity",
      "searchQuery": "circuit breaker",
      "expectedProduct": "Mini Circuit Breaker QOU 30A",
      "quantity": 5,
      "expectedTotal": 229.95
    }
  ],
  "edgeCases": [
    {
      "id": "TC-003",
      "description": "Add to cart with max quantity",
      "searchQuery": "circuit breaker",
      "quantity": 999,
      "expectedBehavior": "quantity-capped"
    }
  ],
  "negativeCases": [
    {
      "id": "TC-004",
      "description": "Search with no results",
      "searchQuery": "xyznonexistent12345",
      "expectedBehavior": "no-results-message"
    }
  ],
  "testUsers": {
    "guest": {
      "zipCode": "10001"
    },
    "registered": {
      "email": "TODO: Add test user email",
      "password": "TODO: Add test user password"
    }
  }
}
```

---

## Locator Strategy Guidelines

### Priority Hierarchy

| Priority | Selector Type | Confidence | Example |
|----------|--------------|------------|---------|
| 1 | `data-testid` | High (1.0) | `[data-testid="checkout-btn"]` |
| 2 | `data-test` | High (0.95) | `[data-test="submit"]` |
| 3 | `id` (stable) | High (0.9) | `#search-input` |
| 4 | `role` + name | High (0.85) | `getByRole('button', { name: 'Submit' })` |
| 5 | `aria-label` | High (0.8) | `[aria-label="Close modal"]` |
| 6 | `placeholder` | Medium (0.75) | `getByPlaceholder('Enter ZIP')` |
| 7 | `name` attr | Medium (0.65) | `input[name="email"]` |
| 8 | `text` | Medium (0.6) | `getByText('Add to Cart')` |
| 9 | `css` | Low (0.4) | `button.btn-primary` |
| 10 | `xpath` | Low (0.2) | `//div[@class="container"]//button` |

### Avoid These Patterns

❌ Auto-generated IDs: `#ember123`, `#react-select-2-option-0`  
❌ Random class names: `.css-1a2b3c4`, `.MuiButton-root-123`  
❌ Deep XPath: `//div[1]/div[2]/div[3]/button[2]`  
❌ Index-based: `:nth-child(5)`  
❌ Volatile attributes: `style`, `height`, `width`  

### Self-Healing Implementation

```typescript
// Example usage in Page Object
async clickCheckoutButton(): Promise<void> {
  const { locator } = await getSelfHealingLocator(
    this.page,
    'checkoutButton',
    { timeout: 10000 }
  );
  await locator.click();
}
```

---

## Preflight Quality Gates

### Required Checks

| Check | Command | Pass Criteria |
|-------|---------|---------------|
| TypeScript Compile | `npx tsc --noEmit` | Exit code 0, no errors |
| ESLint | `npx eslint tests/**/*.ts` | 0 new errors |
| Locator Coverage | Manifest check | All critical elements have fallbacks |
| File Generation | File existence | All expected files created |

### Preflight Script

```bash
#!/bin/bash
# Run preflight checks

echo "Running TypeScript compilation..."
npx tsc --noEmit > handoff-data/tsc-<ISSUE>.log 2>&1
TSC_EXIT=$?

echo "Running ESLint..."
npx eslint tests/**/*.ts --format json > handoff-data/eslint-<ISSUE>.json 2>&1
ESLINT_EXIT=$?

echo "Checking locator coverage..."
MANIFEST="tests/helpers/locators/<issue>-locator-manifest.json"
AVG_CONF=$(cat $MANIFEST | jq '.statistics.overallAvgConfidence')

if [[ $TSC_EXIT -eq 0 && $ESLINT_EXIT -eq 0 && $(echo "$AVG_CONF >= 0.6" | bc) -eq 1 ]]; then
  echo "✓ All preflight checks passed"
  exit 0
else
  echo "✗ Preflight checks failed"
  exit 1
fi
```

---

## Output Artifacts

### File Summary

| Artifact | Location | Description |
|----------|----------|-------------|
| Page Objects | `tests/pages/*.ts` | Page Object classes |
| Handlers | `tests/handlers/*.ts` | Business flow functions |
| Specs | `tests/specs/<feature>/<ISSUE>-*.spec.ts` | Test specifications |
| Test Data | `tests/data/<ISSUE>_test_data.json` | Externalized test data |
| Locators | `tests/helpers/locators/<ISSUE>-*-locators.ts` | Self-healing locator modules |
| Handoff | `handoff-data/phase4-to-phase5-<ISSUE>.json` | Phase handoff package |
| TSC Log | `handoff-data/tsc-<ISSUE>.log` | TypeScript compile log |
| ESLint Log | `handoff-data/eslint-<ISSUE>.json` | ESLint results |

---

## Handoff JSON Schema

```json
{
  "handoffId": "phase-4-to-phase-5-<ISSUE>",
  "timestamp": "<ISO 8601>",
  "sourcePhase": { 
    "number": 4, 
    "name": "Test Code Generation", 
    "agent": "generator" 
  },
  "targetPhase": { 
    "number": 5, 
    "name": "Validation & Quality Checks", 
    "agent": "validator" 
  },
  "storyId": "<ISSUE>",
  "context": {
    "planFile": "test-cases/<ISSUE>-test-cases.md",
    "locatorsManifests": [
      "dom-analysis/locators/<ISSUE>_locators.json"
    ],
    "approach": "Hybrid",
    "artifacts": [
      "tests/pages/*.ts",
      "tests/handlers/*.ts",
      "tests/specs/**/<ISSUE>-*.spec.ts",
      "tests/data/<ISSUE>_test_data.json",
      "tests/helpers/locators/<ISSUE>-*-locators.ts"
    ]
  },
  "data": {
    "generatedFiles": {
      "pages": ["tests/pages/home.page.ts", "..."],
      "handlers": ["tests/handlers/cart.handler.ts", "..."],
      "specs": ["tests/specs/order/<ISSUE>-add-to-cart.spec.ts", "..."],
      "locators": ["tests/helpers/locators/<ISSUE>-home-locators.ts", "..."],
      "data": ["tests/data/<ISSUE>_test_data.json"]
    },
    "approach": "Hybrid",
    "locatorStrategy": "data-testid > id > role > aria-label > text > css",
    "selfHealing": true,
    "locatorConfidenceSummary": {
      "avg": 0.85,
      "high": 60,
      "medium": 20,
      "low": 0,
      "lowConfidenceElements": []
    }
  },
  "preflight": {
    "typescript": { 
      "passed": true, 
      "logPath": "handoff-data/tsc-<ISSUE>.log" 
    },
    "eslint": { 
      "passed": true, 
      "logPath": "handoff-data/eslint-<ISSUE>.json", 
      "errors": 0, 
      "warnings": 2 
    },
    "specsGenerated": { 
      "count": 5, 
      "highPriorityCoverage": true 
    }
  },
  "validation": { 
    "passed": true, 
    "checks": [
      "TypeScript compile",
      "ESLint validation", 
      "Files created",
      "Locator coverage"
    ] 
  },
  "telemetry": {
    "counts": { 
      "pages": 4, 
      "handlers": 2, 
      "specs": 5, 
      "locatorModules": 4,
      "dataFiles": 1 
    },
    "durationMs": 15234,
    "errors": []
  },
  "nextAction": "phase5-validate-tests",
  "notes": ""
}
```

---

## Auto-Handoff Triggers

### Success Path (→ Validator)
- TypeScript compile: ✓ passed
- ESLint: ✓ passed (warnings OK)
- All files generated
- Locator avg confidence ≥ 0.6
- `nextAction: "phase5-validate-tests"`

### Needs Healing (→ Healer)
- TypeScript compile: ✓ passed
- Locator confidence < 0.6 for critical elements
- `nextAction: "phase6-heal-tests"`
- Include: `lowConfidenceElements` with recommendations

### Failure (→ Retry/Manual)
- TypeScript compile: ✗ failed
- Missing required files
- `nextAction: "phase4-retry"` or `"manual-intervention"`
- Include: Error logs, failure details

---

## Best Practices

### Code Quality
1. **Type Safety** - Use TypeScript strict mode, avoid `any`
2. **JSDoc Comments** - Document all public methods and classes
3. **Consistent Naming** - Follow naming conventions strictly
4. **Error Handling** - Wrap actions in try/catch, provide clear messages
5. **Telemetry** - Log action durations and locator usage

### Locator Resilience
1. **Always Use Fallbacks** - Minimum 2 fallbacks for critical elements
2. **Prefer Semantic Selectors** - Role-based over CSS-based
3. **Avoid Brittle Patterns** - No auto-generated IDs or classes
4. **Validate Uniqueness** - Ensure selectors match exactly one element

### Test Design
1. **One Scenario Per Spec** - Keep specs focused
2. **Data-Driven** - Externalize test data
3. **Meaningful Assertions** - Avoid trivial checks
4. **Clean State** - Reset between tests
5. **Traceability** - Reference test plan step IDs

---

## References

- Agent Definition: `.github/agents/generator.agent.md`
- Hook Script: `scripts/agents/generator/locator-strategy-builder.ts`
- Hook Configuration: `.github/hooks/agent-hooks.json`
- Locator Skills: `.github/skills/test-fixtures/SKILL.md`
- E2E Testing Skills: `.github/skills/e2e-testing/SKILL.md`
