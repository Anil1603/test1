---
name: Lightning locators (Salesforce-specific locator guidance)
description: Best practices for selecting stable and maintainable locators in Salesforce Lightning UI automation.
applyTo:  **/*
---
# Shadow DOM handling (Salesforce LWC / Aura)

Purpose: Practical guidance for selecting and interacting with shadow-DOM-hosted elements in test automation (Playwright / Puppeteer / WebDriver-based frameworks).

Principles
- Prefer testing through public component contracts (attributes, ARIA roles, exposed methods) rather than reaching into implementation details.
- When shadow DOM must be traversed, use the automation tool's supported shadow-piercing APIs or evaluate inside the page to access shadow roots.

Best practices
- Add stable, test-only attributes on the host (e.g., `data-testid`, `data-qa`) on Lightning Web Components' root element so tests don't need to pierce shadow boundaries.
- If you cannot modify the app, use a layered approach:
  1. Try role/aria or other exposed attributes on the host element.  
  2. Use framework shadow-piercing selectors (Playwright `pierce=` selector or equivalent) where supported.  
  3. As last resort, use elementHandle.evaluate to run `el.shadowRoot.querySelector()` for targeted access.

Playwright examples
- Prefer: locator('css=lightning-button[data-testid="saveBtn"]') if component exposes attribute.
- Pierce example (where Playwright supports it): locator('pierce=button.slds-button')
- Evaluate example: 
  const host = await page.locator('css:host-selector').elementHandle();
  const inner = await host.evaluateHandle(h => h.shadowRoot.querySelector('button'));

Stability tips
- Limit shadow access to single, well-named elements only (rare & surgical).  
- Wrap any direct shadow queries in helper utilities with clear logging and fallbacks.  
- When adding attributes for tests, prefer `data-testid` or `data-qa` and document them in `pages/` or locators manifest.

Security & maintenance
- Avoid brittle selectors tied to generated IDs (e.g., `__c123`) or auto-generated aura IDs.  
- If an element lives inside a closed shadow root (not accessible), coordinate with devs to expose a test hook or public API.

References
- Document why each shadow access is necessary inside the test (comment) so maintainers can remove when component API stabilizes.