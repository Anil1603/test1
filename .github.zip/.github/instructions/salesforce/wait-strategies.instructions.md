---
name: Wait strategies (Playwright / general UI automation)
description: Reliable synchronization patterns for Salesforce UI automation to reduce flakiness.
applyTo:  **/*
---
# Wait strategies (Playwright / general UI automation)

Purpose: Reliable synchronization patterns for Salesforce UI automation to reduce flakiness.

Core principles
- Prefer explicit, deterministic waits for specific conditions over arbitrary sleeps.
- Keep waits scoped and short; fail fast and provide diagnostic context.
- Use network- and UI-level signals together where appropriate (e.g., wait for API response + UI update).

Recommended patterns
1. Wait-for-state on the UI element
   - `locator.waitFor({ state: 'visible' })` or `expect(locator).toBeVisible()`.
   - Use `enabled`/`stable`/`editable` where supported before interacting with inputs.
2. Wait for text/content change
   - Wait until a success message or status text appears; avoid brittle full-page snapshots.
3. Wait for network or API call
   - Intercept and wait for the specific request to complete when UI update depends on it.
4. Use retries and idempotent actions
   - For transient failures, design retries around idempotent operations with small backoff.
5. Avoid global timeouts that mask slow failures
   - Set per-action reasonable timeouts and a global test timeout for runaway tests.

Playwright examples
- Wait for a button before clicking:
  await page.locator('[data-testid="submit"]').waitFor({ state: 'visible', timeout: 5000 });
  await page.click('[data-testid="submit"]');

- Wait for network response then UI update:
  const req = page.waitForResponse(r => r.url().includes('/api/leads') && r.status() === 200);
  await page.click('button.save');
  await req;
  await expect(page.locator('text=Saved')).toBeVisible();

Timeout guidance
- Default: 5–10s for small UI events; 20–30s for slower server ops. Tailor according to CI speed.
- Fail test with clear message when a wait times out. Log network requests or attach Playwright trace on CI failures.

Diagnostics
- Capture a screenshot, DOM snapshot, and network trace on failure.
- Where possible, log the last successful locator checks (visible/attached states) to speed diagnosis.

When to use sleeps
- Only for debugging or when dealing with known non-deterministic third-party widgets. Prefer retries or improved wait conditions.

Summary
- Prefer explicit, condition-based waits, combine UI and network signals, and keep waits small and well-logged.