---
description: Describe when these instructions should be loaded
# applyTo: 'Describe when these instructions should be loaded' # when provided, instructions will automatically be added to the request context when the pattern matches an attached file
---
The Epistemology of Automation: mechanisms of Object Recognition in the Salesforce Ecosystem
1. Introduction: The Crisis of Determinism in Salesforce Lightning
The transition of enterprise software from server-side page rendering to client-side Single Page Application (SPA) architectures has fundamentally altered the landscape of software quality assurance. Nowhere is this shift more palpable, or more disruptive, than in the Salesforce ecosystem. The evolution from Salesforce Classic (Visualforce) to the Lightning Experience (LEX)—underpinned by the Aura framework and, subsequently, Lightning Web Components (LWC)—has introduced a layer of abstraction that effectively "breaks" traditional, deterministic approaches to test automation.
In a standard web application, the relationship between the code written by a developer and the Document Object Model (DOM) rendered in the browser is often direct and predictable. An input field defined with id="username" appears in the DOM with that specific identifier. In contrast, Salesforce Lightning employs a sophisticated rendering engine that generates the DOM dynamically at runtime. Identifiers are often obfuscated, transient, or dependent on the render cycle (e.g., input-302:0), rendering them useless for long-term automation stability. Furthermore, the adoption of the Web Components standard has introduced the Shadow DOM—a mechanism for encapsulation that isolates component internals from the global document scope. While vital for modular development and style isolation, the Shadow DOM creates a "black box" for standard automation drivers, which historically rely on traversing a unified, open DOM tree.
This report provides an exhaustive analysis of how specialized automation platforms—specifically Provar, ACCELQ, and Testsigma—have re-architected object recognition to solve these challenges. It contrasts their proprietary mechanisms with open-source standards like Playwright and Salesforce’s own UI Test Automation Model (UTAM). By deconstructing the interplay between the Salesforce Metadata API, the Tooling API, and the rendered UI, we explore a fundamental shift in automation philosophy: moving from "locating elements" to "understanding objects."
The analysis further extends into the theoretical frontier of Generative AI, proposing a schema for how Salesforce metadata can serve as the foundational "Knowledge Base" for Retrieval-Augmented Generation (RAG) systems. This enables the creation of autonomous testing agents capable of reasoning about the application’s intent rather than merely interacting with its surface.
2. The Architectural Paradox of the Salesforce DOM
To fully appreciate the solutions provided by modern automation tools, one must first rigorously define the problem space. The Salesforce DOM in Lightning Experience is not merely complex; it is actively hostile to rigid automation strategies due to three core architectural characteristics: Dynamic Hydration, Component Encapsulation, and Polymorphic Rendering.
2.1 The Hydration Cycle and Asynchronous Rendering
Lightning applications do not load as static HTML documents. They are "hydrated." When a user navigates to an Opportunity record, the browser first receives a shell—a skeleton of the page layout. Subsequently, asynchronous network calls fetch the metadata (which fields to show) and the data (the values of those fields). The rendering engine then paints the components onto the screen.
For automation, this presents a "race condition" at scale. A standard Selenium script might query for the "Close Date" field immediately after the URL changes. However, while the container for the field might be present in the DOM, the interactive input element might not yet be hydrated, or it might be in a temporary "loading" state. This discrepancy leads to the infamous ElementNotInteractableException or StaleElementReferenceException.
Tools that rely solely on surface-level DOM inspection often fail to distinguish between a "rendered" component and a "ready" component. The "Smart Locators" discussed later in this report are designed to hook into the lifecycle events of the Aura and LWC frameworks, waiting not just for visibility, but for the component’s internal ready state.1
2.2 The Shadow DOM Enigma
The Shadow DOM is perhaps the most significant barrier to entry for standard automation. It creates a sub-tree of DOM nodes that is attached to a "Shadow Host" but is separated from the main document’s window object.
Encapsulation: Styles defined in the main document do not leak into the shadow tree, and vice-versa.
The Query Barrier: Standard APIs like document.getElementById or document.querySelector do not traverse into shadow roots. An automation driver attempting to find a button inside a custom LWC using a global XPath (//button[@class='slds-button']) will return null, even if the button is clearly visible to the human eye.
This architectural decision forces automation tools to adopt recursive traversal strategies. They must identify a Shadow Host, "pierce" the shadow root (often via specific JavaScript execution or the Chrome DevTools Protocol), and then query within that isolated scope. This process must be repeated for every level of nesting—a common scenario in Salesforce where a standard lightning-card might contain a custom c-datatable, which in turn contains lightning-button-icon components.3
2.3 Polymorphism and Contextual Reusability
A single Salesforce field, such as "Account Name," is not a static entity. It is a polymorphic object that changes its DOM representation based on context:
Detail Page (View Mode): Rendered as a lightning-formatted-text element.
Detail Page (Edit Mode): Rendered as a lightning-input element.
Datatable (Inline Edit): Rendered as a complex cell within a grid, often requiring a double-click event to instantiate the input mechanism.
Global Action: Rendered within a modal container with different CSS scoping.
Traditional "Record and Play" tools fail here because they record the specific state of the field at the moment of capture. If the test requires verifying the field in a list view versus a detail page, the locator strategy breaks. The advanced tools analyzed in this report utilize metadata to identify the business object (Account Name) regardless of its presentation layer.5
3. Provar: The Metadata-First Integration Engine
Provar occupies a unique position in the market as the only tool built explicitly for the Salesforce ecosystem, with its architecture coupled tightly to the Salesforce API layer. Unlike tools that "scan" the website, Provar "connects" to the Org. This distinction is critical: Provar automates the Salesforce application definition, not just the browser instance.
3.1 The Mechanics of Metadata Binding
When a user authenticates a Provar project against a Salesforce Org, the tool initiates a deep synchronization process using the Salesforce Metadata API and the Tooling API. This process creates a local "metadata cache" that serves as the map for all automation activities.
3.1.1 Object Definition Retrieval
Provar downloads the schema definition for all SObjects (Standard and Custom) in scope. This includes:
Field API Names: It maps the human-readable label "Account Name" to the immutable API name Name.
Data Types: It identifies that StageName is a Picklist and Amount is a Currency field.
Relationships: It understands that AccountId on a Contact record is a Lookup relationship to the Account object.
This metadata binding allows Provar to generate locators that are remarkably resilient. When a test step is created to "Enter value in Account Name," Provar does not generate an XPath targeting the text "Account Name." Instead, it generates a locator instruction targeting the component bound to Account.Name. If Salesforce changes the UI label to "Client Name" or the underlying HTML class from input-text to input-search, the test remains valid because the API name Name has not changed.5
3.1.2 Page Layout Parsing
Beyond individual fields, Provar ingests Page Layout metadata. This is crucial for handling required fields and default values.
Implicit Assertions: Because Provar knows which fields are marked as "Required" in the layout metadata, it can implicitly validate that a test case provides data for these fields before execution begins, shifting the "fail fast" mechanism to the design phase.
Record Type Awareness: Salesforce layouts change based on Record Type. Provar’s metadata engine detects the active Record Type during execution and adjusts its locator strategy to match the specific layout assignment for the logged-in user’s profile. This handles the complexity of "Dynamic Forms" where fields might be hidden or rearranged based on data rules.6
3.2 Handling Polymorphism through "Renderers"
Provar addresses the polymorphic nature of Salesforce fields through a proprietary abstraction layer called "Renderers." A Renderer is a specialized logic block that defines how to interact with a specific Salesforce component type in various states.
The Interaction Strategy: When Provar encounters a lightning-input, it delegates the interaction to the specific LWC Renderer. This renderer knows that to set a value, it must potentially trigger a focus event, clear the existing value, type the new value, and then trigger a blur event to fire any attached validation rules.
Context Switching: If the same field is encountered in a Visualforce page, Provar switches to the Visualforce Renderer. This renderer knows how to handle the IFrame context and the legacy id structures generated by the Visualforce view state. The tester, however, uses the same "Set Value" command in the test script, completely abstracted from this complexity.7
3.3 LWC and Shadow DOM Piercing in Provar
Provar’s support for LWC goes beyond simple DOM traversal. It utilizes a "Fact-Based" object recognition system.
The "Fact" Object: In Provar, a UI component is represented as a "Fact." A lightning-button is a Fact with properties like Label, Title, and Variant.
Metadata Mapping: For custom LWCs, Provar allows users to map these Facts to the component’s public properties (@api). If a developer creates a custom component <c-credit-card-form> with a public property cardNumber, Provar can target that property directly.
The Piercing Algorithm: At runtime, Provar’s execution engine (built on a modified Selenium implementation) automatically detects Shadow Roots. It recursively traverses the shadow tree to locate the element matching the Fact definition. This traversal is transparent to the user, who simply sees a "Credit Card Number" field in the test builder.4
4. ACCELQ: The Cognitive and Visual Intelligence Approach
While Provar relies on backend metadata, ACCELQ approaches the problem from the perspective of "Cognitive Quality." Its architecture focuses on building a visual and functional model of the application, which it terms the "Universe." This approach is particularly effective for hybrid environments where Salesforce interacts with non-Salesforce applications, as it does not rely solely on the Salesforce API.
4.1 The "Universe" and Context-Aware Views
In ACCELQ, the fundamental unit of organization is not a "Script" or "Test Case," but a "View."
View Recording: When a user captures a Salesforce page (e.g., "Opportunity Detail"), ACCELQ analyzes the entire DOM structure of that state. It does not just record the element the user clicked; it records the structural relationship of all elements on the page.
Contextual Relationships: The system understands that the "Save" button is contextually related to the modal dialog it sits within. It maps the "Stage" dropdown relative to the "Close Date" picker. This creates a "Context" (or Universe) where elements are defined not by their absolute path, but by their semantic relationship to the page and to each other.8
4.2 AI-Driven Element Identification
ACCELQ employs a "Multi-Attribute Weighting System" for object recognition, often marketed as AI or Smart Locators.
The Attribute Matrix: For any given element, ACCELQ captures dozens of attributes: ID, Name, Class, Tag, Text Label, Neighboring Labels, Ancestor Tags, and CSS properties.
Weighted Scoring: Instead of relying on a single "Golden Selector" (like XPath), it assigns weights to these attributes. In a Salesforce context, it might learn that the data-aura-class attribute is highly stable, while the id attribute is highly volatile. It assigns a higher weight to data-aura-class.
Self-Healing (Heuristic Recovery): If a Salesforce release changes the class structure, the primary locator strategy might fail. ACCELQ’s engine then calculates a similarity score for all elements in the current DOM against the stored Attribute Matrix. If it finds an element that matches 90% of the weighted attributes (e.g., same label, same relative position, same tag, but different ID), it identifies it as the target element and proceeds. This "Self-Healing" capability is essential for surviving the "silent" updates of the Salesforce platform.9
4.3 Visualforce and Frame Management
---
description: Describe when these instructions should be loaded
---

# The Epistemology of Automation: Object Recognition in the Salesforce Ecosystem

## 1. Introduction — The Crisis of Determinism in Salesforce Lightning

The transition from server-side page rendering to client-side Single Page Application (SPA) architectures changed software QA. In the Salesforce ecosystem, the move from Visualforce to Lightning Experience (Aura and Lightning Web Components — LWC) introduced dynamic rendering, obfuscated identifiers, and Shadow DOM encapsulation that break many traditional automation assumptions.

In standard web apps an element with id="username" appears predictably. In Salesforce Lightning the DOM is often generated at runtime, identifiers are transient (e.g., `input-302:0`), and many components use Shadow DOM. These factors make brittle locators and naive DOM inspection unreliable.

## 2. The Architectural Paradox of the Salesforce DOM

Salesforce Lightning brings three architectural challenges for automation:

- Dynamic hydration and asynchronous rendering
- Shadow DOM and component encapsulation
- Polymorphic rendering of business fields

### 2.1 Hydration and asynchronous rendering

Lightning pages are hydrated: a shell loads first, then metadata and data arrive asynchronously and the UI is painted. Automation must therefore distinguish between "rendered" containers and components that are "ready" to interact with (avoiding ElementNotInteractable or StaleElementReference exceptions).

"Smart locators" should wait for component-ready lifecycle events rather than only visibility.

### 2.2 The Shadow DOM enigma

Shadow DOM creates isolated subtrees that standard global queries do not traverse. Automation tools must detect shadow hosts and query shadow roots—often via CDP or specialized traversal logic—to access nested elements.

### 2.3 Polymorphism and contextual reusability

Business fields (e.g., "Account Name") render differently depending on context: view mode, edit mode, embedded datatable, global action modal, etc. Locator strategies that bind to presentation details fail when the representation changes; metadata-aware approaches bind to API names or semantic identifiers instead.

## 3. Provar — Metadata-first integration

Provar connects to a Salesforce org and ingests metadata (Metadata API, Tooling API) to create a local metadata cache. This allows locators to target SObject field bindings (e.g., `Account.Name`) rather than fragile UI selectors.

Key capabilities:

- Downloads SObject schemas and page layout assignments
- Adapts locators for record types and dynamic forms
- Uses "Renderers" to handle component-specific interactions (LWC, Visualforce)
- Detects and pierces Shadow DOM at runtime when necessary

## 4. ACCELQ — Cognitive and visual modeling

ACCELQ builds a structural "Universe" of the page (DOM relationships and visual context) and uses multi-attribute weighting for element identification. Its strengths:

- Contextual views and spatial/visual anchors
- An attribute-weighted matching and self-healing system for locator recovery
- Frame and Visualforce handling via text anchors and spatial heuristics

## 5. Testsigma — NLP and cloud AI

Testsigma emphasizes natural-language tests and cloud-based heuristics. It:

- Translates intent (plain-English steps) into locator strategies
- Uses community-driven heuristics and auto-heal at scale
- Includes Lightning-specific logic (smart waits, shadow handling)

## 6. Open-source standards: Playwright + UTAM

Playwright (CDP-based) and UTAM (Salesforce’s UI Test Automation Model) form a robust, code-first approach.

### 6.1 Playwright

- Communicates via CDP, has native support for traversing open shadow roots with its selector engine
- Encourages accessible locators (getByRole, getByLabel) which align with Salesforce's a11y attributes

Example comparisons:

Selenium (shadow DOM):

```java
WebElement shadowHost = driver.findElement(By.cssSelector("c-app"));
SearchContext shadowRoot = shadowHost.getShadowRoot();
WebElement target = shadowRoot.findElement(By.cssSelector("button"));
```

Playwright:

```js
page.locator('c-app button');
```

### 6.2 UTAM

UTAM provides JSON page-object contracts published by Salesforce for standard components. Using UTAM decouples intent from selectors and reduces maintenance when Salesforce updates base components.

## 7. The future — RAG-driven autonomous testing agents

Combining Salesforce metadata, vector search, and LLMs enables agents that:

- Retrieve metadata-grounded facts (field API names, validation rules, layouts)
- Generate Playwright scripts or UTAM-based interactions grounded in the org's configuration
- Execute, observe failures, and re-query the KB to self-correct

Example RAG schema (conceptual):

```json
{
  "entity": "SObject",
  "name": "Opportunity",
  "api_name": "Opportunity",
  "fields": [
    {
      "label": "Close Date",
      "api_name": "CloseDate",
      "ui_hints": {
        "playwright_locator": "getByLabel('Close Date')",
        "utam_element": "closeDateDatePicker"
      }
    }
  ]
}
```

## 8. Strategic comparison (summary)

| Feature | Provar | ACCELQ | Testsigma | Playwright + UTAM |
|---|---:|---:|---:|---:|
| Object source | Metadata API | DOM/Visual "Universe" | NLP + heuristics | Accessibility / UTAM |
| LWC support | Deep (fact/renderers) | Visual analysis + shadow handling | Smart waits + shadow support | Native CDP + selectors |
| Resilience | High (API binding) | High (self-heal) | High (auto-heal) | High (if using UTAM/a11y) |

## 9. Conclusion

There are two converging philosophies for Salesforce test automation:

- Metadata-first and org-aware (Provar) for highest resilience
- Code-first, standards-driven (Playwright + UTAM) for control and transparency

AI-driven visual heuristics (ACCELQ, Testsigma) and RAG-grounded agents combine elements of both approaches and point the way toward autonomous, self-healing test systems.

## Works cited

- Salesforce UI testing tools: UTAM framework vs third-party solutions — Gearset: https://gearset.com/blog/salesforce-ui-testing-tools/
- DOM Inspection Tests Are Subject to Change — Salesforce Developers: https://developer.salesforce.com/docs/platform/lwc/guide/testing-dom-api.html
- Salesforce LWC Testing — Virtuoso QA: https://www.virtuosoqa.com/post/salesforce-lightning-web-components-lwc-testing
- Provar resources and best practices: https://provar.com
- ACCELQ and Testsigma documentation and blogs (see original references)
- Playwright docs — https://playwright.dev/docs/locators
- UTAM guide — https://utam.dev/guide/page-objects
