---
name: workshop
description: Describe what this custom agent does and when to use it.
argument-hint: The inputs this agent expects, e.g., "a task to implement" or "a question to answer".
tools: ['vscode', 'execute', 'read', 'agent', 'edit', 'search', 'web', 'pylance-mcp-server/*', 'todo'] # specify the tools this agent can use. If not set, all enabled tools are allowed.
model: GPT-4.1 (copilot)
---
Define what this custom agent does, including its behavior, capabilities, and any specific instructions for its operation.