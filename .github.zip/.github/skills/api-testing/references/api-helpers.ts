// API Helpers - Reusable API testing utilities

import { APIRequestContext, expect } from '@playwright/test';

/**
 * API Helper class with common API operations
 */
export class APIHelper {
  constructor(private request: APIRequestContext) {}

  /**
   * Perform GET request and return JSON response
   */
  async get<T = any>(endpoint: string, options?: any): Promise<T> {
    const response = await this.request.get(endpoint, options);
    expect(response.ok()).toBeTruthy();
    return await response.json();
  }

  /**
   * Perform POST request and return JSON response
   */
  async post<T = any>(endpoint: string, data: any): Promise<T> {
    const response = await this.request.post(endpoint, { data });
    expect(response.status()).toBeGreaterThanOrEqual(200);
    expect(response.status()).toBeLessThan(300);
    return await response.json();
  }

  /**
   * Perform PUT request and return JSON response
   */
  async put<T = any>(endpoint: string, data: any): Promise<T> {
    const response = await this.request.put(endpoint, { data });
    expect(response.ok()).toBeTruthy();
    return await response.json();
  }

  /**
   * Perform PATCH request and return JSON response
   */
  async patch<T = any>(endpoint: string, data: any): Promise<T> {
    const response = await this.request.patch(endpoint, { data });
    expect(response.ok()).toBeTruthy();
    return await response.json();
  }

  /**
   * Perform DELETE request
   */
  async delete(endpoint: string): Promise<void> {
    const response = await this.request.delete(endpoint);
    expect([200, 204]).toContain(response.status());
  }

  /**
   * Wait for API endpoint to be available
   */
  async waitForAPI(
    endpoint: string,
    maxAttempts: number = 10,
    delayMs: number = 1000
  ): Promise<boolean> {
    for (let i = 0; i < maxAttempts; i++) {
      try {
        const response = await this.request.get(endpoint);
        if (response.ok()) return true;
      } catch (error) {
        // Continue trying
      }
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
    return false;
  }
}

/**
 * Authentication helper
 */
export class AuthHelper {
  constructor(private request: APIRequestContext) {}

  /**
   * Login and return authentication token
   */
  async login(email: string, password: string): Promise<string> {
    const response = await this.request.post('/api/auth/login', {
      data: { email, password }
    });
    
    expect(response.ok()).toBeTruthy();
    const { token } = await response.json();
    return token;
  }

  /**
   * Create authenticated request context
   */
  static async createAuthContext(
    playwright: any,
    baseURL: string,
    token: string
  ): Promise<APIRequestContext> {
    return await playwright.request.newContext({
      baseURL,
      extraHTTPHeaders: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
  }
}

/**
 * Schema validation helper
 */
export class SchemaValidator {
  /**
   * Validate object matches expected schema
   */
  static validate(obj: any, schema: any): boolean {
    for (const [key, validator] of Object.entries(schema)) {
      if (!obj.hasOwnProperty(key)) {
        return false;
      }
      
      if (typeof validator === 'function') {
        if (!validator(obj[key])) {
          return false;
        }
      } else if (typeof validator === 'object') {
        if (!this.validate(obj[key], validator)) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * Common schema validators
   */
  static validators = {
    string: (val: any) => typeof val === 'string',
    number: (val: any) => typeof val === 'number',
    boolean: (val: any) => typeof val === 'boolean',
    array: (val: any) => Array.isArray(val),
    email: (val: any) =>
      typeof val === 'string' && /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(val),
    uuid: (val: any) =>
      typeof val === 'string' &&
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val),
    url: (val: any) =>
      typeof val === 'string' && /^https?:\/\/.+/.test(val),
    dateString: (val: any) =>
      typeof val === 'string' && !isNaN(Date.parse(val))
  };
}

/**
 * Response validator
 */
export class ResponseValidator {
  /**
   * Validate response has expected properties
   */
  static hasProperties(response: any, ...properties: string[]): boolean {
    return properties.every(prop => response.hasOwnProperty(prop));
  }

  /**
   * Validate array response
   */
  static isArray(response: any, minLength: number = 0): boolean {
    return Array.isArray(response) && response.length >= minLength;
  }

  /**
   * Validate pagination response
   */
  static isPaginatedResponse(response: any): boolean {
    return (
      this.hasProperties(response, 'items', 'total', 'page', 'limit') &&
      Array.isArray(response.items)
    );
  }
}

/**
 * Test data generator
 */
export class TestDataGenerator {
  static generateEmail(): string {
    return `test-${Date.now()}@example.com`;
  }

  static generateUsername(): string {
    return `user_${Date.now()}`;
  }

  static generateId(): string {
    return Date.now().toString();
  }

  static generateUser() {
    return {
      name: `Test User ${Date.now()}`,
      email: this.generateEmail(),
      username: this.generateUsername()
    };
  }
}

/**
 * Usage Example:
 * 
 * import { APIHelper, AuthHelper } from '@utils/api-helpers';
 * 
 * test('example', async ({ request }) => {
 *   const api = new APIHelper(request);
 *   
 *   // GET request
 *   const users = await api.get('/api/users');
 *   
 *   // POST request
 *   const newUser = await api.post('/api/users', {
 *     name: 'Test',
 *     email: 'test@example.com'
 *   });
 *   
 *   // DELETE request
 *   await api.delete(`/api/users/${newUser.id}`);
 * });
 */
