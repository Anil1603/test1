---
name: api-testing
description: Toolkit for API testing with Playwright's request context. Provides patterns for REST API validation, authentication, response verification, and schema validation. Use when testing backend endpoints and API contracts.
---

# API Testing Skill

## Overview

The API Testing Skill provides comprehensive patterns for testing REST APIs using Playwright's request context. It covers HTTP method testing, authentication patterns, response validation, schema verification, and error handling. This skill is essential for validating backend functionality, setting up test data, and ensuring API contract compliance without the overhead of browser automation.

## When to Use This Skill

Use this skill when:
- Testing REST API endpoints
- Validating API contracts and responses
- Testing authentication and authorization
- Setting up test data via API calls
- Testing backend integration points
- Validating error handling and status codes
- Testing API performance and response times

## Prerequisites

- Playwright installed and configured
- API base URL configured
- Authentication credentials available
- Understanding of REST API principles

## Core Capabilities

### 1. HTTP Methods Testing
- GET requests for data retrieval
- POST requests for resource creation
- PUT/PATCH for updates
- DELETE for resource removal
- HEAD, OPTIONS for metadata

### 2. Authentication Testing
- Bearer token authentication
- API key authentication
- OAuth flows
- Session-based auth
- Cookie handling

### 3. Response Validation
- Status code verification
- Header validation
- Body structure validation
- Schema compliance
- Error response handling

### 4. Data Management
- Create test data via API
- Cleanup after tests
- Seed databases
- State management

## Usage Examples

### Basic GET Request
```typescript
import { test, expect } from '@playwright/test';

test('should retrieve user list', async ({ request }) => {
  const response = await request.get('/api/users');
  
  expect(response.ok()).toBeTruthy();
  expect(response.status()).toBe(200);
  
  const users = await response.json();
  expect(Array.isArray(users)).toBeTruthy();
  expect(users.length).toBeGreaterThan(0);
});
```

### POST Request with Authentication
```typescript
test('should create new user', async ({ request }) => {
  const response = await request.post('/api/users', {
    headers: {
      'Authorization': `Bearer ${process.env.API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    data: {
      name: 'Test User',
      email: 'test@example.com',
      role: 'user'
    }
  });

  expect(response.status()).toBe(201);
  
  const user = await response.json();
  expect(user).toHaveProperty('id');
  expect(user.email).toBe('test@example.com');
});
```

### API Request Context
```typescript
import { test as base } from '@playwright/test';

const test = base.extend({
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.API_BASE_URL,
      extraHTTPHeaders: {
        'Authorization': `Bearer ${process.env.API_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });
    await use(context);
    await context.dispose();
  }
});

test('with context', async ({ apiContext }) => {
  const response = await apiContext.get('/api/users');
  expect(response.ok()).toBeTruthy();
});
```

### Schema Validation
```typescript
test('should match user schema', async ({ request }) => {
  const response = await request.get('/api/users/1');
  const user = await response.json();

  // Define expected schema
  expect(user).toMatchObject({
    id: expect.any(Number),
    name: expect.any(String),
    email: expect.stringMatching(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/),
    createdAt: expect.any(String),
    role: expect.stringMatching(/^(admin|user|guest)$/)
  });
});
```

### Error Handling
```typescript
test('should return 404 for non-existent resource', async ({ request }) => {
  const response = await request.get('/api/users/999999');
  
  expect(response.status()).toBe(404);
  
  const error = await response.json();
  expect(error).toHaveProperty('message');
  expect(error.message).toContain('not found');
});

test('should return 400 for invalid data', async ({ request }) => {
  const response = await request.post('/api/users', {
    data: {
      email: 'invalid-email',  // Invalid format
      name: ''  // Empty name
    }
  });
  
  expect(response.status()).toBe(400);
  
  const error = await response.json();
  expect(error).toHaveProperty('errors');
  expect(error.errors).toEqual(
    expect.arrayContaining([
      expect.objectContaining({ field: 'email' }),
      expect.objectContaining({ field: 'name' })
    ])
  );
});
```

## Guidelines

### Request Structure
- Use clear, descriptive variable names
- Set appropriate headers
- Structure data payloads properly
- Handle response parsing correctly

### Response Validation
- Always check status codes
- Validate response structure
- Check required fields
- Verify data types

### Test Organization
- Group tests by resource/endpoint
- Test happy path first
- Cover error scenarios
- Test edge cases

### Data Cleanup
- Delete created resources
- Reset state after tests
- Handle cleanup failures gracefully
- Track created resources

## Common Patterns

### CRUD Operations Suite
```typescript
test.describe('Users API CRUD', () => {
  let userId: number;

  test('CREATE - should create user', async ({ request }) => {
    const response = await request.post('/api/users', {
      data: { name: 'Test', email: 'test@example.com' }
    });
    expect(response.status()).toBe(201);
    const user = await response.json();
    userId = user.id;
  });

  test('READ - should get user', async ({ request }) => {
    const response = await request.get(`/api/users/${userId}`);
    expect(response.ok()).toBeTruthy();
  });

  test('UPDATE - should update user', async ({ request }) => {
    const response = await request.put(`/api/users/${userId}`, {
      data: { name: 'Updated Name' }
    });
    expect(response.ok()).toBeTruthy();
  });

  test('DELETE - should delete user', async ({ request }) => {
    const response = await request.delete(`/api/users/${userId}`);
    expect(response.status()).toBe(204);
  });
});
```

### Pagination Testing
```typescript
test('should handle pagination', async ({ request }) => {
  const response = await request.get('/api/users?page=1&limit=10');
  
  expect(response.ok()).toBeTruthy();
  const data = await response.json();
  
  expect(data).toHaveProperty('items');
  expect(data).toHaveProperty('total');
  expect(data).toHaveProperty('page');
  expect(data).toHaveProperty('limit');
  expect(data.items.length).toBeLessThanOrEqual(10);
});
```

## Best Practices

### 1. Always Verify Status Codes
```typescript
// ✅ Check status explicitly
const response = await request.post('/api/users', { data });
expect(response.status()).toBe(201);
expect(response.ok()).toBeTruthy();

// ❌ Assuming success
const response = await request.post('/api/users', { data });
const user = await response.json(); // Might fail if 4xx/5xx
```

### 2. Validate Response Schema
```typescript
const response = await request.get('/api/users/1');
const user = await response.json();

// Validate structure
expect(user).toMatchObject({
  id: expect.any(Number),
  email: expect.stringMatching(/^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/),
  role: expect.stringMatching(/^(admin|user)$/)
});
```

### 3. Use Request Context for Reusability
```typescript
// Create authenticated context once
const apiContext = await playwright.request.newContext({
  baseURL: 'https://api.example.com',
  extraHTTPHeaders: {
    'Authorization': `Bearer ${token}`
  }
});

// Reuse everywhere
await apiContext.get('/users');
await apiContext.post('/products', { data });
```

### 4. Test Error Cases
```typescript
test('handles 404 correctly', async ({ request }) => {
  const response = await request.get('/api/users/99999');
  expect(response.status()).toBe(404);
  
  const error = await response.json();
  expect(error.message).toBe('User not found');
});
```

### 5. Clean Up Test Data
```typescript
test('user lifecycle', async ({ request }) => {
  // Create
  const createRes = await request.post('/api/users', { data: userData });
  const user = await createRes.json();
  
  try {
    // Test operations
    // ...
  } finally {
    // Always cleanup
    await request.delete(`/api/users/${user.id}`);
  }
});
```

## Examples

### Example 1: Complete CRUD Test Suite
```typescript
import { test, expect } from '@playwright/test';

test.describe('Users API', () => {
  let userId: number;
  
  test('CREATE - creates new user', async ({ request }) => {
    const response = await request.post('/api/users', {
      data: {
        name: 'Test User',
        email: 'test@example.com',
        role: 'user'
      }
    });
    
    expect(response.status()).toBe(201);
    const user = await response.json();
    expect(user).toHaveProperty('id');
    userId = user.id;
  });
  
  test('READ - retrieves user', async ({ request }) => {
    const response = await request.get(`/api/users/${userId}`);
    expect(response.ok()).toBeTruthy();
    
    const user = await response.json();
    expect(user.email).toBe('test@example.com');
  });
  
  test('UPDATE - modifies user', async ({ request }) => {
    const response = await request.put(`/api/users/${userId}`, {
      data: { name: 'Updated Name' }
    });
    
    expect(response.ok()).toBeTruthy();
    const user = await response.json();
    expect(user.name).toBe('Updated Name');
  });
  
  test('DELETE - removes user', async ({ request }) => {
    const response = await request.delete(`/api/users/${userId}`);
    expect(response.status()).toBe(204);
    
    // Verify deletion
    const getRes = await request.get(`/api/users/${userId}`);
    expect(getRes.status()).toBe(404);
  });
});
```

### Example 2: Authentication Testing
```typescript
test('authentication flow', async ({ request }) => {
  // Login
  const loginRes = await request.post('/api/auth/login', {
    data: {
      email: 'user@example.com',
      password: 'password123'
    }
  });
  
  expect(loginRes.ok()).toBeTruthy();
  const { token } = await loginRes.json();
  expect(token).toBeTruthy();
  
  // Use token for authenticated request
  const profileRes = await request.get('/api/profile', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  expect(profileRes.ok()).toBeTruthy();
  const profile = await profileRes.json();
  expect(profile.email).toBe('user@example.com');
});
```

### Example 3: Error Handling
```typescript
test.describe('Error Handling', () => {
  test('returns 400 for invalid data', async ({ request }) => {
    const response = await request.post('/api/users', {
      data: {
        email: 'not-an-email',
        name: ''
      }
    });
    
    expect(response.status()).toBe(400);
    const error = await response.json();
    
    expect(error.errors).toContainEqual(
      expect.objectContaining({ field: 'email', message: expect.any(String) })
    );
  });
  
  test('returns 401 for unauthorized', async ({ request }) => {
    const response = await request.get('/api/admin/users');
    expect(response.status()).toBe(401);
  });
  
  test('returns 404 for not found', async ({ request }) => {
    const response = await request.get('/api/users/99999');
    expect(response.status()).toBe(404);
  });
});
```

## Limitations

- Cannot test UI behavior
- Limited to HTTP/HTTPS protocols
- No browser context available
- Cannot interact with DOM
- No visual validation

## References

- See [api-helpers.ts](./references/api-helpers.ts) for reusable API helpers
- Refer to Playwright [API testing docs](https://playwright.dev/docs/api-testing)
- Use `@playwright-api-tester` agent for API test creation
