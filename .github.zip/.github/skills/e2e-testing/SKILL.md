---
name: e2e-testing
description: Toolkit for end-to-end testing with Playwright. Provides patterns for user flows, navigation, page objects, form interactions, and data management. Use when testing complete user journeys or workflows.
---

# E2E Testing Skill

## Overview

The E2E Testing Skill provides comprehensive patterns and practices for end-to-end testing with Playwright. It focuses on testing complete user workflows from start to finish, simulating real user interactions across multiple pages and components. This skill emphasizes the Page Object Model pattern, proper test isolation, and maintainable test code that accurately represents user journeys.

## When to Use This Skill

Use this skill when:
- Testing complete user workflows and journeys
- Validating multi-page user flows
- Testing form submissions and navigation
- Implementing Page Object Model patterns
- Managing test data for E2E scenarios
- Testing authentication and authorization flows
- Validating cross-page state management

## Prerequisites

- Playwright installed and configured
- Base URL configured in `playwright.config.ts`
- Page objects directory (`pages/`) set up
- Test data fixtures available

## Core Capabilities

### 1. User Flow Testing
Test complete user journeys from start to finish:
- Multi-step workflows
- Form wizards and multi-page forms
- Shopping cart and checkout flows
- User registration and onboarding
- Account settings modification

### 2. Navigation Patterns
Handle complex navigation scenarios:
- Deep linking and URL parameters
- Back/forward navigation
- Tab and window management
- Modal and overlay navigation
- Breadcrumb navigation

### 3. Page Object Integration
Implement maintainable test code:
- Page Object Model (POM) pattern
- Reusable component objects
- Action and assertion separation
- Locator encapsulation

### 4. Form Interactions
Comprehensive form testing:
- Input field validation
- Multi-select and checkboxes
- File uploads
- Date pickers and calendars
- Auto-complete and search fields

### 5. Test Data Management
Efficient data handling:
- Test data fixtures
- Dynamic data generation
- Data setup and teardown
- API-based data seeding

## Usage Examples

### Basic E2E User Flow
```typescript
import { test, expect } from '@playwright/test';
import { LoginPage } from '@pages/login-page';
import { DashboardPage } from '@pages/dashboard-page';

test.describe('User Dashboard Access', () => {
  test('should access dashboard after login', async ({ page }) => {
    await test.step('Navigate to login', async () => {
      const loginPage = new LoginPage(page);
      await loginPage.goto();
    });

    await test.step('Login with credentials', async () => {
      const loginPage = new LoginPage(page);
      await loginPage.login('user@example.com', 'password123');
    });

    await test.step('Verify dashboard access', async () => {
      const  dashboardPage = new DashboardPage(page);
      await dashboardPage.expectToBeVisible();
      await expect(dashboardPage.welcomeMessage).toContainText('Welcome');
    });
  });
});
```

### Multi-Step Form Flow
```typescript
test('should complete registration wizard', async ({ page }) => {
  await test.step('Step 1: Personal Information', async () => {
    await page.goto('/register');
    await page.getByLabel('First Name').fill('John');
    await page.getByLabel('Last Name').fill('Doe');
    await page.getByLabel('Email').fill('john.doe@example.com');
    await page.getByRole('button', { name: 'Next' }).click();
  });

  await test.step('Step 2: Account Details', async () => {
    await expect(page).toHaveURL(/.*step=2/);
    await page.getByLabel('Username').fill('johndoe');
    await page.getByLabel('Password').fill('SecurePass123!');
    await page.getByLabel('Confirm Password').fill('SecurePass123!');
    await page.getByRole('button', { name: 'Next' }).click();
  });

  await test.step('Step 3: Preferences', async () => {
    await expect(page).toHaveURL(/.*step=3/);
    await page.getByLabel('Email notifications').check();
    await page.getByRole('button', { name: 'Complete Registration' }).click();
  });

  await test.step('Verify success', async () => {
    await expect(page).toHaveURL('/dashboard');
    await expect(page.getByText('Registration successful')).toBeVisible();
  });
});
```

### Shopping Cart Flow
```typescript
test('should add items and complete checkout', async ({ page }) => {
  await test.step('Browse and add items', async () => {
    await page.goto('/products');
    await page.getByTestId('product-1').getByRole('button', { name: 'Add to Cart' }).click();
    await page.getByTestId('product-3').getByRole('button', { name: 'Add to Cart' }).click();
    await expect(page.locator('.cart-badge')).toHaveText('2');
  });

  await test.step('View cart', async () => {
    await page.getByRole('link', { name: 'Cart' }).click();
    await expect(page).toHaveURL('/cart');
    await expect(page.locator('.cart-item')).toHaveCount(2);
  });

  await test.step('Proceed to checkout', async () => {
    await page.getByRole('button', { name: 'Checkout' }).click();
    await expect(page).toHaveURL('/checkout');
  });

  await test.step('Fill shipping information', async () => {
    await page.getByLabel('Address').fill('123 Main St');
    await page.getByLabel('City').fill('New York');
    await page.getByLabel('ZIP Code').fill('10001');
    await page.getByRole('button', { name: 'Continue' }).click();
  });

  await test.step('Complete payment', async () => {
    await page.getByLabel('Card Number').fill('4242424242424242');
    await page.getByLabel('Expiry').fill('12/25');
    await page.getByLabel('CVC').fill('123');
    await page.getByRole('button', { name: 'Place Order' }).click();
  });

  await test.step('Verify order confirmation', async () => {
    await expect(page).toHaveURL(/.*order-confirmation/);
    await expect(page.getByText('Order confirmed')).toBeVisible();
  });
});
```

## Guidelines

### Test Organization
- Group tests by feature or user flow
- Use descriptive test names that explain the scenario
- Implement test steps for multi-step flows
- Keep tests focused on one user journey

### Page Object Pattern
- Create page objects for each major page
- Use getters for locators
- Separate actions from assertions
- Reuse common interactions

### Data Management
- Use fixtures for test data
- Clean up test data after tests
- Consider using API for data setup
- Use unique identifiers to avoid conflicts

### Performance
- Minimize unnecessary navigation
- Reuse authentication state
- Run independent tests in parallel
- Optimize wait strategies

### Error Handling
- Add meaningful error messages
- Handle edge cases and error states
- Test negative scenarios
- Verify error messages

## Common Patterns

### Authentication Flow with Fixture
```typescript
// fixtures/auth-fixtures.ts
import { test as base } from '@playwright/test';

export const test = base.extend({
  authenticatedPage: async ({ page }, use) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill(process.env.TEST_EMAIL!);
    await page.getByLabel('Password').fill(process.env.TEST_PASSWORD!);
    await page.getByRole('button', { name: 'Login' }).click();
    await page.waitForURL('/dashboard');
    await use(page);
  },
});

// In test file
import { test } from '@fixtures/auth-fixtures';

test('dashboard test', async ({ authenticatedPage }) => {
  // Already logged in
  await expect(authenticatedPage).toHaveURL('/dashboard');
});
```

### Form Validation Testing
```typescript
test('should validate form fields', async ({ page }) => {
  await page.goto('/contact');

  // Test required field
  await page.getByRole('button', { name: 'Submit' }).click();
  await expect(page.getByText('Email is required')).toBeVisible();

  // Test invalid email format
  await page.getByLabel('Email').fill('invalid-email');
  await page.getByRole('button', { name: 'Submit' }).click();
  await expect(page.getByText('Invalid email format')).toBeVisible();

  // Test successful submission
  await page.getByLabel('Email').fill('valid@example.com');
  await page.getByLabel('Message').fill('Test message');
  await page.getByRole('button', { name: 'Submit' }).click();
  await expect(page.getByText('Message sent successfully')).toBeVisible();
});
```

## Best Practices

### 1. Use Role-Based Locators
```typescript
// ✅ Good - Accessible and stable
await page.getByRole('button', { name: 'Submit' }).click();
await page.getByLabel('Email').fill('user@example.com');

// ❌ Bad - Brittle CSS selectors
await page.locator('div.form > button.submit-btn').click();
```

### 2. Implement Page Objects
```typescript
// Encapsulate page logic in reusable classes
export class CheckoutPage extends BasePage {
  private get confirmButton() {
    return this.page.getByRole('button', { name: 'Confirm Order' });
  }
  
  async confirmOrder() {
    await this.confirmButton.click();
    await this.page.waitForURL('/order-confirmation');
  }
}
```

### 3. Use Test Steps for Clarity
```typescript
test('checkout flow', async ({ page }) => {
  await test.step('Add items to cart', async () => {
    // Setup
  });
  
  await test.step('Complete checkout', async () => {
    // Main action
  });
  
  await test.step('Verify order', async () => {
    // Verification
  });
});
```

### 4. Ensure Test Isolation
```typescript
test.beforeEach(async ({ page }) => {
  // Fresh state for each test
  await page.goto('/');
});

test.afterEach(async ({ page }) => {
  // Clean up
  await page.context().clearCookies();
});
```

### 5. Use Web-First Assertions
```typescript
// ✅ Auto-waiting assertions
await expect(page.locator('.message')).toBeVisible();
await expect(page.locator('.message')).toHaveText('Success');

// ❌ Manual checks (flaky)
const isVisible = await page.locator('.message').isVisible();
expect(isVisible).toBeTruthy();
```

## Examples

### Example 1: Login Flow with Page Objects
```typescript
import { test, expect } from '@playwright/test';
import { LoginPage } from '@pages/login-page';
import { DashboardPage } from '@pages/dashboard-page';

test('successful login redirects to dashboard', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const dashboardPage = new DashboardPage(page);
  
  await loginPage.goto();
  await loginPage.login('user@example.com', 'password123');
  
  await dashboardPage.expectToBeVisible();
  await expect(dashboardPage.welcomeMessage).toContainText('Welcome back');
});
```

### Example 2: E2E Shopping Flow
```typescript
test('complete purchase journey', async ({ page }) => {
  await test.step('Browse products', async () => {
    await page.goto('/products');
    await expect(page.getByRole('heading', { name: 'Products' })).toBeVisible();
  });
  
  await test.step('Add to cart', async () => {
    await page.getByTestId('product-1').getByRole('button', { name: 'Add' }).click();
    await expect(page.locator('.cart-badge')).toHaveText('1');
  });
  
  await test.step('Checkout', async () => {
    await page.getByRole('link', { name: 'Cart' }).click();
    await page.getByRole('button', { name: 'Checkout' }).click();
    await expect(page).toHaveURL(/checkout/);
  });
  
  await test.step('Complete payment', async () => {
    await page.getByLabel('Card Number').fill('4242424242424242');
    await page.getByRole('button', { name: 'Pay' }).click();
    await expect(page.getByText('Order confirmed')).toBeVisible();
  });
});
```

### Example 3: Form Validation
```typescript
test('validates required fields', async ({ page }) => {
  await page.goto('/contact');
  
  // Try to submit empty form
  await page.getByRole('button', { name: 'Submit' }).click();
  
  // Verify validation messages
  await expect(page.getByText('Email is required')).toBeVisible();
  await expect(page.getByText('Message is required')).toBeVisible();
  
  // Fill form correctly
  await page.getByLabel('Email').fill('user@example.com');
  await page.getByLabel('Message').fill('Test message');
  await page.getByRole('button', { name: 'Submit' }).click();
  
  // Verify success
  await expect(page.getByText('Sent successfully')).toBeVisible();
});
```

## Limitations

- E2E tests are slower than unit or integration tests
- Can be affected by external dependencies (APIs, databases)
- May require specific test environment setup
- Not suitable for testing individual component behavior
- Can be flaky if not properly implemented with waits

## References

- See [page-objects.md](./references/page-objects.md) for Page Object Model patterns
- See [test-data.md](./references/test-data.md) for test data management strategies
- Refer to `.github/copilot-instructions.md` for coding standards
- Use `@playwright-e2e-tester` agent for E2E test creation assistance
