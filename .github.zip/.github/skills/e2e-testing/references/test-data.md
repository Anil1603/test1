# Test Data Management

## Overview

Effective test data management is crucial for reliable and maintainable E2E tests. This guide covers strategies for creating, managing, and cleaning up test data.

## Data Management Strategies

### 1. Static Test Data

For stable, predictable test data:

```typescript
// test-data/users.ts
export const testUsers = {
  admin: {
    email: 'admin@example.com',
    password: 'Admin123!',
    role: 'admin'
  },
  standardUser: {
    email: 'user@example.com',
    password: 'User123!',
    role: 'user'
  }
};

// Usage in test
import { testUsers } from '../test-data/users';

test('admin access', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.login(testUsers.admin.email, testUsers.admin.password);
});
```

### 2. Dynamic Test Data

Generate unique data for each test run:

```typescript
// utils/data-generators.ts
export class DataGenerator {
  static generateEmail(): string {
    return `test-${Date.now()}@example.com`;
  }

  static generateUser() {
    return {
      email: this.generateEmail(),
      password: 'Test123!',
      firstName: 'Test',
      lastName: 'User'
    };
  }

  static generateUniqueId(): string {
    return `test-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Usage
test('user registration', async ({ page }) => {
  const newUser = DataGenerator.generateUser();
  // Use newUser in test - guaranteed unique
});
```

### 3. Faker.js Integration

For realistic test data:

```typescript
import { faker } from '@faker-js/faker';

export class TestDataFactory {
  static createUser() {
    return {
      firstName: faker.person.firstName(),
      lastName: faker.person.lastName(),
      email: faker.internet.email(),
      phone: faker.phone.number(),
      address: {
        street: faker.location.streetAddress(),
        city: faker.location.city(),
        state: faker.location.state(),
        zip: faker.location.zipCode()
      }
    };
  }

  static createProduct() {
    return {
      name: faker.commerce.productName(),
      price: faker.commerce.price(),
      description: faker.commerce.productDescription()
    };
  }
}
```

### 4. API-Based Data Setup

Create test data via API:

```typescript
// fixtures/data-fixtures.ts
import { test as base } from '@playwright/test';
import { DataGenerator } from '@utils/data-generators';

type DataFixtures = {
  testUser: User;
  cleanupUser: () => Promise<void>;
};

export const test = base.extend<DataFixtures>({
  testUser: async ({ request }, use) => {
    // Create user via API
    const userData = DataGenerator.generateUser();
    const response = await request.post('/api/users', { data: userData });
    const user = await response.json();

    // Provide user to test
    await use(user);

    // Cleanup after test
    await request.delete(`/api/users/${user.id}`);
  }
});

// Usage
import { test } from '@fixtures/data-fixtures';

test('user profile test', async ({ page, testUser }) => {
  // testUser is already created and will be cleaned up
  await page.goto(`/profile/${testUser.id}`);
});
```

### 5. Database Seeding

For complex test data scenarios:

```typescript
// utils/db-seeder.ts
export class DatabaseSeeder {
  static async seedTestData(database: string) {
    // Connect to test database
    // Insert seed data
    // Return created records
  }

  static async cleanupTestData(database: string) {
    // Remove all test data
  }
}

// In test setup
test.beforeAll(async () => {
  await DatabaseSeeder.seedTestData('test-db');
});

test.afterAll(async () => {
  await DatabaseSeeder.cleanupTestData('test-db');
});
```

## Data Isolation Patterns

### Per-Test Data Isolation

```typescript
test.describe('User Management', () => {
  let userId: string;

  test.beforeEach(async ({ request }) => {
    // Create fresh user for each test
    const user = DataGenerator.generateUser();
    const response = await request.post('/api/users', { data: user });
    const created = await response.json();
    userId = created.id;
  });

  test.afterEach(async ({ request }) => {
    // Clean up user after each test
    if (userId) {
      await request.delete(`/api/users/${userId}`);
    }
  });

  test('should update user profile', async ({ page }) => {
    // Test uses userId
  });

  test('should delete user', async ({ page }) => {
    // Test uses different userId - isolated from previous test
  });
});
```

### Shared Data for Test Suite

```typescript
test.describe('Product Catalog', () => {
  let products: Product[];

  test.beforeAll(async ({ request }) => {
    // Create shared test data for all tests
    products = await Promise.all([
      createTestProduct(request, 'Product 1'),
      createTestProduct(request, 'Product 2'),
      createTestProduct(request, 'Product 3')
    ]);
  });

  test.afterAll(async ({ request }) => {
    // Clean up after all tests complete
    await Promise.all(
      products.map(p => request.delete(`/api/products/${p.id}`))
    );
  });

  test('should list all products', async ({ page }) => {
    // Uses shared products
  });

  test('should search products', async ({ page }) => {
    // Uses same shared products
  });
});
```

## Environment Variables

```typescript
// .env
TEST_USER_EMAIL=test@example.com
TEST_USER_PASSWORD=password123
API_BASE_URL=https://api.example.com

// Using in tests
import * as dotenv from 'dotenv';
dotenv.config();

test('environment-based test', async ({ page }) => {
  const email = process.env.TEST_USER_EMAIL;
  const password = process.env.TEST_USER_PASSWORD;
  // Use credentials
});
```

## Test Data Files

### JSON Files

```json
// test-data/sample-users.json
{
  "users": [
    {
      "email": "admin@example.com",
      "role": "admin",
      "permissions": ["read", "write", "delete"]
    },
    {
      "email": "user@example.com",
      "role": "user",
      "permissions": ["read"]
    }
  ]
}
```

```typescript
// Load in tests
import sampleUsers from '../test-data/sample-users.json';

test('test with JSON data', async ({ page }) => {
  const admin = sampleUsers.users[0];
  await loginPage.login(admin.email, 'password');
});
```

### CSV Files

```typescript
import { parse } from 'csv-parse/sync';
import * as fs from 'fs';

const records = parse(fs.readFileSync('test-data/users.csv'), {
  columns: true,
  skip_empty_lines: true
});

for (const record of records) {
  test(`test for ${record.email}`, async ({ page }) => {
    // Test with each CSV row
  });
}
```

## Best Practices

1. **Use Unique Identifiers**: Timestamp or UUID to avoid conflicts
2. **Clean Up After Tests**: Delete created data to prevent database bloat
3. **Isolate Tests**: Each test should have its own data
4. **Use API for Setup**: Faster than UI-based data creation
5. **Version Control Test Data**: Commit static test data files
6. **Document Data Requirements**: Clear comments on test data needs
7. **Handle Failures**: Cleanup should run even if test fails
8. **Avoid Production Data**: Never use real user data in tests
9. **Parameterize Tests**: Use test data to run same test with different inputs
10. **Cache When Possible**: Reuse expensive data setup across tests

## Data Cleanup Strategies

```typescript
// Track created resources for cleanup
const createdResources: string[] = [];

test.beforeEach(async ({ request }) => {
  const response = await request.post('/api/resource', { data: {} });
  const resource = await response.json();
  createdResources.push(resource.id);
});

test.afterAll(async ({ request }) => {
  // Clean up all created resources
  await Promise.all(
    createdResources.map(id =>
      request.delete(`/api/resource/${id}`).catch(() => {
        // Log but don't fail if cleanup fails
        console.warn(`Failed to cleanup resource ${id}`);
      })
    )
  );
});
```

Remember: Good test data management makes tests reliable, maintainable, and fast.
