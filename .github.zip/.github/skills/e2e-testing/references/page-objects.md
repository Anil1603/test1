# Page Object Model Patterns

## Overview

The Page Object Model (POM) is a design pattern that creates an object repository for storing all web elements. It helps reduce code duplication and improves test maintenance.

## Basic Page Object Structure

```typescript
import { Page, Locator } from '@playwright/test';

export class ExamplePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  // Locators as getters
  private get header(): Locator {
    return this.page.getByRole('banner');
  }

  private get submitButton(): Locator {
    return this.page.getByRole('button', { name: 'Submit' });
  }

  // Actions
  async goto(): Promise<void> {
    await this.page.goto('/example');
  }

  async clickSubmit(): Promise<void> {
    await this.submitButton.click();
  }

  // Assertions
  async expectToBeVisible(): Promise<void> {
    await expect(this.page).toHaveURL(/.*example/);
  }
}
```

## Base Page Class

Create a base page class with common functionality:

```typescript
import { Page, Locator } from '@playwright/test';

export abstract class BasePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  // Common navigation
  async goto(path: string): Promise<void> {
    await this.page.goto(path);
  }

  // Common waits
  async waitForLoadState(): Promise<void> {
    await this.page.waitForLoadState('networkidle');
  }

  // Common actions
  async clickElement(locator: Locator): Promise<void> {
    await locator.waitFor({ state: 'visible' });
    await locator.click();
  }

  async fillInput(locator: Locator, value: string): Promise<void> {
    await locator.waitFor({ state: 'visible' });
    await locator.fill(value);
  }

  // Common assertions
  async expectUrl(pattern: RegExp): Promise<void> {
    await expect(this.page).toHaveURL(pattern);
  }
}
```

## Component Objects

For reusable components across pages:

```typescript
import { Locator, Page } from '@playwright/test';

export class NavigationComponent {
  private readonly container: Locator;

  constructor(page: Page) {
    this.container = page.getByRole('navigation');
  }

  async clickLink(name: string): Promise<void> {
    await this.container.getByRole('link', { name }).click();
  }

  async expectLinkVisible(name: string): Promise<void> {
    await expect(this.container.getByRole('link', { name })).toBeVisible();
  }
}
```

## Best Practices

1. **One page object per page or component**
2. **Use getters for locators** - they're re-evaluated each time
3. **Separate actions from assertions**
4. **Return page objects for chaining**
5. **Keep page objects DRY**
6. **Use descriptive method names**

## Example: Login Page Object

```typescript
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './base-page';

export class LoginPage extends BasePage {
  // Locators
  private get emailInput(): Locator {
    return this.page.getByLabel('Email');
  }

  private get passwordInput(): Locator {
    return this.page.getByLabel('Password');
  }

  private get loginButton(): Locator {
    return this.page.getByRole('button', { name: 'Log in' });
  }

  private get errorMessage(): Locator {
    return this.page.locator('.error-message');
  }

  private get forgotPasswordLink(): Locator {
    return this.page.getByRole('link', { name: 'Forgot password?' });
  }

  // Actions
  async goto(): Promise<void> {
    await super.goto('/login');
  }

  async login(email: string, password: string): Promise<void> {
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  async clickForgotPassword(): Promise<void> {
    await this.forgotPasswordLink.click();
  }

  // Assertions
  async expectLoginSuccess(): Promise<void> {
    await this.expectUrl(/\/dashboard/);
  }

  async expectErrorMessage(message: string): Promise<void> {
    await expect(this.errorMessage).toHaveText(message);
  }

  async expectToBeVisible(): Promise<void> {
    await expect(this.emailInput).toBeVisible();
    await expect(this.passwordInput).toBeVisible();
    await expect(this.loginButton).toBeVisible();
  }
}
```

## Using Page Objects in Tests

```typescript
import { test } from '@playwright/test';
import { LoginPage } from '@pages/login-page';
import { DashboardPage } from '@pages/dashboard-page';

test.describe('Login Flow', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    await loginPage.goto();
  });

  test('should login successfully', async () => {
    await loginPage.login('user@example.com', 'password123');
    await loginPage.expectLoginSuccess();
    await dashboardPage.expectToBeVisible();
  });

  test('should show error for invalid credentials', async () => {
    await loginPage.login('user@example.com', 'wrongpassword');
    await loginPage.expectErrorMessage('Invalid credentials');
  });
});
```

## Method Chaining Pattern

```typescript
export class CheckoutPage extends BasePage {
  async fillShippingAddress(address: Address): Promise<this> {
    await this.page.getByLabel('Street').fill(address.street);
    await this.page.getByLabel('City').fill(address.city);
    await this.page.getByLabel('ZIP').fill(address.zip);
    return this;
  }

  async selectShippingMethod(method: string): Promise<this> {
    await this.page.getByLabel(method).check();
    return this;
  }

  async proceedToPayment(): Promise<PaymentPage> {
    await this.page.getByRole('button', { name: 'Continue' }).click();
    return new PaymentPage(this.page);
  }
}

// Usage
await checkoutPage
  .fillShippingAddress(testAddress)
  .then(page => page.selectShippingMethod('Express'))
  .then(page => page.proceedToPayment());
```

Remember: Page objects should provide a clean API that hides the implementation details of the UI interactions.
