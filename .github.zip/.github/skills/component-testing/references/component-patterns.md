# Component Testing Patterns

## Testing Patterns for Component Tests

### 1. Prop Validation Pattern

```typescript
import { test, expect } from '@playwright/experimental-ct-react';
import { Button } from './Button';

test.describe('Button Props', () => {
  const variants = ['primary', 'secondary', 'danger'];
  
  for (const variant of variants) {
    test(`renders ${variant} variant`, async ({ mount }) => {
      const component = await mount(
        <Button variant={variant}>Button</Button>
      );
      await expect(component).toHaveClass(new RegExp(variant));
    });
  }
});
```

### 2. Event Handler Pattern

```typescript
test('handles multiple events', async ({ mount }) => {
  const events: string[] = [];
  
  const component = await mount(
    <Input
      onChange={() => events.push('change')}
      onBlur={() => events.push('blur')}
      onFocus={() => events.push('focus')}
    />
  );
  
  await component.focus();
  expect(events).toContain('focus');
  
  await component.fill('test');
  expect(events).toContain('change');
  
  await component.blur();
  expect(events).toContain('blur');
});
```

### 3. Controlled Component Pattern

```typescript
test('controlled input', async ({ mount }) => {
  let value = '';
  
  const component = await mount(
    <Input
      value={value}
      onChange={(e) => { value = e.target.value; }}
    />
  );
  
  await component.fill('new value');
  expect(value).toBe('new value');
  
  // Update prop
  await component.update(
    <Input value="updated" onChange={() => {}} />
  );
  
  await expect(component).toHaveValue('updated');
});
```

### 4. Async State Pattern

```typescript
test('handles async operations', async ({ mount }) => {
  const component = await mount(<AsyncButton />);
  
  const button = component.getByRole('button');
  await button.click();
  
  // Should show loading state
  await expect(button).toHaveAttribute('aria-busy', 'true');
  await expect(button).toBeDisabled();
  
  // Wait for completion
  await expect(button).not.toHaveAttribute('aria-busy', 'true');
  await expect(button).toBeEnabled();
});
```

### 5. Form Validation Pattern

```typescript
test('validates form fields', async ({ mount }) => {
  const component = await mount(<LoginForm />);
  
  const submitButton = component.getByRole('button', { name: 'Submit' });
  
  // Submit empty form
  await submitButton.click();
  await expect(component.getByText('Email is required')).toBeVisible();
  
  // Invalid email
  await component.getByLabel('Email').fill('invalid');
  await submitButton.click();
  await expect(component.getByText('Invalid email')).toBeVisible();
  
  // Valid submission
  await component.getByLabel('Email').fill('test@example.com');
  await component.getByLabel('Password').fill('password123');
  await submitButton.click();
  await expect(component.getByText(/error/i)).not.toBeVisible();
});
```

### 6. Accessibility Testing Pattern

```typescript
test.describe('Accessibility', () => {
  test('keyboard navigation', async ({ mount, page }) => {
    await mount(<Menu />);
    
    // Tab to first item
    await page.keyboard.press('Tab');
    await expect(page.getByRole('menuitem').first()).toBeFocused();
    
    // Arrow down to next item
    await page.keyboard.press('ArrowDown');
    await expect(page.getByRole('menuitem').nth(1)).toBeFocused();
    
    // Enter to select
    await page.keyboard.press('Enter');
  });

  test('ARIA attributes', async ({ mount }) => {
    const component = await mount(<Dialog title="Test Dialog" />);
    
    await expect(component).toHaveAttribute('role', 'dialog');
    await expect(component).toHaveAttribute('aria-labelledby');
    await expect(component).toHaveAttribute('aria-modal', 'true');
  });

  test('focus trap', async ({ mount, page }) => {
    const component = await mount(<Modal />);
    
    const firstFocusable = component.getByRole('button').first();
    const lastFocusable = component.getByRole('button').last();
    
    // Focus should start at first element
    await expect(firstFocusable).toBeFocused();
    
    // Shift+Tab from first should go to last
    await page.keyboard.press('Shift+Tab');
    await expect(lastFocusable).toBeFocused();
    
    // Tab from last should go to first
    await page.keyboard.press('Tab');
    await expect(firstFocusable).toBeFocused();
  });
});
```

### 7. Context/Provider Pattern

```typescript
test('uses context providers', async ({ mount }) => {
  const component = await mount(
    <AuthProvider user={{ name: 'Test User', role: 'admin' }}>
      <UserProfile />
    </AuthProvider>
  );
  
  await expect(component.getByText('Test User')).toBeVisible();
  await expect(component.getByText('Admin')).toBeVisible();
});

test('multiple providers', async ({ mount }) => {
  const component = await mount(
    <ThemeProvider theme="dark">
      <I18nProvider locale="en">
        <AuthProvider user={testUser}>
          <App />
        </AuthProvider>
      </I18nProvider>
    </ThemeProvider>
  );
  
  // Component now has all context
});
```

### 8. Custom Hooks Testing Pattern

```typescript
// If you need to test custom hooks, wrap in a test component
function TestComponent({ hook }: { hook: () => any }) {
  const result = hook();
  return <div data-testid="result">{JSON.stringify(result)}</div>;
}

test('custom hook', async ({ mount }) => {
  const component = await mount(
    <TestComponent hook={useCustomHook} />
  );
  
  const result = await component.getByTestId('result').innerText();
  expect(JSON.parse(result)).toEqual({ /* expected */ });
});
```

### 9. Error Boundary Pattern

```typescript
function ThrowError() {
  throw new Error('Test error');
}

test('error boundary catches errors', async ({ mount }) => {
  const component = await mount(
    <ErrorBoundary fallback={<div>Error occurred</div>}>
      <ThrowError />
    </ErrorBoundary>
  );
  
  await expect(component.getByText('Error occurred')).toBeVisible();
});
```

### 10. Animation/Transition Pattern

```typescript
test('handles animations', async ({ mount, page }) => {
  const component = await mount(<FadeIn />);
  
  // Disable animations for stable testing
  await page.addStyleTag({
    content: `*, *::before, *::after {
      animation-duration: 0s !important;
      transition-duration: 0s !important;
    }`
  });
  
  await expect(component).toBeVisible();
  await expect(component).toHaveCSS('opacity', '1');
});
```

## Best Practices

1. **Test Behavior, Not Implementation**
   - Focus on what the user sees and does
   - Avoid testing internal state directly
   - Use role-based queries

2. **Isolation**
   - Mock external dependencies
   - Test one component at a time
   - Provide minimal props needed

3. **Comprehensive Coverage**
   - Test all prop combinations
   - Test all component states
   - Test error cases
   - Test a11y requirements

4. **Maintainability**
   - Use descriptive test names
   - Keep tests simple and focused
   - Reuse test utilities
   - Document complex scenarios

## Component Test Organization

```typescript
test.describe('ComponentName', () => {
  test.describe('Rendering', () => {
    test('renders with default props', async ({ mount }) => {});
    test('renders variants', async ({ mount }) => {});
  });

  test.describe('Interactions', () => {
    test('handles clicks', async ({ mount }) => {});
    test('handles keyboard', async ({ mount }) => {});
  });

  test.describe('State', () => {
    test('manages internal state', async ({ mount }) => {});
    test('responds to prop changes', async ({ mount }) => {});
  });

  test.describe('Accessibility', () => {
    test('keyboard navigation', async ({ mount, page }) => {});
    test('ARIA attributes', async ({ mount }) => {});
  });

  test.describe('Edge Cases', () => {
    test('handles errors', async ({ mount }) => {});
    test('handles empty state', async ({ mount }) => {});
  });
});
```

Remember: Component tests should be fast, isolated, and focus on user-observable behavior.
