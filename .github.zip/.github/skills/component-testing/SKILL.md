---
name: component-testing
description: Toolkit for Playwright component testing. Provides patterns for mounting components in isolation, testing props, events, and interactions with React/Vue/Svelte components. Use when testing UI components independently.
---

# Component Testing Skill

## Overview

The Component Testing Skill enables testing of UI components in isolation using Playwright's component testing capabilities. It focuses on mounting components independently, testing props and state, validating events and interactions, and ensuring accessibility compliance. This skill is ideal for testing individual React, Vue, or Svelte components without the overhead of a full application context.

## When to Use This Skill

Use this skill when:
- Testing individual UI components in isolation
- Validating component props and behavior
- Testing component interactions and events
- Verifying component state management
- Testing component accessibility
- Validating component variants and states
- Testing component rendering without full app context

## Prerequisites

- Playwright component testing setup (`@playwright/experimental-ct-react|vue|svelte`)
- Component testing configuration in `playwright-ct.config.ts`
- Understanding of component framework (React, Vue, or Svelte)

## Core Capabilities

### 1. Component Mounting
- Mount components with props
- Provide context/providers
- Test different prop combinations
- Update props dynamically

### 2. Interaction Testing
- Click handlers
- Form inputs
- Keyboard interactions
- Mouse events
- Focus management

### 3. State Validation
- Component state changes
- Conditional rendering
- Loading states
- Error states

### 4. Accessibility Testing
- ARIA attributes
- Keyboard navigation
- Screen reader support
- Focus management

## Usage Examples

### Basic Component Mount
```typescript
import { test, expect } from '@playwright/experimental-ct-react';
import { Button } from './Button';

test('should render button', async ({ mount }) => {
  const component = await mount(<Button>Click me</Button>);
  await expect(component).toContainText('Click me');
});
```

### Testing Props
```typescript
test.describe('Button variants', () => {
  test('primary button', async ({ mount }) => {
    const component = await mount(
      <Button variant="primary">Primary</Button>
    );
    await expect(component).toHaveClass(/primary/);
  });

  test('disabled button', async ({ mount }) => {
    const component = await mount(<Button disabled>Disabled</Button>);
    await expect(component).to BeDisabled();
  });
});
```

### Testing Events
```typescript
test('should call onClick handler', async ({ mount }) => {
  let clicked = false;
  
  const component = await mount(
    <Button onClick={() => { clicked = true; }}>
      Click me
    </Button>
  );
  
  await component.click();
  expect(clicked).toBeTruthy();
});

test('should handle form submission', async ({ mount }) => {
  const submitted: any[] = [];
  
  const component = await mount(
    <Form onSubmit={(data) => submitted.push(data)}>
      <input name="email" type="email" />
      <button type="submit">Submit</button>
    </Form>
  );
  
  await component.getByRole('textbox').fill('test@example.com');
  await component.getByRole('button').click();
  
  expect(submitted).toHaveLength(1);
  expect(submitted[0]).toEqual({ email: 'test@example.com' });
});
```

### Testing State
```typescript
test('should toggle state', async ({ mount }) => {
  const component = await mount(<Toggle initialValue={false} />);
  
  // Initial state
  await expect(component).toHaveAttribute('aria-checked', 'false');
  
  // After toggle
  await component.click();
  await expect(component).toHaveAttribute('aria-checked', 'true');
});
```

### Testing with Context
```typescript
test('should work with context', async ({ mount }) => {
  const component = await mount(
    <ThemeProvider theme="dark">
      <Button>Themed Button</Button>
    </ThemeProvider>
  );
  
  await expect(component.getByRole('button')).toHaveClass(/dark/);
});
```

## Guidelines

### Component Isolation
- Test components independently
- Mock external dependencies
- Use minimal props needed
- Avoid testing implementation details

### Interaction Patterns
- Use role-based queries
- Test user-observable behavior
- Verify event callbacks
- Test keyboard interactions

### State Management
- Test initial state
- Test state transitions
- Test error boundaries
- Test loading states

### Accessibility
- Include ARIA checks
- Test keyboard navigation
- Verify focus management
- Test screen reader text

## Common Patterns

### Testing All Component States
```typescript
test.describe('Input states', () => {
  test('default state', async ({ mount }) => {
    const component = await mount(<Input />);
    await expect(component).toBeEnabled();
  });

  test('loading state', async ({ mount }) => {
    const component = await mount(<Input loading />);
    await expect(component).toHaveAttribute('aria-busy', 'true');
  });

  test('error state', async ({ mount }) => {
    const component = await mount(
      <Input error="Invalid input" />
    );
    await expect(component).toHaveAttribute('aria-invalid', 'true');
  });

  test('disabled state', async ({ mount }) => {
    const component = await mount(<Input disabled />);
    await expect(component).toBeDisabled();
  });
});
```

### Testing Component Methods
```typescript
test('should expose methods', async ({ mount }) => {
  const component = await mount(<Dialog />);
  
  // Call component method
  await component.evaluate((node: any) => {
    node.open();
  });
  
  await expect(component).toBeVisible();
});
```

## Best Practices

### 1. Test User-Observable Behavior
```typescript
// ✅ Test what users see and do
test('button click triggers action', async ({ mount }) => {
  let clicked = false;
  const component = await mount(
    <Button onClick={() => { clicked = true; }}>Click</Button>
  );
  
  await component.click();
  expect(clicked).toBeTruthy();
});

// ❌ Test implementation details
test('internal state changes', async ({ mount }) => {
  // Don't test internal state directly
});
```

### 2. Use Role-Based Queries
```typescript
// ✅ Accessible queries
await component.getByRole('button', { name: 'Submit' });
await component.getByRole('textbox', { name: 'Email' });
await component.getByRole('checkbox', { name: 'Remember me' });

// ❌ Implementation-coupled selectors
await component.locator('.btn-submit');
```

### 3. Test All Component States
```typescript
test.describe('Button states', () => {
  test('default state', async ({ mount }) => {
    const btn = await mount(<Button>Click</Button>);
    await expect(btn).toBeEnabled();
  });
  
  test('loading state', async ({ mount }) => {
    const btn = await mount(<Button loading>Loading</Button>);
    await expect(btn).toHaveAttribute('aria-busy', 'true');
  });
  
  test('disabled state', async ({ mount }) => {
    const btn = await mount(<Button disabled>Disabled</Button>);
    await expect(btn).toBeDisabled();
  });
});
```

### 4. Test Accessibility
```typescript
test('is keyboard accessible', async ({ mount, page }) => {
  await mount(<Button>Accessible</Button>);
  
  // Tab to button
  await page.keyboard.press('Tab');
  const button = page.getByRole('button', { name: 'Accessible' });
  await expect(button).toBeFocused();
  
  // Activate with Enter
  await page.keyboard.press('Enter');
});
```

### 5. Provide Necessary Context
```typescript
test('works with theme context', async ({ mount }) => {
  const component = await mount(
    <ThemeProvider theme="dark">
      <ThemedButton>Themed</ThemedButton>
    </ThemeProvider>
  );
  
  await expect(component.getByRole('button')).toHaveClass(/dark/);
});
```

## Examples

### Example 1: Form Component Testing
```typescript
import { test, expect } from '@playwright/experimental-ct-react';
import { LoginForm } from './LoginForm';

test.describe('LoginForm', () => {
  test('renders form fields', async ({ mount }) => {
    const component = await mount(<LoginForm />);
    
    await expect(component.getByLabel('Email')).toBeVisible();
    await expect(component.getByLabel('Password')).toBeVisible();
    await expect(component.getByRole('button', { name: 'Login' })).toBeVisible();
  });
  
  test('submits form data', async ({ mount }) => {
    const submissions: any[] = [];
    
    const component = await mount(
      <LoginForm onSubmit={(data) => submissions.push(data)} />
    );
    
    await component.getByLabel('Email').fill('user@example.com');
    await component.getByLabel('Password').fill('password123');
    await component.getByRole('button', { name: 'Login' }).click();
    
    expect(submissions).toHaveLength(1);
    expect(submissions[0]).toEqual({
      email: 'user@example.com',
      password: 'password123'
    });
  });
  
  test('shows validation errors', async ({ mount }) => {
    const component = await mount(<LoginForm />);
    
    // Submit empty form
    await component.getByRole('button', { name: 'Login' }).click();
    
    await expect(component.getByText('Email is required')).toBeVisible();
    await expect(component.getByText('Password is required')).toBeVisible();
  });
});
```

### Example 2: Interactive Component
```typescript
import { Dropdown } from './Dropdown';

test.describe('Dropdown', () => {
  test('opens and closes', async ({ mount }) => {
    const component = await mount(
      <Dropdown>
        <Dropdown.Trigger>Menu</Dropdown.Trigger>
        <Dropdown.Content>
          <Dropdown.Item>Item 1</Dropdown.Item>
          <Dropdown.Item>Item 2</Dropdown.Item>
        </Dropdown.Content>
      </Dropdown>
    );
    
    const trigger = component.getByRole('button', { name: 'Menu' });
    
    // Initially closed
    await expect(component.getByRole('menu')).not.toBeVisible();
    
    // Opens on click
    await trigger.click();
    await expect(component.getByRole('menu')).toBeVisible();
    
    // Closes on second click
    await trigger.click();
    await expect(component.getByRole('menu')).not.toBeVisible();
  });
  
  test('selects item', async ({ mount }) => {
    let selected = '';
    
    const component = await mount(
      <Dropdown onSelect={(value) => { selected = value; }}>
        <Dropdown.Trigger>Menu</Dropdown.Trigger>
        <Dropdown.Content>
          <Dropdown.Item value="1">Item 1</Dropdown.Item>
          <Dropdown.Item value="2">Item 2</Dropdown.Item>
        </Dropdown.Content>
      </Dropdown>
    );
    
    await component.getByRole('button', { name: 'Menu' }).click();
    await component.getByRole('menuitem', { name: 'Item 2' }).click();
    
    expect(selected).toBe('2');
  });
});
```

### Example 3: Testing Component Variants
```typescript
import { Badge } from './Badge';

test.describe('Badge variants', () => {
  const variants = ['success', 'warning', 'error', 'info'] as const;
  
  for (const variant of variants) {
    test(`renders ${variant} variant`, async ({ mount }) => {
      const component = await mount(
        <Badge variant={variant}>Badge</Badge>
      );
      
      await expect(component).toHaveClass(new RegExp(variant));
      await expect(component).toContainText('Badge');
    });
  }
});
```

## Limitations

- No full application context
- Cannot test routing
- Cannot test API integration
- Limited to component-level behavior
- Requires component testing setup

## References

- See [component-patterns.md](./references/component-patterns.md) for advanced patterns
- Refer to Playwright [Component testing docs](https://playwright.dev/docs/test-components)
- Use `@playwright-component-tester` agent for component test creation
