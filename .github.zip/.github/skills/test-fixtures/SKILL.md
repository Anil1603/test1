---
name: test-fixtures
description: Toolkit for managing Playwright test fixtures and shared test resources. Provides patterns for custom fixtures, shared state management, setup/teardown logic, and reusable test utilities. Use when creating consistent test environments.
---

# Test Fixtures Skill

## Overview

The Test Fixtures Skill provides patterns for creating and managing Playwright test fixtures and shared test resources. It focuses on extending the base test with custom fixtures, managing test lifecycle, sharing state across tests, and composing complex fixture dependencies. This skill is fundamental for creating reusable test setup, maintaining test isolation, and building efficient test suites with proper resource management.

## When to Use This Skill

Use this skill when:
- Creating custom fixtures for tests
- Managing shared test state
- Setting up authenticated contexts
- Creating reusable test utilities
- Managing test data lifecycle
- Sharing setup/teardown logic
- Composing fixture dependencies

## Prerequisites

- Understanding of Playwright fixtures system
- Knowledge of TypeScript types
- Familiarity with test lifecycle hooks

## Core Capabilities

### 1. Custom Fixtures
- Extend base test fixtures
- Create typed fixtures
- Compose fixtures
- Parameterized fixtures

### 2. State Management
- Authenticated state
- Shared browser contexts
- Database connections
- API clients

### 3. Setup/Teardown
- Before/after hooks
- Automatic cleanup
- Resource management
- Isolation guarantees

### 4. Test Utilities
- Helper functions
- Data generators
- Mock factories
- Assertion helpers

## Usage Examples

### Basic Custom Fixture
```typescript
import { test as base } from '@playwright/test';

type MyFixtures = {
  authenticatedPage: Page;
};

export const test = base.extend<MyFixtures>({
  authenticatedPage: async ({ page }, use) => {
    // Setup
    await page.goto('/login');
    await page.getByLabel('Email').fill('test@example.com');
    await page.getByLabel('Password').fill('password123');
    await page.getByRole('button', { name: 'Login' }).click();
    await page.waitForURL('/dashboard');
    
    // Provide to test
    await use(page);
    
    // Cleanup (optional)
    await page.context().clearCookies();
  },
});

export { expect } from '@playwright/test';
```

### Using Custom Fixtures
```typescript
import { test, expect } from './fixtures';

test('dashboard test', async ({ authenticatedPage }) => {
  // Already logged in!
  await expect(authenticatedPage).toHaveURL('/dashboard');
});
```

### Multiple Fixtures
```typescript
type CustomFixtures = {
  authenticatedPage: Page;
  apiClient: APIClient;
  testUser: User;
};

export const test = base.extend<CustomFixtures>({
  testUser: async ({}, use) => {
    const user = await createTestUser();
    await use(user);
    await deleteTestUser(user.id);
  },

  apiClient: async ({ testUser }, use) => {
    const client = new APIClient();
    await client.authenticate(testUser.email, testUser.password);
    await use(client);
  },

  authenticatedPage: async ({ page, testUser }, use) => {
    await loginUser(page, testUser);
    await use(page);
    await page.context().clearCookies();
  },
});
```

### Worker-Scoped Fixtures
```typescript
type WorkerFixtures = {
  sharedDatabase: Database;
};

export const test = base.extend<{}, WorkerFixtures>({
  sharedDatabase: [async ({}, use) => {
    // Setup once per worker
    const db = await setupDatabase();
    await use(db);
    await db.close();
  }, { scope: 'worker' }],
});
```

### Page Object Fixtures
```typescript
import { LoginPage } from '@pages/login-page';
import { DashboardPage } from '@pages/dashboard-page';

type PageFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
};

export const test = base.extend<PageFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
});
```

## Guidelines

### Fixture Design
- Keep fixtures focused and single-purpose
- Use descriptive fixture names
- Provide TypeScript types
- Document dependencies

### State Isolation
- Clean up after fixture use
- Avoid global state
- Reset between tests
- Use worker fixtures for shared resources

### Performance
- Use worker-scoped fixtures for expensive setup
- Lazy initialization
- Parallel execution friendly
- Minimize redundant setup

### Composition
- Build complex fixtures from simple ones
- Declare dependencies explicitly
- Avoid circular dependencies
- Reuse existing fixtures

## Common Patterns

### Authentication Fixture
```typescript
type AuthFixtures = {
  authenticatedContext: BrowserContext;
  authenticatedPage: Page;
};

export const test = base.extend<AuthFixtures>({
  authenticatedContext: async ({ browser }, use) => {
    const context = await browser.newContext({
      storageState: 'auth-state.json' // Reuse auth state
    });
    await use(context);
    await context.close();
  },

  authenticatedPage: async ({ authenticatedContext }, use) => {
    const page = await authenticatedContext.newPage();
    await use(page);
    await page.close();
  },
});
```

### API Client Fixture
```typescript
import { APIRequestContext } from '@playwright/test';

type APIFixtures = {
  apiContext: APIRequestContext;
  apiHelper: APIHelper;
};

export const test = base.extend<APIFixtures>({
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.API_URL,
      extraHTTPHeaders: {
        'Accept': 'application/json',
      }
    });
    await use(context);
    await context.dispose();
  },

  apiHelper: async ({ apiContext }, use) => {
    const helper = new APIHelper(apiContext);
    await helper.authenticate();
    await use(helper);
  },
});
```

### Database Fixture
```typescript
type DBFixtures = {
  db: Database;
  dbHelper: DatabaseHelper;
};

export const test = base.extend<DBFixtures>({
  db: [async ({}, use) => {
    const db = await connectToDatabase();
    await db.migrate();
    await use(db);
    await db.cleanup();
    await db.disconnect();
  }, { scope: 'worker' }],

  dbHelper: async ({ db }, use) => {
    const helper = new DatabaseHelper(db);
    await use(helper);
    await helper.cleanup(); // Clean test data
  },
});
```

### Test Data Fixture
```typescript
type DataFixtures = {
  testData: TestData;
  dataGenerator: DataGenerator;
};

export const test = base.extend<DataFixtures>({
  dataGenerator: async ({}, use) => {
    await use(new DataGenerator());
  },

  testData: async ({ dataGenerator }, use) => {
    const data = {
      user: dataGenerator.generateUser(),
      product: dataGenerator.generateProduct(),
      order: dataGenerator.generateOrder(),
    };
    await use(data);
  },
});
```

### Mock Server Fixture
```typescript
type MockFixtures = {
  mockServer: MockServer;
};

export const test = base.extend<MockFixtures>({
  mockServer: async ({ page }, use) => {
    const server = new MockServer();
    await server.start();
    
    // Intercept requests
    await page.route('**/api/**', route => {
      server.handleRequest(route);
    });
    
    await use(server);
    await server.stop();
  },
});
```

### Storage State Fixture
```typescript
// Save authenticated state
test('save auth state', async ({ page }) => {
  await page.goto('/login');
  await page.fill('[name="email"]', 'test@example.com');
  await page.fill('[name="password"]', 'password');
  await page.click('button[type="submit"]');
  
  await page.context().storageState({ path: 'auth-state.json' });
});

// Reuse authenticated state
type StorageFixtures = {
  authenticatedPage: Page;
};

export const test = base.extend<StorageFixtures>({
  authenticatedPage: async ({ browser }, use) => {
    const context = await browser.newContext({
      storageState: 'auth-state.json'
    });
    const page = await context.newPage();
    await use(page);
    await context.close();
  },
});
```

## Best Practices

### 1. Keep Fixtures Focused
```typescript
// ✅ Single responsibility
export const test = base.extend({
  authenticatedPage: async ({ page }, use) => {
    await loginUser(page);
    await use(page);
    await page.context().clearCookies();
  }
});

// ❌ Too much responsibility
export const test = base.extend({
  everythingFixture: async ({ page }, use) => {
    // Don't combine unrelated setup
  }
});
```

### 2. Use Worker Scope for Expensive Setup
```typescript
type WorkerFixtures = {
  database: Database;
};

export const test = base.extend<{}, WorkerFixtures>({
  database: [async ({}, use) => {
    // Setup once per worker
    const db = await setupDatabase();
    await db.migrate();
    await use(db);
    await db.close();
  }, { scope: 'worker' }]
});
```

### 3. Provide TypeScript Types
```typescript
// ✅ Explicit types
type CustomFixtures = {
  authenticatedPage: Page;
  testUser: User;
  apiClient: APIClient;
};

export const test = base.extend<CustomFixtures>({ /* ... */ });

// ❌ No types
export const test = base.extend({ /* ... */ });
```

### 4. Ensure Proper Cleanup
```typescript
export const test = base.extend({
  tempFile: async ({}, use) => {
    const file = await createTempFile();
    
    try {
      await use(file);
    } finally {
      // Always cleanup, even if test fails
      await deleteFile(file);
    }
  }
});
```

### 5. Compose Fixtures Logically
```typescript
// Fixtures can depend on other fixtures
export const test = base.extend({
  testUser: async ({}, use) => {
    const user = await createUser();
    await use(user);
    await deleteUser(user);
  },
  
  // apiClient depends on testUser
  apiClient: async ({ testUser }, use) => {
    const client = new APIClient();
    await client.login(testUser);
    await use(client);
  },
  
  // authenticatedPage depends on testUser
  authenticatedPage: async ({ page, testUser }, use) => {
    await loginWithUser(page, testUser);
    await use(page);
  }
});
```

## Examples

### Example 1: Authentication Fixture
```typescript
import { test as base, expect, Page } from '@playwright/test';
import { User } from './types';

type AuthFixtures = {
  authenticatedPage: Page;
  testUser: User;
  authToken: string;
};

export const test = base.extend<AuthFixtures>({
  // Create test user
  testUser: async ({}, use) => {
    const user = {
      email: `test-${Date.now()}@example.com`,
      password: 'Test123!@#',
      name: 'Test User'
    };
    
    // Create via API
    const response = await fetch('/api/users', {
      method: 'POST',
      body: JSON.stringify(user)
    });
    const createdUser = await response.json();
    
    await use(createdUser);
    
    // Cleanup
    await fetch(`/api/users/${createdUser.id}`, { method: 'DELETE' });
  },
  
  // Get auth token
  authToken: async ({ testUser }, use) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: testUser.email,
        password: testUser.password
      })
    });
    const { token } = await response.json();
    await use(token);
  },
  
  // Authenticated page
  authenticatedPage: async ({ page, testUser }, use) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill(testUser.email);
    await page.getByLabel('Password').fill(testUser.password);
    await page.getByRole('button', { name: 'Login' }).click();
    await page.waitForURL('/dashboard');
    
    await use(page);
    
    await page.context().clearCookies();
  }
});

export { expect };
```

### Example 2: Database Fixture
```typescript
import { test as base } from '@playwright/test';
import { Database } from './database';

type DBFixtures = {
  db: Database;
};

type WorkerFixtures = {
  workerDb: Database;
};

export const test = base.extend<DBFixtures, WorkerFixtures>({
  // Worker-scoped: One connection per worker
  workerDb: [async ({}, use) => {
    const db = new Database();
    await db.connect();
    await db.migrate();
    
    await use(db);
    
    await db.close();
  }, { scope: 'worker' }],
  
  // Test-scoped: Clean state for each test
  db: async ({ workerDb }, use) => {
    // Start transaction
    await workerDb.beginTransaction();
    
    await use(workerDb);
    
    // Rollback after test
    await workerDb.rollback();
  }
});
```

### Example 3: Page Object Fixtures
```typescript
import { test as base } from '@playwright/test';
import { LoginPage } from '@pages/login-page';
import { DashboardPage } from '@pages/dashboard-page';
import { ProfilePage } from '@pages/profile-page';

type PageFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  profilePage: ProfilePage;
};

export const test = base.extend<PageFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
  
  profilePage: async ({ page }, use) => {
    await use(new ProfilePage(page));
  }
});

// Usage
import { test, expect } from './fixtures/page-fixtures';

test('navigate to profile', async ({ loginPage, dashboardPage, profilePage }) => {
  await loginPage.goto();
  await loginPage.login('user@example.com', 'password');
  
  await dashboardPage.expectToBeVisible();
  await dashboardPage.goToProfile();
  
  await profilePage.expectToBeVisible();
});
```

## Limitations

- Fixtures run for every test (unless worker-scoped)
- Cannot conditionally use fixtures
- Setup order determined by dependencies
- Worker fixtures shared across tests in worker

## References

- See [custom-fixtures.ts](./references/custom-fixtures.ts) for example implementations
- See [fixture-composition.md](./references/fixture-composition.md) for advanced patterns
- Refer to Playwright [Fixtures docs](https://playwright.dev/docs/test-fixtures)
- Use custom agents for creating fixtures
