import { test as base, Page, BrowserContext, APIRequestContext } from '@playwright/test';

/**
 * Example custom fixtures for Playwright tests
 */

// ============================================================================
// Type Definitions
// ============================================================================

type User = {
  id: string;
  email: string;
  password: string;
  name: string;
  role: string;
};

type TestDatabase = {
  query: (sql: string) => Promise<any>;
  insert: (table: string, data: any) => Promise<any>;
  cleanup: () => Promise<void>;
};

type APIHelper = {
  get: (url: string) => Promise<any>;
  post: (url: string, data: any) => Promise<any>;
  authenticate: (email: string, password: string) => Promise<string>;
};

// ============================================================================
// Authentication Fixtures
// ============================================================================

type AuthFixtures = {
  authenticatedContext: BrowserContext;
  authenticatedPage: Page;
  authToken: string;
  testUser: User;
};

export const authTest = base.extend<AuthFixtures>({
  // Create test user for the test
  testUser: async ({}, use) => {
    const user: User = {
      id: `test-${Date.now()}`,
      email: `test-${Date.now()}@example.com`,
      password: 'Test123!@#',
      name: 'Test User',
      role: 'user',
    };
    
    // Create user in system (via API or database)
    // await createUserInDatabase(user);
    
    await use(user);
    
    // Cleanup
    // await deleteUserFromDatabase(user.id);
  },

  // Get authentication token
  authToken: async ({ testUser }, use) => {
    // Authenticate and get token
    const token = await authenticateUser(testUser.email, testUser.password);
    await use(token);
  },

  // Browser context with authentication
  authenticatedContext: async ({ browser, authToken }, use) => {
    const context = await browser.newContext({
      extraHTTPHeaders: {
        'Authorization': `Bearer ${authToken}`,
      },
    });
    await use(context);
    await context.close();
  },

  // Page with authentication
  authenticatedPage: async ({ authenticatedContext }, use) => {
    const page = await authenticatedContext.newPage();
    await page.goto('/dashboard');
    await use(page);
  },
});

// Helper function (mock example)
async function authenticateUser(email: string, password: string): Promise<string> {
  // In real implementation, call API or use Playwright request context
  return 'mock-jwt-token';
}

// ============================================================================
// API Fixtures
// ============================================================================

type APIFixtures = {
  apiContext: APIRequestContext;
  apiHelper: APIHelper;
  authenticatedAPI: APIRequestContext;
};

export const apiTest = base.extend<APIFixtures>({
  // Base API context
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.API_URL || 'http://localhost:3000',
      extraHTTPHeaders: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
    });
    await use(context);
    await context.dispose();
  },

  // Authenticated API context
  authenticatedAPI: async ({ playwright }, use) => {
    // First, get auth token
    const loginContext = await playwright.request.newContext({
      baseURL: process.env.API_URL,
    });
    
    const response = await loginContext.post('/api/auth/login', {
      data: {
        email: 'test@example.com',
        password: 'password123',
      },
    });
    
    const { token } = await response.json();
    await loginContext.dispose();
    
    // Create authenticated context
    const authContext = await playwright.request.newContext({
      baseURL: process.env.API_URL,
      extraHTTPHeaders: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });
    
    await use(authContext);
    await authContext.dispose();
  },

  // API helper with common methods
  apiHelper: async ({ apiContext }, use) => {
    const helper: APIHelper = {
      async get(url: string) {
        const response = await apiContext.get(url);
        return response.json();
      },
      
      async post(url: string, data: any) {
        const response = await apiContext.post(url, { data });
        return response.json();
      },
      
      async authenticate(email: string, password: string) {
        const response = await apiContext.post('/api/auth/login', {
          data: { email, password },
        });
        const json = await response.json();
        return json.token;
      },
    };
    
    await use(helper);
  },
});

// ============================================================================
// Database Fixtures
// ============================================================================

type DBFixtures = {
  db: TestDatabase;
};

export const dbTest = base.extend<{}, DBFixtures>({
  // Worker-scoped database connection
  db: [async ({}, use) => {
    // Setup database connection
    const database: TestDatabase = {
      async query(sql: string) {
        // Execute SQL query
        console.log('Executing query:', sql);
        return [];
      },
      
      async insert(table: string, data: any) {
        console.log(`Inserting into ${table}:`, data);
        return { id: 'generated-id' };
      },
      
      async cleanup() {
        // Clean up test data
        console.log('Cleaning up test data');
      },
    };
    
    await use(database);
    
    // Cleanup
    await database.cleanup();
  }, { scope: 'worker' }],
});

// ============================================================================
// Page Object Fixtures
// ============================================================================

class LoginPage {
  constructor(private page: Page) {}
  
  async goto() {
    await this.page.goto('/login');
  }
  
  async login(email: string, password: string) {
    await this.page.getByLabel('Email').fill(email);
    await this.page.getByLabel('Password').fill(password);
    await this.page.getByRole('button', { name: 'Login' }).click();
  }
}

class DashboardPage {
  constructor(private page: Page) {}
  
  async goto() {
    await this.page.goto('/dashboard');
  }
  
  async getUserName() {
    return this.page.locator('.user-name').textContent();
  }
}

type PageFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
};

export const pageTest = base.extend<PageFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
});

// ============================================================================
// Combined Fixtures
// ============================================================================

type AllFixtures = AuthFixtures & APIFixtures & PageFixtures;

export const test = base.extend<AllFixtures>({
  // Auth fixtures
  testUser: async ({}, use) => {
    const user: User = {
      id: `test-${Date.now()}`,
      email: `test-${Date.now()}@example.com`,
      password: 'Test123!@#',
      name: 'Test User',
      role: 'user',
    };
    await use(user);
  },
  
  authToken: async ({ testUser }, use) => {
    const token = await authenticateUser(testUser.email, testUser.password);
    await use(token);
  },
  
  authenticatedContext: async ({ browser, authToken }, use) => {
    const context = await browser.newContext({
      extraHTTPHeaders: { 'Authorization': `Bearer ${authToken}` },
    });
    await use(context);
    await context.close();
  },
  
  authenticatedPage: async ({ authenticatedContext }, use) => {
    const page = await authenticatedContext.newPage();
    await use(page);
  },
  
  // API fixtures
  apiContext: async ({ playwright }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.API_URL || 'http://localhost:3000',
    });
    await use(context);
    await context.dispose();
  },
  
  apiHelper: async ({ apiContext }, use) => {
    const helper: APIHelper = {
      async get(url) {
        const res = await apiContext.get(url);
        return res.json();
      },
      async post(url, data) {
        const res = await apiContext.post(url, { data });
        return res.json();
      },
      async authenticate(email, password) {
        const res = await apiContext.post('/api/auth/login', {
          data: { email, password },
        });
        const json = await res.json();
        return json.token;
      },
    };
    await use(helper);
  },
  
  authenticatedAPI: async ({ playwright, authToken }, use) => {
    const context = await playwright.request.newContext({
      baseURL: process.env.API_URL,
      extraHTTPHeaders: { 'Authorization': `Bearer ${authToken}` },
    });
    await use(context);
    await context.dispose();
  },
  
  // Page object fixtures
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
});

export { expect } from '@playwright/test';
