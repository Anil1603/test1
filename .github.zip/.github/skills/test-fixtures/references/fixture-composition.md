# Fixture Composition Patterns

Advanced patterns for composing and organizing Playwright test fixtures.

## Layered Fixture Architecture

### Layer 1: Infrastructure Fixtures

These are low-level fixtures that provide fundamental resources.

```typescript
import { test as base } from '@playwright/test';

type InfraFixtures = {
  apiBaseURL: string;
  databaseURL: string;
  storagePrefix: string;
};

const infraTest = base.extend<InfraFixtures>({
  apiBaseURL: async ({}, use) => {
    const url = process.env.API_URL || 'http://localhost:3000';
    await use(url);
  },

  databaseURL: async ({}, use) => {
    const url = process.env.DATABASE_URL || 'postgresql://localhost:5432/test';
    await use(url);
  },

  storagePrefix: async ({}, use) => {
    await use(`test-${Date.now()}`);
  },
});
```

### Layer 2: Resource Fixtures

Build on infrastructure to create actual resources.

```typescript
type ResourceFixtures = {
  database: Database;
  apiClient: APIClient;
  storage: Storage;
};

const resourceTest = infraTest.extend<ResourceFixtures>({
  database: async ({ databaseURL }, use) => {
    const db = await Database.connect(databaseURL);
    await db.migrate();
    await use(db);
    await db.close();
  },

  apiClient: async ({ apiBaseURL }, use) => {
    const client = new APIClient(apiBaseURL);
    await use(client);
  },

  storage: async ({ storagePrefix }, use) => {
    const storage = new Storage(storagePrefix);
    await use(storage);
    await storage.clear();
  },
});
```

### Layer 3: Test Data Fixtures

Create test data using resources.

```typescript
type DataFixtures = {
  testUser: User;
  testProduct: Product;
  testOrder: Order;
};

const dataTest = resourceTest.extend<DataFixtures>({
  testUser: async ({ database, apiClient }, use) => {
    const user = await database.createUser({
      email: `test-${Date.now()}@example.com`,
      name: 'Test User',
    });
    await use(user);
    await database.deleteUser(user.id);
  },

  testProduct: async ({ database }, use) => {
    const product = await database.createProduct({
      name: 'Test Product',
      price: 99.99,
    });
    await use(product);
    await database.deleteProduct(product.id);
  },

  testOrder: async ({ testUser, testProduct, database }, use) => {
    const order = await database.createOrder({
      userId: testUser.id,
      productId: testProduct.id,
    });
    await use(order);
    await database.deleteOrder(order.id);
  },
});
```

### Layer 4: Page Fixtures

UI fixtures that depend on test data.

```typescript
type PageFixtures = {
  authenticatedPage: Page;
  checkoutPage: Page;
};

export const test = dataTest.extend<PageFixtures>({
  authenticatedPage: async ({ page, testUser }, use) => {
    await page.goto('/login');
    await page.fill('[name="email"]', testUser.email);
    await page.fill('[name="password"]', 'password');
    await page.click('button[type="submit"]');
    await page.waitForURL('/dashboard');
    await use(page);
  },

  checkoutPage: async ({ authenticatedPage, testProduct }, use) => {
    await authenticatedPage.goto(`/product/${testProduct.id}`);
    await authenticatedPage.click('button[name="add-to-cart"]');
    await authenticatedPage.goto('/checkout');
    await use(authenticatedPage);
  },
});
```

## Fixture Dependency Patterns

### Optional Dependencies

```typescript
type OptionalFixtures = {
  userRole: 'admin' | 'user';
  currentUser: User;
};

const test = base.extend<OptionalFixtures>({
  userRole: ['user', { option: true }],

  currentUser: async ({ userRole }, use) => {
    const user = userRole === 'admin' 
      ? await createAdminUser()
      : await createRegularUser();
    
    await use(user);
    await deleteUser(user.id);
  },
});

// Usage
test('regular user test', async ({ currentUser }) => {
  // currentUser is 'user' by default
});

test('admin test', async ({ currentUser, userRole: 'admin' }) => {
  // currentUser is 'admin'
});
```

### Conditional Fixtures

```typescript
type ConditionalFixtures = {
  mockMode: boolean;
  apiClient: RealAPIClient | MockAPIClient;
};

const test = base.extend<ConditionalFixtures>({
  mockMode: [false, { option: true }],

  apiClient: async ({ mockMode }, use) => {
    const client = mockMode 
      ? new MockAPIClient()
      : new RealAPIClient();
    
    await client.initialize();
    await use(client);
    await client.cleanup();
  },
});
```

## Fixture Reuse Patterns

### Fixture Factories

```typescript
function createAuthFixture(role: string) {
  return async ({ browser }: { browser: Browser }, use: (page: Page) => Promise<void>) => {
    const context = await browser.newContext();
    const page = await context.newPage();
    
    // Login with specific role
    await page.goto('/login');
    await loginAsRole(page, role);
    
    await use(page);
    
    await context.close();
  };
}

type RoleFixtures = {
  adminPage: Page;
  managerPage: Page;
  userPage: Page;
};

const test = base.extend<RoleFixtures>({
  adminPage: createAuthFixture('admin'),
  managerPage: createAuthFixture('manager'),
  userPage: createAuthFixture('user'),
});
```

### Parameterized Fixtures

```typescript
type ParameterizedFixtures = {
  createUser: (role: string) => Promise<User>;
  createPage: (url: string) => Promise<Page>;
};

const test = base.extend<ParameterizedFixtures>({
  createUser: async ({ database }, use) => {
    const users: User[] = [];
    
    const factory = async (role: string) => {
      const user = await database.createUser({ role });
      users.push(user);
      return user;
    };
    
    await use(factory);
    
    // Cleanup all created users
    for (const user of users) {
      await database.deleteUser(user.id);
    }
  },

  createPage: async ({ context }, use) => {
    const pages: Page[] = [];
    
    const factory = async (url: string) => {
      const page = await context.newPage();
      await page.goto(url);
      pages.push(page);
      return page;
    };
    
    await use(factory);
    
    // Close all created pages
    for (const page of pages) {
      await page.close();
    }
  },
});

// Usage
test('multi-user test', async ({ createUser, createPage }) => {
  const admin = await createUser('admin');
  const user = await createUser('user');
  
  const adminPage = await createPage('/admin');
  const userPage = await createPage('/dashboard');
  
  // Test with both users
});
```

## Worker vs Test Scope

### Worker-Scoped for Expensive Setup

```typescript
type WorkerFixtures = {
  databaseConnection: Database;
  testDataSeed: void;
};

const test = base.extend<{}, WorkerFixtures>({
  // Shared database connection across all tests in worker
  databaseConnection: [async ({}, use) => {
    const db = await Database.connect();
    await use(db);
    await db.close();
  }, { scope: 'worker' }],

  // Seed data once per worker
  testDataSeed: [async ({ databaseConnection }, use) => {
    await databaseConnection.seed();
    await use();
    // Note: cleanup happens after all tests in worker
  }, { scope: 'worker' }],
});
```

### Test-Scoped for Isolation

```typescript
type TestFixtures = {
  cleanDatabase: Database;
  isolatedUser: User;
};

const test = base.extend<TestFixtures>({
  // Each test gets clean database state
  cleanDatabase: async ({ databaseConnection }, use) => {
    await databaseConnection.beginTransaction();
    await use(databaseConnection);
    await databaseConnection.rollback();
  },

  // Each test gets unique user
  isolatedUser: async ({ cleanDatabase }, use) => {
    const user = await cleanDatabase.createUser({
      email: `test-${Date.now()}-${Math.random()}@example.com`,
    });
    await use(user);
    // Cleanup via transaction rollback
  },
});
```

## Advanced Patterns

### Fixture Inheritance

```typescript
// Base test with common fixtures
const baseTest = test.extend<BaseFixtures>({
  // Common fixtures
});

// E2E tests extend with UI fixtures
export const e2eTest = baseTest.extend<E2EFixtures>({
  authenticatedPage: async ({ page, testUser }, use) => {
    await loginUser(page, testUser);
    await use(page);
  },
});

// API tests extend with API fixtures
export const apiTest = baseTest.extend<APIFixtures>({
  authenticatedAPI: async ({ request, testUser }, use) => {
    const token = await getAuthToken(testUser);
    const api = await request.newContext({
      extraHTTPHeaders: { 'Authorization': `Bearer ${token}` },
    });
    await use(api);
  },
});
```

### Fixture Composition

```typescript
type ComposedFixtures = {
  scenario: TestScenario;
};

class TestScenario {
  constructor(
    public user: User,
    public page: Page,
    public api: APIClient,
    public db: Database
  ) {}

  async setupUserWithOrders(orderCount: number) {
    for (let i = 0; i < orderCount; i++) {
      await this.api.createOrder({
        userId: this.user.id,
        productId: `product-${i}`,
      });
    }
  }

  async navigateToUserOrders() {
    await this.page.goto(`/users/${this.user.id}/orders`);
  }
}

const test = base.extend<ComposedFixtures>({
  scenario: async ({ testUser, authenticatedPage, apiClient, database }, use) => {
    const scenario = new TestScenario(testUser, authenticatedPage, apiClient, database);
    await use(scenario);
  },
});

// Usage
test('user orders test', async ({ scenario }) => {
  await scenario.setupUserWithOrders(5);
  await scenario.navigateToUserOrders();
  // Test logic
});
```

### Fixture Hooks

```typescript
type FixtureWithHooks = {
  database: Database & {
    onBeforeTest: (cb: () => Promise<void>) => void;
    onAfterTest: (cb: () => Promise<void>) => void;
  };
};

const test = base.extend<FixtureWithHooks>({
  database: async ({}, use) => {
    const db = await Database.connect();
    const beforeHooks: Array<() => Promise<void>> = [];
    const afterHooks: Array<() => Promise<void>> = [];

    const wrappedDb = Object.assign(db, {
      onBeforeTest: (cb: () => Promise<void>) => beforeHooks.push(cb),
      onAfterTest: (cb: () => Promise<void>) => afterHooks.push(cb),
    });

    // Run before hooks
    for (const hook of beforeHooks) {
      await hook();
    }

    await use(wrappedDb);

    // Run after hooks
    for (const hook of afterHooks) {
      await hook();
    }

    await db.close();
  },
});
```

## Best Practices

1. **Single Responsibility**: Each fixture should do one thing well
2. **Clear Dependencies**: Make fixture dependencies explicit
3. **Proper Cleanup**: Always clean up resources in fixtures
4. **Type Safety**: Use TypeScript types for all fixtures
5. **Documentation**: Document complex fixture dependencies
6. **Scope Appropriately**: Use worker scope for expensive setup only
7. **Avoid Side Effects**: Fixtures shouldn't affect each other
8. **Test Isolation**: Ensure fixtures provide isolated test state

Remember: Good fixture design makes tests more maintainable and reliable!
