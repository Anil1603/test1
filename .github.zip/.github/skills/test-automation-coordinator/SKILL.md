---
name: test-automation-coordinator
description: Root-level coordinator skill that orchestrates between specialized testing skills and agents. Provides guidance on selecting appropriate testing approaches, composing test strategies, and coordinating complex testing scenarios. Use this as the entry point for test automation decisions.
---

# Test Automation Coordinator Skill

## Overview

The Test Automation Coordinator is the master orchestrator for all testing activities in the framework. It analyzes testing requirements, selects appropriate specialized skills and agents, and coordinates complex multi-skill scenarios. Think of it as the central intelligence that routes test automation tasks to the right specialists and composes comprehensive testing strategies.

## Purpose

This coordinator skill serves as the central hub for all test automation activities. It helps determine which specialized skills and agents to use based on testing requirements and provides guidance for composing comprehensive test strategies.

## When to Use This Skill

Use this coordinator when:
- Starting a new test automation project
- Determining which type of test to create
- Planning comprehensive test coverage
- Combining multiple testing approaches
- Troubleshooting test failures
- Refactoring existing tests
- Making architecture decisions

## Skill & Agent Hierarchy

```
test-automation-coordinator (this skill)
├── Specialized Skills
│   ├── e2e-testing          → End-to-end user flows
│   ├── api-testing          → REST API validation
│   ├── component-testing    → Isolated UI components
│   ├── visual-testing       → Screenshot regression
│   └── test-fixtures        → Shared test resources
│
└── Specialized Agents
    ├── @playwright-e2e-tester       → E2E test implementation
    ├── @playwright-api-tester       → API test implementation
    ├── @playwright-component-tester → Component test implementation
    ├── @playwright-visual-tester    → Visual regression testing
    ├── @test-debugger              → Test debugging & trace analysis
    └── @test-maintainer            → Test refactoring & maintenance
```

## Decision Tree

### 1. What Are You Testing?

#### Testing User Journeys / Workflows
→ **Use**: `e2e-testing` skill + `@playwright-e2e-tester` agent
- Multi-step user workflows
- Cross-page navigation
- Form submissions
- Authentication flows
- Checkout processes

**Example**:
```typescript
// Use e2e-testing skill for user workflows
test('complete purchase flow', async ({ page }) => {
  await page.goto('/products');
  await page.getByRole('button', { name: 'Add to Cart' }).click();
  await page.goto('/checkout');
  // Full user journey
});
```

#### Testing API Endpoints
→ **Use**: `api-testing` skill + `@playwright-api-tester` agent
- REST/GraphQL APIs
- Request/response validation
- Authentication
- Rate limiting
- Error handling

**Example**:
```typescript
// Use api-testing skill for API endpoints
test('API creates user', async ({ request }) => {
  const response = await request.post('/api/users', {
    data: { email: 'test@example.com' }
  });
  expect(response.ok()).toBeTruthy();
});
```

#### Testing UI Components in Isolation
→ **Use**: `component-testing` skill + `@playwright-component-tester` agent
- Individual React/Vue/Svelte components
- Component props and states
- Component events
- Component accessibility

**Example**:
```typescript
// Use component-testing skill for isolated components
test('button renders correctly', async ({ mount }) => {
  const component = await mount(<Button variant="primary">Click</Button>);
  await expect(component).toHaveClass(/primary/);
});
```

#### Testing Visual Appearance
→ **Use**: `visual-testing` skill + `@playwright-visual-tester` agent
- Visual regression detection
- Cross-browser consistency
- Responsive design
- Theme changes

**Example**:
```typescript
// Use visual-testing skill for screenshots
test('homepage visual check', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveScreenshot('homepage.png');
});
```

### 2. What Are You Trying to Achieve?

#### Creating New Tests
→ **Primary Skill**: Based on test type (see above)
→ **Agent**: Corresponding specialist agent
→ **Support**: `test-fixtures` skill for shared resources

#### Debugging Failing Tests
→ **Use**: `@test-debugger` agent
- Analyzing trace files
- Interpreting error messages
- Identifying flakiness
- Performance issues

#### Refactoring/Maintaining Tests
→ **Use**: `@test-maintainer` agent
- Removing duplication
- Updating selectors
- Improving stability
- Fixing flaky tests

#### Setting Up Test Infrastructure
→ **Use**: `test-fixtures` skill
- Custom fixtures
- Authentication helpers
- Database setup
- Mock servers

## Combining Skills

### Complex Testing Scenarios

Many real-world scenarios require combining multiple skills:

#### Scenario 1: E2E Test with API Setup
```typescript
// Combine e2e-testing + api-testing + test-fixtures

import { test, expect } from './fixtures/custom-fixtures';

test('user dashboard with API setup', async ({ 
  page,           // from test-fixtures
  apiHelper,      // from test-fixtures (api-testing patterns)
  testUser        // from test-fixtures
}) => {
  // API setup (api-testing skill)
  await apiHelper.post('/api/users', testUser);
  
  // E2E flow (e2e-testing skill)
  await page.goto('/login');
  await page.getByLabel('Email').fill(testUser.email);
  await page.getByLabel('Password').fill(testUser.password);
  await page.getByRole('button', { name: 'Login' }).click();
  
  // Visual validation (visual-testing skill)
  await expect(page).toHaveScreenshot('dashboard.png');
});
```

#### Scenario 2: Component Test with Visual Regression
```typescript
// Combine component-testing + visual-testing

test('button component all states', async ({ mount }) => {
  // Component testing
  const component = await mount(<Button>Click me</Button>);
  
  // Visual testing for each state
  await expect(component).toHaveScreenshot('button-default.png');
  
  await component.hover();
  await expect(component).toHaveScreenshot('button-hover.png');
  
  await component.focus();
  await expect(component).toHaveScreenshot('button-focus.png');
});
```

#### Scenario 3: Full Integration Test
```typescript
// Combine all skills

test('complete user registration flow', async ({ 
  page, 
  request,
  database 
}) => {
  // Setup via API (api-testing)
  await request.post('/api/config', { data: { registrationEnabled: true } });
  
  // E2E user flow (e2e-testing)
  await page.goto('/register');
  await page.getByLabel('Email').fill('newuser@example.com');
  await page.getByLabel('Password').fill('SecurePass123!');
  await page.getByRole('button', { name: 'Register' }).click();
  
  // Visual check (visual-testing)
  await expect(page).toHaveScreenshot('registration-success.png');
  
  // API verification (api-testing)
  const response = await request.get('/api/users/me');
  expect(response.ok()).toBeTruthy();
  
  // Database verification (test-fixtures)
  const user = await database.query('SELECT * FROM users WHERE email = ?', ['newuser@example.com']);
  expect(user).toBeTruthy();
});
```

## Test Type Selection Matrix

| Requirement | Recommended Approach | Skills | Agents |
|------------|---------------------|---------|---------|
| User can log in | E2E Test | e2e-testing, test-fixtures | @playwright-e2e-tester |
| API returns valid data | API Test | api-testing | @playwright-api-tester |
| Button displays correctly | Component Test | component-testing | @playwright-component-tester |
| Page looks correct | Visual Test | visual-testing | @playwright-visual-tester |
| Multi-step checkout | E2E + API Test | e2e-testing, api-testing, test-fixtures | @playwright-e2e-tester, @playwright-api-tester |
| Component in all states | Component + Visual | component-testing, visual-testing | @playwright-component-tester, @playwright-visual-tester |
| Test is failing | Debug | N/A | @test-debugger |
| Test is flaky | Maintain/Refactor | All relevant | @test-maintainer |

## Best Practices for Coordination

### 1. Start with the Right Skill

```typescript
// ✅ Right: Use e2e-testing for user flows
test('user workflow', async ({ page }) => {
  // E2E approach
});

// ❌ Wrong: Using component testing for E2E flow
test('user workflow', async ({ mount }) => {
  // This doesn't make sense
});
```

### 2. Layer Your Tests

Build a test pyramid:
1. **Base**: Unit tests (outside Playwright)
2. **Middle**: Component tests (component-testing skill)
3. **Top**: E2E tests (e2e-testing skill)
4. **Cross-cutting**: API tests, Visual tests

### 3. Use Fixtures for Common Setup

```typescript
// Define once in test-fixtures
export const test = base.extend<CustomFixtures>({
  authenticatedPage: async ({ page, testUser }, use) => {
    await login(page, testUser);
    await use(page);
  },
});

// Reuse everywhere
test('dashboard test', async ({ authenticatedPage }) => {
  // Already authenticated
});
```

### 4. Compose Agents for Complex Tasks

```typescript
// For a complex test creation task:
// 1. Use @playwright-e2e-tester for E2E structure
// 2. Use @playwright-api-tester for API setup
// 3. Use @playwright-visual-tester for visual validation
// 4. Use @test-debugger if issues arise
```

## Common Patterns

### Pattern 1: Test-First E2E Development

1. Start with `@playwright-e2e-tester` agent to create test structure
2. Use `test-fixtures` skill for authentication and setup
3. Add `visual-testing` for regression protection
4. Use `@test-debugger` when tests fail

### Pattern 2: API-First Development

1. Create API tests with `@playwright-api-tester`
2. Set up test data fixtures with `test-fixtures` skill
3. Build E2E tests on top with `@playwright-e2e-tester`
4. Add visual tests with `@playwright-visual-tester`

### Pattern 3: Component-Driven Development

1. Test components in isolation with `@playwright-component-tester`
2. Add visual regression with `@playwright-visual-tester`
3. Integrate into E2E flows with `@playwright-e2e-tester`
4. Validate API integration with `@playwright-api-tester`

## Troubleshooting Guide

### Issue: Test is Flaky
→ **Solution**: Use `@test-maintainer` agent
- Check for race conditions
- Add proper waits
- Use web-first assertions
- Stabilize dynamic content

### Issue: Test is Failing
→ **Solution**: Use `@test-debugger` agent
- Analyze trace file
- Check error message
- Verify selectors
- Check test data

### Issue: Need Better Test Coverage
→ **Solution**: Use this coordinator
- Identify gaps in test pyramid
- Add appropriate test types
- Use multiple skills/agents
- Balance E2E, component, API, visual

### Issue: Tests are Slow
→ **Solution**: Use `@test-maintainer` + coordinator
- Replace E2E with API tests where possible
- Use worker-scoped fixtures
- Parallelize tests
- Optimize waits

## Quick Reference

### Choose E2E Testing When:
- Testing complete user workflows
- Multiple pages involved
- Browser behavior matters
- Testing navigation and routing

### Choose API Testing When:
- Testing backend logic
- Data validation
- Authentication flows
- Fast feedback needed

### Choose Component Testing When:
- Testing UI components in isolation
- Props/events/state logic
- Accessibility validation
- Component library development

### Choose Visual Testing When:
- CSS changes
- Design system updates
- Cross-browser rendering
- Responsive design validation

### Use Test Fixtures When:
- Shared setup across tests
- Authentication needed
- Test data management
- Resource lifecycle management

## Resources

- Refer to individual skill documentation in `skills/` directory
- Use specialized agents via `@agent-name` invocation
- Check `.github/copilot-instructions.md` for coding standards
- See `PLAN.md` for overall architecture

## Examples

### Example 1: Determining Test Approach
```typescript
// User asks: "I need to test the login functionality"
// Coordinator analysis:
// - User journey? → e2e-testing skill
// - Using Page Object Model? → Yes
// - Need authentication fixture? → Yes, test-fixtures skill
// Recommendation: Use @playwright-e2e-tester with e2e-testing skill

import { test } from '@fixtures/custom-fixtures';
import { LoginPage } from '@pages/login-page';

test('user login flow', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login('user@example.com', 'password');
  await loginPage.expectLoginSuccess();
});
```

### Example 2: Complex Multi-Skill Scenario
```typescript
// User asks: "Test user registration with email verification"
// Coordinator analysis:
// - E2E flow + API verification + Email checking
// - Skills: e2e-testing, api-testing, test-fixtures
// - Agents: @playwright-e2e-tester, @playwright-api-tester

test('complete registration flow', async ({ page, request, emailClient }) => {
  // E2E: Fill registration form (e2e-testing)
  await page.goto('/register');
  await page.getByLabel('Email').fill('newuser@example.com');
  await page.getByRole('button', { name: 'Register' }).click();
  
  // API: Verify user created (api-testing)
  const response = await request.get('/api/users/me');
  expect(response.ok()).toBeTruthy();
  
  // Email: Check verification email (test-fixtures)
  const email = await emailClient.getLatestEmail('newuser@example.com');
  expect(email.subject).toContain('Verify');
});
```

### Example 3: Routing Test Debugging
```typescript
// User asks: "My test is failing intermittently"
// Coordinator analysis:
// - Flaky test? → @test-debugger agent
// - Needs trace analysis and recommendations

// The debugger agent will:
// 1. Analyze trace files
// 2. Identify race conditions
// 3. Suggest proper waits
// 4. Recommend web-first assertions
```

## Conclusion

This coordinator skill helps you:
1. ✅ Choose the right testing approach
2. ✅ Select appropriate skills and agents
3. ✅ Combine multiple testing strategies
4. ✅ Maintain consistent test quality
5. ✅ Build comprehensive test coverage

**Remember**: Start simple, test what matters, and let the specialized skills and agents guide your implementation.
