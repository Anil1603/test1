# Visual Testing Configuration

## Screenshot Configuration Options

### Basic Configuration

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    screenshot: 'only-on-failure', // or 'on', 'off'
  },
  expect: {
    toHaveScreenshot: {
      maxDiffPixels: 100, // Maximum different pixels allowed
      threshold: 0.2, // Pixel color difference threshold (0-1)
      animations: 'disabled', // Disable animations
    },
  },
});
```

### Per-Test Configuration

```typescript
await expect(page).toHaveScreenshot('screenshot.png', {
  // Visual comparison options
  maxDiffPixels: 100,
  maxDiffPixelRatio: 0.01, // 1% difference allowed
  threshold: 0.2,
  
  // Capture options
  fullPage: true,
  omitBackground: false,
  
  // Animation handling
  animations: 'disabled', // or 'allow'
  
  // Masking
  mask: [page.locator('.dynamic-content')],
  
  // Clip to specific region
  clip: { x: 0, y: 0, width: 800, height: 600 }
});
```

## Baseline Management

### Directory Structure

```
tests/
  __screenshots__/
    component-test/
      chromium/
        button-default.png
        button-hover.png
      firefox/
        button-default.png
        button-hover.png
      webkit/
        button-default.png
        button-hover.png
```

### Updating Baselines

```bash
# Update all screenshots
npx playwright test --update-snapshots

# Update specific test
npx playwright test visual.spec.ts --update-snapshots

# Update for specific browser
npx playwright test --project=chromium --update-snapshots
```

### CI/CD Baseline Strategy

```yaml
# .github/workflows/visual-tests.yml
name: Visual Tests

on: [pull_request]

jobs:
  visual-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run visual tests
        run: npm run test:visual
      
      - name: Upload diff artifacts
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: visual-diffs
          path: test-results/
```

## Handling Dynamic Content

### Time-based Content

```typescript
// Mask timestamps
test('page with timestamp', async ({ page }) => {
  await page.goto('/dashboard');
  
  await expect(page).toHaveScreenshot({
    mask: [
      page.locator('.timestamp'),
      page.locator('.last-updated'),
      page.locator('[data-testid="date"]')
    ]
  });
});

// Replace with fixed value
await page.evaluate(() => {
  const timestamp = document.querySelector('.timestamp');
  if (timestamp) timestamp.textContent = '2024-01-01 00:00:00';
});
```

### User-Specific Content

```typescript
// Mask user avatars and names
await expect(page).toHaveScreenshot({
  mask: [
    page.locator('.user-avatar'),
    page.locator('.username'),
    page.locator('.profile-picture')
  ]
});
```

### Live/Streaming Data

```typescript
// Mock WebSocket data
await page.route('**/ws/**', route => {
  route.fulfill({
    status: 200,
    body: JSON.stringify({ data: 'static-test-data' })
  });
});

// Or mask the live data area
await expect(page).toHaveScreenshot({
  mask: [page.locator('.live-updates')]
});
```

## Animation Handling

### Global Animation Disable

```typescript
test.beforeEach(async ({ page }) => {
  await page.addStyleTag({
    content: `
      *, *::before, *::after {
        animation-duration: 0s !important;
        animation-delay: 0s !important;
        transition-duration: 0s !important;
        transition-delay: 0s !important;
        scroll-behavior: auto !important;
      }
    `
  });
});
```

### Wait for Animation Complete

```typescript
test('animated component', async ({ page }) => {
  await page.goto('/');
  
  const animated = page.locator('.animated-element');
  
  // Wait for animation to finish
  await animated.evaluate(element => {
    return Promise.all(
      element.getAnimations().map(animation => animation.finished)
    );
  });
  
  await expect(animated).toHaveScreenshot();
});
```

## Font Rendering

### Wait for Fonts

```typescript
test('wait for fonts', async ({ page }) => {
  await page.goto('/');
  
  // Wait for all fonts to load
  await page.evaluate(() => document.fonts.ready);
  
  // Or wait for specific font
  await page.evaluate(async () => {
    await document.fonts.load('1em "Custom Font"');
  });
  
  await expect(page).toHaveScreenshot();
});
```

### Use System Fonts in CI

```typescript
// playwright.config.ts
export default defineConfig({
  use: {
    // Use system fonts in CI for consistency
    ...(process.env.CI && {
      extraHTTPHeaders: {
        'Accept-Language': 'en-US,en;q=0.9',
      },
    }),
  },
});
```

## Cross-Browser Consistency

### Per-Browser Baselines

```typescript
test('cross-browser', async ({ page, browserName }) => {
  await page.goto('/');
  
  // Playwright automatically uses browser-specific baselines
  await expect(page).toHaveScreenshot(`page-${browserName}.png`);
});
```

### Tolerance for Browser Differences

```typescript
test('tolerant comparison', async ({ page, browserName }) => {
  await page.goto('/');
  
  const threshold = browserName === 'webkit' ? 0.3 : 0.2;
  
  await expect(page).toHaveScreenshot({
    threshold,
    maxDiffPixels: browserName === 'webkit' ? 200 : 100
  });
});
```

## Responsive Screenshots

### Test Multiple Breakpoints

```typescript
const breakpoints = {
  mobile: { width: 390, height: 844 },
  tablet: { width: 768, height: 1024 },
  desktop: { width: 1440, height: 900 },
  wide: { width: 1920, height: 1080 }
};

for (const [name, size] of Object.entries(breakpoints)) {
  test(`responsive - ${name}`, async ({ page }) => {
    await page.setViewportSize(size);
    await page.goto('/');
    await expect(page).toHaveScreenshot(`home-${name}.png`);
  });
}
```

### Device Emulation

```typescript
import { devices } from '@playwright/test';

test.use(devices['iPhone 13']);

test('mobile device', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveScreenshot('mobile.png');
});
```

## Performance Optimization

### Parallel Visual Tests

```typescript
// playwright.config.ts
export default defineConfig({
  projects: [
    {
      name: 'visual-chromium',
      use: { ...devices['Desktop Chrome'] },
      testMatch: '**/*.visual.spec.ts'
    }
  ],
  workers: process.env.CI ? 2 : 4 // Parallel workers
});
```

### Selective Visual Testing

```typescript
// Only run visual tests on visual changes
test.describe('visual regression', () => {
  test.skip(
    () => !process.env.RUN_VISUAL_TESTS,
    'Visual tests skipped'
  );

  test('homepage', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveScreenshot();
  });
});
```

## Debugging Visual Failures

### Review Diff Images

When a visual test fails, Playwright generates:
- `*-expected.png` - Baseline screenshot
- `*-actual.png` - Current screenshot  
- `*-diff.png` - Visual difference highlighted

### HTML Reporter

```bash
# View test results with visual diffs
npx playwright show-report
```

### Update Specific Screenshot

```bash
# Update just one screenshot
npx playwright test --grep "specific test" --update-snapshots
```

## Best Practices

1. **Consistent Environment**
   - Same OS for baselines and CI
   - Same browser versions
   - Same screen resolution

2. **Stable Content**
   - Wait for all content to load
   - Disable animations
   - Mask dynamic data
   - Wait for fonts

3. **Meaningful Baselines**
   - Review baselines before committing
   - Update baselines intentionally
   - Document visual changes

4. **Appropriate Tolerances**
   - Start strict, relax as needed
   - Different tolerances per browser
   - Document tolerance decisions

5. **CI/CD Integration**
   - Fail build on visual changes
   - Upload diff artifacts
   - Require manual review

Remember: Visual tests catch regressions that functional tests miss!
