---
name: visual-testing
description: Toolkit for visual regression testing with Playwright screenshots. Provides patterns for screenshot comparison, baseline management, responsive testing, and visual diff detection. Use when validating UI appearance and detecting visual regressions.
---

# Visual Testing Skill

## Overview

The Visual Testing Skill provides patterns for screenshot-based visual regression testing with Playwright. It enables pixel-perfect comparison, responsive design validation, cross-browser visual consistency checking, and baseline management. This skill is crucial for catching unintended visual changes, validating CSS updates, and ensuring consistent UI appearance across browsers and devices.

## When to Use This Skill

Use this skill when:
- Detecting visual regressions
- Validating CSS changes
- Testing responsive design
- Ensuring cross-browser visual consistency
- Testing component visual appearance
- Validating theme changes
- Screenshot-based testing

## Prerequisites

- Playwright installed and configured
- Baseline screenshots established
- Understanding of visual diff tolerances
- Version control for screenshots

## Core Capabilities

### 1. Screenshot Capture
- Full page screenshots
- Element screenshots
- Viewport-specific screenshots
- Cross-browser screenshots

### 2. Visual Comparison
- Pixel-perfect comparison
- Toleranced comparison
- Masked dynamic content
- Animation handling

### 3. Responsive Testing
- Multiple viewport sizes
- Device emulation
- Orientation testing
- Breakpoint validation

### 4. Baseline Management
- Create baselines
- Update baselines
- Review visual diffs
- Version control integration

## Usage Examples

### Basic Screenshot Test
```typescript
import { test, expect } from '@playwright/test';

test('homepage visual test', async ({ page }) => {
  await page.goto('/');
  await page.waitForLoadState('networkidle');
  
  await expect(page).toHaveScreenshot('homepage.png');
});
```

### Component Screenshot
```typescript
test('button component visual', async ({ page }) => {
  await page.goto('/components/button');
  
  const button = page.getByRole('button', { name: 'Primary' });
  await expect(button).toHaveScreenshot('primary-button.png');
});
```

### Responsive Screenshots
```typescript
test.describe('Responsive Design', () => {
  const viewports = [
    { name: 'mobile', width: 375, height: 667 },
    { name: 'tablet', width: 768, height: 1024 },
    { name: 'desktop', width: 1920, height: 1080 }
  ];

  for (const viewport of viewports) {
    test(`${viewport.name} view`, async ({ page }) => {
      await page.setViewportSize(viewport);
      await page.goto('/');
      
      await expect(page).toHaveScreenshot(`home-${viewport.name}.png`);
    });
  }
});
```

### Masking Dynamic Content
```typescript
test('dashboard with masked elements', async ({ page }) => {
  await page.goto('/dashboard');
  
  await expect(page).toHaveScreenshot('dashboard.png', {
    mask: [
      page.locator('.timestamp'),
      page.locator('.user-avatar'),
      page.locator('.live-data')
    ]
  });
});
```

### Custom Threshold
```typescript
test('with tolerance', async ({ page }) => {
  await page.goto('/');
  
  await expect(page).toHaveScreenshot('page.png', {
    maxDiffPixels: 100, // Allow up to 100 pixels difference
    threshold: 0.  2  // Pixel similarity threshold
  });
});
```

### Full Page Screenshot
```typescript
test('full page screenshot', async ({ page }) => {
  await page.goto('/long-page');
  
  await expect(page).toHaveScreenshot('full-page.png', {
    fullPage: true,
    animations: 'disabled'
  });
});
```

## Guidelines

### Baseline Creation
- Generate initial screenshots
- Review for quality
- Commit to version control
- Document visual requirements

### Dynamic Content Handling
- Mask timestamps and dates
- Mask user-specific data
- Mask random generated content
- Stabilize animations

### Test Stability
- Wait for content to load
- Disable animations
- Wait for fonts to load
- Ensure consistent viewport

### Threshold Configuration
- Start with strict thresholds
- Relax as needed
- Document threshold decisions
- Different thresholds for different pages

## Common Patterns

### Disable Animations
```typescript
test.beforeEach(async ({ page }) => {
  await page.addStyleTag({
    content: `
      *, *::before, *::after {
        animation-duration: 0s !important;
        transition-duration: 0s !important;
      }
    `
  });
});
```

### Wait for Stability
```typescript
test('stable screenshot', async ({ page }) => {
  await page.goto('/');
  
  // Wait for network idle
  await page.waitForLoadState('networkidle');
  
  // Wait for images
  await page.locator('img').last().waitFor({ state: 'visible' });
  
  // Wait for fonts
  await page.evaluate(() => document.fonts.ready);
  
  await expect(page).toHaveScreenshot();
});
```

### Theme Testing
```typescript
test.describe('Themes', () => {
  test('light theme', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-theme="light"]');
    await expect(page).toHaveScreenshot('app-light.png');
  });

  test('dark theme', async ({ page }) => {
    await page.goto('/');
    await page.click('[data-theme="dark"]');
    await expect(page).toHaveScreenshot('app-dark.png');
  });
});
```

### Component States
```typescript
test.describe('Button states', () => {
  test('default', async ({ page }) => {
    await page.goto('/components/button');
    const button = page.locator('.button-primary');
    await expect(button).toHaveScreenshot('button-default.png');
  });

  test('hover', async ({ page }) => {
    await page.goto('/components/button');
    const button = page.locator('.button-primary');
    await button.hover();
    await expect(button).toHaveScreenshot('button-hover.png');
  });

  test('focus', async ({ page }) => {
    await page.goto('/components/button');
    const button = page.locator('.button-primary');
    await button.focus();
    await expect(button).toHaveScreenshot('button-focus.png');
  });
});
```

## Best Practices

### 1. Disable Animations
```typescript
test.beforeEach(async ({ page }) => {
  await page.addStyleTag({
    content: `
      *, *::before, *::after {
        animation-duration: 0s !important;
        transition-duration: 0s !important;
      }
    `
  });
});
```

### 2. Wait for Stability
```typescript
test('stable screenshot', async ({ page }) => {
  await page.goto('/');
  
  // Wait for network idle
  await page.waitForLoadState('networkidle');
  
  // Wait for fonts
  await page.evaluate(() => document.fonts.ready);
  
  // Wait for images
  await page.waitForSelector('img[src]', { state: 'visible' });
  
  await expect(page).toHaveScreenshot();
});
```

### 3. Mask Dynamic Content
```typescript
test('mask timestamps', async ({ page }) => {
  await page.goto('/dashboard');
  
  await expect(page).toHaveScreenshot('dashboard.png', {
    mask: [
      page.locator('.timestamp'),
      page.locator('.last-updated'),
      page.locator('[data-dynamic="true"]')
    ]
  });
});
```

### 4. Use Appropriate Thresholds
```typescript
test('with tolerance', async ({ page, browserName }) => {
  await page.goto('/');
  
  // Different tolerance for different browsers
  const threshold = browserName === 'webkit' ? 0.3 : 0.2;
  
  await expect(page).toHaveScreenshot('page.png', {
    threshold,
    maxDiffPixels: 100
  });
});
```

### 5. Test Multiple Viewports
```typescript
const viewports = [
  { name: 'mobile', width: 375, height: 667 },
  { name: 'tablet', width: 768, height: 1024 },
  { name: 'desktop', width: 1920, height: 1080 }
];

for (const viewport of viewports) {
  test(`${viewport.name} layout`, async ({ page }) => {
    await page.setViewportSize(viewport);
    await page.goto('/');
    await expect(page).toHaveScreenshot(`home-${viewport.name}.png`);
  });
}
```

## Examples

### Example 1: Component Visual Testing
```typescript
import { test, expect } from '@playwright/test';

test.describe('Button Component Visuals', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/components/button');
    
    // Disable animations
    await page.addStyleTag({
      content: '* { transition: none !important; animation: none !important; }'
    });
  });
  
  test('default state', async ({ page }) => {
    const button = page.locator('.btn-primary').first();
    await expect(button).toHaveScreenshot('button-default.png');
  });
  
  test('hover state', async ({ page }) => {
    const button = page.locator('.btn-primary').first();
    await button.hover();
    await expect(button).toHaveScreenshot('button-hover.png');
  });
  
  test('focus state', async ({ page }) => {
    const button = page.locator('.btn-primary').first();
    await button.focus();
    await expect(button).toHaveScreenshot('button-focus.png');
  });
  
  test('disabled state', async ({ page }) => {
    const button = page.locator('.btn-primary[disabled]').first();
    await expect(button).toHaveScreenshot('button-disabled.png');
  });
});
```

### Example 2: Responsive Design Validation
```typescript
test.describe('Responsive Homepage', () => {
  const breakpoints = [
    { name: 'mobile-portrait', width: 375, height: 667 },
    { name: 'mobile-landscape', width: 667, height: 375 },
    { name: 'tablet-portrait', width: 768, height: 1024 },
    { name: 'tablet-landscape', width: 1024, height: 768 },
    { name: 'desktop', width: 1920, height: 1080 },
    { name: 'desktop-wide', width: 2560, height: 1440 }
  ];
  
  for (const breakpoint of breakpoints) {
    test(`${breakpoint.name} (${breakpoint.width}x${breakpoint.height})`, async ({ page }) => {
      await page.setViewportSize({
        width: breakpoint.width,
        height: breakpoint.height
      });
      
      await page.goto('/');
      await page.waitForLoadState('networkidle');
      
      await expect(page).toHaveScreenshot(
        `homepage-${breakpoint.name}.png`,
        { fullPage: true }
      );
    });
  }
});
```

### Example 3: Theme Comparison
```typescript
test.describe('Theme Visual Tests', () => {
  test('light theme', async ({ page }) => {
    await page.goto('/');
    
    // Set light theme
    await page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'light');
      localStorage.setItem('theme', 'light');
    });
    
    await page.waitForTimeout(100); // Let theme apply
    await expect(page).toHaveScreenshot('app-light-theme.png', {
      fullPage: true
    });
  });
  
  test('dark theme', async ({ page }) => {
    await page.goto('/');
    
    // Set dark theme
    await page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem('theme', 'dark');
    });
    
    await page.waitForTimeout(100);
    await expect(page).toHaveScreenshot('app-dark-theme.png', {
      fullPage: true
    });
  });
  
  test('high-contrast theme', async ({ page }) => {
    await page.goto('/');
    
    await page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'high-contrast');
      localStorage.setItem('theme', 'high-contrast');
    });
    
    await page.waitForTimeout(100);
    await expect(page).toHaveScreenshot('app-high-contrast-theme.png', {
      fullPage: true
    });
  });
});
```

## Limitations

- Requires baseline screenshots in repo
- Can be affected by font rendering differences
- CI/CD environment must match local
- Sensitive to minor CSS changes
- Requires manual review of diffs

## References

- See [visual-config.md](./references/visual-config.md) for configuration details
- Refer to Playwright [Screenshots docs](https://playwright.dev/docs/screenshots)
- Use `@playwright-visual-tester` agent for visual test creation
