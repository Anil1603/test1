# Test Automation Architecture

## Overview

This document explains how the self-healing locator strategy integrates with Explorer Agent artifacts and page objects.

## Quick Start

```bash
# 1. Diagnose current artifacts
./scripts/diagnose-explorer-artifacts.sh SF-02

# 2. Test complete workflow
./scripts/test-integration-workflow.sh SF-02 https://test.salesforce.com standard no

# 3. Manually regenerate locators (if needed)
./scripts/manual-locator-generation.sh SF-02 standard

# 4. Run tests
npx playwright test
```

**Note:** If artifacts are incomplete, re-run Explorer Agent first. See [Troubleshooting](#troubleshooting) section below.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│ Phase 1: User Story Review                                          │
│ Agent: User Story Review Agent                                       │
│ Output: user-stories/<ISSUE>.md                                      │
└────────────────────────┬────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Phase 2: Test Planning                                              │
│ Agent: Planner Agent                                                 │
│ Output: test-cases/<ISSUE>-test-cases.md                           │
│         test-cases/<ISSUE>-test-steps.json                          │
│         test-cases/<ISSUE>-test-data.json                           │
└────────────────────────┬────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Phase 3: DOM Analysis & Locator Discovery                           │
│ Agent: Explorer Agent (Salesforce-optimized)                        │
│                                                                       │
│ Process:                                                             │
│  1. Navigate to pages defined in test plan                          │
│  2. Capture DOM snapshots (JSON + YAML)                             │
│  3. Analyze Salesforce Lightning components                         │
│  4. Extract locator candidates with confidence scores               │
│  5. Generate locator JSON manifest                                  │
│                                                                       │
│ Outputs:                                                             │
│  ├── dom-analysis/                                                   │
│  │   ├── SF-<ISSUE>-<page>-analysis.md      (Human-readable)       │
│  │   ├── dom-snapshots/                                             │
│  │   │   └── SF-<ISSUE>_<PageName>_<timestamp>.json                │
│  │   └── locators/                                                  │
│  │       └── SF-<ISSUE>_locators.json       (Locator manifest)     │
│  │                                                                   │
│  ├── .playwright-mcp/tests/helpers/dom-snapshots/                  │
│  │   └── SF-<ISSUE>-<page>-snapshot.yaml    (Runtime snapshots)    │
│  │                                                                   │
│  └── handoff-data/                                                  │
│      └── phase3-to-phase4-SF-<ISSUE>.json   (Handoff metadata)     │
│                                                                       │
└────────────────────────┬────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Phase 4: Locator Strategy Generation                                │
│ Script: scripts/agents/generator/locator-strategy-builder.ts        │
│                                                                       │
│ Process:                                                             │
│  1. Read dom-analysis/locators/SF-<ISSUE>_locators.json            │
│  2. Apply locator priority strategy                                 │
│  3. Generate primary, secondary, tertiary fallbacks                 │
│  4. Calculate confidence scores                                     │
│  5. Generate TypeScript locator modules                             │
│                                                                       │
│ Command:                                                             │
│   npx tsx scripts/agents/generator/locator-strategy-builder.ts \   │
│     --story SF-02 \                                                  │
│     --healing-strategy standard                                     │
│                                                                       │
│ Outputs:                                                             │
│   tests/helpers/locators/                                           │
│    ├── SF-<ISSUE>-<page>-locators.ts       (Per-page locators)    │
│    ├── SF-<ISSUE>-<page>-locators.json     (JSON config)          │
│    ├── SF-<ISSUE>-locators-index.ts         (Combined index)       │
│    └── SF-<ISSUE>-locator-manifest.json     (Generation stats)     │
│                                                                       │
└────────────────────────┬────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Phase 5: Test Code Generation                                       │
│ Agent: Generator Agent                                               │
│                                                                       │
│ Process:                                                             │
│  1. Read test plan from Phase 2                                     │
│  2. Import generated locator modules                                │
│  3. Generate Page Objects                                           │
│  4. Generate Handlers (business flows)                              │
│  5. Generate Test Specs                                             │
│  6. Generate Test Data                                              │
│                                                                       │
│ Outputs:                                                             │
│   tests/                                                             │
│    ├── pages/                                                       │
│    │   ├── base.page.ts                                             │
│    │   ├── <page>.page.ts              (Uses locator modules)      │
│    │   └── ...                                                      │
│    ├── handlers/                                                    │
│    │   └── <feature>.handler.ts        (Business flows)            │
│    ├── specs/                                                       │
│    │   └── <feature>/                                               │
│    │       └── SF-<ISSUE>-<scenario>.spec.ts                        │
│    └── data/                                                        │
│        └── SF-<ISSUE>_test_data.json                                │
│                                                                       │
└────────────────────────┬────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Runtime: Self-Healing Locator Resolution                            │
│ Module: tests/helpers/self-healing-locator.ts                       │
│                                                                       │
│ Flow:                                                                │
│  1. Page Object calls resolveLocator(page, 'fieldName')            │
│  2. Self-healing utility tries Primary locator                      │
│  3. If Primary fails → retry with configured delays                │
│  4. If still fails → try Secondary locator                          │
│  5. If still fails → try Tertiary locator                           │
│  6. If still fails → try additional fallbacks                       │
│  7. Log all attempts for debugging                                  │
│  8. Return resolved Locator or null                                 │
│                                                                       │
│ Features:                                                            │
│  • Configurable retries per strategy                                │
│  • Automatic scrolling into view                                    │
│  • Wait for element stability                                       │
│  • Detailed logging                                                 │
│  • Validation error detection & recovery                            │
│                                                                       │
└────────────────────────┬────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Runtime: Page Object Execution                                      │
│                                                                       │
│ Example: LeadNewPage.fillField('country', 'India')                  │
│                                                                       │
│  1. Page object stores field value in memory                        │
│  2. Calls resolveLocator(page, 'country', config)                  │
│  3. Self-healing utility resolves element                           │
│  4. Page object performs interaction (fill, click, etc.)            │
│  5. If validation error on save:                                    │
│     a. Detect error dialog                                          │
│     b. Extract failed field names                                   │
│     c. Close dialog                                                 │
│     d. Re-fill fields from memory                                   │
│     e. Retry save                                                   │
│  6. Verify success                                                  │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

## Current Status

### ✅ Fully Implemented
- **Explorer Agent (Phase 3)** - DOM analysis and snapshot capture
- **Self-healing locator utility (Runtime)** - Complete with retry logic
- **Page objects with validation error recovery** - Production ready
- **Locator Strategy Builder** - Confidence scoring and fallback generation
- **Converter Script** - Explorer JSON to TypeScript transformation
- **Agent Hook Scripts** - All pre/post hooks created and documented
- **Integration Scripts** - Workflow automation and diagnostics
- **Complete Documentation** - All guides and references

### ⚠️ Ready for Use (Not Yet Auto-Invoked)
- **Generator Agent Hook Integration** - Hook scripts exist, need agent implementation
- **CI/CD Pipeline Integration** - Scripts ready, need GitHub Actions workflow

### 🔄 Known Issues to Resolve
- **Incomplete Explorer Artifacts** - SF-02_locators.json missing form fields
  - **Solution:** Re-run Explorer Agent after authentication
  - **Tool:** `./scripts/diagnose-explorer-artifacts.sh SF-02`

## Data Flow

### Explorer Agent Output Format
```json
{
  "storyId": "SF-02",
  "pages": [
    {
      "pageName": "NewLeadModal",
      "url": "https://...",
      "elements": [
        {
          "id": "element-1",
          "description": "Country field",
          "tag": "input",
          "locator": "input[aria-label='Country']",
          "type": "aria-label",
          "confidence": "high",
          "visible": true
        }
      ]
    }
  ]
}
```

### Locator Strategy Builder Output Format
```typescript
// tests/helpers/locators/SF-02-newlead-locators.ts
export const locators: Record<string, string[]> = {
  country: [
    'css=input[role="combobox"][aria-label="Country"]',      // Primary
    'css=input[placeholder="Search Countries..."]',           // Secondary
    'xpath=//input[@role="combobox" and @aria-label="Country"]' // Tertiary
  ]
};

export const resolveLocator = createLocatorResolver(locators);
```

### Page Object Usage
```typescript
// tests/pages/lead-new.ts
import { resolveLocator } from '../helpers/locators/SF-02-newlead-locators';

async fillField(key: string, value: string) {
  const locator = await resolveLocator(this.page, key, {
    maxRetries: 3,
    retryDelayMs: 500,
    logAttempts: true
  });
  
  await locator.fill(value);
}
```

## Implementation Complete

### ✅ Gap Resolved

The integration between Explorer Agent and Generator Agent is now fully implemented through:

1. **Pre-Generation Hook Script** - `.github/hooks/scripts/generator-pre-generation.sh`
2. **Locator Strategy Builder** - `scripts/agents/generator/locator-strategy-builder.ts`  
3. **Converter Script** - `scripts/utils/convert-explorer-artifacts.ts`
4. **Integration Workflow** - `scripts/test-integration-workflow.sh`
5. **Diagnostics Tool** - `scripts/diagnose-explorer-artifacts.sh`

### Using the Implementation

#### Automatic (when Generator Agent is updated)

Generator Agent will automatically read `.github/hooks/agent-hooks.json` and execute:

```bash
# Pre-generation hook runs automatically
.github/hooks/scripts/generator-pre-generation.sh --story SF-02
```

This invokes:
1. Locator Strategy Builder with confidence scoring
2. TypeScript locator module generation
3. Validation checks (TypeScript, ESLint)

#### Manual (for testing or one-off runs)

```bash
# Option 1: Full workflow test
./scripts/test-integration-workflow.sh SF-02 https://test.salesforce.com standard no

# Option 2: Just regenerate locators
./scripts/manual-locator-generation.sh SF-02 standard

# Option 3: Diagnose artifacts first
./scripts/diagnose-explorer-artifacts.sh SF-02
```

### What Changed

**Before:**
- Explorer generates `SF-02_locators.json`
- ❌ Generator Agent ignores it
- ❌ Manual locator creation required
- ❌ No automated workflow

**After:**
- Explorer generates `SF-02_locators.json` ✅
- Pre-generation hook processes it automatically ✅
- TypeScript locator modules generated with confidence scoring ✅
- Self-healing strategies applied ✅
- Full workflow automated ✅

### Remaining Work

1. **Fix Explorer Artifacts** - Re-run Explorer Agent to capture complete New Lead form
2. **Update Generator Agent** - Implement hook invocation in agent code
3. **Add CI/CD Integration** - Create GitHub Actions workflow

## Configuration

### Healing Strategies

| Strategy | Retries | Delay | Fallback Depth | Use Case |
|----------|---------|-------|----------------|----------|
| `aggressive` | 5 | 100ms | 7 locators | Fast-changing UIs, CI |
| `standard` | 3 | 250ms | 5 locators | General purpose (default) |
| `conservative` | 2 | 500ms | 3 locators | Stable UIs |

### Locator Priority Order

1. `data-testid` (1.0) - Most stable
2. `data-test` (0.95)
3. `id` (0.9) - If not auto-generated
4. `role` (0.85) - ARIA role + name
5. `aria-label` (0.8)
6. `placeholder` (0.75)
7. `label` (0.7)
8. `name` (0.65)
9. `text` (0.6)
10. `title` (0.55)
11. `css` (0.4) - Less stable
12. `xpath` (0.2) - Last resort

## Best Practices

1. **Always run Explorer Agent first** - Capture DOM snapshots before manual coding
2. **Run Locator Strategy Builder** - Generate locator modules from artifacts
3. **Use generated locators in Page Objects** - Import from generated modules
4. **Store field values** - Enable automatic retry on validation errors
5. **Configure appropriately** - Adjust healing strategy based on environment
6. **Monitor warnings** - Update primary locators when fallbacks are used

## Troubleshooting

### Locator not found
- Check if Explorer Agent captured the element
- Verify element is in `SF-<ISSUE>_locators.json`
- Re-run Explorer Agent if element is missing
- Update locator module manually if needed

### Primary locator fails
- WARNING logged automatically
- Fallback locators tried automatically
- Review logs to understand which fallback succeeded
- Update primary locator based on successful fallback

### Validation errors persist
- Check field values are stored correctly
- Verify error dialog selectors
- Ensure `normalizeFieldKey` maps display names correctly
- Add custom retry logic for complex fields

## Future Enhancements

1. **Auto-detection** - Automatically detect when Explorer artifacts change
2. **Hot reload** - Regenerate locators on artifact updates
3. **Visual feedback** - Dashboard showing locator health
4. **ML-based suggestions** - Learn from failures to suggest better locators
5. **Cross-browser optimization** - Different strategies per browser
