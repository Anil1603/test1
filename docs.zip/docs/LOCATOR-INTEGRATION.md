# Self-Healing Locator Strategy - Integration Guide

## Overview

This guide explains how to properly integrate Explorer Agent artifacts with the self-healing locator strategy and Page Objects.

## Complete Integration Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        PHASE 3: EXPLORER AGENT                          │
│  Input: User Story (SF-02), Test Plan, Base URL                         │
│  Output: DOM Analysis Artifacts                                         │
├─────────────────────────────────────────────────────────────────────────┤
│  Actions:                                                               │
│  1. Analyze DOM structure using Playwright MCP                          │
│  2. Identify interactive elements with priority scoring                 │
│  3. Generate YAML snapshots (.playwright-mcp/dom-snapshots/)            │
│  4. Generate JSON locator manifests (dom-analysis/locators/)            │
│  5. Generate markdown analysis (dom-analysis/*-analysis.md)             │
│  6. Emit handoff JSON (handoff-data/phase3-to-phase4-SF-02.json)        │
└─────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   PHASE 4: GENERATOR AGENT (PRE-HOOKS)                  │
│  Reads: .github/hooks/agent-hooks.json                                  │
│  Executes: Pre-generation hooks before creating Page Objects            │
├─────────────────────────────────────────────────────────────────────────┤
│  Hook 1: Convert Explorer Artifacts                                     │
│    Script: scripts/utils/convert-explorer-artifacts.ts                  │
│    Input:  dom-analysis/locators/SF-02_locators.json                    │
│    Output: tests/helpers/locators/SF-02-*-locators.ts (initial)         │
│    Action: Transform JSON elements to TypeScript selector arrays        │
│                                                                          │
│  Hook 2: Build Locator Strategies                                       │
│    Script: scripts/agents/generator/locator-strategy-builder.ts         │
│    Input:  dom-analysis/dom-snapshots/SF-02_*.yaml                      │
│            tests/helpers/locators/SF-02-*-locators.ts (from Hook 1)     │
│    Output: tests/helpers/locators/SF-02-*-locators.ts (enhanced)        │
│            tests/helpers/locators/SF-02-*-locators.json                 │
│            tests/helpers/locators/SF-02-locator-manifest.json           │
│    Action: Apply confidence scoring, create fallback chains             │
└─────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                PHASE 4: GENERATOR AGENT (CODE GENERATION)               │
│  Input: Generated locator modules from pre-hooks                        │
│  Output: Page Objects, Handlers, Specs, Test Data                       │
├─────────────────────────────────────────────────────────────────────────┤
│  Actions:                                                               │
│  1. Load locator manifest (confidence, coverage stats)                  │
│  2. Generate Page Objects importing generated locators                  │
│     - tests/pages/lead-new.ts imports SF-02-newlead-locators           │
│     - tests/pages/login-page.ts imports SF-02-login-locators           │
│  3. Generate Handlers using Page Objects                                │
│  4. Generate Specs using Handlers                                       │
│  5. Generate Test Data (JSON)                                           │
│  6. Run preflight checks (tsc, eslint)                                  │
│  7. Emit handoff JSON (handoff-data/phase4-to-phase5-SF-02.json)        │
└─────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      RUNTIME: TEST EXECUTION                            │
│  Playwright runs tests/ with self-healing locator strategy              │
├─────────────────────────────────────────────────────────────────────────┤
│  Flow:                                                                  │
│  1. Test imports Page Object (e.g., LeadNewPage)                        │
│  2. Page Object imports resolveLocator from generated module            │
│     const { resolveLocator } = require('SF-02-newlead-locators')       │
│  3. Page method calls resolveLocator('country')                         │
│  4. resolveLocator uses self-healing-locator.ts utility                 │
│  5. Self-healing tries: Primary → Secondary → Tertiary → Fallbacks      │
│  6. Each attempt: Wait → Check visibility → Retry on failure            │
│  7. If validation error: Detect → Close dialog → Re-fill → Retry        │
│  8. Return working Locator or throw after max retries                   │
└─────────────────────────────────────────────────────────────────────────┘
```

## Key Principles

1. **Separation of Concerns**:
   - Explorer Agent: Capture DOM structure
   - Converter Script: Transform JSON to TypeScript
   - Strategy Builder: Apply self-healing patterns
   - Page Objects: Use generated locators
   - Self-Healing Utility: Runtime resolution

2. **Automation Over Manual**:
   - Locators auto-generated from DOM analysis
   - Confidence scoring applied automatically
   - Fallback chains created by algorithm
   - Only overrides should be manual

3. **Continuous Improvement**:
   - Monitor fallback usage in test runs
   - Update Explorer Agent when UI changes
   - Re-run hooks to refresh locators
   - Adjust confidence thresholds based on results

## Current State vs. Intended Architecture

### ⚠️ Current Reality

Currently, the locator files in `tests/helpers/locators/` are **manually created** and do NOT use the Explorer Agent artifacts. This works but loses the automation benefits.

**Files:**
- ✅ `tests/helpers/self-healing-locator.ts` - Self-healing utility (working)
- ✅ `tests/helpers/locators/SF-02-*-locators.ts` - Manual locators (working but not auto-generated)
- ✅ `tests/pages/*.ts` - Page Objects (working, using manual locators)
- ⚠️ `dom-analysis/locators/SF-02_locators.json` - Explorer output (incomplete)
- ❌ `scripts/agents/generator/locator-strategy-builder.ts` - Builder script (not executed)
- ❌ Integration between Explorer → Generator (missing)

### 🎯 Intended Architecture

The proper workflow should be:

```
Explorer Agent → Locator Strategy Builder → Page Objects
     ↓                    ↓                       ↓
  Artifacts        Generated Locators    Uses Generated Locators
```

## Problem Analysis

### Issue #1: Incomplete Explorer Output

The `SF-02_locators.json` only contains login page elements:

```json
{
  "storyId": "SF-02",
  "pages": [
    {
      "pageName": "LoginPage",
      "elements": [
        {"description": "username", "locator": "#username"},
        {"description": "password", "locator": "#password"}
        // ❌ Missing: firstName, lastName, country, email, salutation, etc.
      ]
    }
  ]
}
```

**Root Cause:** Explorer Agent captured snapshots at the wrong time OR the New Lead form fields were not visible/expanded when snapshots were taken.

### Issue #2: Missing Integration

Generated locators are not being consumed by Page Objects.

## Proper Workflow

### Step 1: Run Explorer Agent (Phase 3)

The Explorer Agent should:
1. Navigate to each page
2. Wait for dynamic content to load
3. Interact with forms to expand all sections
4. Capture full DOM snapshots
5. Extract ALL form fields with multiple locator strategies

**Command:**
```bash
# This should be run by the Explorer Agent
# Example invocation (pseudo-code):
npx tsx scripts/agents/explorer/run-exploration.ts \
  --story SF-02 \
  --pages "login,home,leads-list,new-lead-modal" \
  --wait-for-dynamic-content
```

**Expected Output:**
```
dom-analysis/
├── SF-02-login-analysis.md
├── SF-02-home-analysis.md
├── SF-02-leads-list-analysis.md
├── SF-02-newlead-analysis.md            # Should capture ALL form fields
├── locators/
│   └── SF-02_locators.json              # Should include all pages + fields
└── dom-snapshots/
    ├── SF-02_LoginPage_*.json
    ├── SF-02_NewLeadModal_*.json        # Should capture expanded form
    └── ...
```

### Step 2: Convert Explorer Artifacts (Bridge Gap)

Use the converter utility to transform Explorer JSON into self-healing locator modules:

```bash
npx tsx scripts/utils/convert-explorer-artifacts.ts \
  --story SF-02 \
  --input-dir dom-analysis \
  --output-dir tests/helpers/locators
```

**What this does:**
- Reads `dom-analysis/locators/SF-02_locators.json`
- Groups elements by field key (username, password, country, etc.)
- Generates multiple fallback selectors per field
- Creates TypeScript locator modules
- Outputs to `tests/helpers/locators/SF-02-*-locators.ts`

**Example Output:**
```typescript
// tests/helpers/locators/SF-02-newlead-locators.ts  (auto-generated)

export const locators: Record<string, string[]> = {
  country: [
    'css=input[aria-label="Country"]',
    'css=input[placeholder="Search Countries..."]',
    'xpath=//input[@role="combobox" and @aria-label="Country"]'
  ],
  firstName: [
    'label=First Name',
    'css=input[name="FirstName"]',
    'xpath=//label[contains(., "First Name")]/following::input[1]'
  ]
  // ... more fields
};

export const resolveLocator = createLocatorResolver(locators);
```

### Step 3: Use Generated Locators in Page Objects

Page Objects should import from generated locator modules:

```typescript
// tests/pages/lead-new.ts

import { resolveLocator } from '../helpers/locators/SF-02-newlead-locators';
import { detectValidationErrors, closeValidationErrorDialog } from '../helpers/self-healing-locator';

export class LeadNewPage {
  async fillField(key: string, value: string) {
    const locator = await resolveLocator(this.page, key, {
      maxRetries: 3,
      retryDelayMs: 500,
      logAttempts: true
    });
    
    if (!locator) {
      throw new Error(`Field "${key}" not found using self-healing strategy`);
    }
    
    await locator.fill(value);
  }
}
```

### Step 4: Run Tests & Monitor

When tests run:
1. Self-healing utility tries Primary locator
2. If fails → logs attempt and tries Secondary
3. If fails → tries Tertiary
4. If fallback succeeds → logs WARNING to update primary
5. All attempts logged for analysis

**Example Output:**
```
[Self-Healing] Attempt 1: Trying Primary locator for "country"
  Selector: css=input[aria-label="Country"]
[Self-Healing] ✓ Success with Primary locator on attempt 1

[Self-Healing] Attempt 1: Trying P locator for "salutation"
  Selector: role=combobox[name="Salutation"]
[Self-Healing] ✗ Failed: Timeout waiting for element
[Self-Healing] Waiting 500ms before retry...
[Self-Healing] Attempt 2: Trying Primary locator for "salutation"
[Self-Healing] ✗ Failed: Timeout waiting for element
[Self-Healing] Moving to next locator strategy...
[Self-Healing] Attempt 4: Trying Secondary locator for "salutation"
  Selector: css=input[role="combobox"][aria-label*="Salutation"]
[Self-Healing] ✓ Success with Secondary locator on attempt 4
[Self-Healing] WARNING: Primary locator failed. Consider updating.
```

### Step 5: Update Locators Based on Failures

When fallback locators are used, update the generated files OR re-run Explorer Agent to capture better locators.

**Option A: Manual Update**
Edit the generated file and swap primary/secondary:

```typescript
// Before
salutation: [
  'role=combobox[name="Salutation"]',  // Primary (failing)
  'css=input[role="combobox"][aria-label*="Salutation"]'  // Secondary (working)
]

// After
salutation: [
  'css=input[role="combobox"][aria-label*="Salutation"]',  // Now primary
  'role=combobox[name="Salutation"]'  // Now fallback
]
```

**Option B: Re-run Explorer**
Capture updated artifacts with better locators:

```bash
# Re-run exploration
# Update locator manifest
# Re-generate locator modules
npx tsx scripts/utils/convert-explorer-artifacts.ts --story SF-02
```

## Quick Start (Current State)

Since the Explorer artifacts are incomplete, here's how to work with the current manual locators:

### Current Working Flow

1. **Manual Locator Creation** (already done):
   ```typescript
   // tests/helpers/locators/SF-02-newlead-locators.ts
   export const locators: Record<string, string[]> = {
     country: [
       'css=input[role="combobox"][aria-label="Country"]',
       'css=input[placeholder="Search Countries..."]',
       // ... more fallbacks
     ]
   };
   export const resolveLocator = createLocatorResolver(locators);
   ```

2. **Page Object Usage** (already working):
   ```typescript
   import { resolveLocator } from '../helpers/locators/SF-02-newlead-locators';
   
   async fillField(key: string, value: string) {
     const locator = await resolveLocator(this.page, key);
     // ...
   }
   ```

3. **Run Tests**:
   ```bash
   npx playwright test tests/test-1.spec.ts
   ```

### When Explorer Artifacts are Complete

1. **Run Converter**:
   ```bash
   npx tsx scripts/utils/convert-explorer-artifacts.ts --story SF-02
   ```

2. **Review Generated Files**:
   ```bash
   ls -la tests/helpers/locators/SF-02-*-locators.ts
   ``` 3. **Replace Manual Locators** with generated ones

4. **Update Imports** in Page Objects (if filenames changed)

5. **Run Tests** to verify

## File Relationships

```
┌─────────────────────────────────────────────────────────────┐
│ Explorer Agent Artifacts (Input)                            │
├─────────────────────────────────────────────────────────────┤
│ dom-analysis/locators/SF-02_locators.json                  │
│   Contains: Elements with single locator per element        │
│   Problem: Currently incomplete (only login page)           │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ Converter Script (Bridge)                                   │
├─────────────────────────────────────────────────────────────┤
│ scripts/utils/convert-explorer-artifacts.ts                 │
│   Reads: Explorer JSON                                      │
│   Generates: TypeScript locator modules with fallbacks      │
│   Output: tests/helpers/locators/SF-02-*-locators.ts       │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ Generated Locator Modules (Currently Manual)                │
├─────────────────────────────────────────────────────────────┤
│ tests/helpers/locators/SF-02-login-locators.ts             │
│ tests/helpers/locators/SF-02-home-locators.ts              │
│ tests/helpers/locators/SF-02-leadslist-locators.ts         │
│ tests/helpers/locators/SF-02-newlead-locators.ts           │
│   Contains: Multiple fallback selectors per field           │
│   Uses: createLocatorResolver() from self-healing-locator   │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ Self-Healing Utility (Runtime)                              │
├─────────────────────────────────────────────────────────────┤
│ tests/helpers/self-healing-locator.ts                       │
│   Exports:                                                   │
│   - resolveSelfHealingLocator()                             │
│   - createLocatorResolver()                                 │
│   - detectValidationErrors()                                │
│   - closeValidationErrorDialog()                            │
│   Features:                                                  │
│   - Primary/Secondary/Tertiary locator resolution           │
│   - Configurable retries                                    │
│   - Scroll into view                                        │
│   - Stability waiting                                       │
│   - Detailed logging                                        │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ Page Objects (Test Code)                                    │
├─────────────────────────────────────────────────────────────┤
│ tests/pages/lead-new.ts                                     │
│ tests/pages/login-page.ts                                   │
│ tests/pages/home-page.ts                                    │
│   Imports: resolveLocator from generated modules            │
│   Uses: await resolveLocator(page, 'fieldName', config)    │
│   Features:                                                  │
│   - Field value memory                                      │
│   - Validation error recovery                               │
│   - Automatic retry on save errors                          │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│ Test Specs (Execution)                            │
├─────────────────────────────────────────────────────────────┤
│ tests/test-1.spec.ts                                        │
│ tests/specs/lead/SF-02-create-lead.spec.ts                 │
│   Uses: Page Objects                                        │
│   Runs: Playwright test execution                           │
│   Output: Test results + self-healing logs                  │
└─────────────────────────────────────────────────────────────┘
```

## Benefits of Full Integration

### When Properly Integrated:

✅ **Automated Locator Generation** - No manual locator creation
✅ **Consistent Strategy** - All locators use same priority  
✅ **Fallback Coverage** - Every element has 3-5 fallback strategies
✅ **Confidence Scores** - Know which locators are most stable
✅ **Easy Updates** - Re-run converter when UI changes
✅ **Traceability** - Link from test failure → Explorer artifact

### Current Partial Benefits:

✅ **Self-Healing Works** - Primary/Secondary/Tertiary fallback strategy operational
✅ **Validation Recovery** - Auto-retry on form validation errors
✅ **Detailed Logging** - See which locators succeed/fail
⚠️ **Manual Maintenance** - Locators created manually, not from artifacts

## Generator Agent Integration

### How Generator Agent Should Invoke Utilities

The Generator Agent (GPT-4.1) must run these scripts as **pre-generation hooks** before creating Page Objects:

#### Hook Sequence:

```bash
# 1. Convert Explorer artifacts to initial locator modules
npx tsx scripts/utils/convert-explorer-artifacts.ts \
  --story SF-02 \
  --input-dir dom-analysis \
  --output-dir tests/helpers/locators

# 2. Build self-healing locator strategies with confidence scoring
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story SF-02 \
  --dom-analysis dom-analysis \
  --output-dir tests/helpers/locators \
  --healing-strategy standard \
  --format both \
  --min-confidence 0.5 \
  --max-fallbacks 3

# 3. Verify generated artifacts
ls -la tests/helpers/locators/SF-02-*.ts
cat tests/helpers/locators/SF-02-locator-manifest.json
```

#### Expected Outputs:

After running pre-generation hooks, you should have:

```
tests/helpers/locators/
├── SF-02-login-locators.ts
├── SF-02-login-locators.json
├── SF-02-home-locators.ts
├── SF-02-home-locators.json
├── SF-02-leadslist-locators.ts
├── SF-02-leadslist-locators.json
├── SF-02-newlead-locators.ts
├── SF-02-newlead-locators.json
├── SF-02-locators-index.ts              # Combined index
└── SF-02-locator-manifest.json          # Generation manifest
```

#### Generator Agent Workflow:

```typescript
// Pseudo-code for Generator Agent behavior

async function generateTestCode(storyId: string) {
  // Step 1: Run pre-generation hooks
  console.log('Running pre-generation hooks...');
  
  await runCommand(
    `npx tsx scripts/utils/convert-explorer-artifacts.ts --story ${storyId}`
  );
  
  await runCommand(
    `npx tsx scripts/agents/generator/locator-strategy-builder.ts --story ${storyId} --healing-strategy standard`
  );
  
  // Step 2: Verify generated locator modules exist
  const locatorFiles = glob(`tests/helpers/locators/${storyId}-*-locators.ts`);
  if (locatorFiles.length === 0) {
    throw new Error('Locator generation failed - no modules created');
  }
  
  // Step 3: Load locator manifest for confidence analysis
  const manifest = readJSON(`tests/helpers/locators/${storyId}-locator-manifest.json`);
  console.log(`Avg confidence: ${manifest.statistics.avgConfidence}`);
  
  // Step 4: Generate Page Objects that import generated locators
  for (const page of manifest.pages) {
    generatePageObject(page, storyId);
  }
  
  // Step 5: Generate test specs
  generateSpecs(storyId);
  
  // Step 6: Run preflight checks
  await runCommand('npx tsc --noEmit');
  await runCommand('npx eslint tests/**/*.ts');
  
  // Step 7: Emit handoff JSON
  emitHandoff(storyId, manifest);
}
```

### Configuration for Agent Hooks

**File:** `.github/hooks/agent-hooks.json`

```json
{
  "version": "1.0",
  "agents": {
    "generator": {
      "name": "Generator Agent",
      "phase": 4,
      "hooks": {
        "pre-generation": {
          "enabled": true,
          "hooks": [
            {
              "name": "Convert Explorer Artifacts",
              "script": "scripts/utils/convert-explorer-artifacts.ts",
              "required": true,
              "args": ["--story", "$STORY_ID", "--output-dir", "tests/helpers/locators"],
              "timeout": 30000,
              "onFailure": "abort"
            },
            {
              "name": "Build Locator Strategies",
              "script": "scripts/agents/generator/locator-strategy-builder.ts",
              "required": true,
              "args": [
                "--story", "$STORY_ID",
                "--healing-strategy", "standard",
                "--format", "both",
                "--min-confidence", "0.5",
                "--max-fallbacks", "3"
              ],
              "timeout": 60000,
              "onFailure": "abort"
            }
          ]
        }
      }
    }
  }
}
```

### Validation Points

After hooks complete, Generator Agent should verify:

| Validation | Command | Pass Criteria |
|------------|---------|---------------|
| Locator modules exist | `ls tests/helpers/locators/SF-02-*-locators.ts` | ≥ 1 file found |
| Manifest exists | `ls tests/helpers/locators/SF-02-locator-manifest.json` | File exists |
| Avg confidence | `jq '.statistics.avgConfidence' manifest.json` | ≥ 0.6 |
| Low confidence count | `jq '.statistics.lowConfidence' manifest.json` | < 10% of total |
| TypeScript compile | `npx tsc --noEmit tests/helpers/locators/*.ts` | Exit code 0 |

## Current Implementation Status

### ✅ Fully Implemented:

1. **Self-Healing Locator Utility** - Production ready:
   - Primary/Secondary/Tertiary fallback logic
   - Configurable retries and delays
   - Element stability waiting
   - Scroll into view
   - Validation error detection
   - Error dialog closing

2. **Page Objects** - Using self-healing strategy:
   - Field value memory for retry
   - Combobox handling with dropdown selection
   - Validation error recovery
   - Multiple selector strategies per field

3. **Locator Modules** - Using self-healing utility:
   - `SF-02-login-locators.ts`
   - `SF-02-home-locators.ts`
   - `SF-02-leadslist-locators.ts`
   - `SF-02-newlead-locators.ts`

4. **Converter Script** - ✅ Ready and working:
   - File: `scripts/utils/convert-explorer-artifacts.ts`
   - Status: Fully implemented, invoked by strategy builder

5. **Locator Strategy Builder** - ✅ Ready and working:
   - File: `scripts/agents/generator/locator-strategy-builder.ts`
   - Status: Fully implemented with confidence scoring

6. **Agent Hook Scripts** - ✅ All created:
   - `.github/hooks/scripts/planner-pre-planning.sh`
   - `.github/hooks/scripts/explorer-pre-exploration.sh`
   - `.github/hooks/scripts/generator-pre-generation.sh`
   - Status: Ready to be invoked by agents

7. **Integration Scripts** - ✅ All created:
   - `scripts/test-integration-workflow.sh` - Full workflow demo
   - `scripts/manual-locator-generation.sh` - Manual regeneration
   - `scripts/diagnose-explorer-artifacts.sh` - Diagnostics
   - Status: Executable and documented

8. **Documentation** - ✅ Complete:
   - `docs/INTEGRATION-WORKFLOW.md` - Step-by-step guide
   - `docs/LOCATOR-INTEGRATION.md` - This file
   - `docs/ARCHITECTURE.md` - System architecture
   - `docs/README.md` - Quick reference
   - `scripts/README.md` - Script documentation

### ⚠️ Known Issues:

1. **Incomplete Explorer Artifacts** - New Lead form fields incomplete
   - Issue: `SF-02_locators.json` only contains login page elements
   - Root cause: Explorer captured login page instead of authenticated pages
   - Solution: Re-run Explorer Agent after proper authentication
   - Tool: Use `./scripts/diagnose-explorer-artifacts.sh SF-02` to verify

### 🔄 Pending Actions:

1. **Re-run Explorer Agent** - Capture complete New Lead form fields
2. **Invoke Generator Agent** - Agent must read `.github/hooks/agent-hooks.json` 
3. **Test in CI/CD** - Integrate hooks into GitHub Actions pipeline

## Next Steps

### Immediate Actions

1. **Diagnose Current Artifacts**
   ```bash
   ./scripts/diagnose-explorer-artifacts.sh SF-02
   ```
   This will analyze Explorer output and identify issues.

2. **Re-run Explorer Agent** (if artifacts incomplete)
   - Ensure user is authenticated before capturing pages
   - Capture New Lead modal when fully rendered
   - Verify all form sections are visible
   - Wait for SLDS components to fully load

3. **Test Complete Workflow**
   ```bash
   ./scripts/test-integration-workflow.sh SF-02 https://test.salesforce.com standard no
   ```
   This demonstrates the full integration from Explorer → Generator → Tests.

4. **Verify Generated Locators**
   ```bash
   ls -lh tests/helpers/locators/SF-02-*-locators.ts
   cat tests/helpers/locators/SF-02-locator-manifest.json | jq '.statistics'
   ```

5. **Run Tests with Self-Healing**
   ```bash
   npx playwright test tests/test-1.spec.ts --headed
   ```

### Implementation Checklist

- [x] Self-healing locator utility created
- [x] Page Objects using self-healing strategy  
- [x] Converter script implemented
- [x] Locator Strategy Builder implemented
- [x] Pre-generation hook script created
- [x] Pre-exploration hook script created
- [x] Pre-planning hook script created
- [x] Integration workflow script created
- [x] Manual regeneration script created
- [x] Diagnostics script created
- [x] Complete documentation written
- [ ] Explorer artifacts complete (waiting on re-run)
- [ ] Generator Agent reads hook configuration (pending agent update)
- [ ] CI/CD pipeline integration (pending workflow creation)

### Continuous Improvement

1. **Monitor Test Runs** - Look for locator fallback warnings
2. **Update Primary Locators** - When fallbacks consistently succeed
3. **Adjust Confidence Thresholds** - Based on real test results
4. **Re-run Explorer** - After UI changes
5. **Regenerate Locators** - Using manual-locator-generation.sh
6. **Track Metrics** - Average confidence, fallback usage, test flakiness

### Manual Hook Execution (For Testing):

```bash
# Test the full workflow manually
cd /path/to/salesforce-automation

# Step 1: Run converter
npx tsx scripts/utils/convert-explorer-artifacts.ts --story SF-02

# Step 2: Run strategy builder
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story SF-02 \
  --healing-strategy standard \
  --format both

# Step 3: Verify outputs
ls -la tests/helpers/locators/SF-02-*.ts
cat tests/helpers/locators/SF-02-locator-manifest.json | jq '.statistics'

# Step 4: Run tests
npx playwright test tests/test-1.spec.ts --headed
```

## References

- [ARCHITECTURE.md](ARCHITECTURE.md) - Complete system architecture
- [Self-Healing Locator Utility](../tests/helpers/self-healing-locator.ts) - Runtime resolution
- [Converter Script](../scripts/utils/convert-explorer-artifacts.ts) - Explorer→TypeScript converter
- [Strategy Builder](../scripts/agents/generator/locator-strategy-builder.ts) - Confidence scoring & fallbacks
- [Agent Hooks Config](../.github/hooks/agent-hooks.json) - Pre/post hook definitions
- [Explorer Agent Instructions](../.github/instructions/explorer-agent.instructions.md) - Phase 3 guide
- [Generator Agent Instructions](../.github/instructions/generator-agent.instructions.md) - Phase 4 guide
- [Generator Agent Definition](../.github/agents/generator.agent.md) - Agent configuration
