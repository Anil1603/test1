# Documentation Index

## 🎯 Quick Links

- **[IMPLEMENTATION-SUMMARY.md](IMPLEMENTATION-SUMMARY.md)** - ⭐ What was implemented and why
- **[INTEGRATION-WORKFLOW.md](INTEGRATION-WORKFLOW.md)** - Complete workflow guide with step-by-step instructions
- **[LOCATOR-INTEGRATION.md](LOCATOR-INTEGRATION.md)** - How Explorer artifacts connect to self-healing locators
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Complete system architecture and data flow

## TL;DR - What You Need to Know

### ✅ Fully Implemented & Ready

**Self-healing locator strategy** - Production ready with:
- ✅ Primary → Secondary → Tertiary fallback resolution  
- ✅ Automatic retries with configurable delays
- ✅ Validation error detection and recovery
- ✅ Field value memory for auto-retry
- ✅ Detailed logging

**Complete Integration Workflow** - All scripts created:
- ✅ `scripts/test-integration-workflow.sh` - Full workflow demo
- ✅ `scripts/manual-locator-generation.sh` - Regenerate locators
- ✅ `scripts/diagnose-explorer-artifacts.sh` - Diagnostics tool
- ✅ `.github/hooks/scripts/*.sh` - All agent hook scripts
- ✅ `scripts/agents/generator/locator-strategy-builder.ts` - Strategy builder
- ✅ `scripts/utils/convert-explorer-artifacts.ts` - Artifact converter

**Complete Documentation**:
- ✅ `docs/INTEGRATION-WORKFLOW.md` - Step-by-step guide (⭐ START HERE)
- ✅ `docs/LOCATOR-INTEGRATION.md` - Technical integration details  
- ✅ `docs/ARCHITECTURE.md` - System design
- ✅ `scripts/README.md` - Script reference

### ⚠️ Current Locators Status

**Working but manually created** - Locator files exist and work:
- `tests/helpers/locators/SF-02-*-locators.ts` - Hand-crafted with self-healing
- Tests run successfully with self-healing fallback logic
- Validation error recovery works

**Why not auto-generated yet?**
- Explorer Agent artifacts incomplete (only login page captured)
- Need to re-run Explorer Agent after proper authentication
- Then run: `./scripts/manual-locator-generation.sh SF-02`

### 🔄 Next Actions

1. **Diagnose artifacts:** `./scripts/diagnose-explorer-artifacts.sh SF-02`
2. **Re-run Explorer Agent** (if artifacts incomplete)
3. **Test workflow:** `./scripts/test-integration-workflow.sh SF-02`
4. **Run tests:** `npx playwright test`

### How It Works Right Now

```typescript
// 1. Manually defined locators with fallbacks
// tests/helpers/locators/SF-02-newlead-locators.ts
export const locators: Record<string, string[]> = {
  country: [
    'css=input[role="combobox"][aria-label="Country"]',        // Try first
    'css=input[placeholder="Search Countries..."]',             // Try second
    'css=input.slds-combobox__input[aria-label="Country"]'    // Try third
  ]
};

// 2. Page Object uses self-healing resolver
const locator = await resolveLocator(this.page, 'country', {
  maxRetries: 3,           // 3 tries per strategy
  retryDelayMs: 500,       // 500ms between retries
  logAttempts: true        // Log every attempt
});

// 3. Runtime resolution
// - Tries Primary 3 times (with 500ms delays)
// - If fails, tries Secondary 3 times
// - If fails, tries Tertiary 3 times
// - Logs which one succeeded
// - Returns resolved Locator
```

### How It SHOULD Work

```
Explorer Agent → Converter → Generated Locators → Page Objects
     (DOM)          ↓            (TypeScript)         ↓
                Convert                            Use Self
                Artifacts                         -Healing
```

**Missing Step:** Running the converter to bridge Explorer artifacts and generated locators.

## File Organization

```
tests/helpers/
├── self-healing-locator.ts           # ✅ Core self-healing utility
├── locators/
│   ├── SF-02-login-locators.ts       # ⚠️  Manual (should be generated)
│   ├── SF-02-home-locators.ts        # ⚠️  Manual (should be generated)
│   ├── SF-02-leadslist-locators.ts   # ⚠️  Manual (should be generated)
│   └── SF-02-newlead-locators.ts     # ⚠️  Manual (should be generated)

dom-analysis/
├── locators/
│   └── SF-02_locators.json           # ⚠️  Incomplete (only login page)
└── dom-snapshots/                    # ✅ DOM snapshots exist

scripts/
├── agents/generator/
│   └── locator-strategy-builder.ts  # ❌ Not executed yet
└── utils/
    └── convert-explorer-artifacts.ts # ✅ New converter script

docs/
├── README.md                         # 📖 This file
├── LOCATOR-INTEGRATION.md            # 📖 Integration guide
└── ARCHITECTURE.md                   # 📖 System architecture
```

## Key Features

### Self-Healing Strategy

- **Primary Locator**: Most reliable (e.g., `aria-label`, `data-testid`)
- **Secondary Locator**: Good fallback (e.g., `placeholder`, `role`)
- **Tertiary Locator**: Last resort (e.g., `xpath`, complex CSS)
- **Configurable Retries**: 3 retries per locator (default)
- **Smart Delays**: Waits between retries
- **Automatic Scrolling**: Scrolls elements into view
- **Stability Waiting**: Waits for animations to complete
- **Detailed Logging**: See every attempt and result

### Validation Error Recovery

When clicking Save triggers validation errors:
1. ✅ Detects error dialog automatically
2. ✅ Extracts list of fields with errors
3. ✅ Closes error dialog
4. ✅ Re-fills problematic fields from memory
5. ✅ Retries Save button
6. ✅ Verifies success

### Combobox Handling

For dropdown fields (Country, Salutation):
1. Clicks to open dropdown
2. Types to filter/search
3. Waits for options to appear
4. Tries multiple option selectors
5. Falls back to keyboard navigation
6. Verifies selection

## Common Tasks

### Run Tests

```bash
# Run specific test
npx playwright test tests/test-1.spec.ts

# Run with UI
npx playwright test tests/test-1.spec.ts --headed

# Run with debug
npx playwright test tests/test-1.spec.ts --debug
```

### Generate Locators from Artifacts (When Ready)

```bash
# Convert Explorer JSON to TypeScript locator modules
npx tsx scripts/utils/convert-explorer-artifacts.ts \
  --story SF-02 \
  --input-dir dom-analysis \
  --output-dir tests/helpers/locators
```

### Update Locator Priority

If a fallback locator works better than primary:

```typescript
// Before  
country: [
  'css=input[aria-label="Country"]',    // Failing
  'css=input[placeholder="..."]'        // Working <-- swap this up
]

// After
country: [
  'css=input[placeholder="..."]',       // Now primary
  'css=input[aria-label="Country"]'     // Now fallback
]
```

### Add New Field Locator

```typescript
// tests/helpers/locators/SF-02-newlead-locators.ts
export const locators: Record<string, string[]> = {
  // ... existing fields
  
  newField: [
    'css=input[aria-label="New Field"]',           // Primary
    'css=input[placeholder="Enter new field"]',    // Secondary
    'xpath=//label[text()="New Field"]/following::input[1]'  // Tertiary
  ]
};
```

Then use in Page Object:

```typescript
await this.fillField('newField', 'value');
```

## Configuration

### Self-Healing Config

```typescript
interface SelfHealingConfig {
  maxRetries: number;          // Retries per locator strategy (default: 3)
  retryDelayMs: number;        // Delay between retries (default: 500)
  visibilityTimeout: number;   // Element visibility timeout (default: 5000)
  logAttempts: boolean;        // Log all attempts (default: true)
  waitForStability?: boolean;  // Wait for animations (default: true)
  scrollIntoView?: boolean;    // Auto-scroll (default: true)
}
```

### Usage Example

```typescript
const locator = await resolveLocator(this.page, 'country', {
  maxRetries: 5,              // Try each locator 5 times
  retryDelayMs: 1000,         // Wait 1 second between retries
  visibilityTimeout: 15000,   // Wait up to 15s for visibility
  logAttempts: false,         // Suppress verbose logging
  waitForStability: true,     // Wait for element to be stable
  scrollIntoView: true        // Scroll into view if needed
});
```

## Troubleshooting

### Locator Not Found

**Q:** Getting "Locator not found for fieldName" error

**A:** 
1. Check if field key exists in locator module
2. Verify selectors in browser DevTools
3. Add new fallback selectors if needed
4. Run with `logAttempts: true` to see details

### Primary Locator Always Fails

**Q:** Seeing warnings about primary locator failing

**A:**
1. Check which fallback succeeds (look at logs)
2. Swap successful fallback up to primary position
3. Or re-run Explorer Agent to capture better locators

### Validation Errors Not Recovering

**Q:** Save fails with validation errors but doesn't retry

**A:**
1. Check error dialog selector in `detectValidationErrors()`
2. Verify field name mapping in `normalizeFieldKey()`
3. Ensure field values are stored in memory
4. Check `handleValidationErrors()` logic

### Combobox Not Selecting Value

**Q:** Dropdown opens but value not selected

**A:**
1. Increase wait times after opening dropdown
2. Try different option selectors
3. Check if dropdown is being filtered correctly
4. Use keyboard navigation fallback (Enter key)

## Performance Considerations

### Default Configuration (Balanced)

- 3 retries per locator strategy
- 500ms delay between retries
- 3 locator strategies (Primary, Secondary, Tertiary)
- **Worst case:** 3 strategies × 3 retries × 500ms = ~4.5 seconds per field

### Fast Configuration (CI/CD)

```typescript
{
  maxRetries: 2,
  retryDelayMs: 250,
  visibilityTimeout: 3000
}
// Worst case: ~1.5 seconds per field
```

### Stable Configuration (Flaky Envs)

```typescript
{
  maxRetries: 5,
  retryDelayMs: 1000,
  visibilityTimeout: 10000
}
// Worst case: ~15 seconds per field
```

## Getting Started

### Quick Start

```bash
# 1. Diagnose existing artifacts
./scripts/diagnose-explorer-artifacts.sh SF-02

# 2. Run complete integration workflow
./scripts/test-integration-workflow.sh SF-02 https://test.salesforce.com standard no

# 3. Manually regenerate locators (if needed)
./scripts/manual-locator-generation.sh SF-02 standard

# 4. Run tests
npx playwright test tests/test-1.spec.ts
```

### Step-by-Step Guide

See [INTEGRATION-WORKFLOW.md](INTEGRATION-WORKFLOW.md) for complete instructions on:
- Running the multi-agent workflow
- Using pre/post hooks
- Troubleshooting common issues
- Monitoring and maintenance

## Next Steps

1. ✅ **Integration implemented** - All hooks, scripts, and documentation created
2. **Diagnose artifacts** - Run `./scripts/diagnose-explorer-artifacts.sh SF-02`
3. **Re-run Explorer Agent** - Capture complete New Lead form fields (if incomplete)
4. **Test workflow** - Run `./scripts/test-integration-workflow.sh SF-02`
5. **Monitor & Tune** - Adjust strategies based on test results
6. **Iterate** - Continuously improve locator selector quality

## Questions?

See detailed guides:
- [INTEGRATION-WORKFLOW.md](INTEGRATION-WORKFLOW.md) - Complete workflow guide (⭐ START HERE)
- [LOCATOR-INTEGRATION.md](LOCATOR-INTEGRATION.md) - Step-by-step integration details
- [ARCHITECTURE.md](ARCHITECTURE.md) - System design and data flow
- [scripts/README.md](../scripts/README.md) - Script reference
