# Integration Workflow Guide

This guide explains how to use the complete automation workflow, from Explorer Agent through to Test Execution.

## Overview

The test automation framework uses a **multi-agent workflow** where each agent has specific responsibilities and hooks to ensure proper integration:

```
Phase 1: User Story Review (Manual)
   ↓
Phase 2: Test Planning (Planner Agent + RAG)
   ↓ [Pre-Planning Hook]
   ↓
Phase 3: DOM Analysis (Explorer Agent + Playwright MCP)
   ↓ [Pre-Exploration Hook]
   ↓
Phase 4: Code Generation (Generator Agent + Locator Builder)
   ↓ [Pre-Generation Hook] ← Locator Strategy Builder
   ↓
Phase 5: Test Execution (Playwright + Self-Healing Locators)
```

## Prerequisites

Before starting, ensure you have:

- [ ] Node.js 18+ and npm installed
- [ ] Playwright installed (`npm install`)
- [ ] RAG server running (optional, for Phase 2)
- [ ] User story file created in `user-stories/`
- [ ] Access to Salesforce environment

## Quick Start

### Option 1: Full Automated Workflow

Run the integration test script to execute all phases:

```bash
# Make script executable
chmod +x scripts/test-integration-workflow.sh

# Run full workflow
./scripts/test-integration-workflow.sh SF-02 https://test.salesforce.com standard yes

# Arguments:
#   $1 = Story ID (default: SF-02)
#   $2 = Base URL (default: https://test.salesforce.com)
#   $3 = Healing strategy: aggressive|standard|conservative (default: standard)
#   $4 = Run tests: yes|no (default: no)
```

### Option 2: Manual Step-by-Step

#### Phase 2: Test Planning

```bash
# Run Planner Agent pre-planning hook
.github/hooks/scripts/planner-pre-planning.sh --story SF-02

# Then invoke Planner Agent (via Copilot)
# Agent will generate:
#   - test-cases/SF-02-test-cases.md
#   - test-cases/SF-02-test-steps.json
#   - test-cases/SF-02-test-data.json
#   - handoff-data/phase2-to-phase3-SF-02.json
```

#### Phase 3: DOM Analysis

```bash
# Run Explorer Agent pre-exploration hook
.github/hooks/scripts/explorer-pre-exploration.sh \
  --story SF-02 \
  --base-url https://test.salesforce.com

# Then invoke Explorer Agent (via Copilot)
# Agent will use Playwright MCP to analyze pages and generate:
#   - dom-analysis/locators/SF-02_locators.json
#   - dom-analysis/dom-snapshots/*.json
#   - dom-analysis/SF-02-*-analysis.md
#   - handoff-data/phase3-to-phase4-SF-02.json
```

#### Phase 4.1: Locator Strategy Building

```bash
# Run Generator Agent pre-generation hook
.github/hooks/scripts/generator-pre-generation.sh \
  --story SF-02 \
  --healing-strategy standard \
  --min-confidence 0.5 \
  --max-fallbacks 3

# This runs locator-strategy-builder.ts which generates:
#   - tests/helpers/locators/SF-02-*-locators.ts
#   - tests/helpers/locators/SF-02-*-locators.json
#   - tests/helpers/locators/SF-02-locator-manifest.json
```

#### Phase 4.2: Code Generation

```bash
# Invoke Generator Agent (via Copilot)
# Agent will read generated locator modules and create:
#   - tests/pages/*.ts (Page Objects)
#   - tests/handlers/*.ts (Business flows)
#   - tests/specs/**/*.spec.ts (Test specs)
#   - tests/data/*_test_data.json (Test data)
```

#### Phase 5: Test Execution

```bash
# Run tests with Playwright
npx playwright test

# Run specific test
npx playwright test tests/test-1.spec.ts

# Run with UI mode
npx playwright test --ui

# Run with headed browser
npx playwright test --headed
```

## Manual Locator Generation

If you already have Explorer artifacts and just need to regenerate locator modules:

```bash
# Make script executable
chmod +x scripts/manual-locator-generation.sh

# Run manual generation
./scripts/manual-locator-generation.sh SF-02 standard

# Or run directly
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story SF-02 \
  --healing-strategy standard \
  --format both \
  --min-confidence 0.5 \
  --max-fallbacks 3
```

## Configuration

### Agent Hooks Configuration

The `.github/hooks/agent-hooks.json` file defines all hook configurations:

```json
{
  "hooks": {
    "planner-agent": {
      "pre-planning": {
        "script": ".github/hooks/scripts/planner-pre-planning.sh",
        "timeout": 300000
      }
    },
    "explorer-agent": {
      "pre-exploration": {
        "script": ".github/hooks/scripts/explorer-pre-exploration.sh",
        "timeout": 180000
      }
    },
    "generator-agent": {
      "pre-generation": {
        "script": ".github/hooks/scripts/generator-pre-generation.sh",
        "implementation": "scripts/agents/generator/locator-strategy-builder.ts",
        "timeout": 120000
      }
    }
  }
}
```

### Healing Strategies

| Strategy | Retries | Delay | Fallbacks | Use Case |
|----------|---------|-------|-----------|----------|
| `aggressive` | 5 | 100ms | 7 | Fast-changing UIs, CI/CD |
| `standard` | 3 | 250ms | 5 | General purpose (default) |
| `conservative` | 2 | 500ms | 3 | Stable UIs |

### Locator Confidence Thresholds

```typescript
// In generated locator manifest
{
  "statistics": {
    "avgConfidence": 0.75,  // Target: >= 0.6
    "highConfidence": 42,   // Elements with conf >= 0.7
    "lowConfidence": 8      // Elements with conf < 0.5
  }
}
```

## Troubleshooting

### Issue: Explorer Artifacts Incomplete

**Problem:** `SF-02_locators.json` only contains login page elements, missing New Lead form fields.

**Root Cause:** Explorer Agent captured snapshots at wrong time or before New Lead form was fully loaded.

**Solution:**

1. Re-run Explorer Agent with proper navigation flow
2. Ensure New Lead modal is open and fully rendered before snapshot
3. Wait for SLDS components to fully initialize
4. Verify snapshots in `dom-analysis/dom-snapshots/` show expected fields

**Manual Fix:**

```bash
# Delete incomplete artifacts
rm -f dom-analysis/locators/SF-02_locators.json
rm -rf dom-analysis/dom-snapshots/SF-02_*.json

# Re-run Explorer Agent (via Copilot)
# Ensure it captures New Lead form when fully loaded
```

### Issue: Locator Strategy Builder Fails

**Problem:** Script crashes or generates no output.

**Check:**

```bash
# Verify Explorer artifacts exist
ls -lh dom-analysis/locators/SF-02_locators.json
ls -lh dom-analysis/dom-snapshots/

# Check for JSON syntax errors
jq '.' dom-analysis/locators/SF-02_locators.json

# Run with verbose logging
DEBUG=* npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story SF-02 --healing-strategy standard
```

**Fix:**

1. Ensure Explorer artifacts are valid JSON
2. Check file permissions
3. Verify Node.js version (18+)
4. Clear node_modules and reinstall: `rm -rf node_modules && npm install`

### Issue: Generated Locators Not Working

**Problem:** Page Objects can't find elements even with generated locators.

**Debugging:**

```typescript
// In test spec, enable verbose logging
const locator = await resolveLocator(page, 'country', {
  maxRetries: 3,
  retryDelayMs: 500,
  logAttempts: true  // <- Enable this
});

// Check console output:
// [Self-Healing] Attempt 1/3 for locator strategy 1/3: css=input[...]
// [Self-Healing] Strategy 1 failed after 3 retries
// [Self-Healing] Trying fallback strategy 2/3...
```

**Fix:**

1. Review test output logs to see which locator succeeded
2. Update primary locator to use the successful fallback
3. Manually verify selector in browser DevTools
4. If element is in Shadow DOM, update locator to pierce shadows

### Issue: Low Average Confidence

**Problem:** `SF-02-locator-manifest.json` shows `avgConfidence < 0.6`.

**Causes:**

- Too many text-based locators (low confidence)
- Missing stable attributes (data-testid, aria-label)
- Elements without unique identifiers

**Solutions:**

1. Request developers add `data-testid` attributes
2. Use ARIA labels where available
3. Combine multiple attributes for uniqueness
4. Accept lower confidence for read-only elements
5. Manually override low-confidence locators

### Issue: TypeScript Compilation Errors

**Problem:** `tsc --noEmit` fails after generation.

**Common Errors:**

```
tests/helpers/locators/SF-02-newlead-locators.ts:10:5 - error TS2322
  Type 'string' is not assignable to type 'Locator'.
```

**Fix:**

```bash
# Check generated files
cat tests/helpers/locators/SF-02-newlead-locators.ts

# Ensure imports are correct
# Should have: import { createLocatorResolver } from '../self-healing-locator';

# Re-run strategy builder with --format typescript
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story SF-02 --format typescript
```

## Monitoring & Maintenance

### Monitor Self-Healing Usage

```bash
# Run tests and capture logs
npx playwright test 2>&1 | tee test-run.log

# Search for fallback usage
grep "fallback strategy" test-run.log

# Count fallback occurrences
grep -c "fallback strategy" test-run.log
```

If fallbacks are used frequently, update primary locators.

### Update Locator Strategies

```bash
# After UI changes, re-run Explorer Agent
# Then rebuild locator strategies
./scripts/manual-locator-generation.sh SF-02 standard

# Review diffs
git diff tests/helpers/locators/

# Commit if acceptable
git add tests/helpers/locators/
git commit -m "Update: Regenerate locators after UI changes"
```

### Quality Metrics

Track these metrics over time:

- **Average Confidence:** Should stay >= 0.7
- **Fallback Usage:** Should be < 5% of all locator resolutions
- **Test Flakiness:** Should decrease over time with self-healing
- **Locator Update Frequency:** Should decrease as locators stabilize

## Best Practices

### DO

✅ **Run Explorer Agent after every significant UI change**
✅ **Use `standard` healing strategy unless specific needs**
✅ **Store field values in Page Objects for retry logic**
✅ **Monitor test output for fallback warnings**
✅ **Update primary locators when fallbacks consistently succeed**
✅ **Use semantic field names (e.g., `country`, not `field3`)**
✅ **Validate generated artifacts before committing**

### DON'T

❌ **Don't skip pre-generation hooks - they're required**
❌ **Don't manually edit generated JSON manifests**
❌ **Don't ignore low confidence warnings**
❌ **Don't use `aggressive` strategy without understanding impact**
❌ **Don't commit failing tests**
❌ **Don't skip TypeScript compilation checks**

## File Structure Reference

```
.github/hooks/
├── agent-hooks.json                    # Hook configuration
└── scripts/
    ├── explorer-pre-exploration.sh     # Phase 3 pre-hook
    ├── generator-pre-generation.sh     # Phase 4 pre-hook
    └── planner-pre-planning.sh         # Phase 2 pre-hook

scripts/
├── agents/generator/
│   └── locator-strategy-builder.ts    # Core strategy builder
├── utils/
│   └── convert-explorer-artifacts.ts  # JSON → TypeScript converter
├── manual-locator-generation.sh       # Manual regeneration
└── test-integration-workflow.sh       # Full workflow demo

dom-analysis/
├── locators/
│   └── SF-02_locators.json            # Explorer output
├── dom-snapshots/
│   └── SF-02_*.json                   # DOM snapshots
└── SF-02-*-analysis.md                # Human-readable analysis

tests/helpers/locators/
├── SF-02-login-locators.ts            # Generated per-page locators
├── SF-02-home-locators.ts
├── SF-02-leadslist-locators.ts
├── SF-02-newlead-locators.ts
├── SF-02-locator-manifest.json        # Generation metadata
└── SF-02-locators-index.ts            # Combined index (optional)

tests/
├── pages/                             # Page Objects using locators
├── handlers/                          # Business flow handlers
├── specs/                             # Test specifications
└── data/                              # Test data files

docs/
├── INTEGRATION-WORKFLOW.md            # This file
├── LOCATOR-INTEGRATION.md             # Detailed integration guide
├── ARCHITECTURE.md                    # System architecture
└── README.md                          # Quick reference
```

## Next Steps

After implementing this integration:

1. ✅ **Test the workflow** - Run `./scripts/test-integration-workflow.sh`
2. ✅ **Fix Explorer artifacts** - Re-run Explorer to capture complete form fields
3. ✅ **Validate locators** - Ensure generated locators work in real tests
4. ✅ **Train team** - Share documentation with QA and dev teams
5. ✅ **Automate in CI/CD** - Integrate hooks into GitHub Actions
6. ✅ **Monitor metrics** - Track confidence, fallback usage, flakiness
7. ✅ **Iterate** - Continuously improve based on test results

## Support

For issues or questions:

- Review [LOCATOR-INTEGRATION.md](LOCATOR-INTEGRATION.md) for detailed integration guide
- Review [ARCHITECTURE.md](ARCHITECTURE.md) for system design details
- Check `.github/hooks/agent-hooks.json` for hook configuration
- Search test output logs for self-healing warnings
- Run scripts with verbose logging for debugging

---

**Version:** 1.0  
**Last Updated:** February 12, 2026  
**Maintained By:** Test Automation Team
