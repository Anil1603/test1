// Xray Test Repository Configuration
// Copy this file to config.js and update with your project's Xray folder name

module.exports = {
    // The name of your Xray Test Repository folder where tests should be organized
    // Examples: 'ciamAutomation', 'ShoppingCart', 'UserManagement', etc.
    xrayFolderName: 'BFOFS Functional Testing',
    
    // Optional: Custom field ID for test steps (default: customfield_11320)
    // Only change if your Jira instance uses a different field ID
    // Run 'node scripts/discover-fields.cjs' to find the correct field ID
    testStepsFieldId: 'customfield_11320'
};
