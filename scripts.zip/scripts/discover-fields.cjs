const https = require('https');
const path = require('path');
const fs = require('fs');

// Load .env file
function loadEnv() {
    const envPath = path.join(__dirname, '..', '.env');
    if (!fs.existsSync(envPath)) return {};

    const envFile = fs.readFileSync(envPath, 'utf-8');
    const envVars = {};

    envFile.split('\n').forEach(line => {
        line = line.trim();
        if (!line || line.startsWith('#')) return;
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) {
            const key = match[1].trim();
            let value = match[2].trim().replace(/^["']|["']$/g, '');
            envVars[key] = value;
        }
    });
    return envVars;
}

const env = loadEnv();

const jiraBaseUrl = env.JIRA_BASE_URL || 'https://jira.se.com';
const jiraUsername = env.JIRA_USERNAME;
const jiraApiToken = env.JIRA_API_TOKEN;

function makeRequest(url, options) {
    return new Promise((resolve, reject) => {
        const req = https.request(url, options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                    try {
                        resolve(JSON.parse(data));
                    } catch (e) {
                        resolve(data);
                    }
                } else {
                    reject(new Error(`Request failed: ${res.statusCode}\n${data}`));
                }
            });
        });
        req.on('error', reject);
        req.end();
    });
}

async function discoverFields() {
    console.log('🔍 Discovering Jira Fields for CN Project...\n');
    
    try {
        const url = `${jiraBaseUrl}/rest/api/2/field`;
        const options = {
            method: 'GET',
            headers: {
                'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
                'Accept': 'application/json'
            },
            rejectUnauthorized: false
        };
        
        const fields = await makeRequest(url, options);
        
        console.log(`📊 Total fields found: ${fields.length}\n`);
        
        // Filter custom fields
        const customFields = fields.filter(f => f.custom);
        console.log(`📋 Custom fields: ${customFields.length}\n`);
        
        // Look for test-related fields
        console.log('🔎 Searching for Test Details / Test Steps fields:\n');
        
        const testFields = fields.filter(f => {
            const name = f.name?.toLowerCase() || '';
            return name.includes('test') || name.includes('step') || name.includes('xray') || name.includes('manual');
        });
        
        if (testFields.length > 0) {
            console.log('✅ Found test-related fields:\n');
            testFields.forEach(field => {
                console.log(`  - ${field.id}: ${field.name}`);
                if (field.schema) {
                    console.log(`    Schema: ${JSON.stringify(field.schema)}`);
                }
            });
        } else {
            console.log('❌ No test-related fields found\n');
        }
        
        console.log('\n📝 All custom fields:');
        customFields.slice(0, 20).forEach(field => {
            console.log(`  - ${field.id}: ${field.name}`);
        });
        
        if (customFields.length > 20) {
            console.log(`  ... and ${customFields.length - 20} more`);
        }
        
    } catch (error) {
        console.error('❌ Error:', error.message);
    }
}

discoverFields();
