const https = require('https');
const fs = require('fs');
const path = require('path');

// Load project configuration
function loadConfig() {
    const configPath = path.join(__dirname, 'config.js');
    if (!fs.existsSync(configPath)) {
        console.error('\n❌ Configuration Error:');
        console.error('   config.js not found in scripts/ folder');
        console.error('\n📝 Setup Instructions:');
        console.error('   1. Copy config.example.js to config.js');
        console.error('      cd scripts && cp config.example.js config.js');
        console.error('   2. Edit config.js and set your Xray folder name');
        console.error('   3. Example: xrayFolderName: "ciamAutomation"');
        console.error('\n   See scripts/README.md for full setup guide\n');
        process.exit(1);
    }
    return require(configPath);
}

const config = loadConfig();

// Load .env file
function loadEnv() {
    const envPath = path.join(__dirname, '..', '.env');
    if (!fs.existsSync(envPath)) return {};
    const envFile = fs.readFileSync(envPath, 'utf-8');
    const envVars = {};
    envFile.split('\n').forEach(line => {
        line = line.trim();
        if (!line || line.startsWith('#')) return;
        const eqIndex = line.indexOf('=');
        if (eqIndex === -1) return;
        const key = line.substring(0, eqIndex).trim();
        const value = line.substring(eqIndex + 1).trim().replace(/^["']|["']$/g, '');
        envVars[key] = value;
    });
    return envVars;
}

const env = loadEnv();
const jiraBaseUrl = env.JIRA_BASE_URL || 'https://jira.se.com';
const xrayBaseUrl = `${jiraBaseUrl}${env.XRAY_API_PATH || '/rest/raven/2.0/api'}`;
const jiraUsername = env.JIRA_USERNAME;
const jiraApiToken = env.JIRA_API_TOKEN;

// Utility function for HTTPS requests
function makeRequest(url, options) {
    return new Promise((resolve, reject) => {
        const req = https.request(url, options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                    try {
                        resolve(JSON.parse(data));
                    } catch (e) {
                        resolve(data);
                    }
                } else {
                    reject(new Error(`Request failed: ${res.statusCode} ${res.statusMessage}\n${data}`));
                }
            });
        });
        req.on('error', reject);
        if (options.body) req.write(options.body);
        req.end();
    });
}

// Parse CSV with proper handling of quoted fields
function parseCSV(filePath) {
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n').filter(line => line.trim());

    // Parse headers
    const headers = [];
    let currentHeader = '';
    let insideQuotes = false;

    for (let i = 0; i < lines[0].length; i++) {
        const char = lines[0][i];
        if (char === '"') {
            insideQuotes = !insideQuotes;
        } else if (char === ',' && !insideQuotes) {
            headers.push(currentHeader.trim());
            currentHeader = '';
        } else {
            currentHeader += char;
        }
    }
    headers.push(currentHeader.trim());

    // Parse data rows
    return lines.slice(1).map(line => {
        const values = [];
        let currentValue = '';
        let insideQuotes = false;

        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            if (char === '"') {
                insideQuotes = !insideQuotes;
            } else if (char === ',' && !insideQuotes) {
                values.push(currentValue.trim());
                currentValue = '';
            } else {
                currentValue += char;
            }
        }
        values.push(currentValue.trim());

        const row = {};
        headers.forEach((header, index) => {
            row[header] = values[index] || '';
        });
        return row;
    });
}

// Get custom fields for Test issue type
async function getTestFieldMetadata(projectKey) {
    const url = `${jiraBaseUrl}/rest/api/2/issue/createmeta?projectKeys=${projectKey}&issuetypeNames=Test&expand=projects.issuetypes.fields`;
    const options = {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Accept': 'application/json'
        },
        rejectUnauthorized: false
    };
    return await makeRequest(url, options);
}

// Get all fields in Jira
async function getAllFields() {
    const url = `${jiraBaseUrl}/rest/api/2/field`;
    const options = {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Accept': 'application/json'
        },
        rejectUnauthorized: false
    };
    return await makeRequest(url, options);
}

// Create Jira issue
async function createJiraIssue(issueData) {
    const url = `${jiraBaseUrl}/rest/api/2/issue`;
    const options = {
        method: 'POST',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(issueData)
    };
    return await makeRequest(url, options);
}

// Link test to story
async function linkIssues(testKey, storyKey) {
    const url = `${jiraBaseUrl}/rest/api/2/issueLink`;
    const linkData = {
        type: { name: 'Tests' },
        inwardIssue: { key: testKey },
        outwardIssue: { key: storyKey }
    };
    const options = {
        method: 'POST',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(linkData)
    };
    await makeRequest(url, options);
}

// Search for existing test issues by summary in a project
async function findExistingTest(projectKey, summary) {
    const jql = encodeURIComponent(`project = "${projectKey}" AND issuetype = Test AND summary ~ "${summary.replace(/"/g, '\\"')}"`);
    const url = `${jiraBaseUrl}/rest/api/2/search?jql=${jql}&fields=summary,key&maxResults=5`;
    const options = {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Accept': 'application/json'
        },
        rejectUnauthorized: false
    };
    const result = await makeRequest(url, options);
    // Exact match on summary
    return (result.issues || []).find(i => i.fields.summary === summary) || null;
}

// Get Xray folder tree
async function getFolderTree(projectKey) {
    const url = `${xrayBaseUrl}/testrepository/${projectKey}/folders`;
    const options = {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Accept': 'application/json'
        }
    };
    return await makeRequest(url, options);
}

// Find Xray folder by configured name
async function findXrayFolder(projectKey) {
    const folderName = config.xrayFolderName || 'ciamAutomation';
    const tree = await getFolderTree(projectKey);
    const folder = tree.folders.find((f) => f.name === folderName);
    if (!folder) {
        console.error(`\n❌ Xray Folder Not Found: '${folderName}'`);
        console.error('\n📝 Available folders in Xray Test Repository:');
        tree.folders.forEach(f => console.error(`   - ${f.name}`));
        console.error('\n💡 Fix: Update xrayFolderName in scripts/config.js\n');
        throw new Error(`Folder '${folderName}' not found in Xray Test Repository`);
    }
    return folder.id;
}

// Find module folder by name (legacy - kept for backward compatibility)
async function findModuleFolder(projectKey, moduleName) {
    const tree = await getFolderTree(projectKey);
    const topFolder = tree.folders.find((f) => f.name === 'Test Repository');
    if (!topFolder) throw new Error("Top-level folder 'Test Repository' not found");
    const subfolder = (topFolder.folders || []).find((sf) => sf.name.toLowerCase() === moduleName.toLowerCase());
    if (!subfolder) throw new Error(`Module folder '${moduleName}' not found`);
    return subfolder.id;
}

// Add test to Xray folder
async function addTestToFolder(projectKey, testIssueKey, folderId) {
    const url = `${xrayBaseUrl}/testrepository/${projectKey}/folders/${folderId}/tests`;
    const payload = {
        add: [testIssueKey]
    };
    const options = {
        method: 'PUT',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
    };
    await makeRequest(url, options);
}

// Main orchestration function
async function orchestrateJiraXrayImport(config) {
    const {
        csvFilePath,
        testStepsFilePath,
        projectKey,
        storyKey,
        moduleName
    } = config;

    console.log('='.repeat(70));
    console.log('JIRA + XRAY AUTOMATED IMPORT ORCHESTRATOR');
    console.log('='.repeat(70));
    console.log(`\n📋 Configuration:`);
    console.log(`   CSV File: ${csvFilePath}`);
    console.log(`   Test Steps: ${testStepsFilePath}`);
    console.log(`   Project: ${projectKey}`);
    console.log(`   Story: ${storyKey}`);
    console.log(`   Module: ${moduleName}\n`);

    const results = {
        created: [],
        linked: [],
        organized: [],
        errors: []
    };

    try {
        // Step 1: Parse CSV
        console.log('📖 Step 1: Parsing CSV file...');
        const testCases = parseCSV(csvFilePath);
        console.log(`   ✓ Found ${testCases.length} test cases\n`);

        // Step 2: Use known Xray Manual Test Steps field
        console.log('🔍 Step 2: Using Xray Manual Test Steps field...');
        const testDetailsFieldId = 'customfield_11320'; // Manual Test Steps (Xray)
        console.log(`   ✓ Using field: ${testDetailsFieldId} (Manual Test Steps)\n`);

        // Step 3: Create Jira test issues
        console.log('🔨 Step 3: Creating Jira test issues...');
        for (const testCase of testCases) {
            try {
                // Use summary as-is from CSV
                const summary = testCase.Summary;

                // Check if test already exists (avoid duplicates on re-run)
                const existing = await findExistingTest(projectKey, summary);
                if (existing) {
                    console.log(`   ⏭ Skipped (already exists): ${existing.key} - ${summary}`);
                    results.created.push(existing.key);
                    results.linked.push(existing.key);
                    continue;
                }

                // Build issue data with required fields
                const issueData = {
                    fields: {
                        project: { key: projectKey },
                        summary: summary,
                        issuetype: { name: 'Test' }
                    }
                };

                // Add labels if present in CSV
                if (testCase.Labels) {
                    const labelsArray = testCase.Labels.split(',').map(l => l.trim());
                    issueData.fields.labels = labelsArray;
                }

                // Set priority to Medium for all test cases
                issueData.fields.priority = { name: 'Medium' };

                // Add test details using configured field ID
                const fieldId = config.testStepsFieldId || testDetailsFieldId || 'customfield_11320';
                if (fieldId) {
                    const testSteps = testCase['Test Steps'] || '';
                    const expectedResult = testCase['Expected Result'] || '';
                    
                    if (testSteps) {
                        const formattedSteps = testSteps.replace(/\\n/g, '\n');
                        issueData.fields[fieldId] = {
                            steps: [{
                                index: 1,
                                fields: {
                                    "Action": formattedSteps,
                                    "Data": "",
                                    "Expected Result": expectedResult
                                }
                            }]
                        };
                    }
                }

                let createdIssue;
                createdIssue = await createJiraIssue(issueData);
                const testKey = createdIssue.key;
                results.created.push(testKey);
                console.log(`   ✓ Created: ${testKey} - ${testCase.Summary}`);

                // Step 4: Link to story
                await linkIssues(testKey, storyKey);
                results.linked.push(testKey);
                console.log(`   ✓ Linked ${testKey} to ${storyKey}`);

            } catch (error) {
                results.errors.push({ testCase: testCase.Summary, error: error.message });
                console.error(`   ✗ Failed to create ${testCase.Summary}: ${error.message}`);
            }
        }

        // Step 5: Find Xray folder
        const folderName = config.xrayFolderName || 'ciamAutomation';
        console.log(`\n🗂️  Step 4: Finding Xray folder '${folderName}'...`);
        const folderId = await findXrayFolder(projectKey);
        console.log(`   ✓ Found '${folderName}' folder (id: ${folderId})\n`);

        // Step 6: Add tests to Xray folder
        console.log('📁 Step 5: Adding tests to Xray folder...');
        for (const testKey of results.created) {
            try {
                await addTestToFolder(projectKey, testKey, folderId.toString());
                results.organized.push(testKey);
                console.log(`   ✓ Added ${testKey} to ${folderName} folder`);
            } catch (error) {
                results.errors.push({ testCase: testKey, error: error.message });
                console.error(`   ✗ Failed to add ${testKey} to folder: ${error.message}`);
            }
        }

        // Summary
        console.log('\n' + '='.repeat(70));
        console.log('✅ IMPORT COMPLETED');
        console.log('='.repeat(70));
        console.log(`\n📊 Summary:`);
        console.log(`   ✓ Test cases created: ${results.created.length}`);
        console.log(`   ✓ Test cases linked: ${results.linked.length}`);
        console.log(`   ✓ Test cases organized: ${results.organized.length}`);
        console.log(`   ✗ Errors: ${results.errors.length}`);

        if (results.errors.length > 0) {
            console.log(`\n⚠️  Errors encountered:`);
            results.errors.forEach((err, idx) => {
                console.log(`   ${idx + 1}. ${err.testCase}: ${err.error}`);
            });
        }

        console.log(`\n🔗 View in Jira:`);
        console.log(`   Story: ${jiraBaseUrl}/browse/${storyKey}`);
        console.log(`   Tests: ${results.created.join(', ')}`);
        console.log('\n');
        return results;

    } catch (error) {
        console.error('\n❌ Fatal error:', error.message);
        throw error;
    }
}

// CLI usage
if (require.main === module) {
    const args = process.argv.slice(2);

    if (args.length < 5) {
        console.log('Usage: node jira-xray-orchestrator.cjs <csvFile> <testStepsFile> <projectKey> <storyKey> <moduleName>');
        console.log('\nExample:');
        console.log('  node jira-xray-orchestrator.cjs \\');
        console.log('    test-cases/<STORY-ID>_Test_Cases_Jira_Import.csv \\');
        console.log('    test-cases/<STORY-ID>_Test_Steps.md \\');
        console.log('    <PROJECT-KEY> \\');
        console.log('    <STORY-ID> \\');
        console.log('    <MODULE-NAME>');
        console.log('\n  Example with actual values:');
        console.log('    node jira-xray-orchestrator.cjs \\');
        console.log('      test-cases/MSWDCM-12320_Test_Cases_Jira_Import.csv \\');
        console.log('      test-cases/MSWDCM-12320_Test_Steps.md \\');
        console.log('      MSWDCM \\');
        console.log('      MSWDCM-12320 \\');
        console.log('      Programs');
        process.exit(1);
    }

    const config = {
        csvFilePath: args[0],
        testStepsFilePath: args[1],
        projectKey: args[2],
        storyKey: args[3],
        moduleName: args[4]
    };

    orchestrateJiraXrayImport(config)
        .then(results => {
            process.exit(results.errors.length > 0 ? 1 : 0);
        })
        .catch(error => {
            console.error('Fatal error:', error);
            process.exit(1);
        });
}

module.exports = { orchestrateJiraXrayImport };
