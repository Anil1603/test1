# Scripts Directory

This directory contains utility scripts for the test automation workflow.

## Workflow Scripts

### `test-integration-workflow.sh`
**Purpose:** Demonstrates the complete multi-agent workflow from Explorer to Test Execution.

**Usage:**
```bash
./test-integration-workflow.sh <STORY_ID> <BASE_URL> <HEALING_STRATEGY> <RUN_TESTS>

# Examples:
./test-integration-workflow.sh SF-02 https://test.salesforce.com standard yes
./test-integration-workflow.sh AP-1 https://app.example.com aggressive no
```

**What it does:**
1. Runs Explorer Agent pre-exploration hook
2. Verifies Explorer artifacts (locators, snapshots)
3. Runs Generator Agent pre-generation hook (builds locator strategies)
4. Validates generated locator modules
5. Checks Page Objects and test specs
6. Runs TypeScript and ESLint validation
7. Optionally runs Playwright tests

**When to use:**
- Testing the complete workflow end-to-end
- Onboarding new team members
- Debugging integration issues
- CI/CD pipeline testing

---

### `manual-locator-generation.sh`
**Purpose:** Manually regenerate self-healing locator modules from Explorer artifacts.

**Usage:**
```bash
./manual-locator-generation.sh <STORY_ID> <HEALING_STRATEGY>

# Examples:
./manual-locator-generation.sh SF-02 standard
./manual-locator-generation.sh AP-1 aggressive
```

**What it does:**
1. Verifies Explorer artifacts exist
2. Converts Explorer JSON to TypeScript locator modules
3. Builds self-healing strategies with confidence scoring
4. Validates generated TypeScript files
5. Runs ESLint and TypeScript compilation checks

**When to use:**
- Explorer artifacts already exist but locators need regeneration
- After modifying locator strategy configuration
- Testing different healing strategies
- UI has changed and locators need updating

---

### `diagnose-explorer-artifacts.sh`
**Purpose:** Analyzes Explorer Agent output and identifies issues.

**Usage:**
```bash
./diagnose-explorer-artifacts.sh <STORY_ID>

# Example:
./diagnose-explorer-artifacts.sh SF-02
```

**What it does:**
1. Checks locator manifest existence
2. Validates JSON syntax
3. Analyzes page coverage
4. Checks element quality (detects duplicate login pages)
5. Verifies expected form fields are present
6. Validates DOM snapshots
7. Checks handoff data
8. Provides actionable recommendations

**When to use:**
- Explorer artifacts seem incomplete
- Locator generation fails
- Debugging why page elements are missing
- Before running manual locator generation

**Common Issues Detected:**
- Incomplete artifacts (missing form fields)
- Duplicate login pages (authentication issues)
- Missing DOM snapshots
- Invalid JSON syntax

---

## Agent Scripts

### `agents/generator/locator-strategy-builder.ts`
**Purpose:** Core script that generates self-healing locator strategies with confidence scoring.

**Usage:**
```bash
npx tsx scripts/agents/generator/locator-strategy-builder.ts \
  --story SF-02 \
  --healing-strategy standard \
  --format both \
  --min-confidence 0.5 \
  --max-fallbacks 3
```

**Options:**
- `--story`: Story/Issue ID (required)
- `--output-dir`: Output directory (default: tests/helpers/locators)
- `--dom-analysis`: DOM analysis directory (default: dom-analysis)
- `--format`: Output format: typescript | json | both (default: both)
- `--min-confidence`: Minimum confidence threshold (default: 0.5)
- `--max-fallbacks`: Maximum fallback locators per element (default: 3)
- `--healing-strategy`: Strategy: aggressive | standard | conservative (default: standard)

**Invoked by:**
- Generator Agent pre-generation hook
- `manual-locator-generation.sh` script
- `test-integration-workflow.sh` script

---

## Utility Scripts

### `utils/convert-explorer-artifacts.ts`
**Purpose:** Converts Explorer Agent JSON artifacts to TypeScript locator modules.

**Usage:**
```bash
npx tsx scripts/utils/convert-explorer-artifacts.ts \
  --story SF-02 \
  --input-dir dom-analysis \
  --output-dir tests/helpers/locators
```

**What it does:**
1. Reads Explorer JSON manifest
2. Parses element data (tag, type, locator, confidence)
3. Generates TypeScript locator modules per page
4. Uses `createLocatorResolver` pattern from self-healing utility

**Note:** This is typically invoked automatically by `locator-strategy-builder.ts`, not run directly.

---

## Hook Scripts

Hook scripts are located in `.github/hooks/scripts/` and are invoked by agent-hooks.json configuration.

### `.github/hooks/scripts/planner-pre-planning.sh`
- Runs before Planner Agent generates test cases
- Checks RAG server availability
- Creates output directories
- Verifies user story exists

### `.github/hooks/scripts/explorer-pre-exploration.sh`
- Runs before Explorer Agent analyzes DOM
- Loads handoff data from Planner Agent
- Creates output directories
- Verifies test cases file exists

### `.github/hooks/scripts/generator-pre-generation.sh`
- Runs before Generator Agent creates test code
- Loads handoff data from Explorer Agent
- Invokes locator-strategy-builder.ts
- Validates generated locator modules
- Checks TypeScript compilation

---

## Quick Reference

| Task | Command |
|------|---------|
| Test complete workflow | `./test-integration-workflow.sh SF-02` |
| Regenerate locators | `./manual-locator-generation.sh SF-02` |
| Diagnose Explorer issues | `./diagnose-explorer-artifacts.sh SF-02` |
| Build locator strategies | `npx tsx scripts/agents/generator/locator-strategy-builder.ts --story SF-02` |
| Convert Explorer JSON | `npx tsx scripts/utils/convert-explorer-artifacts.ts --story SF-02` |

---

## Troubleshooting

### Scripts won't execute
```bash
# Make scripts executable
chmod +x scripts/*.sh
chmod +x .github/hooks/scripts/*.sh
```

### jq command not found
```bash
# Install jq (JSON processor)
# macOS:
brew install jq

# Ubuntu/Debian:
sudo apt-get install jq

# Windows (WSL):
sudo apt-get install jq
```

### bc command not found
```bash
# Install bc (calculator for shell scripts)
# macOS:
brew install bc

# Ubuntu/Debian:
sudo apt-get install bc
```

### TypeScript compilation errors
```bash
# Verify Node.js version
node --version  # Should be 18+

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install

# Run TypeScript check
npx tsc --noEmit
```

---

## Best Practices

1. **Always run diagnostics first**
   ```bash
   ./scripts/diagnose-explorer-artifacts.sh SF-02
   ```

2. **Use standard healing strategy unless needed**
   ```bash
   ./scripts/manual-locator-generation.sh SF-02 standard
   ```

3. **Test workflow before committing**
   ```bash
   ./scripts/test-integration-workflow.sh SF-02 <URL> standard no
   ```

4. **Monitor script output for warnings**
   - Low confidence warnings
   - Fallback usage warnings
   - TypeScript/ESLint errors

5. **Keep scripts executable**
   ```bash
   git update-index --chmod=+x scripts/*.sh
   git commit -m "Make scripts executable"
   ```

---

## Related Documentation

- [INTEGRATION-WORKFLOW.md](../docs/INTEGRATION-WORKFLOW.md) - Complete workflow guide
- [LOCATOR-INTEGRATION.md](../docs/LOCATOR-INTEGRATION.md) - Locator integration details
- [ARCHITECTURE.md](../docs/ARCHITECTURE.md) - System architecture
- [agent-hooks.json](../.github/hooks/agent-hooks.json) - Hook configuration

---

**Version:** 1.0  
**Last Updated:** February 12, 2026
