/**
 * Planner Agent Integration for JIRA + XRAY Automation
 * 
 * This module provides a simple interface for the planner agent to:
 * 1. Upload test cases to Jira
 * 2. Link them to the user story
 * 3. Organize them in Xray Test Repository
 * 
 * All in one seamless call.
 */

const { orchestrateJiraXrayImport } = require('./jira-xray-orchestrator.cjs');
const path = require('path');
const fs = require('fs');

/**
 * Main function that planner agent should call after generating test cases
 * 
 * @param {Object} params - Configuration parameters
 * @param {string} params.storyId - User story ID (e.g., 'MSWDCM-12320')
 * @param {string} params.moduleName - Module name for Xray folder (e.g., 'Programs', 'Rewards', 'Trainings')
 * @param {string} [params.csvFileName] - Optional CSV filename, defaults to {storyId}_Test_Cases_Jira_Import.csv
 * @param {string} [params.testStepsFileName] - Optional test steps filename, defaults to {storyId}_Test_Steps.md
 * @param {string} [params.projectKey] - Optional project key, defaults to 'MSWDCM'
 * 
 * @returns {Promise<Object>} Results object with created, linked, and organized test keys
 * 
 * @example
 * // Basic usage with defaults
 * const results = await uploadTestCasesToJiraAndXray({
 *   storyId: 'MSWDCM-12320',
 *   moduleName: 'Programs'
 * });
 * 
 * @example
 * // Custom file names
 * const results = await uploadTestCasesToJiraAndXray({
 *   storyId: 'MSWDCM-12320',
 *   moduleName: 'Programs',
 *   csvFileName: 'custom-test-cases.csv',
 *   testStepsFileName: 'custom-test-steps.json'
 * });
 */
async function uploadTestCasesToJiraAndXray(params) {
    const {
        storyId,
        moduleName,
        csvFileName,
        testStepsFileName,
        projectKey
    } = params;

    // Validate required parameters
    if (!storyId) {
        throw new Error('storyId is required (e.g., CN-3059)');
    }
    
    // Extract project key from story ID if not provided
    const actualProjectKey = projectKey || storyId.split('-')[0];

    // Build file paths
    const baseDir = path.join(__dirname, '..');
    const testCasesDir = path.join(baseDir, 'test-cases');

    const csvFile = csvFileName || `${storyId}_Test_Cases_Jira_Import.csv`;
    const testStepsFile = testStepsFileName || `${storyId}_Test_Steps.md`;

    const csvFilePath = path.join(testCasesDir, csvFile);
    const testStepsFilePath = path.join(testCasesDir, testStepsFile);

    // Validate required CSV file exists
    if (!fs.existsSync(csvFilePath)) {
        throw new Error(`CSV file not found: ${csvFilePath}`);
    }

    console.log(`📄 CSV File: ${csvFilePath}`);
    if (fs.existsSync(testStepsFilePath)) {
        console.log(`📄 Test Steps File: ${testStepsFilePath} (optional - CSV contains all test details)`);
    } else {
        console.log(`ℹ️  Test Steps File not found (using test details from CSV instead)`);
    }

    // Configuration for orchestrator
    const config = {
        csvFilePath,
        testStepsFilePath,
        projectKey: actualProjectKey,
        storyKey: storyId,
        moduleName: moduleName || 'Tests'
    };

    console.log('🤖 Planner Agent: Initiating automated Jira + Xray import...\n');

    // Execute orchestration
    const results = await orchestrateJiraXrayImport(config);

    console.log('🤖 Planner Agent: Import completed successfully!\n');

    return results;
}

/**
 * Map user story to module name
 * Helper function to automatically determine module from story
 */
function getModuleFromStory(storyContent) {
    const storyLower = storyContent.toLowerCase();

    if (storyLower.includes('program') || storyLower.includes('enrollment')) return 'Programs';
    if (storyLower.includes('reward') || storyLower.includes('points')) return 'Rewards';
    if (storyLower.includes('training') || storyLower.includes('course')) return 'Trainings';
    if (storyLower.includes('opportunity') || storyLower.includes('lead')) return 'Opportunities';
    if (storyLower.includes('document') || storyLower.includes('file')) return 'Account Documents';
    if (storyLower.includes('topic') || storyLower.includes('content')) return 'Topics for you';

    // Default to Programs if can't determine
    return 'Programs';
}

// CLI usage
if (require.main === module) {
    const args = process.argv.slice(2);

    if (args.length < 1) {
        console.log('Planner Agent Integration - JIRA + XRAY Automation');
        console.log('='.repeat(50));
        console.log('\nUsage: node jira-test-uploader.cjs <storyId> [moduleName] [csvFile] [testStepsFile]');
        console.log('\nExamples:');
        console.log('  # Basic usage (uses default file names, no module):');
        console.log('  node jira-test-uploader.cjs CN-3059');
        console.log('');
        console.log('  # With module name:');
        console.log('  node jira-test-uploader.cjs CN-3059 MFA');
        console.log('');
        console.log('  # With custom files:');
        console.log('  node jira-test-uploader.cjs CN-3059 MFA custom.csv custom-steps.json');
        process.exit(1);
    }

    const params = {
        storyId: args[0],
        moduleName: args[1],
        csvFileName: args[2],
        testStepsFileName: args[3]
    };

    uploadTestCasesToJiraAndXray(params)
        .then(results => {
            console.log('✅ All done! Test cases are ready in Jira and Xray.');
            process.exit(results.errors.length > 0 ? 1 : 0);
        })
        .catch(error => {
            console.error('❌ Error:', error.message);
            process.exit(1);
        });
}

module.exports = {
    uploadTestCasesToJiraAndXray,
    getModuleFromStory
};
