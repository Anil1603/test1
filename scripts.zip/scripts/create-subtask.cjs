const https = require('https');
const fs = require('fs');
const path = require('path');

// Load .env file
function loadEnv() {
    const envPath = path.join(__dirname, '..', '.env');
    if (!fs.existsSync(envPath)) return {};
    const envFile = fs.readFileSync(envPath, 'utf-8');
    const envVars = {};
    envFile.split('\n').forEach(line => {
        line = line.trim();
        if (!line || line.startsWith('#')) return;
        const eqIndex = line.indexOf('=');
        if (eqIndex === -1) return;
        const key = line.substring(0, eqIndex).trim();
        const value = line.substring(eqIndex + 1).trim().replace(/^["']|["']$/g, '');
        envVars[key] = value;
    });
    return envVars;
}

const env = loadEnv();
const jiraBaseUrl = env.JIRA_BASE_URL || 'https://jira.se.com';
const jiraUsername = env.JIRA_USERNAME;
const jiraApiToken = env.JIRA_API_TOKEN;

function makeRequest(url, options) {
    return new Promise((resolve, reject) => {
        const req = https.request(url, options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                    try {
                        resolve(JSON.parse(data));
                    } catch (e) {
                        resolve(data);
                    }
                } else {
                    reject(new Error(`Request failed: ${res.statusCode} ${res.statusMessage}\n${data}`));
                }
            });
        });
        req.on('error', reject);
        if (options.body) req.write(options.body);
        req.end();
    });
}

async function createSubTask(parentKey, summary, description) {
    const projectKey = parentKey.split('-')[0];

    const issueData = {
        fields: {
            project: { key: projectKey },
            parent: { key: parentKey },
            summary: summary,
            description: description || '',
            issuetype: { name: 'Sub-task' }
        }
    };

    const url = `${jiraBaseUrl}/rest/api/2/issue`;
    const options = {
        method: 'POST',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${jiraUsername}:${jiraApiToken}`).toString('base64'),
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(issueData),
        rejectUnauthorized: false
    };

    return await makeRequest(url, options);
}

async function main() {
    const parentKey = process.argv[2] || 'BFOFS-12159';
    const summary = process.argv[3] || 'Prepare test cases for this user story BFOFS-12159';
    const description = `Prepare and document all test cases for user story ${parentKey}: Work Detail's IPSerialCapture__c ISCHANGED.\n\nThis sub-task covers:\n- Test case design (positive, negative, edge cases)\n- Test steps extraction for Playwright automation\n- Test data creation\n- Jira/Xray import CSV generation`;

    console.log(`\n🔧 Creating sub-task for ${parentKey}...`);
    console.log(`   Summary: "${summary}"`);
    console.log(`   Jira URL: ${jiraBaseUrl}`);

    if (!jiraUsername || !jiraApiToken) {
        console.error('\n❌ Missing Jira credentials in .env file.');
        console.error('   Required: JIRA_USERNAME, JIRA_API_TOKEN');
        process.exit(1);
    }

    try {
        const result = await createSubTask(parentKey, summary, description);
        console.log(`\n✅ Sub-task created successfully!`);
        console.log(`   Key:  ${result.key}`);
        console.log(`   URL:  ${jiraBaseUrl}/browse/${result.key}`);
    } catch (err) {
        console.error('\n❌ Failed to create sub-task:');
        console.error('  ', err.message);
        process.exit(1);
    }
}

main();
