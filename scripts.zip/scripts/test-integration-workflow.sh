#!/bin/bash
# Complete Agent Workflow Integration Script
# Demonstrates the full cycle: Explorer → Generator → Test Execution
# This script shows how all the hooks and utilities work together

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

# ============================================================================
# Configuration
# ============================================================================

STORY_ID=${1:-"SF-02"}
BASE_URL=${2:-"https://test.salesforce.com"}
HEALING_STRATEGY=${3:-"standard"}
RUN_TESTS=${4:-"no"}

echo -e "${CYAN}"
cat << "EOF"
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║     Test Automation Integration - Complete Workflow Demo        ║
║                                                                  ║
║  Phase 1: User Story Review (Manual)                            ║
║  Phase 2: Test Planning (Planner Agent + RAG)                   ║
║  Phase 3: DOM Analysis (Explorer Agent + Playwright MCP)        ║
║  Phase 4: Code Generation (Generator Agent + Locator Builder)   ║
║  Phase 5: Test Execution (Playwright + Self-Healing)            ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

echo -e "${YELLOW}Story ID:${NC} $STORY_ID"
echo -e "${YELLOW}Base URL:${NC} $BASE_URL"
echo -e "${YELLOW}Healing Strategy:${NC} $HEALING_STRATEGY"
echo -e "${YELLOW}Run Tests:${NC} $RUN_TESTS"
echo ""

read -p "Press Enter to continue or Ctrl+C to abort..."
echo ""

# ============================================================================
# Phase 3: Explorer Agent (DOM Analysis)
# ============================================================================

echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Phase 3: Explorer Agent - DOM Analysis                    ${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""

# Run pre-exploration hook
echo -e "${CYAN}[Hook] Running pre-exploration hook...${NC}"
if [ -f ".github/hooks/scripts/explorer-pre-exploration.sh" ]; then
  bash .github/hooks/scripts/explorer-pre-exploration.sh \
    --story "$STORY_ID" \
    --base-url "$BASE_URL"
  
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Pre-exploration hook completed${NC}"
  else
    echo -e "${RED}✗ Pre-exploration hook failed${NC}"
    exit 1
  fi
else
  echo -e "${YELLOW}⚠ Pre-exploration hook script not found (optional)${NC}"
fi
echo ""

# Check Explorer artifacts
echo -e "${CYAN}[Artifacts] Checking Explorer Agent output...${NC}"
LOCATORS_FILE="dom-analysis/locators/${STORY_ID}_locators.json"

if [ -f "$LOCATORS_FILE" ]; then
  echo -e "${GREEN}✓ Locator manifest exists: $LOCATORS_FILE${NC}"
  
  # Show statistics
  if command -v jq &> /dev/null; then
    PAGES=$(jq -r '.pages | length' "$LOCATORS_FILE")
    TOTAL_ELEMENTS=$(jq -r '[.pages[].elements | length] | add' "$LOCATORS_FILE")
    echo -e "  ${YELLOW}Pages:${NC} $PAGES"
    echo -e "  ${YELLOW}Total Elements:${NC} $TOTAL_ELEMENTS"
  fi
else
  echo -e "${RED}✗ Explorer artifacts missing${NC}"
  echo -e "${YELLOW}  Please run Explorer Agent first to generate DOM snapshots${NC}"
  echo -e "${YELLOW}  Expected file: $LOCATORS_FILE${NC}"
  exit 1
fi

# Check DOM snapshots
SNAPSHOT_COUNT=$(find dom-analysis/dom-snapshots -name "${STORY_ID}_*.json" 2>/dev/null | wc -l | tr -d ' ')
echo -e "${GREEN}✓ DOM snapshots: $SNAPSHOT_COUNT files${NC}"
echo ""

# ============================================================================
# Phase 4: Generator Agent - Part 1 (Locator Strategy Building)
# ============================================================================

echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Phase 4.1: Generator Pre-Hook - Locator Strategies        ${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""

# Run pre-generation hook
echo -e "${CYAN}[Hook] Running pre-generation hook...${NC}"
if [ -f ".github/hooks/scripts/generator-pre-generation.sh" ]; then
  bash .github/hooks/scripts/generator-pre-generation.sh \
    --story "$STORY_ID" \
    --healing-strategy "$HEALING_STRATEGY" \
    --min-confidence 0.5 \
    --max-fallbacks 3
  
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Pre-generation hook completed${NC}"
  else
    echo -e "${RED}✗ Pre-generation hook failed${NC}"
    exit 1
  fi
else
  echo -e "${YELLOW}⚠ Pre-generation hook script not found${NC}"
  echo -e "${YELLOW}  Running locator-strategy-builder manually...${NC}"
  
  npx tsx scripts/agents/generator/locator-strategy-builder.ts \
    --story "$STORY_ID" \
    --healing-strategy "$HEALING_STRATEGY" \
    --format both \
    --min-confidence 0.5 \
    --max-fallbacks 3
  
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Locator strategy builder completed${NC}"
  else
    echo -e "${RED}✗ Locator strategy builder failed${NC}"
    exit 1
  fi
fi
echo ""

# Verify generated locator modules
echo -e "${CYAN}[Artifacts] Checking generated locator modules...${NC}"
LOCATOR_MODULES=$(find tests/helpers/locators -name "${STORY_ID}-*-locators.ts" 2>/dev/null)

if [ -n "$LOCATOR_MODULES" ]; then
  MODULE_COUNT=$(echo "$LOCATOR_MODULES" | wc -l | tr -d ' ')
  echo -e "${GREEN}✓ Generated locator modules: $MODULE_COUNT files${NC}"
  echo "$LOCATOR_MODULES" | while read -r module; do
    echo -e "  - $(basename "$module")"
  done
else
  echo -e "${RED}✗ No locator modules generated${NC}"
  exit 1
fi

# Show manifest statistics
MANIFEST_FILE="tests/helpers/locators/${STORY_ID}-locator-manifest.json"
if [ -f "$MANIFEST_FILE" ]; then
  echo -e "${GREEN}✓ Locator manifest: $MANIFEST_FILE${NC}"
  
  if command -v jq &> /dev/null; then
    AVG_CONF=$(jq -r '.statistics.avgConfidence // 0' "$MANIFEST_FILE")
    HIGH_CONF=$(jq -r '.statistics.highConfidence // 0' "$MANIFEST_FILE")
    LOW_CONF=$(jq -r '.statistics.lowConfidence // 0' "$MANIFEST_FILE")
    
    echo -e "  ${YELLOW}Average Confidence:${NC} $AVG_CONF"
    echo -e "  ${YELLOW}High Confidence Elements:${NC} $HIGH_CONF"
    echo -e "  ${YELLOW}Low Confidence Elements:${NC} $LOW_CONF"
  fi
fi
echo ""

# ============================================================================
# Phase 4: Generator Agent - Part 2 (Page Objects & Specs)
# ============================================================================

echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Phase 4.2: Generator Agent - Code Generation              ${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "${CYAN}[Status] Checking Page Objects...${NC}"

# Check if page objects exist
PAGE_OBJECTS=$(find tests/pages -name "*.ts" 2>/dev/null | grep -v "base.page.ts" || true)

if [ -n "$PAGE_OBJECTS" ]; then
  PO_COUNT=$(echo "$PAGE_OBJECTS" | wc -l | tr -d ' ')
  echo -e "${GREEN}✓ Page Objects found: $PO_COUNT files${NC}"
  echo "$PAGE_OBJECTS" | while read -r po; do
    echo -e "  - $(basename "$po")"
  done
else
  echo -e "${YELLOW}⚠ No Page Objects found${NC}"
  echo -e "  Generator Agent should create these automatically"
fi
echo ""

# Check if specs exist
echo -e "${CYAN}[Status] Checking Test Specs...${NC}"
TEST_SPECS=$(find tests -name "*.spec.ts" 2>/dev/null || true)

if [ -n "$TEST_SPECS" ]; then
  SPEC_COUNT=$(echo "$TEST_SPECS" | wc -l | tr -d ' ')
  echo -e "${GREEN}✓ Test Specs found: $SPEC_COUNT files${NC}"
  echo "$TEST_SPECS" | while read -r spec; do
    echo -e "  - $(basename "$spec")"
  done
else
  echo -e "${YELLOW}⚠ No Test Specs found${NC}"
fi
echo ""

# ============================================================================
# Validation & Quality Checks
# ============================================================================

echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Validation & Quality Checks                               ${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""

# TypeScript compilation
echo -n "${CYAN}[Check 1/3]${NC} TypeScript compilation... "
npx tsc --noEmit > /tmp/integration-tsc-check.log 2>&1
if [ $? -eq 0 ]; then
  echo -e "${GREEN}✓ PASS${NC}"
else
  echo -e "${RED}✗ FAIL${NC}"
  echo -e "${YELLOW}  See /tmp/integration-tsc-check.log for details${NC}"
fi

# ESLint validation
echo -n "${CYAN}[Check 2/3]${NC} ESLint validation... "
npx eslint tests/**/*.ts --format json > /tmp/integration-eslint-check.json 2>&1
if [ $? -eq 0 ]; then
  echo -e "${GREEN}✓ PASS${NC}"
else
  if command -v jq &> /dev/null; then
    ERRORS=$(jq '[.[].errorCount] | add // 0' /tmp/integration-eslint-check.json)
    WARNINGS=$(jq '[.[].warningCount] | add // 0' /tmp/integration-eslint-check.json)
    echo -e "${YELLOW}⚠ $ERRORS errors, $WARNINGS warnings${NC}"
  else
    echo -e "${YELLOW}⚠ WARNINGS${NC}"
  fi
fi

# Locator coverage check
echo -n "${CYAN}[Check 3/3]${NC} Locator coverage... "
if [ -f "$MANIFEST_FILE" ] && command -v jq &> /dev/null; then
  AVG_CONF=$(jq -r '.statistics.avgConfidence // 0' "$MANIFEST_FILE")
  if (( $(echo "$AVG_CONF >= 0.6" | bc -l) )); then
    echo -e "${GREEN}✓ PASS${NC} (${AVG_CONF})"
  else
    echo -e "${YELLOW}⚠ LOW${NC} (${AVG_CONF})"
  fi
else
  echo -e "${YELLOW}⚠ SKIPPED${NC} (manifest not found)"
fi
echo ""

# ============================================================================
# Phase 5: Test Execution (Optional)
# ============================================================================

if [ "$RUN_TESTS" = "yes" ] || [ "$RUN_TESTS" = "y" ]; then
  echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
  echo -e "${BLUE}  Phase 5: Test Execution                                   ${NC}"
  echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
  echo ""
  
  echo -e "${CYAN}[Playwright] Running tests...${NC}"
  
  if [ -n "$TEST_SPECS" ]; then
    # Run first spec as a demo
    FIRST_SPEC=$(echo "$TEST_SPECS" | head -n 1)
    echo -e "${YELLOW}Running: $FIRST_SPEC${NC}"
    
    npx playwright test "$FIRST_SPEC" --reporter=list
    
    if [ $? -eq 0 ]; then
      echo -e "${GREEN}✓ Tests passed${NC}"
    else
      echo -e "${RED}✗ Tests failed${NC}"
      echo -e "${YELLOW}  Check playwright-report/ for details${NC}"
    fi
  else
    echo -e "${YELLOW}⚠ No test specs to run${NC}"
  fi
  echo ""
fi

# ============================================================================
# Summary & Next Steps
# ============================================================================

echo -e "${GREEN}"
cat << "EOF"
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║              Integration Workflow Completed!                     ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

echo -e "${CYAN}Generated Artifacts:${NC}"
echo -e "  ${YELLOW}├─${NC} dom-analysis/locators/${STORY_ID}_locators.json"
echo -e "  ${YELLOW}├─${NC} tests/helpers/locators/${STORY_ID}-*-locators.ts"
echo -e "  ${YELLOW}├─${NC} tests/pages/*.ts"
echo -e "  ${YELLOW}└─${NC} tests/*.spec.ts"
echo ""

echo -e "${CYAN}Next Steps:${NC}"
echo -e "  ${YELLOW}1.${NC} Review generated locator strategies"
echo -e "  ${YELLOW}2.${NC} Update Page Objects to use generated locators"
echo -e "  ${YELLOW}3.${NC} Run tests: ${GREEN}npx playwright test${NC}"
echo -e "  ${YELLOW}4.${NC} Monitor self-healing warnings in test output"
echo -e "  ${YELLOW}5.${NC} Iterate on locator strategies based on results"
echo ""

echo -e "${CYAN}Documentation:${NC}"
echo -e "  ${YELLOW}●${NC} docs/LOCATOR-INTEGRATION.md - Integration guide"
echo -e "  ${YELLOW}●${NC} docs/ARCHITECTURE.md - System architecture"
echo -e "  ${YELLOW}●${NC} docs/README.md - Quick reference"
echo ""

exit 0
