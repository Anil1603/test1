import {Page} from "@playwright/test";
import playwrightBase from "../utils/base/playWrightBase";

export default class opportunityPage extends playwrightBase {
    constructor(page: Page){
         super(page)
    }
}