 /*
 * @author Vivek
 * 
 * lead page
 * this file is used to store the functions related to lead page
 * we can include all the functions related to lead page in this file and 
 * we can call these functions in the test files
 * 
 */

import { expect, Locator, Page } from "@playwright/test";
import playwrightBase from "../utils/base/playWrightBase";
import leadPageLoc from "..//utils//pageLocators//leadPageLoc.json";



export default class leadPage extends playwrightBase{
    constructor(page: Page){
       super(page);
    }
    // this function is used to create lead and it takes the test data as parameter
      async leadCreation(data: any){
         await this.clickonButton(leadPageLoc.newLeadCreation);
         await this.enterText(leadPageLoc.firstName, data.firstName as string);
         await this.enterTextLastName(leadPageLoc.lastName, data.lastName as string);
         await this.enterText(leadPageLoc.phone, data.phone as string);
         await this.enterText(leadPageLoc.company, data.company as string);
         await this.selectFromDropdown("Opportunity Type",leadPageLoc.opportunityType, data.opportunityType as string);
         await this.selectFromDropdown("Opportunity Line Scope",leadPageLoc.opportunityLineScope, data.opportunityLineScope as string);
         await this.enterText(leadPageLoc.opportunityFinder, data.opportunityFinder as string); 
         await this.enterTextOnObject(leadPageLoc.suspectedValue, data.suspectedValue as number);
         await this.selectFromDropdown("Opportunity Source",leadPageLoc.opportunitySource, data.opportunitySource as string);
         await this.enterText(leadPageLoc.street, data.street as string);
         await this.enterText(leadPageLoc.city, data.city as string);
         await this.enterText(leadPageLoc.zipCode, data.zipCode as string);
         await this.selectFromDropdown("Leading Business",leadPageLoc.leadingBusiness, data.leadingBusiness as string);
         await this.selectCountry(data.country as string);
         await this.scrolldown(leadPageLoc.contactRole);
         await this.selectFromOption(leadPageLoc.contactRole, data.contactRole as string);
         await this.clickonButton(leadPageLoc.saveLeadCreation);
         return await this.getCreatedLeadName();
     }
   //this function helps to select country from the country search box
   // we can pass the country name as parameter and it will select the country from the search box
     async selectCountry(data: string){
      
        const element : Locator  = await this.waitForElementLoad(leadPageLoc.country);
        await element.click();
        await element.pressSequentially(data);
       
        let countryLocator : string = "//lightning-base-combobox-formatted-text[@title='TITLE']"
        countryLocator = countryLocator.replace("TITLE",data);
         const demo : Locator =  await this.page.locator(countryLocator);
          await demo.click();      
     }

     // this fundtion helps to get the created lead name after lead creation and it will return the lead name
     async getCreatedLeadName(){
      await this.page.waitForTimeout(2000);
        await expect(this.page.locator(leadPageLoc.txtCreatedLead)).toBeVisible();
         const element : Locator  = await this.waitForElementLoad(leadPageLoc.txtCreatedLead);
         return await element.textContent() as string;
     }
     // this function helps to edit the project name and save the changes
     async editProjectName(data: string){
       await this.waitForElementLoad(leadPageLoc.editProjectName);
       await this.click(leadPageLoc.editProjectName);
       await this.enterText(leadPageLoc.projectName, data);
       await this.clickonButton(leadPageLoc.saveChanges);
     }
      // this function helps to click on the details tab in lead page
     async clickOnDetailsTab(){
        await this.click(leadPageLoc.detailTab);
     }

     //this function helps to create account
      async createAccount(data: any){
        await this.searchAccount(data.staticAddress as string);
        await this.page.waitForTimeout(3000);
        const strAccount :string = "LeadManagementMKTAccount" + Date.now()+Math.floor(Math.random() * 1000);
        await this.selectFromStaticDropdown(leadPageLoc.classificationLevel, data.classificationLevel as string);
        await this.enterAccountName(strAccount);
        await this.selectFromStaticDropdown(leadPageLoc.marketSegment, data.marketSegment as string);
        await this.selectFromStaticDropdown(leadPageLoc.marketSubSegment, data.marketSubSegment as string);
         await this.page.locator(leadPageLoc.saveAccContCreation).nth(1).click();
      }

      //this function helps to search the account
      async searchAccount(data: string){
         const element : Locator = await this.page.locator(leadPageLoc.searchPlaceholder).nth(1);
         await element.click();
          await element.pressSequentially(data);
         (await this.waitForElementLoad(leadPageLoc.staticAddress)).click();
      }

      //this function helps to select from classification level dropdown
       async editProjectNameAndLevel(data: string, classificationLevel: string){
         await this.waitForElementLoad(leadPageLoc.editProjectName);
       await this.click(leadPageLoc.editProjectName);
       await this.enterText(leadPageLoc.projectName, data);
        await this.selectFromOption(leadPageLoc.level1, classificationLevel);
        await this.clickonButton(leadPageLoc.saveChanges);
        await this.page.waitForTimeout(5000);
      }

      //this function helps to convert the lead to opportunity
      async convertLeadToOppty(data: any){ 
        await this.clickonButton(leadPageLoc.convert);
       // await this.waitForElementLoad(leadPageLoc.hdConvertLead);
        await this.switchToFrameAndEnterText(leadPageLoc.convertLeadIframe, leadPageLoc.opportunityLeader, data.opportunityOwner as string);
        await this.switchToFrameAndClick(leadPageLoc.convertLeadIframe, leadPageLoc.AccAndConCreate);
        await this.waitForElementLoad(leadPageLoc.hdContact);
        await this.waitForElementLoad(leadPageLoc.hdBusinessAccount);
        this.page.waitForTimeout(3000);
        await this.createAccount(data);
        try{
         await this.switchToFrameAndClick(leadPageLoc.convertLeadIframe, leadPageLoc.hdConvertLead);
        }catch(error){
          await this.clickonButton(leadPageLoc.confirmAndSave);
        }
          const elementConfirm : Locator = await this.page.locator(leadPageLoc.confirmConvert).nth(0);
         await this.switchToFrameAndClick(leadPageLoc.convertLeadIframe, elementConfirm as any);
         const element : Locator = await this.waitForElementLoad(leadPageLoc.createdOpptyName);

          return await element.textContent() as string;

}
       async enterAccountName(data: string){
        const element : Locator = await this.waitForElementLoad(leadPageLoc.textAccountName);
        await element.click();
        await element.fill(data);
       }
}